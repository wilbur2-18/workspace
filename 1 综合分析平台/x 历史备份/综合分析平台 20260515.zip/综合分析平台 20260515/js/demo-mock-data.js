    // 工作台与审计助手共用的资料 / 审计发现（结果）数据源
    function demoMakeProjectMaterials() {
      const tagPool = ['会议纪要', '银行流水', '合同', '发票', '总账明细', '审批单', '项目台账', '资金拨付表', '往来函证', '验收报告'];
      const uploaderPool = ['张审计', '李审计', '王审计', '系统导入'];
      const extByTag = {
        会议纪要: 'DOCX',
        银行流水: 'PDF',
        合同: 'PDF',
        发票: 'PDF',
        总账明细: 'XLSX',
        审批单: 'PDF',
        项目台账: 'XLSX',
        资金拨付表: 'XLSX',
        往来函证: 'PDF',
        验收报告: 'DOCX',
      };
      const list = [];
      const sortBucket = { __root: 0, mf001: 0, mf002: 0, mf003: 0, __abn: 0 };
      function nextSort(bucket) {
        sortBucket[bucket] = (sortBucket[bucket] || 0) + 1;
        return sortBucket[bucket];
      }
      for (let i = 1; i <= 35; i++) {
        const tag = tagPool[(i - 1) % tagPool.length];
        const format = extByTag[tag] || 'PDF';
        const seq = String(i).padStart(2, '0');
        const day = String((i % 28) + 1).padStart(2, '0');
        let status = 'done';
        let progress = 100;
        if (i % 9 === 0) {
          status = 'failed';
          progress = 100;
        } else if (i % 5 === 0) {
          status = 'parsing';
          progress = 25 + ((i * 7) % 70);
        } else if (i % 7 === 0) {
          status = 'queued';
          progress = 0;
        }
        let parentId = null;
        let sort = 0;
        if (status === 'done') {
          const b = i % 6;
          if (b === 0 || b === 1) {
            parentId = null;
            sort = nextSort('__root');
          } else if (b === 2 || b === 3) {
            parentId = 'mf-001';
            sort = nextSort('mf001');
          } else if (b === 4) {
            parentId = 'mf-002';
            sort = nextSort('mf002');
          } else {
            parentId = 'mf-003';
            sort = nextSort('mf003');
          }
        } else {
          parentId = null;
          sort = nextSort('__abn');
        }
        list.push({
          id: 'm-001-' + seq,
          name: `${tag}-资料-${seq}.${format.toLowerCase()}`,
          uploader: uploaderPool[(i - 1) % uploaderPool.length],
          size: Number((0.8 + (i * 0.65) % 16).toFixed(1)),
          format,
          status,
          progress,
          parentId,
          sort,
          uploadedAt: `2026-03-${day} ${String(8 + (i % 10)).padStart(2, '0')}:${String((i * 7) % 60).padStart(2, '0')}`,
        });
      }
      return list;
    }
    function demoMakeAnalysisResults() {
      /** 与 workbenchTaskDemoRows 中已完成任务 id 对齐；对话产出使用 resultTreeBucket: 'dialog' */
      return [
        {
          id: 'ar-001',
          name: '合同与发票一致性检查结果',
          format: 'MD',
          sourceTaskId: 'wb-task-01',
          sourceTaskName: '合同与发票专项核对',
          sourceSkillName: '施工合同与发票一致性核查',
          sourceMaterialIds: ['m-001-03', 'm-001-02', 'm-001-01'],
          createdAt: '2026-03-24 10:20',
          status: 'done',
          analysisMarkdownEditedBy: '王审计',
          analysisMarkdownEditedAt: '2026-03-24 14:30',
        },
        {
          id: 'ar-003',
          name: '付款节点与批复对照',
          format: 'MD',
          sourceTaskId: 'wb-task-02',
          sourceTaskName: '付款与验收追踪',
          sourceSkillName: '工程款节点支付合规核对',
          sourceMaterialIds: ['m-001-04', 'm-001-05'],
          createdAt: '2026-03-24 09:12',
          status: 'done',
        },
        {
          id: 'ar-007',
          name: '预算执行率分项汇总',
          format: 'MD',
          sourceTaskId: 'wb-task-03',
          sourceTaskName: '预算与对标分析',
          sourceSkillName: '预算执行率分项汇总（技能）',
          createdAt: '2026-03-22 18:30',
          status: 'done',
        },
        {
          id: 'ar-dlg-01',
          name: '疑点摘录与跟进建议（会话稿）',
          format: 'MD',
          resultTreeBucket: 'dialog',
          sourceSkillName: '审计助手对话',
          createdAt: '2026-03-25 09:00',
          status: 'done',
        },
      ];
    }
    /** 工作台资料文件夹（与 demoProjectMaterialsById 同 projectId 对齐；仅演示） */
    const demoProjectMaterialFoldersById = Vue.reactive({
      'PRJ-2026-001': [
        { id: 'mf-001', name: '合同与财务', parentId: null, sort: 0 },
        { id: 'mf-002', name: '合同扫描件', parentId: 'mf-001', sort: 0 },
        { id: 'mf-003', name: '进度与验收', parentId: null, sort: 1 },
      ],
      'PRJ-2026-002': [],
    });
    const demoProjectMaterialsById = Vue.reactive({
      'PRJ-2026-001': demoMakeProjectMaterials(),
      'PRJ-2026-002': [
        { id: 'm-101', name: '专项资金台账.xlsx', uploader: '张审计', size: 2.8, format: 'XLSX', status: 'done', progress: 100, parentId: null, sort: 0, uploadedAt: '2026-03-22 18:45' },
        { id: 'm-102', name: '审批单-支付节点.pdf', uploader: '李审计', size: 0.9, format: 'PDF', status: 'done', progress: 100, parentId: null, sort: 1, uploadedAt: '2026-03-22 18:48' },
      ],
    });
    const demoProjectAnalysisResultsById = Vue.reactive({
      'PRJ-2026-001': demoMakeAnalysisResults(),
    });
    /** 审计助手「结果」树文件夹（与 demoProjectAnalysisResultsById 同 projectId；根级 parentId 为空；linkedTaskId 表示任务完成时自动创建的任务夹） */
    const demoProjectAnalysisResultFoldersById = Vue.reactive({
      'PRJ-2026-001': [
        { id: 'arf-seed-1', name: '归档草稿', parentId: null, sort: 0 },
        { id: 'arf-tr-wb-task-01', name: '合同与发票专项核对', parentId: null, sort: 10, linkedTaskId: 'wb-task-01' },
        { id: 'arf-tr-wb-task-02', name: '付款与验收追踪', parentId: null, sort: 11, linkedTaskId: 'wb-task-02' },
        { id: 'arf-tr-wb-task-03', name: '预算与对标分析', parentId: null, sort: 12, linkedTaskId: 'wb-task-03' },
        { id: 'arf-tasksub-1', name: '核对底稿', parentId: 'arf-tr-wb-task-01', sort: 0 },
        { id: 'arf-dialog-notes', name: '会话纪要夹', parentId: null, sort: 1 },
      ],
      'PRJ-2026-002': [],
    });
    /** 跑批任务创建 · 数据源预览（演示，不解析真实 xlsx/csv） */
    const DEMO_BATCH_DATASOURCE_PREVIEW = {
      columns: ['企业名称', '统一社会信用代码', '注册地址', '法定代表人', '注册资本', '成立日期', '经营状态', '所属行业'],
      rows: [
        ['杭州城建集团有限公司', '91330100MA2XXXX01', '杭州市西湖区文三路 88 号', '张某某', '50000 万元', '1998-06-12', '存续', '建筑业'],
        ['浙江宏达建设股份有限公司', '91330100MA2XXXX02', '杭州市滨江区江南大道 168 号', '李某某', '12000 万元', '2005-03-08', '存续', '建筑业'],
        ['宁波港务投资有限公司', '91330200MA2XXXX03', '宁波市北仑区港口路 1 号', '王某某', '80000 万元', '2001-11-20', '存续', '交通运输'],
        ['温州民商银行股份有限公司', '91330300MA2XXXX04', '温州市鹿城区车站大道 200 号', '陈某某', '200000 万元', '2015-01-16', '存续', '金融业'],
        ['嘉兴科技城发展有限公司', '91330400MA2XXXX05', '嘉兴市南湖区科技城路 66 号', '赵某某', '30000 万元', '2010-07-30', '存续', '房地产业'],
        ['绍兴纺织产业集团有限公司', '91330600MA2XXXX06', '绍兴市柯桥区纺都大道 18 号', '周某某', '15000 万元', '2003-09-05', '存续', '制造业'],
        ['金华义乌小商品贸易公司', '91330700MA2XXXX07', '金华市义乌市稠州北路 100 号', '吴某某', '5000 万元', '2012-04-22', '存续', '批发零售'],
        ['台州海洋装备制造有限公司', '91331000MA2XXXX08', '台州市椒江区滨海大道 50 号', '郑某某', '25000 万元', '2008-12-01', '存续', '制造业'],
        ['湖州绿色能源科技有限公司', '91330500MA2XXXX09', '湖州市吴兴区新能源路 9 号', '孙某某', '8000 万元', '2018-05-17', '存续', '电力热力'],
        ['舟山远洋渔业发展有限公司', '91330900MA2XXXX10', '舟山市定海区渔港路 3 号', '钱某某', '6000 万元', '2006-08-28', '存续', '农林牧渔'],
      ],
    };
    window.DEMO_BATCH_DATASOURCE_PREVIEW = DEMO_BATCH_DATASOURCE_PREVIEW;

    const demoWorkbenchTaskRows = Vue.reactive((() => {
      const nowMs = Date.now();
      const completedAt = new Date(nowMs - 3600000).toISOString().slice(0, 19).replace('T', ' ');
      const md = '## 任务输出（演示）\n\n用于任务完成态预览；关联结果见右侧「结果」树。';
      const formatTs = (ms) => new Date(ms).toISOString().slice(0, 19).replace('T', ' ');
      const taskBody = (id, title, skillId, skillName, resources, status, createdOffsetMin, extra) => {
        const created = formatTs(nowMs - Math.max(0, Number(createdOffsetMin) || 0) * 60000);
        return {
          id,
          type: 'analysis',
          title,
          status,
          analysisMarkdown: md,
          taskConfig: { skillId, skillName, resources, instruction: (extra && extra.instruction) || '' },
          projectSource: {
            id,
            status,
            createdAt: created,
            completedAt: status === 'done' ? completedAt : null,
            sourceSkillName: skillName,
            name: title,
            analysisMarkdown: md,
          },
          ...(extra || {}),
        };
      };
      const batchParentId = 'wb-task-batch-01';
      const batchSkillId = 'sk-prj-fork-001';
      const batchSkillName = '施工合同与发票一致性核查';
      const batchResources = [
        { key: 'file:contract-sample', name: '施工合同节选（演示）', type: 'file', format: 'PDF' },
      ];
      const batchInstruction =
        '请使用技能「{{技能名称}}」，针对数据源中「{{标识列}}」列的每一行企业，查询工商登记信息并输出结构化摘要（演示）。';
      const batchChild = (id, rowLabel, status, offsetMin) =>
        taskBody(id, rowLabel, batchSkillId, batchSkillName, batchResources, status, offsetMin, {
          taskType: 'batch-child',
          parentId: batchParentId,
          rowLabel,
          taskConfig: {
            skillId: batchSkillId,
            skillName: batchSkillName,
            resources: batchResources,
            instruction: batchInstruction.replace('{{标识列}}', '企业名称').replace('{{技能名称}}', batchSkillName),
          },
        });
      const batchChildren = [
        batchChild('wb-batch-c-01', '杭州城建集团有限公司', 'done', 90),
        batchChild('wb-batch-c-02', '浙江宏达建设股份有限公司', 'done', 88),
        batchChild('wb-batch-c-03', '宁波港务投资有限公司', 'done', 86),
        batchChild('wb-batch-c-04', '温州民商银行股份有限公司', 'parsing', 20),
        batchChild('wb-batch-c-05', '嘉兴科技城发展有限公司', 'queued', 18),
        batchChild('wb-batch-c-06', '绍兴纺织产业集团有限公司', 'queued', 16),
        batchChild('wb-batch-c-07', '金华义乌小商品贸易公司', 'failed', 14),
        batchChild('wb-batch-c-08', '台州海洋装备制造有限公司', 'done', 12),
      ];
      const batchParent = taskBody(
        batchParentId,
        '企业工商信息批量查询',
        batchSkillId,
        batchSkillName,
        batchResources,
        'parsing',
        100,
        {
          taskType: 'batch',
          children: batchChildren,
          batchMeta: {
            fileName: '企业名单.xlsx',
            idColumn: '企业名称',
            idColumns: ['企业名称'],
            total: batchChildren.length,
            instruction: batchInstruction,
          },
          taskConfig: {
            skillId: batchSkillId,
            skillName: batchSkillName,
            resources: batchResources,
            instruction: batchInstruction,
          },
        }
      );
      /** 创建时间错开，便于任务列表按「创建时间倒序」展示时有稳定先后（数值越小越新） */
      return [
        batchParent,
        taskBody('wb-task-01', '合同与发票专项核对', 'sk-prj-fork-001', '施工合同与发票一致性核查', [
          { key: 'file:contract-sample', name: '施工合同节选（演示）', type: 'file', format: 'PDF' },
          { key: 'file:invoice-sample', name: '发票样本（演示）', type: 'file', format: 'PDF' },
        ], 'done', 5760),
        taskBody('wb-task-02', '付款与验收追踪', 'sk-pub-3', '工程款节点支付合规核对', [
          { key: 'file:pay-approve', name: '付款审批（演示）', type: 'file', format: 'PDF' },
        ], 'done', 4320),
        taskBody('wb-task-03', '预算与对标分析', 'sk-prj-fork-003', '合同变更链路与金额追踪（演示失败）', [
          { key: 'file:budget-xls', name: '预算执行表（演示）', type: 'file', format: 'XLSX' },
        ], 'done', 2880),
        taskBody('wb-task-04', '往来函证抽样核对', 'sk-pub-2', '投资完成进度偏差扫描', [
          { key: 'file:sample-04', name: '函证控制表（演示）', type: 'file', format: 'XLSX' },
        ], 'parsing', 15),
        taskBody('wb-task-05', '采购异常专项扫描', 'sk-prj-fork-002', '采购环节供应商交叉比对（试用）', [
          { key: 'file:sample-05', name: '供应商清单（演示）', type: 'file', format: 'XLSX' },
        ], 'failed', 120),
      ];
    })());
    const DEMO_SKILL_LINKED_RESOURCE_PRESET_MAP = {
      'sk-pub-1': {
        ids: ['m-001-03', 'm-001-02', 'm-001-01'],
        meta: {
          'm-001-03': '命中规则：合同金额/付款条款',
          'm-001-02': '命中规则：发票金额/开票时间',
          'm-001-01': '关联类型：会议纪要（合同执行背景）',
        },
      },
      'sk-pub-2': {
        ids: ['m-001-07', 'm-001-08', 'm-001-10'],
        meta: {
          'm-001-07': '命中规则：计划投资字段',
          'm-001-08': '命中规则：实际完成进度字段',
          'm-001-10': '关联类型：验收报告（偏差说明）',
        },
      },
      'sk-prv-1': {
        ids: ['m-001-04', 'm-001-05'],
        meta: {
          'm-001-04': '命中规则：供应商主体',
          'm-001-05': '命中规则：收款方账号',
        },
      },
    };
    function getDemoSkillLinkedResourcePreset(skillId) {
      const raw = DEMO_SKILL_LINKED_RESOURCE_PRESET_MAP[String(skillId || '')] || null;
      return {
        ids: raw && Array.isArray(raw.ids) ? Array.from(new Set(raw.ids.map((x) => String(x)).filter(Boolean))) : [],
        meta: raw && raw.meta && typeof raw.meta === 'object' ? { ...raw.meta } : {},
      };
    }

    /** 工作台级分析技能（工作台与审计助手共享，新增技能在两端同步可见） */
    const demoProjectAnalysisTemplatesById = Vue.reactive({
      'PRJ-2026-001': [
        {
          id: 'sk-prj-fork-001',
          library: 'public',
          name: '施工合同与发票一致性核查',
          sourceSkillId: 'sk-pub-1',
          sourceLibrary: 'public',
          sourceSkillName: '施工合同与发票一致性核查',
          sourceVersionLabel: '组织快照',
          tags: ['城建', '金额', '合规'],
          skillFiles: [
            {
              id: 'sk-pub-1-f1',
              kind: 'file',
              fileKind: 'md',
              codeLang: '',
              filename: '施工合同.md',
              content: '从施工合同中提取：合同金额、付款方式、工程期限、甲乙双方。',
            },
            {
              id: 'sk-pub-1-f2',
              kind: 'file',
              fileKind: 'md',
              codeLang: '',
              filename: '发票.md',
              content: '从发票中提取：发票金额、开票日期、销方名称、购方名称。',
            },
          ],
          analysisRule: '比对合同金额与发票累计金额，识别超付或少付；检查发票开具日期与合同签订日期的先后关系并标注异常。',
          linkedResourceIds: ['m-001-03', 'm-001-02', 'm-001-01'],
          linkedResourceMeta: {
            'm-001-03': '命中规则：合同金额/付款条款',
            'm-001-02': '命中规则：发票金额/开票时间',
            'm-001-01': '关联类型：会议纪要（合同执行背景）',
          },
        },
        {
          id: 'sk-prj-fork-002',
          library: 'private',
          name: '采购环节供应商交叉比对（试用）',
          sourceSkillId: 'sk-prv-1',
          sourceLibrary: 'private',
          sourceSkillName: '采购环节供应商交叉比对（试用）',
          sourceVersionLabel: '技能库副本',
          tags: ['采购', '私有'],
          skillFiles: [
            {
              id: 'sk-prv-1-f1',
              kind: 'file',
              fileKind: 'md',
              codeLang: '',
              filename: '采购合同.md',
              content: '提取供应商名称、合同金额、签约日期、付款节点。',
            },
            {
              id: 'sk-prv-1-f2',
              kind: 'file',
              fileKind: 'md',
              codeLang: '',
              filename: '付款流水.md',
              content: '提取收款方名称、金额、日期、摘要。',
            },
          ],
          analysisRule: '比对合同供应商与流水中收款方一致性；对名称近似但非完全一致的情况列出待人工核实清单。',
          linkedResourceIds: ['m-001-04', 'm-001-05'],
          linkedResourceMeta: {
            'm-001-04': '命中规则：供应商主体',
            'm-001-05': '命中规则：收款方账号',
          },
        },
        {
          id: 'sk-prj-fork-003',
          library: 'private',
          name: '合同变更链路与金额追踪（演示失败）',
          sourceSkillId: 'sk-prv-2',
          sourceLibrary: 'private',
          sourceSkillName: '合同变更链路与金额追踪（技能）',
          sourceVersionLabel: '技能库副本',
          tags: ['合同', '变更'],
          skillFiles: [
            {
              id: 'sk-prv-2-f1',
              kind: 'file',
              fileKind: 'md',
              codeLang: '',
              filename: '合同变更记录.md',
              content: '提取变更金额、变更时间、审批单号和对应合同条款编号。',
            },
            {
              id: 'sk-prv-2-f2',
              kind: 'file',
              fileKind: 'md',
              codeLang: '',
              filename: '付款台账.md',
              content: '提取付款金额、付款节点、付款时间并与变更单进行映射。',
            },
          ],
          analysisRule: '识别合同变更金额与后续付款流水是否存在链路断点，定位未闭环变更单。',
          linkedResourceIds: ['m-001-09'],
          linkedResourceMeta: {
            'm-001-09': '命中规则：变更单号/金额映射',
          },
        },
      ],
    });
    (function hydrateProjectTemplateExtractionRules() {
      const T = typeof DemoSkillFileTree !== 'undefined' ? DemoSkillFileTree : null;
      if (!T || typeof T.syncExtractionRulesFromSkillFiles !== 'function') return;
      Object.keys(demoProjectAnalysisTemplatesById).forEach((pid) => {
        const list = demoProjectAnalysisTemplatesById[pid];
        (list || []).forEach((row) => T.syncExtractionRulesFromSkillFiles(row));
      });
    })();

    /** 与工作台「结果预览」共用的证据溯源映射（演示数据） */
    const DEMO_ANALYSIS_CITATION_MAP = {
      E1: {
        /** 演示：点击溯源「弹出」时打开的本工作台资料 id（与 demoMakeProjectMaterials 中「合同」条目一致） */
        materialId: 'm-001-03',
        conclusionLabel: '金额一致性异常',
        conclusionContext: '系统识别合同金额与发票累计金额存在异常偏差，且超出阈值。该偏差直接影响资金支付准确性，需优先核查。',
        sourceLabel: '施工合同.pdf（第8页）｜发票台账.xlsx（Sheet1）',
        anchor: '合同#CT-2026-018 第4条；发票台账第12-19行',
        sourceExcerpt: '“合同总价款为人民币 1,260 万元，按进度节点分期支付。”\n“截至 2026-03-18，累计开票金额 1,416 万元。”',
        sourceFullText:
          '【施工合同 CT-2026-018 摘录 · 金额与支付条款】\n\n'
          + '第四条 合同价款与调整\n'
          + '4.1 合同总价款为人民币 1,260 万元（含税），按进度节点分期支付；具体节点与比例见附件《付款计划表》。\n'
          + '4.2 若发生设计变更或现场签证，应按业主确认的变更价款调整合同总价，并同步更新累计开票与结算口径。\n\n'
          + '【发票台账 Sheet1 摘录 · 累计开票】\n'
          + '截至 2026-03-18，本工作台累计开票金额 1,416 万元，较合同总价款超出 156 万元。台账备注栏显示存在跨期开票与红冲记录，需结合合同补充协议与现场签证逐项核对。',
      },
      E2: {
        materialId: 'm-001-02',
        conclusionLabel: '付款时点异常',
        conclusionContext: '部分支付发生在验收节点之前，存在提前支付风险，可能造成资金拨付与工程进度不匹配。',
        sourceLabel: '付款流水.pdf（第3页）｜进度验收单.docx（第2页）',
        anchor: '流水#PAY-334；验收单第2页“未验收”',
        sourceExcerpt: '“2026-02-28 支付进度款 280 万元。”\n“截至 2026-03-05，该节点工程尚未验收通过。”',
        sourceFullText:
          '【付款流水 PAY-334】\n'
          + '2026-02-28 支付进度款 280 万元；摘要：二期路基工程进度款；收款方与合同乙方一致。\n\n'
          + '【进度验收单 · 节点 B-2】\n'
          + '截至 2026-03-05，该节点工程尚未验收通过；现场存在问题清单：基层压实度抽检 2 处不达标，需整改复验后方可进入下一付款节点。\n\n'
          + '审计提示：在验收未通过前发生大额进度款支付，应核查是否满足合同“先验后付”或类似条款，并补充审批豁免资料。',
      },
      E3: {
        materialId: 'm-001-03',
        conclusionLabel: '主体一致性疑点',
        conclusionContext: '供应商主体名称在不同资料中不完全一致，可能是简称，也可能涉及主体识别偏差，需人工确认。',
        sourceLabel: '采购合同.pdf（第1页）｜开户信息表.xlsx（第4行）',
        anchor: '采购合同乙方字段；开户信息表第4行',
        sourceExcerpt: '“乙方：建工实业有限公司。”\n“账户名称：建工实业。”',
        sourceFullText:
          '【采购合同首页 · 乙方信息】\n'
          + '乙方：建工实业有限公司；统一社会信用代码：91**************12；注册地址：……\n\n'
          + '【开户信息表 第4行】\n'
          + '账户名称：建工实业；开户行：……；账号：……\n\n'
          + '说明：名称差异可能为简称，也可能涉及分支机构或授权收款主体。建议调取工商登记与授权委托书，确认付款对象与合同主体法律关系一致。',
      },
    };

    function analysisCitationDisplayIndex(key) {
      const raw = String(key || '').trim();
      const matched = raw.match(/(\d+)$/);
      return matched ? matched[1] : raw;
    }

    function collectAnalysisCitationKeys(text) {
      const seen = new Set();
      const keys = [];
      String(text || '').replace(/\[(E\d+)\]/g, (_, key) => {
        if (!seen.has(key)) {
          seen.add(key);
          keys.push(key);
        }
        return _;
      });
      return keys;
    }

    function buildAnalysisCitationAppendix(text, citationMap) {
      const keys = collectAnalysisCitationKeys(text);
      if (!keys.length) return '';
      const map = citationMap || DEMO_ANALYSIS_CITATION_MAP;
      const lines = ['---', '', '### 引用信息', ''];
      keys.forEach((key) => {
        const data = map[key] || {};
        const idx = analysisCitationDisplayIndex(key);
        const sourceLabel = String(data.sourceLabel || '引用来源').trim() || '引用来源';
        const excerpt = String(data.sourceExcerpt || data.sourceFullText || '').trim() || '暂无可展示的引用内容';
        lines.push(`**（${idx}）${sourceLabel}**`);
        excerpt.split('\n').forEach((line) => {
          lines.push(`> ${line}`);
        });
        lines.push('');
      });
      return lines.join('\n').trim();
    }

    function normalizeAnalysisCitationText(text) {
      return String(text || '').replace(/\[(E\d+)\]/g, (_, key) => `（${analysisCitationDisplayIndex(key)}）`);
    }

    function buildAnalysisResultPreviewMarkdown(rec) {
      const createdAt = rec.createdAt || '—';
      const name = rec.name || '当前分析任务';
      const base = [
        '## 一、分析结论摘要',
        `围绕“${name}”，系统对合同、发票、付款流水与验收记录进行了交叉比对。初步识别出金额口径不一致、付款时点与验收节点不匹配等问题，其中金额差异集中在少数高金额条目，具备进一步核查价值。[E1]`,
        '本次分析显示，异常并非单点偶发，而是呈现出“同类字段在多个资料中重复偏离”的模式，提示流程控制环节可能存在系统性执行偏差。建议优先核验高金额条目及跨月支付记录，并补充项目变更审批链路资料，以提高结论稳定性。',
        '',
        '## 二、关键发现',
        '- 发现 3 处合同金额与发票累计金额差异，最高差额 156 万元；[E1]',
        '- 发现 2 处付款日期早于对应验收节点，存在提前支付风险；[E2]',
        '- 发现 1 处供应商名称近似不一致，需进一步确认主体是否同一。[E3]',
        '',
        '## 三、审计建议',
        '建议按“先金额、后流程、再主体一致性”的顺序推进复核：先确认金额差异是否由补充协议引起，再核验付款与验收的流程闭环，最后核查供应商主体一致性与授权关系。对已确认异常项，建议同步补充责任部门说明，形成可落地整改台账。',
        '',
        `> 生成时间：${createdAt}`,
      ].join('\n');
      const appendix = buildAnalysisCitationAppendix(base, rec && rec.citationMap);
      return [normalizeAnalysisCitationText(base), appendix].filter(Boolean).join('\n\n');
    }

    /**
     * 分析结果「生成说明」：技能名 + 资料名列表（演示）。
     * @param {object} rec - 含 sourceSkillName、可选 sourceMaterialIds
     * @param {(id: string) => string} [resolveMaterialName] - 资料 id → 展示名
     */
    function buildAnalysisResultGenerationDesc(rec, resolveMaterialName) {
      const skill = String((rec && rec.sourceSkillName) || '').trim() || '关联技能';
      const ids = Array.isArray(rec && rec.sourceMaterialIds) ? rec.sourceMaterialIds : [];
      const resolver = typeof resolveMaterialName === 'function' ? resolveMaterialName : (id) => String(id || '').trim();
      const names = ids.map((id) => resolver(id)).filter(Boolean);
      if (!names.length) {
        return `使用技能「${skill}」基于当前工作台所选资料生成的结果（演示）。`;
      }
      const max = 5;
      const shown = names.slice(0, max);
      const more = names.length > max ? ` 等共 ${names.length} 项资料` : '';
      return `使用技能「${skill}」基于《${shown.join('》《')}》${more}生成的结果。`;
    }

    function hydrateDemoAnalysisResultMarkdown(rows) {
      return (rows || []).map((row) => (
        row && row.status === 'done' && !row.analysisMarkdown
          ? { ...row, analysisMarkdown: buildAnalysisResultPreviewMarkdown(row) }
          : row
      ));
    }

    /** 资料预览 · 仅文档页示意（不含文件元信息；与基本信息 Tab 拆分） */
    function materialPreviewDocumentPagesFromRecord(rec) {
      if (!rec) return ['暂无内容'];
      const fmt = String(rec.format || '').toUpperCase();
      if (fmt === 'XLSX' || fmt === 'XLS' || fmt === 'CSV') {
        return ['【表格预览】\n\n结构化表格内容请在「文件预览」表格区查看（演示）。'];
      }
      return [
        '【在线预览页 1】\n\n这里展示 PDF 首屏内容（演示态）。\n系统后续可替换为真实 PDF 渲染流。',
        '【在线预览页 2】\n\n这是第 2 页示意内容。\n你可以继续补充 OCR 文本、关键段落高亮、页码跳转等能力。\n\n当前版本重点是：资料点击即可弹出在线浏览窗口。',
      ];
    }

    /** 资料预览 · OCR 演示页（每页对应文档预览页） */
    function materialPreviewOcrPagesFromRecord(rec) {
      if (!rec) return ['暂无 OCR 内容'];
      const fmt = String(rec.format || '').toUpperCase();
      if (fmt === 'XLSX' || fmt === 'XLS' || fmt === 'CSV') {
        return [
          '【OCR 结果 · 演示】\n\n表格类资料的单元格级 OCR 可在后续版本接入；当前为占位说明。',
        ];
      }
      const name = String(rec.name || '未命名文件');
      const docs = materialPreviewDocumentPagesFromRecord(rec);
      return docs.map(
        (body, index) =>
          `【OCR 识别结果 · 第 ${index + 1} 页】\n文件：${name}\n\n${body}`,
      );
    }

    /** 为 OCR 结果纯文本左侧追加行号（与 pre-wrap 展示配合；开启时建议配合等宽字体类） */
    function materialPreviewOcrPageWithLineNumbers(pageText, showLineNumbers) {
      if (!showLineNumbers) return String(pageText == null ? '' : pageText);
      const s = String(pageText == null ? '' : pageText);
      if (!s) return s;
      const lines = s.split('\n');
      const w = String(lines.length).length;
      return lines.map((line, i) => `${String(i + 1).padStart(w, ' ')}  ${line}`).join('\n');
    }

    /**
     * 兼容旧调用：历史上与「在线预览」页片同源；现等同于文档预览页数组。
     * @deprecated 新代码请使用 materialPreviewDocumentPagesFromRecord
     */
    function materialPreviewPagesFromRecord(rec) {
      return materialPreviewDocumentPagesFromRecord(rec);
    }

    /** 资料行 → 审计助手资料池节点（保留 projectSource 引用） */
    function mapProjectRowToWorkbenchMaterial(row, projectId) {
      const fmt = String(row.format || '').toUpperCase();
      const rawSubtype = fmt === 'XLSX' || fmt === 'XLS' || fmt === 'CSV' ? 'table' : 'document';
      const title = row.name || '未命名';
      return {
        id: row.id,
        type: 'raw',
        rawSubtype,
        title,
        projectSource: row,
        checked: false,
        overview: '资料',
        meta: row.uploadedAt || '—',
        originalView: rawSubtype === 'table'
          ? { type: 'table', headers: ['说明'], rows: [['请在工作台查看表格类资料全文（演示）。']] }
          : { type: 'document', pages: materialPreviewPagesFromRecord(row) },
        paired: {
          id: 'ex-' + row.id,
          title: title + ' - 提取结果（演示）',
          overview: row.status === 'done' ? '解析完成' : `状态：${row.status || '—'}`,
          summary: '解析摘要（演示占位）',
          excerpts: [],
          extractBlocks: [],
        },
        excerpts: [],
      };
    }
        /** 工作台结果行 → 审计助手中的审计发现节点 */
    function mapAnalysisResultRowToWorkbench(row, projectId) {
      const title = row.name || '未命名';
      const analysisMarkdown = row.analysisMarkdown || buildAnalysisResultPreviewMarkdown({ name: title, createdAt: row.createdAt });
      const line = `【${title}】\n生成时间：${row.createdAt || '—'}`;
      return {
        id: row.id,
        type: 'analysis',
        title,
        projectSource: row,
        checked: false,
        overview: '审计发现',
        sourceMaterialIds: Array.isArray(row.sourceMaterialIds) ? row.sourceMaterialIds.slice() : [],
        analysisMarkdown,
        citationMap: row.citationMap || DEMO_ANALYSIS_CITATION_MAP,
        excerpts: [line],
        excerptsWithCitations: [{ text: line, citations: [] }],
        meta: row.createdAt || '—',
      };
    }

    Object.keys(demoProjectAnalysisResultsById).forEach((projectId) => {
      demoProjectAnalysisResultsById[projectId] = hydrateDemoAnalysisResultMarkdown(demoProjectAnalysisResultsById[projectId]);
    });

    const SKILL_LIBRARY = { PUBLIC: 'public', PRIVATE: 'private' };
    const SKILL_SEED_PUBLIC = [
      {
        id: 'sk-pub-1',
        library: 'public',
        name: '施工合同与发票一致性核查',
        description: '系统从合同与发票中自动抽取并对账，帮你快速发现金额与时间逻辑异常。',
        tags: ['城建', '金额', '合规'],
        skillFiles: [
          {
            id: 'sk-pub-1-f1',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '施工合同.md',
            content: '从施工合同中提取：合同金额、付款方式、工程期限、甲乙双方。',
          },
          {
            id: 'sk-pub-1-f2',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '发票.md',
            content: '从发票中提取：发票金额、开票日期、销方名称、购方名称。',
          },
        ],
        analysisRule: '比对合同金额与发票累计金额，识别超付或少付；检查发票开具日期与合同签订日期的先后关系并标注异常。',
        createdAt: '2024-02-01 10:00',
        updatedAt: '2024-03-10 18:30',
        sharedBy: '系统预置',
      },
      {
        id: 'sk-pub-2',
        library: 'public',
        name: '投资完成进度偏差扫描',
        description: '系统对照计划与实际投资进度，自动标记偏离并提示是否需补充说明。',
        tags: ['投资', '进度', '财务'],
        skillFiles: [
          {
            id: 'sk-pub-2-fd',
            kind: 'folder',
            name: '结构化抽取',
            children: [
              {
                id: 'sk-pub-2-f1',
                kind: 'file',
                fileKind: 'md',
                codeLang: '',
                filename: '财务数据表.md',
                content: '提取计划投资、实际完成、完成比例等字段。',
              },
              {
                id: 'sk-pub-2-f2',
                kind: 'file',
                fileKind: 'md',
                codeLang: '',
                filename: '会议纪要.md',
                content: '提取会议时间、整改要求、责任主体与完成时限。',
              },
            ],
          },
        ],
        analysisRule: '按年度与截至月对比计划与实际完成比例，结合时间进度阈值标记偏差；归纳会议纪要中是否对滞后原因有书面说明。',
        createdAt: '2024-02-08 14:00',
        updatedAt: '2024-03-08 12:00',
        sharedBy: '审计管理员',
      },
      {
        id: 'sk-pub-3',
        library: 'public',
        name: '工程款节点支付合规核对',
        description: '系统比对合同付款节点与实际付款时间金额，提示提前支付或超节点支付风险。',
        tags: ['城建', '付款节点', '合规'],
        skillFiles: [
          {
            id: 'sk-pub-3-f1',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '工程合同.md',
            content: '提取付款节点、节点条件、应付比例、签署日期。',
          },
          {
            id: 'sk-pub-3-f2',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '付款台账.md',
            content: '提取付款日期、付款金额、付款事由、对应合同编号。',
          },
        ],
        analysisRule: '按合同节点校验付款时间与金额，识别提前支付、超比例支付及缺少节点依据的付款记录。',
        createdAt: '2024-02-20 09:20',
        updatedAt: '2024-03-20 15:10',
        sharedBy: '平台管理员',
      },
      {
        id: 'sk-pub-4',
        library: 'public',
        name: '资金拨付与预算批复一致性检查',
        description: '系统对照预算批复、拨付台账与用途说明，定位超预算与用途偏离。',
        tags: ['预算', '资金拨付', '合规'],
        skillFiles: [
          {
            id: 'sk-pub-4-f1',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '预算批复文件.md',
            content: '提取预算科目、批复金额、批复日期、使用范围。',
          },
          {
            id: 'sk-pub-4-f2',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '资金拨付记录.md',
            content: '提取拨付金额、拨付日期、用途说明、执行单位。',
          },
        ],
        analysisRule: '按预算科目汇总对比批复与实际拨付，标注超预算拨付与用途不匹配记录并输出风险说明。',
        createdAt: '2024-02-26 10:40',
        updatedAt: '2024-03-22 17:30',
        sharedBy: '资金监管组',
      },
    ];
    const SKILL_SEED_PRIVATE = [
      {
        id: 'sk-prv-1',
        library: 'private',
        name: '采购环节供应商交叉比对（试用）',
        description: '系统交叉核对合同与流水中供应商及账号，列出待核实项。',
        tags: ['采购', '私有'],
        skillFiles: [
          {
            id: 'sk-prv-1-f1',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '采购合同.md',
            content: '提取供应商名称、合同金额、签约日期、付款节点。',
          },
          {
            id: 'sk-prv-1-f2',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '付款流水.md',
            content: '提取收款方名称、金额、日期、摘要。',
          },
        ],
        analysisRule: '比对合同供应商与流水中收款方一致性；对名称近似但非完全一致的情况列出待人工核实清单。',
        createdAt: '2024-03-01 09:00',
        updatedAt: '2024-03-12 16:20',
      },
      {
        id: 'sk-prv-2',
        library: 'private',
        name: '往来科目余额勾稽',
        description: '系统按科目汇总余额变动，提示长期挂账与借贷方向异常。',
        tags: ['往来', '余额', '财务'],
        skillFiles: [
          {
            id: 'sk-prv-2-f1',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '科目余额表.md',
            content: '提取科目代码、科目名称、期初、本期借/贷、期末余额。',
          },
          {
            id: 'sk-prv-2-f2',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '账龄附件.md',
            content: '提取账龄区间、金额、主要对手方说明。',
          },
        ],
        analysisRule: '对同名科目多期余额变动进行勾稽；标注余额长期不变或借贷方向与业务不符的科目。',
        createdAt: '2024-03-05 11:00',
        updatedAt: '2024-03-18 10:00',
      },
      {
        id: 'sk-prv-3',
        library: 'private',
        name: '三公经费异常波动扫描',
        description: '系统按部门扫描三公经费环比/同比波动，超限结果集中标出。',
        tags: ['三公', '预算', '私有'],
        skillFiles: [
          {
            id: 'sk-prv-3-f1',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '费用明细.md',
            content: '提取费用类型、金额、发生日期、审批单号、部门。',
          },
        ],
        analysisRule: '计算各部门三类费用环比/同比，超过设定比例输出清单并要求说明原因。',
        createdAt: '2024-03-06 14:30',
        updatedAt: '2024-03-14 09:15',
      },
      {
        id: 'sk-prv-4',
        library: 'private',
        name: '往来函证缺口提醒',
        description: '系统对照发函与回函记录，汇总逾期未回与替代程序缺口。',
        tags: ['函证', '往来', '合规'],
        skillFiles: [
          {
            id: 'sk-prv-4-f1',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '发函清单.md',
            content: '提取函证对象、科目、账面金额、发函日期。',
          },
          {
            id: 'sk-prv-4-f2',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '回函登记.md',
            content: '提取回函日期、差异说明、经办人。',
          },
        ],
        analysisRule: '匹配发函与回函记录；对超期未回函且无替代程序记录的条目汇总为待办。',
        applicableScenario: '往来函证阶段；资料中含发函登记与回函登记或回函快递单时启用。',
        createdAt: '2024-03-08 16:00',
        updatedAt: '2024-03-19 11:40',
      },
      {
        id: 'sk-prv-5',
        library: 'private',
        name: '资产类与盘点差异初筛',
        description: '系统比对资产卡片与盘点结果，初筛有账无物、有物无账线索。',
        tags: ['资产', '盘点'],
        skillFiles: [
          {
            id: 'sk-prv-5-f1',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '资产卡片.md',
            content: '提取资产编号、名称、原值、使用部门、存放地点。',
          },
          {
            id: 'sk-prv-5-f2',
            kind: 'file',
            fileKind: 'md',
            codeLang: '',
            filename: '盘点表.md',
            content: '提取实盘数量、盘盈盘亏标记、备注。',
          },
        ],
        analysisRule: '以编号或名称模糊匹配卡片与盘点行，输出双向未匹配清单供现场核实。',
        createdAt: '2024-03-11 09:20',
        updatedAt: '2024-03-11 09:20',
      },
    ];
    /** 技能库「我的技能」种子：多条已发布版本（演示：最新 + 历史折叠列表） */
    function buildDemoPrivateSkillPublishedVersions(seed) {
      if (!seed) return [];
      const baseSnap = (rev) => {
        const o = {
          name: seed.name || '未命名技能',
          description: seed.description || '',
          tags: Array.isArray(seed.tags) ? seed.tags.slice() : [],
          analysisRule: seed.analysisRule || '',
          applicableScenario: seed.applicableScenario != null ? String(seed.applicableScenario) : '',
          skillFiles: Array.isArray(seed.skillFiles) ? JSON.parse(JSON.stringify(seed.skillFiles)) : [],
        };
        if (rev > 0 && o.name && !/·\s*r\d+$/.test(o.name)) o.name = o.name + ' · r' + rev;
        return o;
      };
      const labels = ['v1.0.0', 'v1.0.1', 'v1.0.2', 'v1.0.3', 'v1.0.4', 'v1.0.5', 'v1.0.6'];
      const times = [
        '2026-01-05 10:00',
        '2026-02-01 14:20',
        '2026-02-15 09:30',
        '2026-02-28 11:00',
        '2026-03-05 16:45',
        '2026-03-08 20:00',
        '2026-03-09 22:11',
      ];
      return labels.map((versionLabel, i) => ({
        versionLabel,
        versionNote: '演示：' + versionLabel + ' 发布说明（可恢复快照）。',
        createdAt: times[i] || seed.updatedAt || seed.createdAt || '2026-03-09 22:11',
        publisherName: '周宇',
        publisherRole: '（教授）',
        versionStatus: 'published',
        snapshot: baseSnap(i),
      }));
    }
    (SKILL_SEED_PRIVATE || []).forEach((s) => {
      if (!s) return;
      if (!Array.isArray(s.publishedVersions)) s.publishedVersions = [];
      if (s.publishedVersions.length === 0) s.publishedVersions = buildDemoPrivateSkillPublishedVersions(s);
    });
    /** 工作台 / 审计助手「引用技能」共用的「我的技能」池（可运行时追加） */
    function demoSeedToAnalysisTemplateShape(seed, library) {
      const skillFiles = Array.isArray(seed.skillFiles)
        ? JSON.parse(JSON.stringify(seed.skillFiles))
        : [];
      const linkedPreset = getDemoSkillLinkedResourcePreset(seed && seed.id);
      const linkedIdsFromSeed = Array.isArray(seed && seed.linkedResourceIds)
        ? seed.linkedResourceIds.map((id) => String(id))
        : linkedPreset.ids;
      const row = {
        id: seed.id,
        name: seed.name,
        description: seed.description || '',
        tags: Array.isArray(seed.tags) ? seed.tags.slice() : [],
        skillFiles,
        analysisRule: seed.analysisRule || '',
        applicableScenario: seed.applicableScenario != null ? String(seed.applicableScenario) : '',
        createdAt: seed.createdAt,
        updatedAt: seed.updatedAt,
        library: library || seed.library || 'private',
        extractionRules: [],
        linkedResourceIds: Array.from(new Set(linkedIdsFromSeed.filter(Boolean))),
        linkedResourceMeta: seed && seed.linkedResourceMeta && typeof seed.linkedResourceMeta === 'object'
          ? { ...seed.linkedResourceMeta }
          : linkedPreset.meta,
        publishedVersions: Array.isArray(seed.publishedVersions)
          ? JSON.parse(JSON.stringify(seed.publishedVersions))
          : [],
      };
      if (seed.sourceSkillId) row.sourceSkillId = seed.sourceSkillId;
      if (seed.sourceLibrary) row.sourceLibrary = seed.sourceLibrary;
      if (seed.sourceSkillName) row.sourceSkillName = seed.sourceSkillName;
      if (seed.sourceVersionLabel) row.sourceVersionLabel = seed.sourceVersionLabel;
      if (typeof DemoSkillFileTree !== 'undefined' && DemoSkillFileTree.syncExtractionRulesFromSkillFiles) {
        DemoSkillFileTree.syncExtractionRulesFromSkillFiles(row);
      }
      return row;
    }
    const demoSharedPrivateAnalysisTemplatePool = Vue.reactive(
      (SKILL_SEED_PRIVATE || []).map((s) => demoSeedToAnalysisTemplateShape(s, 'private'))
    );
    function skillDeepClone(o) { return JSON.parse(JSON.stringify(o)); }
    function newSkillId(prefix) { return prefix + '-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7); }

    /**
     * 工作台 / 审计助手共用：按选定技能向 demoProjectAnalysisResultsById 追加演示分析任务。
     * @param {string} projectId
     * @param {object[]} templates
     * @param {{ message?: { success?: Function, warning?: Function }, successMessage?: string, registerTimer?: (id: number) => void }} [options]
     * @returns {number} 提交条数，0 表示未提交
     */
    function demoSubmitProjectTemplateAnalysisJobs(projectId, templates, options) {
      const opts = options || {};
      const msg = opts.message || {};
      const pid = String(projectId || '');
      const tpls = Array.isArray(templates) ? templates.filter(Boolean) : [];
      if (!pid || !tpls.length) {
        if (msg.warning) msg.warning('暂无可提交的技能');
        return 0;
      }
      if (!Array.isArray(demoProjectAnalysisResultsById[pid])) demoProjectAnalysisResultsById[pid] = [];
      const reg =
        typeof opts.registerTimer === 'function'
          ? opts.registerTimer
          : (id) => {
              if (!window.__demoAnalysisJobTimers) window.__demoAnalysisJobTimers = [];
              window.__demoAnalysisJobTimers.push(id);
            };
      const now = new Date();
      const createdAt = now.toISOString().slice(0, 19).replace('T', ' ');
      const batchTaskId = 'wb-task-01';
      const batchTaskName = '合同与发票专项核对';
      const insert = tpls.map((tpl, idx) => ({
        id: 'ar-' + (Date.now() + idx),
        name: `${tpl.name} - 发现结果`,
        sourceTaskId: batchTaskId,
        sourceTaskName: batchTaskName,
        sourceSkillName: String(tpl.name || '').trim() || '技能',
        tags: Array.isArray(tpl.tags) ? tpl.tags.slice(0, 3) : [],
        createdAt,
        status: 'queued',
      }));
      demoProjectAnalysisResultsById[pid] = [...insert, ...demoProjectAnalysisResultsById[pid]];
      insert.forEach((item, idx) => {
        const parseDelay = 400 + idx * 240;
        const doneDelay = parseDelay + 900 + idx * 260;
        const t1 = window.setTimeout(() => {
          const rows = demoProjectAnalysisResultsById[pid] || [];
          const i = rows.findIndex((r) => r.id === item.id);
          if (i < 0) return;
          demoProjectAnalysisResultsById[pid].splice(i, 1, { ...rows[i], status: 'parsing' });
        }, parseDelay);
        const t2 = window.setTimeout(() => {
          const rows = demoProjectAnalysisResultsById[pid] || [];
          const i = rows.findIndex((r) => r.id === item.id);
          if (i < 0) return;
          const isFailed = Math.random() < 0.2;
          demoProjectAnalysisResultsById[pid].splice(i, 1, { ...rows[i], status: isFailed ? 'failed' : 'done' });
        }, doneDelay);
        reg(t1);
        reg(t2);
      });
      const custom = opts.successMessage != null && String(opts.successMessage).trim() !== '';
      if (msg.success) msg.success(custom ? String(opts.successMessage).trim() : `已提交 ${insert.length} 条分析任务`);
      return insert.length;
    }
