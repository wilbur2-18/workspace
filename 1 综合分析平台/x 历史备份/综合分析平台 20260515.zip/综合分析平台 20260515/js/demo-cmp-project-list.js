(function () {
  const app = window.__DEMO_APP;

  /* === DEMO:project-list · 工作台卡片列表（子组件） === */
  app.component('ProjectCenterListPanel', {
    props: {
      projectListSearch: { type: String, default: '' },
      filteredProjectList: { type: Array, default: () => [] },
      emptyDescription: { type: String, default: '' },
      cardMaterialCount: { type: Function, required: true },
      cardAnalysisResultCount: { type: Function, required: true },
      cardTemplateCount: { type: Function, required: true },
      projectTotalCount: { type: Number, default: 0 },
      projectSortBy: { type: String, default: 'created_desc' },
      projectSortOptions: { type: Array, default: () => [] },
      /** 'mine' | 'shared' — 与父级 projectListScope 同步 */
      projectListScope: { type: String, default: 'mine' },
    },
    emits: [
      'update:projectListSearch',
      'update:projectListScope',
      'update:projectSortBy',
      'create-space',
      'open-detail',
      'open-workbench',
      'card-menu',
      'clear-search',
    ],
    template: `
      <div class="main-container">
          <header class="ds-page-hero ds-page-hero--l1" aria-label="工作台">
            <h1 class="ds-page-hero__title ds-page-hero__title--with-icon">
              <span class="ds-page-hero__title-icon ds-page-hero__title-icon--audit-space" aria-hidden="true"><i class="fas fa-cube"></i></span>
              <span class="ds-page-hero__title-text">工作台</span>
            </h1>
            <p class="ds-page-hero__subtitle">在此开启审计任务，围绕工作台持续管理资料、技能与结果，并进入对话协同分析。</p>
          </header>
          <div class="ds-l1-toolbar-rail-content-stack">
          <div class="ds-page-toolbar ds-page-toolbar--l1 ds-page-toolbar--split">
            <div class="ds-page-toolbar__start">
              <a-segmented
                class="ds-ant-segmented ds-ant-segmented--l1-skill-scope"
                size="large"
                :value="projectListScope"
                :options="[
                  { label: '我的工作台', value: 'mine' },
                  { label: '共享工作台', value: 'shared' },
                ]"
                aria-label="我的工作台与共享工作台"
                @update:value="$emit('update:projectListScope', $event)"
              />
            </div>
            <div class="ds-page-toolbar__end">
              <div class="ds-page-heading-actions ds-page-toolbar__actions">
                <a-button type="primary" size="large" class="ds-btn-page-cta" @click="$emit('create-space')"><i class="fas fa-plus ds-btn-icon-before"></i>创建工作台</a-button>
              </div>
            </div>
          </div>

          <ui-info-control-rail aria-label="列表统计与排序">
            <template #total>
              <span class="ds-l1-stat-line">
                <span>共 {{ filteredProjectList.length }} 个工作台</span>
              </span>
            </template>
            <template #query>
              <a-input
                :value="projectListSearch"
                placeholder="搜索"
                size="middle"
                class="l1-rail-inline-search ds-input-inline-search"
                allow-clear
                aria-label="搜索"
                @update:value="$emit('update:projectListSearch', $event)"
              >
                <template #prefix>
                  <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                </template>
              </a-input>
            </template>
            <template #sort>
              <div class="ds-l1-sort-wrap">
                <a-dropdown v-model:open="projectSortDropdownOpen" :trigger="['click']" placement="bottomRight">
                  <button
                    type="button"
                    class="ds-trigger-btn ds-trigger-btn--icon-text"
                    :class="{ 'is-active': projectSortDropdownOpen || isProjectSortSelected, 'is-open': projectSortDropdownOpen }"
                    :title="'排序：' + currentProjectSortLabel"
                    aria-label="选择排序方式"
                    :aria-expanded="projectSortDropdownOpen ? 'true' : 'false'"
                  >
                    <i class="fas fa-arrow-down-short-wide ds-trigger-btn__icon" aria-hidden="true"></i>
                    <span class="ds-trigger-btn__text">排序</span>
                  </button>
                  <template #overlay>
                    <a-menu @click="onProjectSortMenuClick">
                      <a-menu-item v-for="opt in projectSortOptions" :key="opt.value">
                        <span class="ds-trigger-menu-item-label">
                          <i
                            v-if="projectSortBy === opt.value"
                            class="fas fa-check"
                            style="font-size:var(--ds-type-icon-inline-fs);line-height:var(--ds-type-icon-symbol-lh);"
                          ></i>
                          <span v-else style="width:var(--ds-icon-chevron-placeholder-w);"></span>
                          {{ opt.label }}
                        </span>
                      </a-menu-item>
                    </a-menu>
                  </template>
                </a-dropdown>
              </div>
            </template>
          </ui-info-control-rail>

          <div class="ds-l1-list">
          <a-row :gutter="16" class="recent-projects-row">
            <a-col v-for="p in filteredProjectList" :key="p.id" :span="8">
              <div
                class="ds-page-card ds-hover-lift ds-list-card ds-list-card--with-corner project-center-list-card ds-list-card-clickable ds-l1-grid-card"
                tabindex="0"
                role="button"
                :aria-label="'打开工作台：' + (p.name || '')"
                @click="$emit('open-detail', p.id)"
                @keydown.enter.prevent="$emit('open-detail', p.id)"
                @keydown.space.prevent="$emit('open-detail', p.id)"
              >
                <a-dropdown class="ds-list-card-corner" :trigger="['click']" placement="bottomRight" @click.stop>
                  <a-button type="text" size="small" class="ds-icon-btn ds-icon-btn--standard ds-list-card-more-btn" @click.stop aria-label="更多操作">
                    <i class="fas fa-ellipsis" aria-hidden="true"></i>
                  </a-button>
                  <template #overlay>
                    <a-menu @click="(info) => $emit('card-menu', info, p)">
                      <a-menu-item key="edit">编辑</a-menu-item>
                      <a-menu-item key="delete" danger>删除</a-menu-item>
                    </a-menu>
                  </template>
                </a-dropdown>
                <div class="ds-list-card-body">
                  <h3 class="ds-list-card-title">{{ p.name }}</h3>
                  <p class="project-center-card-desc" :title="p.description || '暂无描述'">{{ p.description || '暂无描述' }}</p>
                  <div class="project-center-card-stats ds-space-stat-row" role="group" aria-label="工作台统计，每项可跳转对应分区">
                    <a
                      class="ds-space-stat-hit ds-space-stat-hit--materials"
                      :href="projectTabHref(p.id, 'materials')"
                      :aria-label="'资料 ' + cardMaterialCount(p.id) + ' 项，打开资料'"
                      @click.stop
                    >
                      <span class="ds-space-stat-hit__icon" aria-hidden="true"><i class="fas fa-file-lines" role="presentation"></i></span>
                      <span class="ds-space-stat-hit__num tabular-nums">{{ cardMaterialCount(p.id) }}</span>
                    </a>
                    <a
                      class="ds-space-stat-hit ds-space-stat-hit--skills"
                      :href="projectTabHref(p.id, 'templates')"
                      :aria-label="'技能 ' + cardTemplateCount(p.id) + ' 个，打开技能'"
                      @click.stop
                    >
                      <span class="ds-space-stat-hit__icon" aria-hidden="true"><i class="fas fa-diagram-project" role="presentation"></i></span>
                      <span class="ds-space-stat-hit__num tabular-nums">{{ cardTemplateCount(p.id) }}</span>
                    </a>
                    <a
                      class="ds-space-stat-hit ds-space-stat-hit--results"
                      :href="projectTabHref(p.id, 'results')"
                      :aria-label="'结果 ' + cardAnalysisResultCount(p.id) + ' 条，打开结果'"
                      @click.stop
                    >
                      <span class="ds-space-stat-hit__icon" aria-hidden="true"><i class="fas fa-file-signature" role="presentation"></i></span>
                      <span class="ds-space-stat-hit__num tabular-nums">{{ cardAnalysisResultCount(p.id) }}</span>
                    </a>
                  </div>
                  <div class="ds-card-foot" @click.stop>
                    <a-button class="ds-trigger-btn ds-trigger-btn--icon-text" @click.stop="$emit('open-detail', p.id)">
                      <i class="fas fa-play ds-trigger-btn__icon" aria-hidden="true"></i><span class="ds-trigger-btn__text">继续审计</span>
                    </a-button>
                  </div>
                </div>
              </div>
            </a-col>
          </a-row>
          </div>
          <div v-if="!filteredProjectList.length" class="ds-page-empty-block ds-page-empty-block--l1">
            <a-empty :description="emptyDescription" />
            <template v-if="projectTotalCount === 0">
              <a-button type="primary" size="large" class="ds-btn-page-cta" @click="$emit('create-space')"><i class="fas fa-plus ds-btn-icon-before"></i>创建工作台</a-button>
            </template>
            <template v-else-if="(projectListSearch || '').trim()">
              <a-button type="default" @click="$emit('clear-search')">清除搜索</a-button>
            </template>
          </div>
          </div>
      </div>
    `,
    methods: {
      onProjectSortMenuClick(info) {
        const next = info && info.key ? String(info.key) : '';
        if (!next) return;
        this.$emit('update:projectSortBy', next);
        this.projectSortDropdownOpen = false;
      },
      projectTabHref(id, tab) {
        return '#project/' + encodeURIComponent(String(id)) + '?tab=' + String(tab);
      },
    },
    computed: {
      currentProjectSortLabel() {
        const list = this.projectSortOptions || [];
        const hit = list.find((opt) => String(opt.value) === String(this.projectSortBy || ''));
        return hit ? hit.label : '排序';
      },
      isProjectSortSelected() {
        return String(this.projectSortBy || '') !== 'created_desc';
      },
    },
    data() {
      return {
        projectSortDropdownOpen: false,
      };
    },
  });
})();
