(function () {
  const app = window.__DEMO_APP;

  /**
   * 大标签（统一内容标签）：a-tag + .ds-tag.ds-tag--lg；样式见 pm-ui-prototype-kit/components/tag.md / ui/runtime-ui.css。
   */
  app.component('TagLg', {
    inheritAttrs: false,
    template: `
      <a-tag v-bind="boundAttrs" size="small" :class="rootClass">
        <slot />
      </a-tag>
    `,
    computed: {
      boundAttrs() {
        const { class: _c, ...rest } = this.$attrs;
        return rest;
      },
      rootClass() {
        const extra = this.$attrs.class;
        const base = ['ds-tag', 'ds-tag--lg'];
        return extra ? [...base, extra] : base;
      },
    },
  });

  /**
   * 小标签：variant static = 只读展示；filter = 筛选 chip（可选 count、active）。
   */
  app.component('TagSm', {
    inheritAttrs: false,
    props: {
      variant: {
        type: String,
        default: 'static',
        validator: (v) => v === 'static' || v === 'filter',
      },
      active: { type: Boolean, default: false },
      /** filter 模式下展示为 (n)，不传则不渲染计数 span */
      count: { type: [Number, String], default: undefined },
    },
    emits: ['click'],
    template: `
      <a-tag
        v-bind="passthrough"
        size="small"
        :class="rootClass"
        @click="onClick"
      >
        <slot />
        <span v-if="variant === 'filter' && count != null && count !== ''" class="skill-filter-chip-count">({{ count }})</span>
      </a-tag>
    `,
    computed: {
      rootClass() {
        const extra = this.$attrs.class;
        if (this.variant === 'filter') {
          const base = ['ds-tag', 'ds-tag--sm', 'skill-filter-chip', this.active ? 'skill-filter-chip--active' : ''];
          return extra ? [...base.filter(Boolean), extra] : base.filter(Boolean);
        }
        const base = ['ds-tag', 'ds-tag--sm', 'ds-tag--static'];
        return extra ? [...base, extra] : base;
      },
      passthrough() {
        const { class: _c, ...r } = this.$attrs;
        return r;
      },
    },
    methods: {
      onClick(e) {
        this.$emit('click', e);
      },
    },
  });
})();
