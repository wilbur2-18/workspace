(function () {
  const app = window.__DEMO_APP;

    // SettingsView
    app.component('SettingsView', {
      template: `
        <a-layout class="shell-main shell-main--sider-page">
          <AppShellSiderMenu v-model:selected-key="settingsActiveTab" :menu-items="settingsMenuItems" />
          <div class="ant-layout-content main-content-area app-shell-content-workspace">
            <div class="ds-page-card ds-card-section app-shell-content-card">
            <div class="ds-page-shell">
              <div class="ds-settings-breadcrumb">系统管理 / {{ currentSettingsTabLabel }}</div>
              <div class="ds-settings-toolbar">
                <h2 class="ds-section-title title-reset">{{ currentSettingsTabLabel }}列表</h2>
                <div class="ds-settings-toolbar-actions">
                  <a-button v-if="settingsActiveTab === 'datasource'" type="primary" size="large" class="ds-btn-page-cta" @click="datasourceFormVisible = true">+ 新建</a-button>
                  <a-button v-else type="primary" size="large" class="ds-btn-page-cta">+ 新建</a-button>
                  <a-dropdown>
                    <a-button size="small">更多 <i class="fas fa-chevron-down icon-gap-left"></i></a-button>
                    <template #overlay>
                      <a-menu>
                        <a-menu-item key="export">导出</a-menu-item>
                        <a-menu-item key="import">导入</a-menu-item>
                      </a-menu>
                    </template>
                  </a-dropdown>
                </div>
              </div>
              <div class="ds-settings-body" v-if="settingsActiveTab === 'datasource'">
                <div class="ds-card-section">
                  <a-table :columns="datasourceColumns" :data-source="datasourceList" :pagination="{ pageSize: 10, showTotal: (t) => '共 ' + t + ' 条' }" size="small" row-key="id">
                    <template #bodyCell="{ column, record }">
                      <template v-if="column.key === 'action'">
                        <a-space>
                          <a @click="datasourceFormVisible = true">编辑</a>
                          <a @click="message.success('测试连接（占位）')">测试连接</a>
                          <a class="ds-link-danger">删除</a>
                        </a-space>
                      </template>
                    </template>
                  </a-table>
                </div>
              </div>
              <div class="ds-settings-body" v-else>
                <div class="ds-card-section">
                  <div class="ds-empty-state">
                    <a-empty :description="currentSettingsPlaceholder" />
                    <p class="ds-page-meta meta-centered">具体功能以生产环境为准，此处为占位展示。</p>
                  </div>
                </div>
              </div>
              <a-modal v-model:open="datasourceFormVisible" title="数据源（占位）" width="560" :footer="null" @cancel="datasourceFormVisible = false">
                <a-form layout="vertical">
                  <a-form-item label="数据源名称"><a-input placeholder="请输入名称" /></a-form-item>
                  <a-form-item label="类型"><a-select placeholder="请选择" style="width:100%" :options="[{ label: '数据库', value: '数据库' }, { label: 'API', value: 'API' }, { label: '知识库', value: '知识库' }, { label: '数据图谱', value: '数据图谱' }]" /></a-form-item>
                  <a-form-item label="连接信息"><a-textarea placeholder="占位：连接串或配置" :rows="3" /></a-form-item>
                  <a-form-item>
                    <a-space>
                      <a-button type="primary" @click="datasourceFormVisible = false; message.success('保存成功（占位）')">保存</a-button>
                      <a-button @click="datasourceFormVisible = false">取消</a-button>
                    </a-space>
                  </a-form-item>
                </a-form>
              </a-modal>
            </div>
            </div>
          </div>
        </a-layout>
      `,
      data() {
        return {
          settingsActiveTab: 'menu',
          settingsMenuItems: [
            { key: 'menu', label: '菜单管理', icon: 'fa-bars' },
            { key: 'dept', label: '部门管理', icon: 'fa-sitemap' },
            { key: 'role', label: '角色管理', icon: 'fa-shield-halved' },
            { key: 'user', label: '用户管理', icon: 'fa-user' },
            { key: 'datasource', label: '数据源管理', icon: 'fa-plug' },
            { key: 'model', label: '模型管理', icon: 'fa-database' },
            { key: 'oauth', label: '三方登录', icon: 'fa-link' },
            { key: 'cert', label: '证书管理', icon: 'fa-certificate' }
          ],
          datasourceList: [
            { id: 'ds1', name: '主业务库', type: '数据库', connectionStatus: '正常', lastChecked: '2024-03-11 10:00', createdAt: '2024-02-01' },
            { id: 'ds2', name: '政策知识库 API', type: 'API', connectionStatus: '正常', lastChecked: '2024-03-10 18:30', createdAt: '2024-02-05' },
            { id: 'ds3', name: '审计规范知识库', type: '知识库', connectionStatus: '正常', lastChecked: '2024-03-11 09:00', createdAt: '2024-02-08' }
          ],
          datasourceFormVisible: false
        };
      },
      computed: {
        currentSettingsTabLabel() {
          const item = this.settingsMenuItems.find(m => m.key === this.settingsActiveTab);
          return item ? item.label : '';
        },
        currentSettingsPlaceholder() {
          const map = {
            menu: '菜单管理：配置系统导航菜单、图标、排序与权限标识。',
            dept: '部门管理：维护组织架构与部门层级。',
            role: '角色管理：定义角色及其权限范围。',
            user: '用户管理：管理系统用户账号与归属。',
            datasource: '数据源管理：配置数据库、API、知识库、数据图谱等数据源连接。',
            model: '模型管理：配置大模型调用与资源策略。',
            oauth: '三方登录：配置 OAuth、SSO 等第三方登录方式。',
            cert: '证书管理：管理 SSL 证书与 API 密钥。'
          };
          return map[this.settingsActiveTab] || '占位内容';
        },
        datasourceColumns() {
          return [
            { title: '数据源名称', dataIndex: 'name', key: 'name', ellipsis: true },
            { title: '类型', dataIndex: 'type', key: 'type', width: 100 },
            { title: '连接状态', dataIndex: 'connectionStatus', key: 'connectionStatus', width: 100 },
            { title: '最近校验时间', dataIndex: 'lastChecked', key: 'lastChecked', width: 160 },
            { title: '创建时间', dataIndex: 'createdAt', key: 'createdAt', width: 120 },
            { title: '操作', key: 'action', width: 220 }
          ];
        }
      },
    });

})();
