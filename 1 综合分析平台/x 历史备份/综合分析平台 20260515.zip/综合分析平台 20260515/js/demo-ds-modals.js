/**
 * pm-ui-prototype-kit 弹窗工厂（确认类）
 *
 * 真源对账：本文件的 dsConfirm.delete 与原型既有 12 处 Modal.confirm 删除点完全等价，
 * 仅做"调用口径收敛"——把分散的 12 份 { centered, title, content, okText, okType, cancelText }
 * 收敛成一处定义，后续若要改动删除弹窗的视觉/文案规则只改这里。
 *
 * 所属轮次：R1 · 工作台列表 — 修复"删除弹窗规约违反零虚构"问题（2026-04-19）
 * 接管范围：本轮先迁工作台列表的删除点（demo-cmp-project.js · onProjectCardMoreMenu）；
 *           其他页（技能/资料/结果/技能库的删除）在各自抽取轮次再迁。
 */
(function () {
  if (typeof window === 'undefined' || !window.antd) return;
  var Modal = window.antd.Modal;

  /**
   * 删除二次确认（不可逆操作的最终护栏）
   *
   * @param {Object} opts
   * @param {string} opts.subject  操作对象的称谓（如 "该工作台" / "该技能" / "该资料"）。会拼成 title。
   * @param {string} [opts.batchTitle]  当为批量删除时直接传整段标题（如 "确定删除已选 3 项资料？"）。
   *                                    传了 batchTitle 会忽略 subject。
   * @param {string} [opts.hint]   一句话补充（默认 "删除后不可恢复。"）。会作为 content。
   * @param {string} [opts.okText] 主按钮文字（默认 "删除"）。批量场景可传 "批量删除"。
   * @param {Function} opts.onOk   确认后的回调。
   * @returns {Object} antdv 返回的 Modal 实例（含 destroy / update）
   */
  function dsConfirmDelete(opts) {
    var o = opts || {};
    var title = o.batchTitle || ('确定删除' + (o.subject || '该项') + '？');
    return Modal.confirm({
      centered: true,
      title: title,
      content: o.hint || '删除后不可恢复。',
      okText: o.okText || '删除',
      okType: 'danger',
      cancelText: '取消',
      onOk: o.onOk,
      onCancel: o.onCancel,
    });
  }

  window.dsConfirm = window.dsConfirm || {};
  window.dsConfirm.delete = dsConfirmDelete;
})();
