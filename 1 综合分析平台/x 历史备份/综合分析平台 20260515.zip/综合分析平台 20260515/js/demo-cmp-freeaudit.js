(function () {
  const app = window.__DEMO_APP;
  const Modal = antd.Modal;
  const message = antd.message;

    // FreeAuditView：审计助手（hash 仍为 freeaudit，与工作台共用资料与结果 store）
    const freeauditUtils = window.__DEMO_FREEAUDIT_UTILS || {};
    const getFreeAuditQuery = freeauditUtils.getFreeAuditQuery || function () { return {}; };
    const presetSuggestions = freeauditUtils.presetSuggestions || [];
    const WORKBENCH_PROJECT_NAME_BY_ID = freeauditUtils.WORKBENCH_PROJECT_NAME_BY_ID || {};
    const SUMMARY_RESPONSE_DEMO = freeauditUtils.SUMMARY_RESPONSE_DEMO || '';
    const DEMO_RUN_SUMMARY_TEXT = freeauditUtils.DEMO_RUN_SUMMARY_TEXT || '';
    const demoToolDiffLineClass = freeauditUtils.demoToolDiffLineClass || function () { return 'nlm-tool-diff-line--ctx'; };
    const demoLinesUnifiedDiff = freeauditUtils.demoLinesUnifiedDiff || function () { return { lines: [], truncated: false }; };
    const toAnalysisTemplateShared = freeauditUtils.toAnalysisTemplateShared || function (seed) { return seed; };
    const buildWorkbenchMaterialAntTreeData = freeauditUtils.buildWorkbenchMaterialAntTreeData || function () { return { treeData: [], autoExpandKeys: [] }; };
    const buildWorkbenchAnalysisResultAntTreeData = freeauditUtils.buildWorkbenchAnalysisResultAntTreeData || function () { return { treeData: [], autoExpandKeys: [], initialExpandKeys: [] }; };
    const applyWorkbenchMaterialTreeDrop = freeauditUtils.applyWorkbenchMaterialTreeDrop || function () { return { ok: false, message: '未实现' }; };
    const applyWorkbenchAnalysisResultTreeDrop = freeauditUtils.applyWorkbenchAnalysisResultTreeDrop || function () { return { ok: false, message: '未实现' }; };
    const wbMatMaterialPathPrefixForRow = freeauditUtils.wbMatMaterialPathPrefixForRow || function () { return ''; };
    const wbMatAntTreeKey = freeauditUtils.wbMatAntTreeKey || function (k, id) { return `${k}:${id}`; };
    /** 侧栏「添加库表」可选数据源（与工作台已无添加的扁平表列表分离，避免两边重复同步） */
    const DEMO_WORKBENCH_DB_CATALOGS = Object.freeze([
      {
        id: 'db-1',
        nameEn: 'fiscal_payment',
        name: '财政支付库',
        source: '核心业务库',
        owner: '数据中心',
        updatedAt: '2026-05-06 09:30:00',
        tables: Object.freeze([
          { name: 'payment_order', comment: '财政集中支付主单', rowCount: 124600, ddl: 'CREATE TABLE payment_order (id bigint, amount decimal(16,2), dept_name varchar(128));' },
          { name: 'payment_detail', comment: '支付明细与科目拆分', rowCount: 982000, ddl: 'CREATE TABLE payment_detail (order_id bigint, item_name varchar(128), amount decimal(16,2));' },
        ]),
      },
      {
        id: 'db-2',
        nameEn: 'contract_execution',
        name: '合同执行库',
        source: '合同管理系统',
        owner: '审计组A',
        updatedAt: '2026-05-05 15:20:00',
        tables: Object.freeze([
          { name: 'contract_main', comment: '合同主数据与履约状态', rowCount: 18630, ddl: 'CREATE TABLE contract_main (contract_no varchar(64), vendor_name varchar(128), signed_at datetime);' },
        ]),
      },
    ]);
    app.component('FreeAuditView', {
      emits: ['navigate'],
      template: `<a-layout class="shell-main shell-main-flex-col freeaudit-view"><a-layout-content class="content-reset-flex-col">
            <div class="nlm-main nlm-main-shell">
          <div v-if="toastMessage" class="nlm-toast">{{ toastMessage }}</div>
          <div v-if="citationPopover.show" class="nlm-extract-citation-popover" :style="{ left: citationPopover.x + 'px', top: citationPopover.y + 'px' }" @mouseenter="onCitationPopoverEnter" @mouseleave="onExtractCitationLeave">
            <div class="nlm-extract-citation-popover-title">{{ citationPopover.title || '原文' }}</div>
            <div class="nlm-extract-citation-popover-content">{{ citationPopover.excerpt }}</div>
          </div>
          <div v-if="sourcesLeftFullscreen" class="nlm-fullscreen-overlay">
            <button class="close-btn" @click="sourcesLeftFullscreen = false; fullscreenMaterialId = null; fullscreenLeftView = 'list'; fullscreenSelectedSourceId = null; fullscreenExcerptRefs = {}; fullscreenOriginalHighlight = null; fullscreenOriginalPageRefs = {}; fullscreenOriginalRowRefs = {}"><i class="fas fa-times"></i></button>
            <h2 v-if="fullscreenMaterial" class="nlm-heading-reset">{{ fullscreenMaterial.title }}</h2>
            <div v-if="fullscreenMaterial && fullscreenMaterial.type === 'raw'" class="nlm-fullscreen-raw-single nlm-fill-scroll">
              <div v-if="(fullscreenMaterial.rawSubtype || 'document') === 'document' && fullscreenMaterial.originalView && fullscreenMaterial.originalView.pages" class="nlm-original-doc-view nlm-fill-scroll">
                <div v-for="(page, pi) in fullscreenMaterial.originalView.pages" :key="pi" :class="['nlm-original-doc-page', { 'nlm-original-doc-page-highlight': fullscreenOriginalHighlight && fullscreenOriginalHighlight.pageIndex === pi }]" :ref="el => setFullscreenOriginalPageRef(pi, el)">{{ page }}</div>
              </div>
              <div v-else-if="(fullscreenMaterial.rawSubtype || 'document') === 'table' && fullscreenMaterial.originalView && fullscreenMaterial.originalView.headers" class="nlm-original-table-wrap nlm-fill-scroll">
                <table class="nlm-original-table">
                  <thead><tr><th v-for="(h, hi) in fullscreenMaterial.originalView.headers" :key="hi">{{ h }}</th></tr></thead>
                  <tbody><tr v-for="(row, ri) in (fullscreenMaterial.originalView.rows || [])" :key="ri" :class="{ 'nlm-original-row-highlight': fullscreenOriginalHighlight && fullscreenOriginalHighlight.rowIndex === ri }" :ref="el => setFullscreenOriginalRowRef(ri, el)"><td v-for="(cell, ci) in row" :key="ci">{{ cell }}</td></tr></tbody>
                </table>
              </div>
              <div v-else class="nlm-source-read nlm-fill-scroll">
                <div v-for="(ex, i) in (fullscreenMaterial.excerpts || [])" :key="i" class="excerpt">{{ ex }}</div>
              </div>
            </div>
            <div v-else-if="fullscreenMaterial && ['analysis','report'].includes(fullscreenMaterial.type)" class="nlm-dual-column nlm-dual-column-fill" ref="fullscreenAnalysisContainer">
              <div v-if="fullscreenSourceMaterials.length" class="col nlm-col-flex nlm-col-flex-wide">
                <div v-if="fullscreenLeftView === 'list'" class="nlm-fill-hidden-col">
                  <h4>依据资料</h4>
                  <div class="nlm-fill-scroll">
                    <div v-for="sm in fullscreenSourceMaterials" :key="sm.id" :class="['nlm-source-item', 'nlm-source-item-soft', { selected: fullscreenSelectedSourceId === sm.id }]" @click="fullscreenSelectedSourceId = sm.id; fullscreenLeftView = 'detail'">
                      <span class="type-icon"><i class="fas" :class="getMaterialIcon(sm)"></i></span>
                      <span class="title">{{ sm.title }}</span>
                    </div>
                  </div>
                </div>
                <div v-else class="nlm-fill-hidden-col">
                  <div class="back-row nlm-back-row-compact">
                    <button type="button" class="back-btn back-btn--icon-only" title="返回列表" aria-label="返回列表" @click="fullscreenLeftView = 'list'"><i class="fas fa-arrow-left" aria-hidden="true"></i></button>
                  </div>
                  <div v-if="fullscreenSelectedSource" class="nlm-fill-hidden-col">
                    <h4 class="nlm-source-title">{{ fullscreenSelectedSource.title }}</h4>
                    <div class="nlm-source-read nlm-fill-scroll">
                      <div v-for="(ex, i) in (fullscreenSelectedSource.excerpts || [])" :key="i" :class="['excerpt', { highlight: fullscreenHighlightSourceId === fullscreenSelectedSource.id && fullscreenHighlightExcerptIndex === i }]" :ref="el => setFullscreenExcerptRef(fullscreenSelectedSource.id, i, el)">{{ ex }}</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col" :style="fullscreenSourceMaterials.length ? 'flex: 2;' : 'flex: 1;'">
                <h4>{{ fullscreenMaterial.type === 'analysis' ? '结果' : '报告' }}</h4>
                <div class="nlm-source-read" v-html="renderFullscreenAnalysisContent(fullscreenMaterial)" @click="handleFullscreenCitationClick($event)"></div>
              </div>
            </div>
          </div>
          <header class="workbench-top-header workbench-top-header--unified workbench-top-header--project-detail">
                  <div class="workbench-top-header__left workbench-top-header__left--with-pane-toggle">
                    <a-button type="text" class="ds-icon-btn workbench-back-text-btn" title="返回工作台" aria-label="返回工作台" @click="goBackToProjectCenterList">
                      <i class="fas fa-arrow-left workbench-back-icon" aria-hidden="true"></i>
                    </a-button>
                    <a-button
                      type="text"
                      class="ds-icon-btn workbench-left-pane-toggle-btn"
                      :title="sourcesCollapsed ? '展开左栏（资源 / 技能）' : '收起左栏（资源 / 技能）'"
                      :aria-label="sourcesCollapsed ? '展开左栏' : '收起左栏'"
                      :aria-expanded="sourcesCollapsed ? 'false' : 'true'"
                      @click="sourcesCollapsed = !sourcesCollapsed"
                    >
                      <i class="fas fa-table-columns workbench-left-pane-toggle-icon" aria-hidden="true"></i>
                    </a-button>
                  </div>
                  <div class="workbench-top-header__center-title-wrap">
                    <div class="workbench-top-header__title-with-mode">
                      <template v-if="workbenchProjectId">
                        <div class="workbench-top-header__title-cluster">
                          <span class="workbench-top-header__title-kicker" aria-label="工作台" title="工作台">
                            <span class="ds-page-hero__title-icon ds-page-hero__title-icon--audit-space" aria-hidden="true"><i class="fas fa-cube"></i></span>
                          </span>
                                    <span class="workbench-top-header__title-name" :title="'工作台 · ' + workbenchPageHeadTitle">{{ workbenchPageHeadTitle }}</span>
                        </div>
                      </template>
                      <span v-else class="workbench-top-header__title workbench-top-header__title--solo" :title="workbenchPageHeadTitle">{{ workbenchPageHeadTitle }}</span>
                    </div>
                  </div>
                  <div class="workbench-top-header__actions">
                    <a-button
                      type="text"
                      class="ds-icon-btn workbench-right-pane-toggle-btn"
                      :title="studioCollapsed ? '展开右栏（结果）' : '收起右栏（结果）'"
                      :aria-label="studioCollapsed ? '展开右栏' : '收起右栏'"
                      :aria-expanded="studioCollapsed ? 'false' : 'true'"
                      @click="studioCollapsed = !studioCollapsed"
                    >
                      <i class="fas fa-table-columns workbench-right-pane-toggle-icon" aria-hidden="true"></i>
                    </a-button>
                    <a-dropdown :trigger="['click']" placement="bottomRight" :disabled="!workbenchProjectId">
                      <a-button
                        type="text"
                        size="small"
                        class="ds-icon-btn workbench-project-gear-btn"
                        title="工作台操作"
                        aria-label="工作台操作菜单"
                        :disabled="!workbenchProjectId"
                      >
                        <i class="fas fa-ellipsis" aria-hidden="true"></i>
                      </a-button>
                      <template #overlay>
                        <a-menu @click="onWorkbenchHeaderMenu">
                          <a-menu-item key="edit">编辑</a-menu-item>
                        </a-menu>
                      </template>
                    </a-dropdown>
                  </div>
          </header>
          <div ref="mainBody" class="workbench-body">
            <aside class="workbench-rail workbench-rail--sources" :style="leftWorkbenchRailStyle">
              <div
                v-show="!sourcesCollapsed"
                class="nlm-side-panel"
              >
                <div class="nlm-panel-header">
                  <div class="nlm-panel-title-row">
                    <a-segmented
                      v-model:value="workbenchLeftPrimaryTab"
                      class="ds-ant-segmented ds-ant-segmented--compact nlm-pool-tab-bar"
                      size="small"
                      :options="[
                        { label: '资源', value: 'material' },
                        { label: '技能', value: 'skill' },
                      ]"
                      aria-label="左侧资源页签"
                    />
                  </div>
                </div>
                <div v-if="sourcesLeftView === 'list'" class="nlm-side-panel-body">
                  <template v-if="workbenchLeftPrimaryTab === 'material'">
                  <div class="nlm-resource-drawer-stack">
                  <section class="nlm-resource-drawer" :class="{ 'is-open': resourceDrawerOpen.file }" :style="resourceDrawerSectionStyle('file')">
                    <div class="nlm-resource-drawer__head-row">
                      <button type="button" class="nlm-resource-drawer__head nlm-resource-drawer__head--split" @click="toggleResourceDrawer('file')">
                        <span class="nlm-resource-drawer__title">
                          <i class="fas fa-chevron-right nlm-resource-drawer__chevron" aria-hidden="true"></i>
                          文件
                        </span>
                      </button>
                      <div class="nlm-material-action-row__right">
                        <template v-if="resourceDrawerOpen.file">
                          <a-tooltip :title="workbenchMaterialSearchOpen ? '收起搜索' : '展开搜索'">
                            <a-button
                              type="text"
                              class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn"
                              :title="workbenchMaterialSearchOpen ? '收起搜索' : '展开搜索'"
                              :aria-label="workbenchMaterialSearchOpen ? '收起搜索' : '展开搜索'"
                              @click="toggleWorkbenchMaterialSearchPanel"
                            >
                              <i class="fas fa-search"></i>
                            </a-button>
                          </a-tooltip>
                          <a-tooltip title="重新加载资料列表（不刷新对话）">
                            <a-button
                              type="text"
                              class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-toolbar-pool-refresh-btn"
                              :disabled="!workbenchProjectId"
                              title="重新加载资料列表（演示数据，未接真实接口）。不会刷新中间助手对话。"
                              aria-label="重新加载资料列表，不刷新对话"
                              @click="refreshWorkbenchDemoResources('material')"
                            >
                              <i class="fas fa-rotate-right" aria-hidden="true"></i>
                            </a-button>
                          </a-tooltip>
                        </template>
                        <a-dropdown :trigger="['click']" @click.stop>
                          <a-tooltip title="添加">
                            <a-button
                              type="text"
                              size="small"
                              class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-upload-primary-btn"
                              :disabled="!workbenchProjectId"
                              title="添加"
                              aria-label="添加"
                              @click.stop
                            >
                              <i class="fas fa-plus" aria-hidden="true"></i>
                            </a-button>
                          </a-tooltip>
                          <template #overlay>
                            <a-menu @click="({ key }) => onWorkbenchMaterialAddMenu(key, '')">
                              <a-menu-item key="upload-file">
                                <span class="wb-menu-action-item">
                                  <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('upload-file')" aria-hidden="true"></i>
                                  <span>上传文件</span>
                                </span>
                              </a-menu-item>
                              <a-menu-item key="new-folder">
                                <span class="wb-menu-action-item">
                                  <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('new-folder')" aria-hidden="true"></i>
                                  <span>新建文件夹</span>
                                </span>
                              </a-menu-item>
                            </a-menu>
                          </template>
                        </a-dropdown>
                      </div>
                    </div>
                    <div v-show="resourceDrawerOpen.file" :ref="(el) => setResourceDrawerBodyRef('file', el)" class="nlm-resource-drawer__body">
                  <div class="nlm-material-toolbar">
                    <div v-if="workbenchMaterialSearchOpen" class="nlm-material-query-row">
                      <a-input
                        v-model:value="materialSearchQuery"
                        allow-clear
                        placeholder="搜索文件名称"
                        class="ds-input-inline-search ds-input-inline-search--compact"
                      >
                        <template #prefix>
                          <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                        </template>
                      </a-input>
                    </div>
                  </div>
                  <div v-if="extractionResults.length" class="nlm-extraction-cards">
                    <div v-for="item in extractionResults" :key="item.id" :class="['nlm-extraction-card', item.status]">
                      <div v-if="item.status === 'loading'" class="nlm-extraction-card-loading">
                        <a-spin size="small" class="nlm-extraction-card-loading__spin" />
                        <span>正在从「{{ item.dataSourceName }}」抽取...</span>
                      </div>
                      <template v-else>
                        <div class="nlm-extraction-card-header">
                          <span class="nlm-extraction-card-title"><i class="fas fa-wand-magic-sparkles"></i> {{ item.dataSourceName }} 抽取已完成!</span>
                          <a class="nlm-extraction-card-view" @click.prevent="viewExtractionResult(item.id)">查看</a>
                        </div>
                        <div class="nlm-extraction-card-body">
                          <div v-for="(sn, si) in (item.snippets || []).slice(0, 3)" :key="si" class="nlm-extraction-snippet">
                            <span class="nlm-extraction-snippet-title">{{ sn.title }}</span>
                            <p class="nlm-extraction-snippet-desc">{{ sn.desc }}</p>
                          </div>
                          <p v-if="(item.snippets || []).length > 3" class="nlm-extraction-more">另外 {{ (item.snippets || []).length - 3 }} 个来源</p>
                        </div>
                        <div class="nlm-extraction-card-footer">
                          <a class="nlm-extraction-card-delete" @click.prevent="removeExtractionResult(item.id)">删除</a>
                          <button type="button" class="nlm-extraction-card-import" @click="importExtractionResult(item)"><i class="fas fa-plus"></i> 导入</button>
                        </div>
                      </template>
                    </div>
                  </div>
                  <div v-if="workbenchShouldShowMaterialStatusFooter" class="wb-material-status-footer wb-material-status-footer--file-pool ds-popover-panel__footer">
                    <div class="wb-material-status-footer__right" :class="{ 'wb-material-status-footer__right--running': workbenchRawMaterialFlowBorderActive }">
                      <div class="wb-material-status-footer__stats" aria-label="资料解析状态摘要">
                        <button type="button" :class="['ds-trigger-btn nlm-chat-result-toolbar-btn', { 'is-active': workbenchMaterialStatusView === 'queued' }]" @click.stop="setWorkbenchMaterialStatusView('queued')">
                          <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--queued">排队中<span class="wb-status-chip__count">{{ workbenchRawMaterialStatusSummary.queued }}</span></span>
                        </button>
                        <button type="button" :class="['ds-trigger-btn nlm-chat-result-toolbar-btn', { 'is-active': workbenchMaterialStatusView === 'parsing' }]" @click.stop="setWorkbenchMaterialStatusView('parsing')">
                          <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--parsing">解析中<span class="wb-status-chip__count">{{ workbenchRawMaterialStatusSummary.parsing }}</span></span>
                        </button>
                        <button type="button" :class="['ds-trigger-btn nlm-chat-result-toolbar-btn', { 'is-active': workbenchMaterialStatusView === 'failed' }]" @click.stop="setWorkbenchMaterialStatusView('failed')">
                          <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--failed">失败<span class="wb-status-chip__count">{{ workbenchRawMaterialStatusSummary.failed }}</span></span>
                        </button>
                      </div>
                    </div>
                  </div>
                  <div v-if="workbenchMaterialStatusView !== 'all'" class="wb-material-list-top-actions">
                    <a-button
                      type="text"
                      class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn wb-material-status-footer__back-btn"
                      title="返回全部文件"
                      aria-label="返回全部文件"
                      @click="resetWorkbenchMaterialStatusView"
                    >
                      <i class="fas fa-arrow-left" aria-hidden="true"></i>
                    </a-button>
                    <div class="wb-material-list-top-actions__batch" v-if="workbenchMaterialBatchTargetCount > 0">
                      <a-button
                        v-if="workbenchMaterialStatusView === 'parsing'"
                        type="text"
                        class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn wb-material-status-footer__back-btn"
                        title="一键中止"
                        aria-label="一键中止"
                        @click.stop="batchAbortWorkbenchMaterials"
                      ><i class="fas fa-stop" aria-hidden="true"></i></a-button>
                      <a-button
                        v-if="workbenchMaterialStatusView === 'parsing' || workbenchMaterialStatusView === 'failed'"
                        type="text"
                        class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn wb-material-status-footer__back-btn"
                        title="一键重跑"
                        aria-label="一键重跑"
                        @click.stop="batchRerunWorkbenchMaterials"
                      ><i class="fas fa-rotate-right" aria-hidden="true"></i></a-button>
                      <a-button
                        type="text"
                        class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm ds-icon-btn--danger nlm-input-bar-btn wb-material-status-footer__back-btn"
                        title="一键删除"
                        aria-label="一键删除"
                        @click.stop="batchClearWorkbenchMaterials"
                      ><i class="fas fa-trash" aria-hidden="true"></i></a-button>
                    </div>
                  </div>
                  <div class="nlm-fill-scroll wb-material-file-drawer" @mouseleave="hoveredMaterialId = null" @click="onMaterialListAreaClick($event)">
                    <div class="nlm-cards-wrap nlm-tree-wrap">
                      <template v-if="workbenchMaterialStatusView === 'all'">
                        <a-tree
                          v-if="workbenchMaterialFileTreeData.length"
                          class="wb-material-file-tree"
                          block-node
                          :show-line="{ showLeafIcon: false }"
                          :show-icon="false"
                          :tree-data="workbenchMaterialFileTreeData"
                          v-model:expanded-keys="workbenchFileTreeExpandedKeys"
                          draggable
                          @drop="onWorkbenchMaterialFileTreeDrop"
                        >
                          <template #switcherIcon><span aria-hidden="true"></span></template>
                          <template #title="d">
                            <a-dropdown v-if="d.isFolder" :trigger="['contextmenu']" @click.stop>
                              <div
                                :class="['nlm-tree-leaf', 'nlm-tree-leaf--folder']"
                                @click.stop="onWorkbenchMaterialFolderRowClick(d)"
                              >
                                <span class="nlm-tree-leaf-icon nlm-tree-leaf-icon--folder-toggle" aria-hidden="true">
                                  <i
                                    class="fas fa-chevron-right nlm-resource-drawer__chevron wb-material-file-tree-switcher-chev"
                                    :class="{ 'wb-material-file-tree-switcher-chev--expanded': workbenchFileTreeExpandedKeys.includes(String(d.key)) }"
                                  ></i>
                                </span>
                                <div class="nlm-tree-leaf-title-wrap">
                                  <div class="nlm-tree-leaf-col">
                                    <div class="nlm-tree-leaf-title">{{ d.title }}</div>
                                  </div>
                                </div>
                                <span class="nlm-tree-leaf-right">
                                  <div class="nlm-tree-leaf-actions">
                                    <a-dropdown :trigger="['click']" @click.stop>
                                      <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="文件夹操作" aria-label="文件夹操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                      <template #overlay>
                                        <a-menu @click="({ key }) => onWorkbenchMaterialFolderMenu(key, d)">
                                          <a-menu-item key="upload-file">
                                            <span class="wb-menu-action-item">
                                              <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('upload-file')" aria-hidden="true"></i>
                                              <span>上传文件</span>
                                            </span>
                                          </a-menu-item>
                                          <a-menu-item key="new-folder">
                                            <span class="wb-menu-action-item">
                                              <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('new-folder')" aria-hidden="true"></i>
                                              <span>新建文件夹</span>
                                            </span>
                                          </a-menu-item>
                                          <a-menu-divider />
                                          <a-menu-item key="rename">重命名</a-menu-item>
                                          <a-menu-item key="delete" danger>删除</a-menu-item>
                                        </a-menu>
                                      </template>
                                    </a-dropdown>
                                    <a-button
                                      type="text"
                                      class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                      :title="workbenchMaterialFolderChatRefMenuLabel(d)"
                                      :aria-label="workbenchMaterialFolderChatRefMenuLabel(d)"
                                      @click.stop="onWorkbenchMaterialFolderMenu('ref', d)"
                                    ><i class="fas fa-comment-medical"></i></a-button>
                                  </div>
                                </span>
                              </div>
                              <template #overlay>
                                <a-menu @click="({ key }) => onWorkbenchFileTreeFolderContextMenu(key, d)">
                                  <a-menu-item key="upload-file">
                                    <span class="wb-menu-action-item">
                                      <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('upload-file')" aria-hidden="true"></i>
                                      <span>上传文件</span>
                                    </span>
                                  </a-menu-item>
                                  <a-menu-item key="new-folder">
                                    <span class="wb-menu-action-item">
                                      <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('new-folder')" aria-hidden="true"></i>
                                      <span>新建文件夹</span>
                                    </span>
                                  </a-menu-item>
                                  <a-menu-divider />
                                  <a-menu-item key="ref">
                                    <span class="wb-menu-action-item">
                                      <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('ref')" aria-hidden="true"></i>
                                      <span>{{ workbenchMaterialFolderChatRefMenuLabel(d) }}</span>
                                    </span>
                                  </a-menu-item>
                                  <a-menu-divider />
                                  <a-menu-item key="rename">重命名</a-menu-item>
                                  <a-menu-item key="delete" danger>删除</a-menu-item>
                                </a-menu>
                              </template>
                            </a-dropdown>
                            <a-dropdown v-else :trigger="['contextmenu']" @click.stop>
                              <div
                                :class="['nlm-tree-leaf', { checked: isWorkbenchFileTreeRawSelected(d) }]"
                                @click.stop="onWorkbenchMaterialFileTreeRawClick(d)"
                              >
                                <span class="nlm-tree-leaf-icon">
                                  <i
                                    class="fas"
                                    :class="[getMaterialIcon(wbWorkbenchMaterialVmForTreeFile(d)), getMaterialIconColorClass(wbWorkbenchMaterialVmForTreeFile(d))]"
                                    aria-hidden="true"
                                  ></i>
                                </span>
                                <div class="nlm-tree-leaf-title-wrap">
                                  <div class="nlm-tree-leaf-col">
                                    <div class="nlm-tree-leaf-title" @click.stop="openWorkbenchFileTreeRawDetail(d)">{{ (wbMaterialVmById(d.materialId) || {}).title }}</div>
                                  </div>
                                </div>
                                <span class="nlm-tree-leaf-right">
                                  <div class="nlm-tree-leaf-actions">
                                    <a-dropdown :trigger="['click']" @click.stop>
                                      <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                      <template #overlay>
                                        <a-menu @click="(info) => onWorkbenchFileTreeRawMenu(info && info.key, d)">
                                          <a-menu-item key="download">下载</a-menu-item>
                                          <a-menu-divider />
                                          <a-menu-item key="rename">重命名</a-menu-item>
                                          <a-menu-item key="delete" danger>删除</a-menu-item>
                                        </a-menu>
                                      </template>
                                    </a-dropdown>
                                    <a-button
                                      type="text"
                                      class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                      title="添加到对话"
                                      aria-label="添加到对话"
                                      @click.stop="onWorkbenchFileTreeRawToggleRef(d)"
                                    ><i class="fas fa-comment-medical"></i></a-button>
                                  </div>
                                </span>
                              </div>
                              <template #overlay>
                                <a-menu @click="(info) => onWorkbenchFileTreeRawMenu(info && info.key, d)">
                                  <a-menu-item key="ref">
                                    <span class="wb-menu-action-item">
                                      <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('ref')" aria-hidden="true"></i>
                                      <span>添加到对话</span>
                                    </span>
                                  </a-menu-item>
                                  <a-menu-item key="download">下载</a-menu-item>
                                  <a-menu-divider />
                                  <a-menu-item key="rename">重命名</a-menu-item>
                                  <a-menu-item key="delete" danger>删除</a-menu-item>
                                </a-menu>
                              </template>
                            </a-dropdown>
                          </template>
                        </a-tree>
                        <a-empty v-else class="wb-material-file-tree-empty" description="暂无解析完成的文件" />
                      </template>
                      <template v-else>
                        <template v-for="section in workbenchLeftTreeSections" :key="section.key">
                          <div class="nlm-tree-children">
                            <a-dropdown v-for="node in section.children" :key="node.id" :trigger="['contextmenu']" @click.stop>
                              <div :class="['nlm-tree-leaf', { 'nlm-tree-leaf--analysis': section.key === 'analysis', 'nlm-source-item-loading': node.raw.loading, checked: isTreeNodeSelected(node, section.key), 'is-status-view': workbenchMaterialStatusView !== 'all' && section.key === 'material' }]" draggable="true" @click="selectTreeNode(node, section.key)" @dragstart="onTreeLeafDragStart($event, node, section.key)">
                                <span class="nlm-tree-leaf-icon">
                                  <i
                                    v-if="section.key === 'material' && workbenchMaterialStatusOf(node.raw) === 'queued'"
                                    class="fas fa-clock is-status-queued"
                                  ></i>
                                  <span
                                    v-else-if="section.key === 'material' && workbenchMaterialStatusOf(node.raw) === 'parsing'"
                                    class="nlm-tree-leaf-progress-ring-real is-status-pending"
                                    :style="{ '--nlm-progress': workbenchMaterialProgressOf(node.raw) + '%' }"
                                    :title="'解析中 ' + Math.round(workbenchMaterialProgressOf(node.raw)) + '%'"
                                    aria-hidden="true"
                                  ></span>
                                  <i
                                    v-else-if="section.key === 'material' && workbenchMaterialStatusOf(node.raw) === 'failed'"
                                    class="fas fa-xmark is-status-failed"
                                  ></i>
                                  <i
                                    v-else-if="section.key === 'analysis' && workbenchAnalysisStatusOf(node.raw) === 'queued'"
                                    class="fas fa-clock is-status-queued"
                                  ></i>
                                  <i
                                    v-else-if="section.key === 'analysis' && workbenchAnalysisStatusOf(node.raw) === 'parsing'"
                                    class="fas fa-circle-notch fa-spin is-status-pending nlm-tree-leaf-progress-ring"
                                    aria-hidden="true"
                                  ></i>
                                  <i
                                    v-else-if="section.key === 'analysis' && workbenchAnalysisStatusOf(node.raw) === 'failed'"
                                    class="fas fa-xmark is-status-failed"
                                  ></i>
                                  <a-spin v-else-if="node.raw.loading" size="small" class="nlm-tree-leaf-spin" />
                                  <i v-else class="fas" :class="[getMaterialIcon(node.raw), getMaterialIconColorClass(node.raw)]"></i>
                                </span>
                                <div class="nlm-tree-leaf-title-wrap">
                                  <div class="nlm-tree-leaf-col">
                                    <div class="nlm-tree-leaf-title" :class="{ 'is-muted': (section.key === 'material' && ['queued', 'parsing', 'failed'].includes(workbenchMaterialStatusOf(node.raw))) || (section.key === 'analysis' && ['queued', 'parsing', 'failed'].includes(workbenchAnalysisStatusOf(node.raw))) }" @click.stop="openDetailFromTreeTitle(node, section.key)">{{ node.raw.title }}</div>
                                  </div>
                                </div>
                                <span class="nlm-tree-leaf-right">
                                  <div class="nlm-tree-leaf-actions">
                                    <template v-if="workbenchMaterialStatusView !== 'all' && section.key === 'material'">
                                      <a-button
                                        v-if="workbenchMaterialStatusView === 'parsing'"
                                        type="text"
                                        class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                        title="中止"
                                        aria-label="中止"
                                        @click.stop="abortWorkbenchMaterial(node.raw)"
                                      ><i class="fas fa-stop"></i></a-button>
                                      <a-button
                                        v-if="workbenchMaterialStatusView === 'parsing' || workbenchMaterialStatusView === 'failed'"
                                        type="text"
                                        class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                        title="重跑"
                                        aria-label="重跑"
                                        @click.stop="rerunWorkbenchMaterial(node.raw)"
                                      ><i class="fas fa-rotate-right"></i></a-button>
                                      <a-button
                                        type="text"
                                        class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                        title="删除"
                                        aria-label="删除"
                                        @click.stop="deleteMaterial(node.raw)"
                                      ><i class="fas fa-xmark"></i></a-button>
                                    </template>
                                    <template v-else>
                                      <a-dropdown :trigger="['click']" @click.stop>
                                        <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                        <template #overlay>
                                          <a-menu v-if="workbenchMaterialStatusView !== 'all' && section.key === 'material'" @click="({ key }) => onWorkbenchMaterialStatusListContextMenu(key, node.raw)">
                                            <a-menu-item v-if="workbenchMaterialStatusView === 'parsing'" key="abort">中止</a-menu-item>
                                            <a-menu-item v-if="workbenchMaterialStatusView === 'parsing' || workbenchMaterialStatusView === 'failed'" key="rerun">重跑</a-menu-item>
                                            <a-menu-divider v-if="workbenchMaterialStatusView === 'parsing' || workbenchMaterialStatusView === 'failed'" />
                                            <a-menu-item key="delete" danger>删除</a-menu-item>
                                          </a-menu>
                                          <a-menu v-else @click="({ key }) => handleTreeContextMenu(key, node, section.key)">
                                            <a-menu-item v-if="section.key === 'material' && workbenchMaterialStatusOf(node.raw) !== 'done'" key="rerun">重跑</a-menu-item>
                                            <a-menu-item v-if="section.key === 'material'" key="download">下载</a-menu-item>
                                            <a-sub-menu v-if="section.key === 'analysis'" key="export-analysis-sub" title="下载">
                                              <a-menu-item key="export-md">下载为 Markdown</a-menu-item>
                                              <a-menu-item key="export-pdf">下载为 PDF</a-menu-item>
                                              <a-menu-item key="export-docx">下载为 Word</a-menu-item>
                                            </a-sub-menu>
                                            <a-menu-divider />
                                            <a-menu-item key="rename">重命名</a-menu-item>
                                            <a-menu-item key="delete" danger>删除</a-menu-item>
                                          </a-menu>
                                        </template>
                                      </a-dropdown>
                                      <a-button
                                        type="text"
                                        class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                        title="添加到对话"
                                        aria-label="添加到对话"
                                        @click.stop="handleTreeContextMenu('ref', node, section.key)"
                                      ><i class="fas fa-comment-medical"></i></a-button>
                                    </template>
                                  </div>
                                </span>
                              </div>
                              <template #overlay>
                                <a-menu v-if="workbenchMaterialStatusView !== 'all' && section.key === 'material'" @click="({ key }) => onWorkbenchMaterialStatusListContextMenu(key, node.raw)">
                                  <a-menu-item v-if="workbenchMaterialStatusView === 'parsing'" key="abort">中止</a-menu-item>
                                  <a-menu-item v-if="workbenchMaterialStatusView === 'parsing' || workbenchMaterialStatusView === 'failed'" key="rerun">重跑</a-menu-item>
                                  <a-menu-divider v-if="workbenchMaterialStatusView === 'parsing' || workbenchMaterialStatusView === 'failed'" />
                                  <a-menu-item key="delete" danger>删除</a-menu-item>
                                </a-menu>
                                <a-menu v-else @click="({ key }) => handleTreeContextMenu(key, node, section.key)">
                                  <a-menu-item key="ref">
                                    <span class="wb-menu-action-item">
                                      <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('ref')" aria-hidden="true"></i>
                                      <span>添加到对话</span>
                                    </span>
                                  </a-menu-item>
                                  <a-menu-item v-if="section.key === 'material' && workbenchMaterialStatusOf(node.raw) !== 'done'" key="rerun">重跑</a-menu-item>
                                  <a-menu-item v-if="section.key === 'material'" key="download">下载</a-menu-item>
                                  <a-sub-menu v-if="section.key === 'analysis'" key="export-analysis-sub-ctx" title="下载">
                                    <a-menu-item key="export-md">下载为 Markdown</a-menu-item>
                                    <a-menu-item key="export-pdf">下载为 PDF</a-menu-item>
                                    <a-menu-item key="export-docx">下载为 Word</a-menu-item>
                                  </a-sub-menu>
                                  <a-menu-divider />
                                  <a-menu-item key="rename">重命名</a-menu-item>
                                  <a-menu-item key="delete" danger>删除</a-menu-item>
                                </a-menu>
                              </template>
                            </a-dropdown>
                          </div>
                        </template>
                      </template>
                    </div>
                  </div>
                    </div>
                  </section>
                  <section class="nlm-resource-drawer" :class="{ 'is-open': resourceDrawerOpen.database }" :style="resourceDrawerSectionStyle('database')">
                    <div class="nlm-resource-drawer__head-row">
                      <button type="button" class="nlm-resource-drawer__head nlm-resource-drawer__head--split" @click="toggleResourceDrawer('database')">
                        <span class="nlm-resource-drawer__title">
                          <i class="fas fa-chevron-right nlm-resource-drawer__chevron" aria-hidden="true"></i>
                          数据库
                        </span>
                      </button>
                      <div class="nlm-material-action-row__right">
                        <template v-if="resourceDrawerOpen.database">
                          <a-tooltip :title="workbenchDbSearchOpen ? '收起搜索' : '展开搜索'">
                            <a-button
                              type="text"
                              class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn"
                              :title="workbenchDbSearchOpen ? '收起搜索' : '展开搜索'"
                              :aria-label="workbenchDbSearchOpen ? '收起搜索' : '展开搜索'"
                              @click="toggleWorkbenchDbSearchPanel"
                            >
                              <i class="fas fa-search"></i>
                            </a-button>
                          </a-tooltip>
                        </template>
                        <a-tooltip title="添加库表">
                          <a-button
                            type="text"
                            size="small"
                            class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-upload-primary-btn"
                            title="添加库表"
                            aria-label="添加库表"
                            @click="openWorkbenchDbAddModal"
                          >
                            <i class="fas fa-plus" aria-hidden="true"></i>
                          </a-button>
                        </a-tooltip>
                      </div>
                    </div>
                    <div v-show="resourceDrawerOpen.database" :ref="(el) => setResourceDrawerBodyRef('database', el)" class="nlm-resource-drawer__body">
                      <div class="nlm-material-toolbar">
                        <div v-if="workbenchDbSearchOpen" class="nlm-material-query-row">
                          <a-input v-model:value="dbResourceSearchQuery" allow-clear placeholder="搜索库表" class="ds-input-inline-search ds-input-inline-search--compact">
                            <template #prefix><i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i></template>
                          </a-input>
                        </div>
                      </div>
                      <div class="nlm-fill-scroll">
                        <div class="nlm-cards-wrap nlm-tree-wrap">
                          <div class="nlm-tree-children">
                            <div v-if="!filteredDatabaseResources.length" class="nlm-empty-state nlm-db-table-empty">
                              <p class="nlm-empty-desc">暂无数据表，点击右上角「+」添加。</p>
                            </div>
                            <template v-else>
                              <section
                                v-for="grp in filteredDatabaseResourceGroups"
                                :key="grp.databaseId"
                                class="nlm-db-table-group"
                                :aria-label="'数据源：' + grp.databaseName"
                              >
                                <a-dropdown :trigger="['contextmenu']" @click.stop>
                                  <div
                                    class="nlm-tree-leaf nlm-db-table-group__head-row"
                                    :class="{ 'is-expanded': isWorkbenchDbTableGroupExpanded(grp.databaseId) }"
                                  >
                                    <div
                                      class="nlm-db-table-group__head-main"
                                      role="button"
                                      tabindex="0"
                                      :aria-expanded="isWorkbenchDbTableGroupExpanded(grp.databaseId) ? 'true' : 'false'"
                                      :aria-label="'展开或收起：' + grp.databaseName"
                                      @click.stop="toggleWorkbenchDbTableGroup(grp.databaseId)"
                                      @keydown.enter.prevent="toggleWorkbenchDbTableGroup(grp.databaseId)"
                                      @keydown.space.prevent="toggleWorkbenchDbTableGroup(grp.databaseId)"
                                    >
                                      <span class="nlm-db-table-group__chev" aria-hidden="true"><i class="fas fa-chevron-right nlm-resource-drawer__chevron"></i></span>
                                      <span class="nlm-db-table-group__name">{{ grp.databaseName }}</span>
                                    </div>
                                    <span class="nlm-tree-leaf-right">
                                      <div class="nlm-tree-leaf-actions">
                                        <a-dropdown :trigger="['click']" @click.stop>
                                          <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                          <template #overlay>
                                            <a-menu @click="({ key }) => onWorkbenchDbCatalogMoreMenu(key, grp)">
                                              <a-menu-item key="remove-catalog" danger>删除</a-menu-item>
                                            </a-menu>
                                          </template>
                                        </a-dropdown>
                                        <a-button
                                          type="text"
                                          class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                          title="添加到对话"
                                          aria-label="添加到对话"
                                          @click.stop="onWorkbenchDbCatalogContextMenu('chat', grp)"
                                        ><i class="fas fa-comment-medical"></i></a-button>
                                      </div>
                                    </span>
                                  </div>
                                  <template #overlay>
                                    <a-menu @click="({ key }) => onWorkbenchDbCatalogContextMenu(key, grp)">
                                      <a-menu-item key="chat">
                                        <span class="wb-menu-action-item">
                                          <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('chat')" aria-hidden="true"></i>
                                          <span>添加到对话</span>
                                        </span>
                                      </a-menu-item>
                                      <a-menu-item key="remove-catalog" danger>删除</a-menu-item>
                                    </a-menu>
                                  </template>
                                </a-dropdown>
                                <div v-show="isWorkbenchDbTableGroupExpanded(grp.databaseId)" class="nlm-db-table-group__body">
                                  <a-dropdown v-for="tbl in grp.tables" :key="tbl.id" :trigger="['contextmenu']" @click.stop>
                                    <div class="nlm-tree-leaf nlm-tree-leaf--db-table-item" @click.prevent="previewDbTableResource(tbl)">
                                      <span class="nlm-tree-leaf-icon"><i class="fas fa-table"></i></span>
                                      <div class="nlm-tree-leaf-title-wrap">
                                        <div class="nlm-tree-leaf-col">
                                          <div class="nlm-tree-leaf-title" :title="(tbl.comment && String(tbl.comment).trim()) ? String(tbl.comment).trim() : (tbl.tableName || tbl.name || '')">{{ (tbl.comment && String(tbl.comment).trim()) ? String(tbl.comment).trim() : (tbl.tableName || tbl.name || '') }}</div>
                                        </div>
                                      </div>
                                      <span class="nlm-tree-leaf-right">
                                        <div class="nlm-tree-leaf-actions">
                                          <a-dropdown :trigger="['click']" @click.stop>
                                            <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                            <template #overlay>
                                              <a-menu @click="({ key }) => onWorkbenchDbTableContextMenu(key, tbl)">
                                                <a-menu-item key="delete" danger>删除</a-menu-item>
                                              </a-menu>
                                            </template>
                                          </a-dropdown>
                                          <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="添加到对话" aria-label="添加到对话" @click.stop="addResourceToChat('database', tbl)"><i class="fas fa-comment-medical"></i></a-button>
                                        </div>
                                      </span>
                                    </div>
                                    <template #overlay>
                                      <a-menu @click="({ key }) => onWorkbenchDbTableContextMenu(key, tbl)">
                                        <a-menu-item key="chat">
                                          <span class="wb-menu-action-item">
                                            <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('chat')" aria-hidden="true"></i>
                                            <span>添加到对话</span>
                                          </span>
                                        </a-menu-item>
                                        <a-menu-item key="delete" danger>删除</a-menu-item>
                                      </a-menu>
                                    </template>
                                  </a-dropdown>
                                </div>
                              </section>
                            </template>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                  <section class="nlm-resource-drawer" :class="{ 'is-open': resourceDrawerOpen.graph }" :style="resourceDrawerSectionStyle('graph')">
                    <div class="nlm-resource-drawer__head-row">
                      <button type="button" class="nlm-resource-drawer__head nlm-resource-drawer__head--split" @click="toggleResourceDrawer('graph')">
                        <span class="nlm-resource-drawer__title">
                          <i class="fas fa-chevron-right nlm-resource-drawer__chevron" aria-hidden="true"></i>
                          数据图谱
                        </span>
                      </button>
                      <div class="nlm-material-action-row__right">
                        <template v-if="resourceDrawerOpen.graph">
                          <a-tooltip :title="workbenchGraphSearchOpen ? '收起搜索' : '展开搜索'">
                            <a-button
                              type="text"
                              class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn"
                              :title="workbenchGraphSearchOpen ? '收起搜索' : '展开搜索'"
                              :aria-label="workbenchGraphSearchOpen ? '收起搜索' : '展开搜索'"
                              @click="toggleWorkbenchGraphSearchPanel"
                            >
                              <i class="fas fa-search"></i>
                            </a-button>
                          </a-tooltip>
                        </template>
                        <a-tooltip title="添加图谱">
                          <a-button
                            type="text"
                            size="small"
                            class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-upload-primary-btn"
                            title="添加图谱"
                            aria-label="添加图谱"
                            @click="openWorkbenchGraphAddModal"
                          >
                            <i class="fas fa-plus" aria-hidden="true"></i>
                          </a-button>
                        </a-tooltip>
                      </div>
                    </div>
                    <div v-show="resourceDrawerOpen.graph" :ref="(el) => setResourceDrawerBodyRef('graph', el)" class="nlm-resource-drawer__body">
                      <div class="nlm-material-toolbar">
                        <div v-if="workbenchGraphSearchOpen" class="nlm-material-query-row">
                          <a-input v-model:value="graphResourceSearchQuery" allow-clear placeholder="搜索图谱" class="ds-input-inline-search ds-input-inline-search--compact">
                            <template #prefix><i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i></template>
                          </a-input>
                        </div>
                      </div>
                      <div class="nlm-fill-scroll">
                        <div class="nlm-cards-wrap nlm-tree-wrap">
                          <div class="nlm-tree-children">
                            <a-dropdown v-for="graph in filteredGraphResources" :key="graph.id" :trigger="['contextmenu']" @click.stop>
                              <div class="nlm-tree-leaf nlm-tree-leaf--graph-item" @click.prevent="previewResource('graph', graph)">
                                <span class="nlm-tree-leaf-icon"><i class="fas fa-circle-nodes"></i></span>
                                <div class="nlm-tree-leaf-title-wrap">
                                  <div class="nlm-tree-leaf-col">
                                    <div class="nlm-tree-leaf-title">{{ graph.name }}</div>
                                  </div>
                                </div>
                                <span class="nlm-tree-leaf-right">
                                  <div class="nlm-tree-leaf-actions">
                                    <a-dropdown :trigger="['click']" @click.stop>
                                      <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                      <template #overlay>
                                        <a-menu @click="({ key }) => onWorkbenchGraphContextMenu(key, graph)">
                                          <a-menu-item key="delete" danger>删除</a-menu-item>
                                        </a-menu>
                                      </template>
                                    </a-dropdown>
                                    <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="添加到对话" aria-label="添加到对话" @click.stop="addResourceToChat('graph', graph)"><i class="fas fa-comment-medical"></i></a-button>
                                  </div>
                                </span>
                              </div>
                              <template #overlay>
                                <a-menu @click="({ key }) => onWorkbenchGraphRowContextMenu(key, graph)">
                                  <a-menu-item key="chat">
                                    <span class="wb-menu-action-item">
                                      <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('chat')" aria-hidden="true"></i>
                                      <span>添加到对话</span>
                                    </span>
                                  </a-menu-item>
                                  <a-menu-item key="delete" danger>删除</a-menu-item>
                                </a-menu>
                              </template>
                            </a-dropdown>
                          </div>
                        </div>
                      </div>
                    </div>
                  </section>
                  <section class="nlm-resource-drawer" :class="{ 'is-open': resourceDrawerOpen.knowledge }" :style="resourceDrawerSectionStyle('knowledge')">
                    <button type="button" class="nlm-resource-drawer__head" @click="toggleResourceDrawer('knowledge')">
                      <span class="nlm-resource-drawer__title">
                        <i class="fas fa-chevron-right nlm-resource-drawer__chevron" aria-hidden="true"></i>
                        知识库
                      </span>
                    </button>
                    <div v-show="resourceDrawerOpen.knowledge" :ref="(el) => setResourceDrawerBodyRef('knowledge', el)" class="nlm-resource-drawer__body">
                      <div class="nlm-empty-state" style="padding: var(--ds-space-m) var(--ds-space-sm);">
                        <p class="nlm-empty-desc">知识库能力暂未开放，当前仅展示占位信息。</p>
                      </div>
                    </div>
                  </section>
                  </div>
                  </template>
                  <template v-else>
                    <div class="nlm-material-toolbar">
                      <div class="nlm-material-header-row">
                        <div class="nlm-toolbar-pool-caption-wrap">
                          <span class="nlm-toolbar-pool-caption">{{ workbenchTemplateTotalCount }}个技能</span>
                        </div>
                        <div class="nlm-material-toolbar__actions">
                          <a-tooltip :title="wbSkillSidebarSearchOpen ? '收起搜索' : '展开搜索'">
                            <a-button
                              type="text"
                              class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn"
                              :title="wbSkillSidebarSearchOpen ? '收起搜索' : '展开搜索'"
                              :aria-label="wbSkillSidebarSearchOpen ? '收起搜索' : '展开搜索'"
                              @click="toggleWbSkillSearchPanel"
                            >
                              <i class="fas fa-search"></i>
                            </a-button>
                          </a-tooltip>
                          <a-tooltip title="重新加载技能列表（不刷新对话）">
                            <a-button
                              type="text"
                              class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-toolbar-pool-refresh-btn"
                              :disabled="!workbenchProjectId"
                              title="重新加载技能列表（演示数据，未接真实接口）。不会刷新中间助手对话。"
                              aria-label="重新加载技能列表，不刷新对话"
                              @click="refreshWorkbenchDemoResources('skill')"
                            >
                              <i class="fas fa-rotate-right" aria-hidden="true"></i>
                            </a-button>
                          </a-tooltip>
                          <a-dropdown :trigger="['click']" placement="bottomRight">
                            <a-tooltip title="添加技能">
                              <a-button
                                type="text"
                                size="small"
                                class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-upload-primary-btn"
                                title="添加技能入口"
                                aria-label="添加技能入口（次操作）"
                              >
                                <i class="fas fa-plus" aria-hidden="true"></i>
                              </a-button>
                            </a-tooltip>
                            <template #overlay>
                              <a-menu @click="onWorkbenchTemplateAddMenu">
                                <a-menu-item key="new">
                                  <span class="wb-menu-action-item">
                                    <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('new')" aria-hidden="true"></i>
                                    <span>创建技能</span>
                                  </span>
                                </a-menu-item>
                                <a-menu-item key="library">
                                  <span class="wb-menu-action-item">
                                    <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('library')" aria-hidden="true"></i>
                                    <span>引用技能</span>
                                  </span>
                                </a-menu-item>
                              </a-menu>
                            </template>
                          </a-dropdown>
                        </div>
                      </div>
                      <div v-if="wbSkillSidebarSearchOpen" class="nlm-material-query-row">
                        <a-input
                          v-model:value="wbSkillSidebarSearchKeyword"
                          allow-clear
                          placeholder="搜索技能名称或标签"
                          aria-label="搜索技能"
                          class="ds-input-inline-search ds-input-inline-search--compact"
                        >
                          <template #prefix>
                            <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                          </template>
                        </a-input>
                      </div>
                    </div>
                    <div class="nlm-fill-scroll" style="flex:1;min-height:0;">
                      <div class="nlm-cards-wrap nlm-tree-wrap">
                        <template v-for="section in workbenchTemplateTreeSections" :key="'tpl-' + section.key">
                          <div class="nlm-tree-children">
                            <div
                              v-for="node in section.children"
                              :key="node.key"
                              :class="['nlm-tree-leaf', { checked: wbSelectedTemplateKey === node.key }]"
                              role="button"
                              tabindex="0"
                              @click="selectWorkbenchSkillTemplate(node)"
                              @keydown.enter.prevent="selectWorkbenchSkillTemplate(node)"
                              @keydown.space.prevent="selectWorkbenchSkillTemplate(node)"
                              @contextmenu.prevent="onWbSkillTreeLeafContextMenu(node)"
                            >
                              <span class="nlm-tree-leaf-icon">
                                <a-spin v-if="isWbProjectSkillSummarizing(node.raw)" size="small" class="nlm-tree-leaf-spin is-status-pending" />
                                <i v-else class="fas fa-diagram-project"></i>
                              </span>
                              <div class="nlm-tree-leaf-title-wrap">
                                <div class="nlm-tree-leaf-col">
                                  <div
                                    class="nlm-tree-leaf-title nlm-tree-leaf-title--wb-skill-name"
                                    role="button"
                                    tabindex="0"
                                    title="查看并编辑技能"
                                    aria-label="打开技能详情（可编辑）"
                                    @click.stop="openWbProjectSkillDetailFromNode(node, { readOnly: false })"
                                    @keydown.enter.prevent.stop="openWbProjectSkillDetailFromNode(node, { readOnly: false })"
                                    @keydown.space.prevent.stop="openWbProjectSkillDetailFromNode(node, { readOnly: false })"
                                  >{{ node.raw.name || '未命名技能' }}</div>
                                </div>
                              </div>
                              <span class="nlm-tree-leaf-right">
                                <div class="nlm-tree-leaf-actions">
                                  <a-dropdown
                                    :open="wbSkillTreeActionMenuKey === node.key"
                                    :trigger="['click']"
                                    placement="bottomRight"
                                    @update:open="(v) => onWbSkillTreeActionMenuOpenUpdate(v, node)"
                                    @click.stop
                                  >
                                    <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                    <template #overlay>
                                      <a-menu @click="(info) => onWbProjectSkillTreeMenu(info, node)">
                                        <a-menu-item key="archive">入库</a-menu-item>
                                        <a-menu-item key="delete" danger>删除</a-menu-item>
                                      </a-menu>
                                    </template>
                                  </a-dropdown>
                                  <a-button
                                    type="text"
                                    class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                    title="添加到对话"
                                    aria-label="添加到对话"
                                    @click.stop="onWbProjectSkillTreeMenu({ key: 'cite' }, node)"
                                  ><i class="fas fa-comment-medical"></i></a-button>
                                </div>
                              </span>
                            </div>
                          </div>
                        </template>
                        <div v-if="!workbenchTemplateTotalCount" class="nlm-empty-state" style="padding: var(--ds-space-m) var(--ds-space-sm);">
                          <p class="nlm-empty-desc">请先在工作台配置技能：创建或引用技能库中的技能，并关联资料后，即可在此执行并查看结果。</p>
                        </div>
                      </div>
                    </div>
                  </template>
                </div>
                <div
                  v-else
                  class="nlm-side-panel-body"
                >
                  <div class="nlm-source-detail nlm-extraction-detail" v-if="selectedExtractionResult">
                    <div class="back-row">
                      <button type="button" class="back-btn back-btn--icon-only" title="返回列表" aria-label="返回列表" @click="selectedExtractionId = null; selectedTreeNode = null; sourcesLeftView = 'list'; sourcesWidth = 300"><i class="fas fa-arrow-left" aria-hidden="true"></i></button>
                    </div>
                    <h3 class="nlm-source-title">{{ selectedExtractionResult.dataSourceName }} 抽取结果</h3>
                    <div class="nlm-source-guide">
                      <div class="nlm-source-guide-header" @click="sourceGuideOpen = !sourceGuideOpen">
                        摘要 <i class="fas" :class="sourceGuideOpen ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
                      </div>
                      <div v-show="sourceGuideOpen" class="nlm-source-guide-body">
                        <p>{{ (selectedExtractionResult.snippets || []).length }} 条抽取结果，根据规则「{{ selectedExtractionResult.prompt || '（未填写）' }}」从 {{ selectedExtractionResult.dataSourceName }} 获取。</p>
                      </div>
                    </div>
                    <div class="nlm-source-read">
                      <div v-for="(sn, i) in (selectedExtractionResult.snippets || [])" :key="i" class="excerpt nlm-extraction-detail-snippet">
                        <strong>{{ sn.title }}</strong>
                        <p style="margin:var(--ds-space-xxs) 0 0 0">{{ sn.desc }}</p>
                      </div>
                    </div>
                  </div>
                  <div
                    class="nlm-source-detail nlm-source-detail--workbench-preview material-preview-modal material-preview-modal--workbench-embed"
                    v-else-if="selectedResourcePreview"
                  >
                    <div class="back-row" style="display:flex; align-items:center; flex-wrap:nowrap; justify-content:flex-start; gap:var(--ds-space-xxs);">
                      <button type="button" class="back-btn back-btn--icon-only" title="返回列表" aria-label="返回列表" @click="closeResourcePreview"><i class="fas fa-arrow-left" aria-hidden="true"></i></button>
                      <span class="back-row__title" style="text-align:left;">{{ selectedResourcePreview.name || '资源预览' }}</span>
                      <a-button
                        type="text"
                        class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                        title="添加到对话"
                        aria-label="添加到对话"
                        style="margin-left:auto;"
                        @click.stop="addResourceToChat(selectedResourcePreview.type, selectedResourcePreview)"
                      ><i class="fas fa-comment-medical"></i></a-button>
                      <a-dropdown :trigger="['click']" placement="bottomRight" @click.stop>
                        <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                        <template #overlay>
                          <a-menu @click="({ key }) => onResourcePreviewContextMenu(key, selectedResourcePreview)">
                            <a-menu-item key="delete" danger>删除</a-menu-item>
                          </a-menu>
                        </template>
                      </a-dropdown>
                    </div>
                    <div class="tc-skill-modal-body tc-skill-modal-body--unified material-preview-unified-body workbench-material-preview-unified-body">
                      <a-tabs v-model:activeKey="resourcePreviewTab" class="skill-unified-modal-tabs material-preview-unified-tabs workbench-embed-top-tabs" tab-position="top">
                        <a-tab-pane key="basic" tab="基本信息">
                          <div class="ds-unified-tab-pane-stack">
                            <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息">
                              <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                              <div class="ds-unified-tab-pane-chrome__actions"></div>
                            </div>
                            <div class="material-preview-basic-tab">
                              <div
                                v-for="(row, idx) in resourcePreviewBasicMetaRows"
                                :key="'resource-preview-meta-' + idx"
                                class="material-preview-meta-dl-row"
                              >
                                <span class="material-preview-meta-dl-label">{{ row.label }}</span>
                                <span class="material-preview-meta-dl-value">{{ row.value }}</span>
                              </div>
                            </div>
                          </div>
                        </a-tab-pane>
                        <a-tab-pane v-if="selectedResourcePreview.type === 'database'" key="schema" tab="字段信息">
                          <div class="ds-unified-tab-pane-stack">
                            <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="字段信息">
                              <h3 class="ds-unified-tab-pane-chrome__title">字段信息</h3>
                              <div class="ds-unified-tab-pane-chrome__actions"></div>
                            </div>
                            <div class="preview-modal-content-frame preview-modal-content-frame--material">
                              <div class="material-preview-modal__viewer">
                                <div class="material-preview-modal__viewer-body">
                                  <div class="nlm-source-read">
                                    <div v-for="table in (selectedResourcePreview.tables || [])" :key="table.name" class="excerpt">
                                      <strong>{{ table.name }}</strong>
                                      <p style="margin:var(--ds-space-xxs) 0 0 0; white-space:pre-wrap;">{{ table.ddl }}</p>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </a-tab-pane>
                        <a-tab-pane v-else key="topology" tab="本体建模">
                          <div class="ds-unified-tab-pane-stack">
                            <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="本体建模">
                              <h3 class="ds-unified-tab-pane-chrome__title">本体建模</h3>
                              <div class="ds-unified-tab-pane-chrome__actions"></div>
                            </div>
                            <div class="preview-modal-content-frame preview-modal-content-frame--material">
                              <div class="nlm-empty-state" style="padding: var(--ds-space-m) var(--ds-space-sm);">
                                <p class="nlm-empty-desc">拓扑视图占位：实体 {{ selectedResourcePreview.entityCount || 0 }}，关系 {{ selectedResourcePreview.edgeCount || 0 }}</p>
                              </div>
                            </div>
                          </div>
                        </a-tab-pane>
                      </a-tabs>
                    </div>
                  </div>
                  <div
                    class="nlm-source-detail nlm-source-detail--workbench-preview"
                    :class="{ 'material-preview-modal material-preview-modal--workbench-embed': selectedMaterial && selectedMaterial.type === 'raw' && selectedMaterial.projectSource }"
                    v-else-if="selectedMaterialDetail"
                  >
                    <div class="back-row" style="display:flex; align-items:center; flex-wrap:nowrap; justify-content:flex-start; gap:var(--ds-space-xxs);">
                      <button type="button" class="back-btn back-btn--icon-only" title="返回列表" aria-label="返回列表" @click="closeWorkbenchMaterialDetail"><i class="fas fa-arrow-left" aria-hidden="true"></i></button>
                      <span class="back-row__title" style="text-align:left;">{{ (workbenchSelectedProjectMaterialRow && workbenchSelectedProjectMaterialRow.name) || (selectedMaterial && selectedMaterial.title) || '资料预览' }}</span>
                      <a-button
                        v-if="selectedMaterial"
                        type="text"
                        class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                        title="添加到对话"
                        aria-label="添加到对话"
                        style="margin-left:auto;"
                        @click.stop="handleTreeContextMenu('ref', { raw: selectedMaterial }, 'material')"
                      ><i class="fas fa-comment-medical"></i></a-button>
                      <a-dropdown v-if="selectedMaterial" :trigger="['click']" placement="bottomRight" @click.stop>
                        <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                        <template #overlay>
                          <a-menu @click="({ key }) => handleTreeContextMenu(key, { raw: selectedMaterial }, 'material')">
                            <a-menu-item key="rename">重命名</a-menu-item>
                            <a-menu-item key="download">下载</a-menu-item>
                            <a-menu-item v-if="workbenchMaterialStatusOf(selectedMaterial) !== 'done'" key="rerun">重跑</a-menu-item>
                            <a-menu-item key="delete">删除</a-menu-item>
                          </a-menu>
                        </template>
                      </a-dropdown>
                    </div>
                    <div v-if="selectedMaterial && ['analysis','report'].includes(selectedMaterial.type)" class="nlm-wb-derived-line">根据 {{ sourceMaterialCount }} 个提取资料得到此{{ selectedMaterial.type === 'analysis' ? '结果' : '报告' }}</div>
                    <template v-if="selectedMaterial && selectedMaterial.type === 'raw' && selectedMaterial.projectSource && workbenchSelectedProjectMaterialRow">
                        <div class="tc-skill-modal-body tc-skill-modal-body--unified material-preview-unified-body workbench-material-preview-unified-body">
                          <a-tabs
                            v-model:activeKey="wbMaterialPreviewActiveTab"
                            class="skill-unified-modal-tabs material-preview-unified-tabs workbench-embed-top-tabs"
                            tab-position="top"
                            aria-label="资料预览：基本信息、文件预览或 OCR 结果"
                          >
                            <a-tab-pane key="basic" tab="基本信息">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息">
                                  <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions"></div>
                                </div>
                                <div class="material-preview-basic-tab">
                                  <div
                                    v-for="(row, idx) in workbenchMaterialPreviewBasicMetaRows"
                                    :key="'wbmeta-' + idx"
                                    class="material-preview-meta-dl-row"
                                  >
                                    <span class="material-preview-meta-dl-label">{{ row.label }}</span>
                                    <span class="material-preview-meta-dl-value">{{ row.value }}</span>
                                  </div>
                                </div>
                              </div>
                            </a-tab-pane>
                            <a-tab-pane key="preview" tab="文件预览">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="文件预览操作">
                                  <h3 class="ds-unified-tab-pane-chrome__title">文件预览</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions">
                                    <a-button
                                      v-if="(selectedMaterial.rawSubtype || 'document') !== 'table'"
                                      type="default"
                                      class="material-preview-download-link"
                                      :disabled="!workbenchSelectedProjectMaterialRow"
                                      title="下载"
                                      aria-label="下载"
                                      @click.stop="downloadWorkbenchMaterialPreview"
                                    >
                                      下载
                                    </a-button>
                                  </div>
                                </div>
                                <div class="preview-modal-content-frame preview-modal-content-frame--material">
                                  <div v-if="(selectedMaterial.rawSubtype || 'document') !== 'table'" class="material-preview-modal__viewer">
                                    <div class="material-preview-modal__viewer-body">
                                      <div
                                        v-for="(page, pi) in workbenchMaterialDocumentPages"
                                        :key="'wb-embed-mp-' + pi"
                                        class="nlm-original-doc-page material-preview-modal__page"
                                      >{{ page }}</div>
                                    </div>
                                  </div>
                                  <div v-else class="material-preview-modal__viewer">
                                    <div class="material-preview-modal__viewer-body">
                                      <div v-if="selectedMaterial.originalView && selectedMaterial.originalView.headers" class="nlm-original-table-wrap">
                                        <table class="nlm-original-table">
                                          <thead><tr><th v-for="(h, hi) in selectedMaterial.originalView.headers" :key="hi">{{ h }}</th></tr></thead>
                                          <tbody><tr v-for="(row, ri) in (selectedMaterial.originalView.rows || [])" :key="ri"><td v-for="(cell, ci) in row" :key="ci">{{ cell }}</td></tr></tbody>
                                        </table>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </a-tab-pane>
                            <a-tab-pane key="ocr" tab="OCR结果">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="OCR结果">
                                  <h3 class="ds-unified-tab-pane-chrome__title">OCR结果</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions material-preview-ocr-chrome-actions">
                                    <div class="ds-mode-switch-slider material-preview-ocr-mode-switch" :class="{ 'is-assisted': materialPreviewOcrShowLineNumbers, 'is-auto': !materialPreviewOcrShowLineNumbers }" role="tablist" aria-label="OCR预览模式切换">
                                      <span class="ds-mode-switch-slider__thumb" aria-hidden="true"></span>
                                      <button
                                        type="button"
                                        class="ds-mode-switch-slider__item"
                                        :class="{ 'is-current': !materialPreviewOcrShowLineNumbers }"
                                        role="tab"
                                        :aria-selected="!materialPreviewOcrShowLineNumbers"
                                        :tabindex="!materialPreviewOcrShowLineNumbers ? 0 : -1"
                                        title="普通预览"
                                        aria-label="普通预览"
                                        @click="materialPreviewOcrShowLineNumbers = false"
                                      >
                                        <i class="fas fa-eye" aria-hidden="true"></i>
                                      </button>
                                      <button
                                        type="button"
                                        class="ds-mode-switch-slider__item"
                                        :class="{ 'is-current': materialPreviewOcrShowLineNumbers }"
                                        role="tab"
                                        :aria-selected="materialPreviewOcrShowLineNumbers"
                                        :tabindex="materialPreviewOcrShowLineNumbers ? 0 : -1"
                                        title="带行号预览"
                                        aria-label="带行号预览"
                                        @click="materialPreviewOcrShowLineNumbers = true"
                                      >
                                        <i class="fas fa-code" aria-hidden="true"></i>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                                <div class="material-preview-modal__viewer material-preview-modal__viewer--ocr-tab">
                                  <div class="material-preview-modal__viewer-body">
                                    <div
                                      v-for="(page, pi) in workbenchMaterialOcrPagesDisplayed"
                                      :key="'wb-embed-ocr-' + pi"
                                      :class="['nlm-original-doc-page', 'material-preview-modal__page', { 'ds-font-mono': materialPreviewOcrShowLineNumbers }]"
                                    >{{ page }}</div>
                                  </div>
                                </div>
                              </div>
                            </a-tab-pane>
                          </a-tabs>
                        </div>
                    </template>
                    <template v-else-if="selectedMaterial && selectedMaterial.type === 'raw'">
                      <div class="wb-material-preview-shell wb-material-preview-shell--workbench-embed">
                        <div class="wb-material-preview-toolbar">
                          <span class="wb-material-preview-toolbar-meta">在线预览（PDF）</span>
                          <span class="wb-material-preview-toolbar-meta">1 / {{ workbenchMaterialDocumentPages.length || 1 }}</span>
                        </div>
                        <div class="wb-material-preview-body">
                          <div
                            v-for="(page, pi) in workbenchMaterialDocumentPages"
                            :key="'wb-embed-fb-' + pi"
                            class="nlm-original-doc-page wb-material-preview-page"
                          >{{ page }}</div>
                        </div>
                      </div>
                    </template>
                    <template v-else-if="!(selectedMaterial && selectedMaterial.type === 'analysis')">
                      <h3 class="nlm-source-title">{{ selectedMaterialDetail.title }}</h3>
                      <div class="nlm-source-guide">
                        <div class="nlm-source-guide-header" @click="sourceGuideOpen = !sourceGuideOpen">
                          资料指南 <i class="fas" :class="sourceGuideOpen ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
                        </div>
                        <div v-show="sourceGuideOpen" class="nlm-source-guide-body">
                          <p>{{ selectedMaterialDetail.overview }}</p>
                        </div>
                      </div>
                      <div class="nlm-source-read" ref="sourceRead">
                        <div v-for="(ex, i) in detailExcerpts" :key="i" :class="['excerpt', { highlight: highlightSourceId === selectedMaterialDetail.id && highlightExcerptIndex === i }]" :ref="el => setExcerptRef(selectedMaterialDetail.id, i, el)">{{ ex }}</div>
                      </div>
                    </template>
                  </div>
                </div>
              </div>
            </aside>
            <div class="nlm-resizer" :class="{ 'is-hidden': sourcesCollapsed }" @mousedown="beginResize('sources', $event)"></div>
            <section class="nlm-assistant-column" :style="{ flex: layoutMode === 'B' ? 4 : layoutRatios.middle, minWidth: 0, minHeight: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }">
              <div class="nlm-panel-header">
                <div class="nlm-panel-title-row">
                  <span class="nlm-panel-title">{{ layoutMode === 'B' ? '经验沉淀' : '对话' }}</span>
                </div>
                <div v-if="layoutMode === 'A'" class="nlm-assistant-header-actions">
                  <button type="button" class="nlm-assistant-header-btn" title="生成技能" aria-label="生成技能" @click="openGenerateSkillConfigModal">
                    <i class="fas fa-file-contract" aria-hidden="true"></i>
                    <span>生成技能</span>
                  </button>
                  <a-dropdown v-model:open="historyDropdownOpen" :trigger="['click']">
                    <button type="button" class="nlm-assistant-header-btn" title="历史会话" aria-label="历史会话">
                      <i class="fas fa-history" aria-hidden="true"></i>
                      <span>历史</span>
                    </button>
                    <template #overlay>
                      <a-menu v-if="sessionHistory.length" @click="({ key }) => { const s = sessionHistory.find(x => x.id === key); if (s) restoreSession(s); }">
                        <a-menu-item v-for="s in sessionHistory" :key="s.id">{{ s.title }}</a-menu-item>
                      </a-menu>
                      <div v-else class="nlm-history-empty">暂无历史会话</div>
                    </template>
                  </a-dropdown>
                  <button type="button" class="nlm-assistant-header-btn" title="新建会话" aria-label="新建会话" @click="newSession">
                    <i class="fas fa-plus" aria-hidden="true"></i>
                    <span>会话</span>
                  </button>
                </div>
              </div>
              <template v-if="layoutMode === 'B'">
                <div class="nlm-mode-b-canvas">
                  <div class="nlm-draft-block"><label>抽取技能草案</label><textarea v-model="experienceDrafts.extract" rows="4" placeholder="抽取技能草案" /></div>
                  <div class="nlm-draft-block"><label>分析技能草案</label><textarea v-model="experienceDrafts.analysis" rows="4" placeholder="分析技能草案" /></div>
                  <div class="nlm-draft-block"><label>报告技能草案</label><textarea v-model="experienceDrafts.report" rows="4" placeholder="报告技能草案" /></div>
                  <div class="nlm-mode-b-actions">
                    <button class="nlm-btn" @click="exitExperienceDraftMode">返回模式 A</button>
                    <a-button type="primary" @click="saveExperienceToTemplate">保存至技能库</a-button>
                  </div>
                </div>
              </template>
              <template v-else>
              <FreeAuditChatPanel :host="freeAuditChatHost" />
              <div class="nlm-chat-input-wrap" @dragover.prevent @drop="onChatAreaDrop">
                <teleport to="body">
                  <div
                    v-if="chatInputTriggerOpen && chatInputTriggerKind === 'at'"
                    ref="chatAtTriggerFloater"
                    class="nlm-chat-input-trigger-floater nlm-chat-input-trigger-floater--at-fixed nlm-chat-at-dropdown-root"
                    role="listbox"
                    aria-label="引用资料或结果"
                    :style="chatAtFloaterStyle"
                    @mousedown.prevent
                  >
                    <div class="nlm-chat-at-menu-wrap">
                      <template v-if="chatAtMenuHasAnythingToRef">
                        <template v-if="chatTriggerFilterTrimmed">
                          <div class="nlm-chat-at-cascade nlm-chat-at-cascade--solo">
                            <div class="nlm-chat-at-card nlm-chat-at-card--single nlm-chat-at-card--match-list">
                              <div class="nlm-chat-at-card__chrome">
                                <div class="nlm-chat-at-ref-head">匹配资料与结果</div>
                              </div>
                              <div class="nlm-chat-at-card__body nlm-chat-at-card__body--scroll">
                                <button
                                  v-for="row in chatAtUnifiedMatchRows"
                                  :key="'chat-at-uni-' + row.kind + '-' + row.m.id"
                                  type="button"
                                  class="nlm-chat-at-item-row nlm-chat-at-item-row--unified"
                                  @click="onChatInputTriggerPickMaterial(row.m)"
                                >
                                  <span
                                    class="nlm-chat-at-item-row__kind nlm-chat-at-item-row__kind--ic"
                                    :title="row.kind === 'raw' ? '资料' : '结果'"
                                    :aria-label="row.kind === 'raw' ? '资料' : '结果'"
                                  >
                                    <i class="fas" :class="[getMaterialIcon(row.m), getMaterialIconColorClass(row.m), chatAtUnifiedRowStatusClass(row)]" aria-hidden="true"></i>
                                  </span>
                                  <span class="nlm-chat-at-item-row__title">{{ row.kind === 'raw' ? chatAtRawMaterialDisplayTitle(row.m) : (row.m.title || row.m.name || '未命名') }}</span>
                                </button>
                                <div v-if="!chatAtUnifiedMatchRows.length" class="nlm-chat-at-item-row nlm-chat-at-item-row--empty" aria-disabled="true">无匹配项</div>
                              </div>
                            </div>
                          </div>
                        </template>
                        <template v-else>
                          <div class="nlm-chat-at-cascade">
                            <div class="nlm-chat-at-flyout-anchor">
                              <div class="nlm-chat-at-card nlm-chat-at-card--flyout-rail">
                                <div class="nlm-chat-at-card__chrome">
                                  <div class="nlm-chat-at-ref-head">引用</div>
                                </div>
                                <div class="nlm-chat-at-card__body nlm-chat-at-card__body--rail">
                                  <button
                                    v-for="cat in chatAtMenuRailCategories"
                                    :key="'chat-trg-at-cat-' + cat.key"
                                    type="button"
                                    class="nlm-chat-at-cat-row"
                                    @click="openChatInputAtSubmenu(cat.key)"
                                  >
                                    <span class="nlm-chat-at-cat-row__label">{{ cat.label }}</span>
                                    <i class="fas fa-chevron-right nlm-chat-at-cat-row__chev" aria-hidden="true"></i>
                                  </button>
                                </div>
                              </div>
                              <div v-if="chatAtMenuPanel === 'items'" class="nlm-chat-at-card nlm-chat-at-card--flyout-sub">
                                <div class="nlm-chat-at-ref-head nlm-chat-at-ref-head--sub">
                                  <button
                                    type="button"
                                    class="nlm-chat-at-back"
                                    title="返回"
                                    aria-label="返回引用分类"
                                    @click="backChatInputAtSubmenu"
                                  >
                                    <i class="fas fa-chevron-left" aria-hidden="true"></i>
                                  </button>
                                  <span class="nlm-chat-at-ref-head__title">{{ chatAtSubmenuTitle }}</span>
                                </div>
                                <div class="nlm-chat-at-card__body nlm-chat-at-card__body--scroll">
                                  <template v-if="chatInputAtRail === 'raw'">
                                    <button
                                      v-for="m in chatAtMenuRawMaterials"
                                      :key="'chat-trg-at-mat-' + m.id"
                                      type="button"
                                      class="nlm-chat-at-item-row"
                                      @click="onChatInputTriggerPickMaterial(m)"
                                    >
                                      <span class="nlm-chat-at-item-row__title">{{ chatAtRawMaterialDisplayTitle(m) }}</span>
                                    </button>
                                    <div v-if="!chatAtMenuRawMaterials.length" class="nlm-chat-at-item-row nlm-chat-at-item-row--empty" aria-disabled="true">暂无资料</div>
                                  </template>
                                  <template v-else-if="chatInputAtRail === 'result'">
                                    <button
                                      v-for="m in chatAtMenuResultMaterials"
                                      :key="'chat-trg-at-res-' + m.id"
                                      type="button"
                                      class="nlm-chat-at-item-row"
                                      @click="onChatInputTriggerPickMaterial(m)"
                                    >
                                      <span class="nlm-chat-at-item-row__title">{{ m.title || m.name || '未命名' }}</span>
                                    </button>
                                    <div v-if="!chatAtMenuResultMaterials.length" class="nlm-chat-at-item-row nlm-chat-at-item-row--empty" aria-disabled="true">暂无结果</div>
                                  </template>
                                </div>
                              </div>
                            </div>
                          </div>
                        </template>
                      </template>
                      <div v-else class="nlm-chat-at-cascade nlm-chat-at-cascade--solo">
                        <div class="nlm-chat-at-card nlm-chat-at-card--single">
                          <div class="nlm-chat-at-card__chrome">
                            <div class="nlm-chat-at-ref-head">引用</div>
                            <p class="nlm-chat-at-ref-hint">上传资料并产出结果后，可输入 @ 引用</p>
                          </div>
                          <div class="nlm-chat-at-card__body">
                            <div class="nlm-chat-at-item-row nlm-chat-at-item-row--empty">暂无可引用项</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </teleport>
                <div
                  v-if="chatInputTriggerOpen && chatInputTriggerKind === 'slash'"
                  class="nlm-chat-input-trigger-floater nlm-chat-insert-dropdown"
                  role="listbox"
                  aria-label="选择技能"
                  @mousedown.prevent
                >
                  <a-menu class="nlm-chat-insert-menu" @click="onChatInputTriggerSlashMenuClick">
                    <template v-if="chatSlashMenuHasAnyItem">
                      <template v-for="sec in chatSlashMenuSectionsFiltered" :key="'chat-trg-slash-sec-' + sec.key">
                        <a-menu-item-group :title="sec.label">
                          <a-menu-item v-for="node in sec.children" :key="node.key">{{ node.raw.name || '未命名' }}</a-menu-item>
                        </a-menu-item-group>
                      </template>
                    </template>
                    <a-menu-item v-else key="chat-trg-slash-empty" disabled>{{ chatTriggerFilter.trim() ? '无匹配技能' : '暂无技能' }}</a-menu-item>
                  </a-menu>
                </div>
                <div class="nlm-chat-input-box">
                  <div class="nlm-chat-input-text">
                    <textarea
                      ref="chatInputEl"
                      v-model="chatInput"
                      placeholder="输入问题；@ 引用资料或结果，/ 选择技能；Enter 发送"
                      rows="1"
                      @keydown="onChatInputKeydown"
                      @input="onChatInputInput"
                      @focus="onChatInputFocus"
                      @blur="onChatInputBlur"
                    ></textarea>
                  </div>
                  <div class="nlm-chat-input-bar">
                    <div class="nlm-chat-input-bar__right">
                      <button
                        v-if="chatReplyInProgress"
                        type="button"
                        class="ds-icon-btn ds-icon-btn--standard nlm-chat-send-btn nlm-chat-send-btn--pause"
                        title="暂停生成"
                        aria-label="暂停生成"
                        @click="pauseChatGeneration"
                      >
                        <i class="fas fa-pause nlm-chat-send-btn__icon" aria-hidden="true"></i>
                      </button>
                      <button
                        v-else
                        type="button"
                        class="ds-icon-btn ds-icon-btn--standard nlm-chat-send-btn"
                        title="发送"
                        aria-label="发送"
                        @click="sendChat"
                      >
                        <i class="fas fa-arrow-up nlm-chat-send-btn__icon" aria-hidden="true"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="nlm-disclaimer">系统生成内容需人工核查，审计结论以人工确认为准。</div>
              </template>
            </section>
            <div class="nlm-resizer" :class="{ 'is-hidden': studioCollapsed }" @mousedown="beginResize('studio', $event)"></div>
            <aside class="workbench-rail workbench-rail--studio" :style="rightWorkbenchRailStyle">
              <div v-show="!studioCollapsed" class="nlm-side-panel" :class="{ 'is-analysis-detail-open': sourcesRightView === 'detail' && selectedMaterial && selectedMaterial.type === 'analysis', 'is-right-split-list': sourcesRightView === 'list' }">
                <template v-if="sourcesRightView === 'list'">
                  <div
                    class="nlm-side-panel-body nlm-right-split-panel"
                    :class="{ 'is-wb-batch-children-active': wbTaskListView === 'batch-children' }"
                    style="display:flex;flex-direction:column;min-height:0;"
                  >
                    <section
                      class="nlm-right-split-section nlm-right-split-section--task"
                      :class="{ 'is-wb-batch-children-active': wbTaskListView === 'batch-children' }"
                    >
                      <div class="nlm-panel-header">
                        <div class="nlm-panel-title-row nlm-panel-title-row--task-with-refresh">
                          <a-button
                            v-if="wbTaskListView === 'batch-children'"
                            type="text"
                            class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn wb-task-list-panel-back-btn"
                            title="返回任务列表"
                            aria-label="返回任务列表"
                            @click.stop="exitBatchChildListView"
                          ><i class="fas fa-arrow-left" aria-hidden="true"></i></a-button>
                          <span class="nlm-panel-title">{{ wbTaskListPanelTitle }}</span>
                          <div class="nlm-material-toolbar__actions">
                            <template v-if="wbTaskListView === 'batch-children' && wbActiveBatchParentTask">
                              <a-dropdown :trigger="['click']" @click.stop>
                                <a-button type="text" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis" aria-hidden="true"></i></a-button>
                                <template #overlay>
                                  <a-menu @click="({ key }) => handleBatchParentHeaderMenu(key)">
                                    <a-menu-item v-if="['queued','parsing'].includes(workbenchAnalysisStatusOf(wbActiveBatchParentTask))" key="abort-task">中止</a-menu-item>
                                    <a-sub-menu v-if="isWorkbenchBatchParentTask(wbActiveBatchParentTask) && ['queued','parsing','failed'].includes(workbenchAnalysisStatusOf(wbActiveBatchParentTask))" key="rerun-batch-sub-header" title="重跑">
                                      <a-menu-item key="rerun-full">完全重跑</a-menu-item>
                                      <a-menu-item key="rerun-continue">继续跑</a-menu-item>
                                    </a-sub-menu>
                                    <a-menu-item v-else-if="['queued','parsing','failed'].includes(workbenchAnalysisStatusOf(wbActiveBatchParentTask))" key="rerun-task">重跑</a-menu-item>
                                    <a-menu-divider v-if="['queued','parsing','failed'].includes(workbenchAnalysisStatusOf(wbActiveBatchParentTask))" />
                                    <a-menu-item key="delete" danger>删除</a-menu-item>
                                  </a-menu>
                                </template>
                              </a-dropdown>
                              <a-button
                                v-if="['queued','parsing'].includes(workbenchAnalysisStatusOf(wbActiveBatchParentTask))"
                                type="text"
                                class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn"
                                title="中止"
                                aria-label="中止任务"
                                @click.stop="workbenchTaskRowAbort(wbActiveBatchParentTask)"
                              ><i class="fas fa-stop" aria-hidden="true"></i></a-button>
                              <a-button
                                v-else-if="workbenchAnalysisStatusOf(wbActiveBatchParentTask) === 'failed'"
                                type="text"
                                class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn"
                                title="重跑"
                                aria-label="重跑任务"
                                @click.stop="workbenchTaskRowRerun(wbActiveBatchParentTask)"
                              ><i class="fas fa-rotate-right" aria-hidden="true"></i></a-button>
                            </template>
                            <a-tooltip v-else title="重新加载任务列表（不刷新对话）">
                              <a-button
                                type="text"
                                class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-toolbar-pool-refresh-btn"
                                :disabled="!workbenchProjectId"
                                title="重新加载任务列表（演示数据，未接真实接口）。不会刷新中间助手对话。"
                                aria-label="重新加载任务列表，不刷新对话"
                                @click="refreshWorkbenchDemoResources('task')"
                              >
                                <i class="fas fa-rotate-right" aria-hidden="true"></i>
                              </a-button>
                            </a-tooltip>
                            <a-button
                              v-if="poolTabAnalysisTaskCount > 0 && wbTaskListView !== 'batch-children'"
                              type="text"
                              size="small"
                              class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-task-add-icon-btn"
                              title="新建任务（演示）"
                              aria-label="新建任务"
                              @click="handleWorkbenchTaskCreate"
                            ><i class="fas fa-plus" aria-hidden="true"></i></a-button>
                          </div>
                        </div>
                      </div>
                      <div class="nlm-fill-scroll nlm-right-split-scroll nlm-task-list-scroll" style="flex:1;min-height:0;display:flex;flex-direction:column;" @mouseleave="hoveredMaterialId = null" @click="onMaterialListAreaClick($event)">
                        <template v-if="wbTaskListView === 'batch-children'">
                          <div class="wb-task-batch-children-view">
                          <div class="wb-material-status-footer wb-batch-child-status-footer wb-material-status-footer--file-pool ds-popover-panel__footer">
                            <div class="wb-material-status-footer__right">
                              <div class="wb-material-status-footer__stats" aria-label="子任务状态摘要">
                                <button type="button" :class="['ds-trigger-btn nlm-chat-result-toolbar-btn', { 'is-active': wbBatchChildStatusView === 'all' }]" @click.stop="resetWbBatchChildStatusView">
                                  <span class="ds-trigger-btn__text wb-status-chip">全部</span>
                                </button>
                                <button type="button" :class="['ds-trigger-btn nlm-chat-result-toolbar-btn', { 'is-active': wbBatchChildStatusView === 'parsing' }]" @click.stop="setWbBatchChildStatusView('parsing')">
                                  <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--parsing">运行中</span>
                                </button>
                                <button type="button" :class="['ds-trigger-btn nlm-chat-result-toolbar-btn', { 'is-active': wbBatchChildStatusView === 'done' }]" @click.stop="setWbBatchChildStatusView('done')">
                                  <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--done">成功</span>
                                </button>
                                <button type="button" :class="['ds-trigger-btn nlm-chat-result-toolbar-btn', { 'is-active': wbBatchChildStatusView === 'failed' }]" @click.stop="setWbBatchChildStatusView('failed')">
                                  <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--failed">失败</span>
                                </button>
                              </div>
                            </div>
                          </div>
                          <div class="wb-material-list-top-actions wb-batch-child-list-top-actions">
                            <span class="wb-batch-child-list-top-actions__count">共 {{ filteredBatchChildren.length }} 条</span>
                            <div class="wb-material-list-top-actions__batch" v-if="wbBatchChildBatchTargetCount > 0">
                              <a-button v-if="wbBatchChildStatusView === 'parsing'" type="text" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn wb-material-status-footer__back-btn" title="一键中止" aria-label="一键中止" @click.stop="batchAbortWbBatchChildren"><i class="fas fa-stop" aria-hidden="true"></i></a-button>
                              <a-button v-if="['parsing','failed'].includes(wbBatchChildStatusView)" type="text" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn wb-material-status-footer__back-btn" title="一键重跑" aria-label="一键重跑" @click.stop="batchRerunWbBatchChildren"><i class="fas fa-rotate-right" aria-hidden="true"></i></a-button>
                              <a-button type="text" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm ds-icon-btn--danger nlm-input-bar-btn wb-material-status-footer__back-btn" title="一键删除" aria-label="一键删除" @click.stop="batchDeleteWbBatchChildren"><i class="fas fa-trash" aria-hidden="true"></i></a-button>
                            </div>
                          </div>
                          <div class="wb-task-batch-child-list-shell">
                          <div class="nlm-cards-wrap nlm-tree-wrap nlm-task-batch-child-list" style="flex:1;min-height:0;overflow:auto;">
                            <a-dropdown v-for="child in pagedBatchChildren" :key="child.id" :trigger="['contextmenu']" @click.stop>
                              <div :class="['nlm-tree-leaf', 'nlm-tree-leaf--analysis', { checked: selectedMaterialId === child.id }]" @click="openMaterialDetail(child)">
                                <span class="nlm-tree-leaf-icon">
                                  <i v-if="workbenchAnalysisStatusOf(child) === 'queued'" class="fas fa-clock is-status-queued" title="排队中"></i>
                                  <i v-else-if="workbenchAnalysisStatusOf(child) === 'parsing'" class="fas fa-circle-notch fa-spin is-status-pending nlm-tree-leaf-progress-ring" title="执行中"></i>
                                  <i v-else-if="workbenchAnalysisStatusOf(child) === 'failed'" class="fas fa-xmark is-status-failed" title="失败"></i>
                                  <i v-else-if="workbenchAnalysisStatusOf(child) === 'done'" class="fas fa-circle-check is-status-success" title="成功"></i>
                                </span>
                                <div class="nlm-tree-leaf-title-wrap"><div class="nlm-tree-leaf-col"><div class="nlm-tree-leaf-title" :class="{ 'is-muted': ['queued','parsing','failed'].includes(workbenchAnalysisStatusOf(child)) }">{{ child.title || child.rowLabel }}</div></div></div>
                                <span class="nlm-tree-leaf-right"><div class="nlm-tree-leaf-actions">
                                  <a-dropdown :trigger="['click']" @click.stop>
                                    <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                    <template #overlay><a-menu @click="({ key }) => handleBatchChildContextMenu(key, child)"><a-menu-item v-if="workbenchAnalysisStatusOf(child) === 'parsing'" key="abort-task">中止</a-menu-item><a-menu-item v-if="['parsing','failed'].includes(workbenchAnalysisStatusOf(child))" key="rerun-task">重跑</a-menu-item><a-menu-divider /><a-menu-item key="delete" danger>删除</a-menu-item></a-menu></template>
                                  </a-dropdown>
                                  <a-button v-if="workbenchAnalysisStatusOf(child) === 'parsing'" type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="中止" @click.stop="workbenchTaskRowAbort(child)"><i class="fas fa-stop"></i></a-button>
                                  <a-button v-if="['parsing','failed'].includes(workbenchAnalysisStatusOf(child))" type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="重跑" @click.stop="workbenchTaskRowRerun(child)"><i class="fas fa-rotate-right"></i></a-button>
                                </div></span>
                              </div>
                              <template #overlay><a-menu @click="({ key }) => handleBatchChildContextMenu(key, child)"><a-menu-item v-if="workbenchAnalysisStatusOf(child) === 'parsing'" key="abort-task">中止</a-menu-item><a-menu-item v-if="['parsing','failed'].includes(workbenchAnalysisStatusOf(child))" key="rerun-task">重跑</a-menu-item><a-menu-divider /><a-menu-item key="delete" danger>删除</a-menu-item></a-menu></template>
                            </a-dropdown>
                            <a-empty v-if="!filteredBatchChildren.length" description="暂无子任务" />
                          </div>
                          <div v-if="filteredBatchChildren.length" class="wb-task-batch-child-list-footer">
                            <a-pagination
                              size="small"
                              :current="wbBatchChildPage"
                              :page-size="wbBatchChildPageSize"
                              :total="filteredBatchChildren.length"
                              :show-size-changer="false"
                              @change="onWbBatchChildPageChange"
                            />
                          </div>
                          </div>
                          </div>
                        </template>
                        <template v-else>
                        <div class="nlm-cards-wrap nlm-tree-wrap">
                          <template v-if="poolTabAnalysisTaskCount > 0">
                            <template v-for="section in workbenchTaskTreeSections" :key="(section.treeScope || 'pool') + '-' + section.key">
                              <div class="nlm-tree-children">
                                <a-dropdown v-for="node in section.children" :key="node.id" :trigger="['contextmenu']" @click.stop>
                                  <div :class="['nlm-tree-leaf', { 'nlm-tree-leaf--analysis': section.key === 'analysis', 'nlm-source-item-loading': node.raw.loading, checked: isTreeNodeSelected(node, section.key) }]" draggable="true" @click="selectTreeNode(node, section.key)" @dragstart="onTreeLeafDragStart($event, node, section.key)">
                                    <span class="nlm-tree-leaf-icon">
                                      <i
                                        v-if="section.key === 'analysis' && workbenchAnalysisStatusOf(node.raw) === 'queued'"
                                        class="fas fa-clock is-status-queued"
                                        title="排队中"
                                      ></i>
                                      <i
                                        v-else-if="section.key === 'analysis' && workbenchAnalysisStatusOf(node.raw) === 'parsing' && !isWorkbenchBatchParentTask(node.raw)"
                                        class="fas fa-circle-notch fa-spin is-status-pending nlm-tree-leaf-progress-ring"
                                        aria-hidden="true"
                                        title="执行中"
                                      ></i>
                                      <span
                                        v-else-if="section.key === 'analysis' && workbenchAnalysisStatusOf(node.raw) === 'parsing' && isWorkbenchBatchParentTask(node.raw)"
                                        class="nlm-tree-leaf-progress-ring-real is-status-pending"
                                        :style="{ '--nlm-progress': workbenchBatchProgressPercent(node.raw) + '%' }"
                                        :title="'执行中 ' + Math.round(workbenchBatchProgressPercent(node.raw)) + '%'"
                                        aria-hidden="true"
                                      ></span>
                                      <i
                                        v-else-if="section.key === 'analysis' && workbenchAnalysisStatusOf(node.raw) === 'failed'"
                                        class="fas fa-xmark is-status-failed"
                                        title="失败"
                                      ></i>
                                      <i
                                        v-else-if="section.key === 'analysis' && workbenchAnalysisStatusOf(node.raw) === 'done'"
                                        class="fas fa-circle-check is-status-success"
                                        title="成功"
                                        aria-hidden="true"
                                      ></i>
                                      <a-spin v-else-if="node.raw.loading" size="small" class="nlm-tree-leaf-spin" />
                                      <i v-else class="fas" :class="[getMaterialIcon(node.raw), getMaterialIconColorClass(node.raw)]"></i>
                                    </span>
                                    <div class="nlm-tree-leaf-title-wrap">
                                      <div class="nlm-tree-leaf-col">
                                        <div class="nlm-tree-leaf-title nlm-tree-leaf-title--with-meta" :class="{ 'is-muted': (section.key === 'analysis' && ['queued', 'parsing', 'failed'].includes(workbenchAnalysisStatusOf(node.raw))) }" @click.stop="openDetailFromTreeTitle(node, section.key)">
                                          <span class="nlm-tree-leaf-title__text">{{ node.raw.title }}</span>
                                        </div>
                                      </div>
                                    </div>
                                    <span class="nlm-tree-leaf-right">
                                      <div class="nlm-tree-leaf-actions">
                                        <template v-if="section.treeScope === 'task'">
                                          <a-dropdown :trigger="['click']" @click.stop>
                                            <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                            <template #overlay>
                                              <a-menu @click="({ key }) => handleTreeContextMenu(key, node, section.key, section.treeScope)">
                                                <a-menu-item v-if="['queued','parsing'].includes(workbenchAnalysisStatusOf(node.raw))" key="abort-task">中止</a-menu-item>
                                                <a-sub-menu v-if="isWorkbenchBatchParentTask(node.raw) && ['queued','parsing','failed'].includes(workbenchAnalysisStatusOf(node.raw))" key="rerun-batch-sub" title="重跑">
                                                  <a-menu-item key="rerun-full">完全重跑</a-menu-item>
                                                  <a-menu-item key="rerun-continue">继续跑</a-menu-item>
                                                </a-sub-menu>
                                                <a-menu-item v-else-if="['queued','parsing','failed'].includes(workbenchAnalysisStatusOf(node.raw))" key="rerun-task">重跑</a-menu-item>
                                                <a-menu-divider v-if="['queued','parsing','failed'].includes(workbenchAnalysisStatusOf(node.raw))" />
                                                <a-menu-item key="delete" danger>删除</a-menu-item>
                                              </a-menu>
                                            </template>
                                          </a-dropdown>
                                          <a-button
                                            v-if="['queued','parsing'].includes(workbenchAnalysisStatusOf(node.raw))"
                                            type="text"
                                            class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                            title="中止"
                                            aria-label="中止任务"
                                            @click.stop="workbenchTaskRowAbort(node.raw)"
                                          ><i class="fas fa-stop" aria-hidden="true"></i></a-button>
                                          <a-button
                                            v-else-if="workbenchAnalysisStatusOf(node.raw) === 'failed'"
                                            type="text"
                                            class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                            title="重跑"
                                            aria-label="重跑任务"
                                            @click.stop="workbenchTaskRowRerun(node.raw)"
                                          ><i class="fas fa-rotate-right" aria-hidden="true"></i></a-button>
                                        </template>
                                        <template v-else>
                                          <a-dropdown :trigger="['click']" @click.stop>
                                            <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                            <template #overlay>
                                              <a-menu @click="({ key }) => handleTreeContextMenu(key, node, section.key, section.treeScope)">
                                                <a-menu-item v-if="section.key === 'material' && workbenchMaterialStatusOf(node.raw) !== 'done'" key="rerun">重跑</a-menu-item>
                                                <a-menu-item v-if="section.key === 'material'" key="download">下载</a-menu-item>
                                                <a-sub-menu v-if="section.key === 'analysis'" key="export-analysis-sub-queue" title="下载">
                                                  <a-menu-item key="export-md">下载为 Markdown</a-menu-item>
                                                  <a-menu-item key="export-pdf">下载为 PDF</a-menu-item>
                                                  <a-menu-item key="export-docx">下载为 Word</a-menu-item>
                                                </a-sub-menu>
                                                <a-menu-divider />
                                                <a-menu-item key="rename">重命名</a-menu-item>
                                                <a-menu-item key="delete" danger>删除</a-menu-item>
                                              </a-menu>
                                            </template>
                                          </a-dropdown>
                                          <a-button
                                            type="text"
                                            class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                            title="添加到对话"
                                            aria-label="添加到对话"
                                            @click.stop="handleTreeContextMenu('ref', node, section.key, section.treeScope)"
                                          ><i class="fas fa-comment-medical"></i></a-button>
                                        </template>
                                      </div>
                                    </span>
                                  </div>
                                  <template #overlay>
                                    <a-menu @click="({ key }) => handleTreeContextMenu(key, node, section.key, section.treeScope)">
                                      <template v-if="section.treeScope === 'task'">
                                        <a-menu-item v-if="['queued','parsing'].includes(workbenchAnalysisStatusOf(node.raw))" key="abort-task">中止</a-menu-item>
                                        <a-sub-menu v-if="isWorkbenchBatchParentTask(node.raw) && ['queued','parsing','failed'].includes(workbenchAnalysisStatusOf(node.raw))" key="rerun-batch-sub-ctx" title="重跑">
                                          <a-menu-item key="rerun-full">完全重跑</a-menu-item>
                                          <a-menu-item key="rerun-continue">继续跑</a-menu-item>
                                        </a-sub-menu>
                                        <a-menu-item v-else-if="['queued','parsing','failed'].includes(workbenchAnalysisStatusOf(node.raw))" key="rerun-task">重跑</a-menu-item>
                                        <a-menu-divider v-if="['queued','parsing','failed'].includes(workbenchAnalysisStatusOf(node.raw))" />
                                        <a-menu-item key="delete" danger>删除</a-menu-item>
                                      </template>
                                      <template v-else>
                                        <a-menu-item key="ref">
                                          <span class="wb-menu-action-item">
                                            <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('ref')" aria-hidden="true"></i>
                                            <span>添加到对话</span>
                                          </span>
                                        </a-menu-item>
                                        <a-menu-item v-if="section.key === 'material' && workbenchMaterialStatusOf(node.raw) !== 'done'" key="rerun">重跑</a-menu-item>
                                        <a-menu-item v-if="section.key === 'material'" key="download">下载</a-menu-item>
                                        <a-sub-menu v-if="section.key === 'analysis'" key="export-analysis-sub-queue-ctx" title="下载">
                                          <a-menu-item key="export-md">下载为 Markdown</a-menu-item>
                                          <a-menu-item key="export-pdf">下载为 PDF</a-menu-item>
                                          <a-menu-item key="export-docx">下载为 Word</a-menu-item>
                                        </a-sub-menu>
                                        <a-menu-divider />
                                        <a-menu-item key="rename">重命名</a-menu-item>
                                        <a-menu-item key="delete" danger>删除</a-menu-item>
                                      </template>
                                    </a-menu>
                                  </template>
                                </a-dropdown>
                              </div>
                            </template>
                          </template>
                          <div v-else class="nlm-task-queue-empty nlm-task-queue-empty--guided">
                            <p class="nlm-task-queue-empty__hint">「执行技能」快速获取结果</p>
                            <a-button
                              type="primary"
                              size="small"
                              class="ds-btn-micro nlm-task-add-btn"
                              title="新建任务（演示）"
                              aria-label="新建任务"
                              @click="handleWorkbenchTaskCreate"
                            >+任务</a-button>
                          </div>
                        </div>
                        </template>
                      </div>
                    </section>
                    <section class="nlm-right-split-section nlm-right-split-section--result">
                      <div class="nlm-panel-header">
                        <div class="nlm-panel-title-row nlm-panel-title-row--result-with-refresh">
                          <span class="nlm-panel-title">结果</span>
                          <div class="nlm-material-toolbar__actions">
                            <a-tooltip :title="workbenchAnalysisSearchOpen ? '收起搜索' : '展开搜索'">
                              <a-button
                                type="text"
                                class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn"
                                :title="workbenchAnalysisSearchOpen ? '收起搜索' : '展开搜索'"
                                :aria-label="workbenchAnalysisSearchOpen ? '收起搜索' : '展开搜索'"
                                @click="toggleWorkbenchAnalysisSearchPanel"
                              >
                                <i class="fas fa-search"></i>
                              </a-button>
                            </a-tooltip>
                            <a-tooltip title="重新加载结果列表（不刷新对话）">
                              <a-button
                                type="text"
                                class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-toolbar-pool-refresh-btn"
                                :disabled="!workbenchProjectId"
                                title="重新加载结果列表（演示数据，未接真实接口）。不会刷新中间助手对话。"
                                aria-label="重新加载结果列表，不刷新对话"
                                @click="refreshWorkbenchDemoResources('result')"
                              >
                                <i class="fas fa-rotate-right" aria-hidden="true"></i>
                              </a-button>
                            </a-tooltip>
                            <a-tooltip title="在结果根目录创建文件夹">
                              <a-button
                                type="text"
                                class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn"
                                title="创建文件夹"
                                aria-label="创建文件夹"
                                :disabled="!workbenchProjectId"
                                @click="openWorkbenchAnalysisResultCreateFolderModal({ type: 'root' })"
                              >
                                <i class="fas fa-folder-plus" aria-hidden="true"></i>
                              </a-button>
                            </a-tooltip>
                          </div>
                        </div>
                      </div>
                      <div class="nlm-material-toolbar">
                      <div v-if="workbenchAnalysisSearchOpen" class="nlm-material-query-row">
                        <a-input
                          v-model:value="workbenchAnalysisSearchQuery"
                          allow-clear
                          placeholder="搜索名称、技能或结果文件夹"
                          class="ds-input-inline-search ds-input-inline-search--compact"
                        >
                          <template #prefix>
                            <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                          </template>
                        </a-input>
                      </div>
                    </div>
                      <div class="nlm-fill-scroll nlm-right-split-scroll wb-material-file-drawer" style="flex:1;min-height:0;" @mouseleave="hoveredMaterialId = null" @click="onMaterialListAreaClick($event)">
                        <div class="nlm-cards-wrap nlm-tree-wrap">
                        <a-tree
                          v-if="workbenchAnalysisResultAntTreeData.length"
                          class="wb-material-file-tree"
                          block-node
                          :show-line="{ showLeafIcon: false }"
                          :show-icon="false"
                          :tree-data="workbenchAnalysisResultAntTreeData"
                          v-model:expanded-keys="workbenchAnalysisResultTreeExpandedKeys"
                          draggable
                          @drop="onWorkbenchAnalysisResultTreeDrop"
                        >
                          <template #switcherIcon><span aria-hidden="true"></span></template>
                          <template #title="d">
                            <a-dropdown v-if="d.isFolder" :trigger="['contextmenu']" @click.stop>
                              <div
                                :class="['nlm-tree-leaf', 'nlm-tree-leaf--folder', {
                                  'nlm-tree-leaf--result-user-folder': d.folderKind === 'userResult' && !d.linkedTaskFolder,
                                  'nlm-tree-leaf--task-run': d.linkedTaskFolder,
                                }]"
                                :title="d.linkedTaskFolder ? '任务完成时自动创建，可改名或删除' : ''"
                                @click.stop="onWorkbenchAnalysisResultFolderRowClick(d)"
                              >
                                <span class="nlm-tree-leaf-icon nlm-tree-leaf-icon--folder-toggle" aria-hidden="true">
                                  <i
                                    class="fas fa-chevron-right nlm-resource-drawer__chevron wb-material-file-tree-switcher-chev"
                                    :class="{ 'wb-material-file-tree-switcher-chev--expanded': workbenchAnalysisResultTreeExpandedKeys.includes(String(d.key)) }"
                                  ></i>
                                </span>
                                <div class="nlm-tree-leaf-title-wrap">
                                  <div class="nlm-tree-leaf-col">
                                    <div class="nlm-tree-leaf-title">{{ d.title }}</div>
                                  </div>
                                </div>
                                <span class="nlm-tree-leaf-right">
                                  <div class="nlm-tree-leaf-actions">
                                    <a-dropdown :trigger="['click']" @click.stop>
                                      <a-button
                                        type="text"
                                        class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                        title="文件夹操作"
                                        aria-label="文件夹操作"
                                        @click.stop
                                      ><i class="fas fa-ellipsis"></i></a-button>
                                      <template #overlay>
                                        <a-menu @click="({ key }) => onWorkbenchAnalysisResultAnyFolderMenu(key, d)">
                                          <a-menu-item key="new-folder">
                                            <span class="wb-menu-action-item">
                                              <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('new-folder')" aria-hidden="true"></i>
                                              <span>新建文件夹</span>
                                            </span>
                                          </a-menu-item>
                                          <a-sub-menu key="download-folder-zip" title="打包下载">
                                            <a-menu-item key="download-folder-zip-keep">保留层级打包（ZIP）</a-menu-item>
                                            <a-menu-item key="download-folder-zip-flat">剔除层级打包（ZIP）</a-menu-item>
                                          </a-sub-menu>
                                          <template v-if="d.userFolderId">
                                            <a-menu-divider />
                                            <a-menu-item key="rename">重命名</a-menu-item>
                                            <a-menu-item key="delete" danger>删除</a-menu-item>
                                          </template>
                                        </a-menu>
                                      </template>
                                    </a-dropdown>
                                    <a-button
                                      type="text"
                                      class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                      :title="workbenchAnalysisResultFolderChatRefMenuLabel(d)"
                                      :aria-label="workbenchAnalysisResultFolderChatRefMenuLabel(d)"
                                      @click.stop="onWorkbenchAnalysisResultAnyFolderMenu('ref', d)"
                                    ><i class="fas fa-comment-medical"></i></a-button>
                                  </div>
                                </span>
                              </div>
                              <template #overlay>
                                <a-menu @click="({ key }) => onWorkbenchAnalysisResultAnyFolderMenu(key, d)">
                                  <a-menu-item key="new-folder">
                                    <span class="wb-menu-action-item">
                                      <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('new-folder')" aria-hidden="true"></i>
                                      <span>新建文件夹</span>
                                    </span>
                                  </a-menu-item>
                                  <a-menu-divider />
                                  <a-menu-item key="ref">
                                    <span class="wb-menu-action-item">
                                      <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('ref')" aria-hidden="true"></i>
                                      <span>{{ workbenchAnalysisResultFolderChatRefMenuLabel(d) }}</span>
                                    </span>
                                  </a-menu-item>
                                  <a-sub-menu key="download-folder-zip-ctx" title="打包下载">
                                    <a-menu-item key="download-folder-zip-keep">保留层级打包（ZIP）</a-menu-item>
                                    <a-menu-item key="download-folder-zip-flat">剔除层级打包（ZIP）</a-menu-item>
                                  </a-sub-menu>
                                  <template v-if="d.userFolderId">
                                    <a-menu-divider />
                                    <a-menu-item key="rename">重命名</a-menu-item>
                                    <a-menu-item key="delete" danger>删除</a-menu-item>
                                  </template>
                                </a-menu>
                              </template>
                            </a-dropdown>
                            <a-dropdown v-else :trigger="['contextmenu']" @click.stop>
                              <div
                                :class="['nlm-tree-leaf', 'nlm-tree-leaf--analysis', { checked: isWorkbenchAnalysisResultTreeLeafSelected(d) }]"
                                draggable="true"
                                @click.stop="onWorkbenchAnalysisResultTreeLeafClick(d)"
                                @dragstart="onWorkbenchAnalysisResultTreeDragStart($event, d)"
                              >
                                <span class="nlm-tree-leaf-icon">
                                  <i
                                    v-if="workbenchAnalysisStatusOf(wbMaterialVmById(d.materialId)) === 'queued'"
                                    class="fas fa-clock is-status-queued"
                                    title="排队中"
                                  ></i>
                                  <i
                                    v-else-if="workbenchAnalysisStatusOf(wbMaterialVmById(d.materialId)) === 'parsing'"
                                    class="fas fa-circle-notch fa-spin is-status-pending nlm-tree-leaf-progress-ring"
                                    aria-hidden="true"
                                    title="执行中"
                                  ></i>
                                  <i
                                    v-else-if="workbenchAnalysisStatusOf(wbMaterialVmById(d.materialId)) === 'failed'"
                                    class="fas fa-xmark is-status-failed"
                                    title="失败"
                                  ></i>
                                  <i
                                    v-else-if="workbenchAnalysisStatusOf(wbMaterialVmById(d.materialId)) === 'done'"
                                    class="fas"
                                    :class="[getMaterialIcon(wbMaterialVmById(d.materialId)), getMaterialIconColorClass(wbMaterialVmById(d.materialId))]"
                                    title="已完成"
                                    aria-hidden="true"
                                  ></i>
                                  <i v-else class="fas" :class="[getMaterialIcon(wbMaterialVmById(d.materialId)), getMaterialIconColorClass(wbMaterialVmById(d.materialId))]"></i>
                                </span>
                                <div class="nlm-tree-leaf-title-wrap">
                                  <div class="nlm-tree-leaf-col">
                                    <div
                                      class="nlm-tree-leaf-title"
                                      :class="{ 'is-muted': ['queued', 'parsing', 'failed'].includes(workbenchAnalysisStatusOf(wbMaterialVmById(d.materialId))) }"
                                      @click.stop="openWorkbenchAnalysisResultTreeLeafDetail(d)"
                                    >{{ (wbMaterialVmById(d.materialId) || {}).title }}</div>
                                  </div>
                                </div>
                                <span class="nlm-tree-leaf-right" v-if="wbMaterialVmById(d.materialId)">
                                  <div class="nlm-tree-leaf-actions">
                                    <a-dropdown :trigger="['click']" @click.stop>
                                      <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                      <template #overlay>
                                        <a-menu @click="({ key }) => onWorkbenchAnalysisResultTreeRawMenu(key, d)">
                                          <a-sub-menu key="export-result-tree-ellipsis" title="下载">
                                            <a-menu-item key="export-md">下载为 Markdown</a-menu-item>
                                            <a-menu-item key="export-pdf">下载为 PDF</a-menu-item>
                                            <a-menu-item key="export-docx">下载为 Word</a-menu-item>
                                          </a-sub-menu>
                                          <a-menu-divider />
                                          <a-menu-item key="rename">重命名</a-menu-item>
                                          <a-menu-item key="delete" danger>删除</a-menu-item>
                                        </a-menu>
                                      </template>
                                    </a-dropdown>
                                    <a-button
                                      type="text"
                                      class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                                      title="添加到对话"
                                      aria-label="添加到对话"
                                      @click.stop="onWorkbenchAnalysisResultTreeRawToggleRef(d)"
                                    ><i class="fas fa-comment-medical"></i></a-button>
                                  </div>
                                </span>
                              </div>
                              <template #overlay>
                                <a-menu @click="({ key }) => onWorkbenchAnalysisResultTreeRawMenu(key, d)">
                                  <a-menu-item key="ref">
                                    <span class="wb-menu-action-item">
                                      <i class="fas wb-menu-action-item__icon" :class="workbenchMenuItemIcon('ref')" aria-hidden="true"></i>
                                      <span>添加到对话</span>
                                    </span>
                                  </a-menu-item>
                                  <a-sub-menu key="export-result-tree-ctx" title="下载">
                                    <a-menu-item key="export-md">下载为 Markdown</a-menu-item>
                                    <a-menu-item key="export-pdf">下载为 PDF</a-menu-item>
                                    <a-menu-item key="export-docx">下载为 Word</a-menu-item>
                                  </a-sub-menu>
                                  <a-menu-divider />
                                  <a-menu-item key="rename">重命名</a-menu-item>
                                  <a-menu-item key="delete" danger>删除</a-menu-item>
                                </a-menu>
                              </template>
                            </a-dropdown>
                          </template>
                        </a-tree>
                        <a-empty v-else class="wb-material-file-tree-empty" description="暂无已完成的分析结果" />
                        </div>
                      </div>
                    </section>
                  </div>
                </template>
                <div v-if="sourcesRightView === 'detail'" class="nlm-side-panel-body is-analysis-detail-open" style="display:flex;flex-direction:column;min-height:0;">
                  <div class="nlm-panel-header" style="flex-shrink:0;">
                    <div class="nlm-panel-title-row">
                      <span class="nlm-panel-title">{{ selectedMaterialIsWorkbenchCreatedTask ? '任务' : '结果' }}</span>
                    </div>
                  </div>
                  <div
                    class="nlm-source-detail nlm-source-detail--workbench-preview nlm-fill-scroll analysis-result-preview-modal analysis-result-preview-modal--workbench-embed"
                    style="flex:1;min-height:0;"
                    v-if="selectedMaterial && selectedMaterial.type === 'analysis'"
                  >
                    <div class="back-row" style="display:flex; align-items:center; flex-wrap:nowrap; justify-content:flex-start; gap:var(--ds-space-xxs);">
                      <a-button type="text" size="small" class="ds-icon-btn ds-icon-btn--nlm wb-back-icon-btn" title="返回列表" aria-label="返回列表" @click="closeWorkbenchMaterialDetail">
                        <i class="fas fa-arrow-left" aria-hidden="true"></i>
                      </a-button>
                      <span class="back-row__title" style="text-align:left;">{{ workbenchEmbedRightAnalysisHeaderTitle }}</span>
                      <a-button
                        v-if="selectedMaterial && !selectedMaterialIsWorkbenchCreatedTask"
                        type="text"
                        class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                        title="添加到对话"
                        aria-label="添加到对话"
                        style="margin-left:auto;"
                        @click.stop="handleTreeContextMenu('ref', { raw: selectedMaterial }, 'analysis')"
                      ><i class="fas fa-comment-medical"></i></a-button>
                      <a-dropdown v-if="selectedMaterial && !selectedMaterialIsWorkbenchCreatedTask" :trigger="['click']" placement="bottomRight" @click.stop>
                        <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                        <template #overlay>
                          <a-menu @click="({ key }) => handleTreeContextMenu(key, { raw: selectedMaterial }, 'analysis')">
                            <a-menu-item key="rename">重命名</a-menu-item>
                            <a-sub-menu key="export-embed-header-sub" title="下载">
                              <a-menu-item key="export-md">下载为 Markdown</a-menu-item>
                              <a-menu-item key="export-pdf">下载为 PDF</a-menu-item>
                              <a-menu-item key="export-docx">下载为 Word</a-menu-item>
                            </a-sub-menu>
                            <a-menu-item key="delete">删除</a-menu-item>
                          </a-menu>
                        </template>
                      </a-dropdown>
                      <a-dropdown v-else-if="selectedMaterialIsWorkbenchCreatedTask" :trigger="['click']" placement="bottomRight" @click.stop>
                        <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" style="margin-left:auto;" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                        <template #overlay>
                          <a-menu @click="({ key }) => handleTreeContextMenu(key, { raw: selectedMaterial }, 'analysis', 'task')">
                            <a-menu-item v-if="selectedMaterial && ['queued','parsing'].includes(workbenchAnalysisStatusOf(selectedMaterial))" key="abort-task">中止</a-menu-item>
                            <a-menu-item v-if="selectedMaterial && ['queued','parsing','failed'].includes(workbenchAnalysisStatusOf(selectedMaterial))" key="rerun-task">重跑</a-menu-item>
                            <a-menu-item key="delete">删除</a-menu-item>
                          </a-menu>
                        </template>
                      </a-dropdown>
                      <a-button
                        v-if="selectedMaterialIsWorkbenchCreatedTask && selectedMaterial && ['queued','parsing'].includes(workbenchAnalysisStatusOf(selectedMaterial))"
                        type="text"
                        class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                        title="中止"
                        aria-label="中止任务"
                        @click.stop="workbenchTaskRowAbort(selectedMaterial)"
                      ><i class="fas fa-stop" aria-hidden="true"></i></a-button>
                      <a-button
                        v-else-if="selectedMaterialIsWorkbenchCreatedTask && selectedMaterial && workbenchAnalysisStatusOf(selectedMaterial) === 'failed'"
                        type="text"
                        class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon"
                        title="重跑"
                        aria-label="重跑任务"
                        @click.stop="workbenchTaskRowRerun(selectedMaterial)"
                      ><i class="fas fa-rotate-right" aria-hidden="true"></i></a-button>
                    </div>
                    <div class="workbench-analysis-result-embed">
                      <div class="tc-skill-modal-body tc-skill-modal-body--unified workbench-analysis-result-unified-body">
                        <a-tabs
                          :activeKey="wbAnalysisResultPreviewActiveTab"
                          class="skill-unified-modal-tabs workbench-analysis-result-embed-tabs workbench-embed-top-tabs"
                          tab-position="top"
                          aria-label="任务/结果预览：基本信息与任务详情"
                          @update:activeKey="onWorkbenchAnalysisResultPreviewTabUpdate"
                        >
                          <a-tab-pane key="basic" tab="基本信息">
                            <div class="workbench-result-preview-pane workbench-result-preview-pane--basic">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息">
                                  <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions"></div>
                                </div>
                                <div class="workbench-result-preview-tab-inner">
                                  <div
                                    v-for="(row, idx) in workbenchEmbedBasicMetaRows"
                                    :key="'wbar-meta-' + idx"
                                    class="material-preview-meta-dl-row"
                                  >
                                    <span class="material-preview-meta-dl-label">{{ row.label }}</span>
                                    <span
                                      v-if="row.label === '状态'"
                                      class="material-preview-meta-dl-value material-preview-meta-dl-value--status-pill"
                                    >
                                      <span
                                        class="ds-status-pill"
                                        :class="analysisStatusChipClass(workbenchSelectedAnalysisResultRow && workbenchSelectedAnalysisResultRow.status)"
                                      >
                                        <span class="ds-status-pill__dot"></span>
                                        <span class="ds-status-pill__label">{{ analysisResultStatusLabel(workbenchSelectedAnalysisResultRow && workbenchSelectedAnalysisResultRow.status) }}</span>
                                      </span>
                                    </span>
                                    <span v-else class="material-preview-meta-dl-value">{{ row.value }}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </a-tab-pane>
                          <a-tab-pane v-if="selectedMaterialIsWorkbenchCreatedTask" key="task-config" tab="任务详情">
                            <div class="workbench-result-preview-pane workbench-result-preview-pane--body">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--result-body" role="toolbar" aria-label="任务详情">
                                  <h3 class="ds-unified-tab-pane-chrome__title">任务详情</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions"></div>
                                </div>
                                <div class="workbench-result-preview-tab-inner workbench-result-preview-tab-inner--task-dag">
                                  <div
                                    v-if="workbenchSelectedTaskConfigDagModel"
                                    class="wb-task-detail-sections"
                                    role="region"
                                    :aria-label="wbTaskConfigIsGenerateSkillTask ? '任务详情：产出技能、生成要求与引用上下文' : '任务详情：产出结果、使用技能与引用资源'"
                                  >
                                    <section v-if="selectedMaterialIsBatchParentTask" class="wb-task-detail-section wb-task-detail-section--batch-overview">
                                      <h4 class="wb-task-detail-section__title">跑批概览</h4>
                                      <div class="wb-task-detail-generate-req-box" role="region">
                                        <p class="wb-task-detail-generate-req-body">数据源：{{ (selectedMaterial.batchMeta && selectedMaterial.batchMeta.fileName) || '—' }}</p>
                                        <p class="wb-task-detail-generate-req-body">标识列：{{ wbBatchMetaIdColumnText(selectedMaterial) }}</p>
                                        <p class="wb-task-detail-generate-req-body">子任务：{{ workbenchBatchProgressText(selectedMaterial) }}（共 {{ (selectedMaterial.batchMeta && selectedMaterial.batchMeta.total) || 0 }} 条）</p>
                                      </div>
                                    </section>
                                    <section class="wb-task-detail-section">
                                      <h4 class="wb-task-detail-section__title">{{ selectedMaterialIsBatchParentTask ? '执行汇总' : '产出结果' }}</h4>
                                      <ul v-if="!selectedMaterialIsBatchParentTask" class="wb-task-detail-simple-list">
                                        <li
                                          class="wb-task-detail-simple-row"
                                          role="button"
                                          tabindex="0"
                                          @click="wbTaskConfigIsGenerateSkillTask ? wbOpenTaskDetailSkill() : openWorkbenchAnalysisModal()"
                                          @keydown.enter.prevent="wbTaskConfigIsGenerateSkillTask ? wbOpenTaskDetailSkill() : openWorkbenchAnalysisModal()"
                                        >
                                          <span class="nlm-tree-leaf-icon wb-task-detail-simple-row__icon" aria-hidden="true">
                                            <template v-if="selectedMaterial && selectedMaterialIsWorkbenchCreatedTask">
                                              <template v-if="wbTaskConfigIsGenerateSkillTask">
                                                <i
                                                  v-if="workbenchAnalysisStatusOf(selectedMaterial) === 'queued'"
                                                  class="fas fa-clock is-status-queued"
                                                  title="排队中"
                                                ></i>
                                                <i
                                                  v-else-if="workbenchAnalysisStatusOf(selectedMaterial) === 'parsing'"
                                                  class="fas fa-circle-notch fa-spin is-status-pending nlm-tree-leaf-progress-ring"
                                                  title="生成中"
                                                ></i>
                                                <i
                                                  v-else-if="workbenchAnalysisStatusOf(selectedMaterial) === 'failed'"
                                                  class="fas fa-wand-magic-sparkles is-status-failed"
                                                  title="技能生成失败"
                                                ></i>
                                                <i
                                                  v-else-if="workbenchAnalysisStatusOf(selectedMaterial) === 'done'"
                                                  class="fas fa-wand-magic-sparkles is-md"
                                                  title="已产出技能"
                                                ></i>
                                                <i v-else class="fas fa-wand-magic-sparkles is-md" title="产出技能"></i>
                                              </template>
                                              <template v-else>
                                                <i
                                                  v-if="workbenchAnalysisStatusOf(selectedMaterial) === 'queued'"
                                                  class="fas fa-clock is-status-queued"
                                                  title="排队中"
                                                ></i>
                                                <i
                                                  v-else-if="workbenchAnalysisStatusOf(selectedMaterial) === 'parsing'"
                                                  class="fas fa-circle-notch fa-spin is-status-pending nlm-tree-leaf-progress-ring"
                                                  title="执行中"
                                                ></i>
                                                <i
                                                  v-else-if="workbenchAnalysisStatusOf(selectedMaterial) === 'failed'"
                                                  class="fas fa-file-circle-xmark is-status-failed"
                                                  title="产出失败"
                                                ></i>
                                                <i
                                                  v-else-if="workbenchAnalysisStatusOf(selectedMaterial) === 'done'"
                                                  class="fas fa-file-lines is-md"
                                                  title="Markdown 产出"
                                                ></i>
                                                <i v-else class="fas fa-file-lines is-md" title="产出结果"></i>
                                              </template>
                                            </template>
                                            <i v-else class="fas fa-file-signature is-doc" title="产出结果"></i>
                                          </span>
                                          <span class="wb-task-detail-simple-row__text">{{
                                            wbTaskConfigIsGenerateSkillTask ? wbTaskConfigGenerateSkillOutputRowSingleLine : wbTaskConfigResultRowSingleLine
                                          }}</span>
                                        </li>
                                      </ul>
                                      <div v-else class="wb-task-detail-generate-req-box"><p class="wb-task-detail-generate-req-body">跑批父任务不展示单条产出；请点击左侧父任务进入子任务列表查看各行结果（演示）。</p></div>
                                    </section>
                                    <section v-if="!wbTaskConfigIsGenerateSkillTask" class="wb-task-detail-section">
                                      <h4 class="wb-task-detail-section__title">任务指令</h4>
                                      <div class="wb-task-detail-generate-req-box" role="region" aria-label="任务指令">
                                        <p class="wb-task-detail-generate-req-body">{{ wbSelectedTaskInstructionDisplay }}</p>
                                      </div>
                                    </section>
                                    <section class="wb-task-detail-section">
                                      <h4 class="wb-task-detail-section__title">{{ wbTaskConfigIsGenerateSkillTask ? '生成要求' : '使用技能' }}</h4>
                                      <template v-if="wbTaskConfigIsGenerateSkillTask">
                                        <div class="wb-task-detail-generate-req-box" role="region" aria-label="创建任务时填写的生成技能要求">
                                          <p class="wb-task-detail-generate-req-body">{{ wbSelectedGenerateSkillIntentDisplay }}</p>
                                        </div>
                                      </template>
                                      <ul v-else class="wb-task-detail-simple-list">
                                        <li
                                          class="wb-task-detail-simple-row"
                                          role="button"
                                          tabindex="0"
                                          @click="wbOpenTaskDetailSkill"
                                          @keydown.enter.prevent="wbOpenTaskDetailSkill"
                                        >
                                          <span
                                            class="nlm-tree-leaf-icon wb-task-detail-simple-row__icon"
                                            :class="{ 'wb-task-detail-tree__icon--accent': workbenchSelectedTaskConfigDagModel.dagMode === 'generate-skill' }"
                                            aria-hidden="true"
                                          >
                                            <i class="fas fa-diagram-project" title="技能"></i>
                                          </span>
                                          <span class="wb-task-detail-simple-row__text">{{ wbTaskConfigSkillRowSingleLine }}</span>
                                        </li>
                                      </ul>
                                    </section>
                                    <section
                                      class="wb-task-detail-section"
                                      :class="{ 'wb-task-detail-section--task-detail-context-embed': wbTaskConfigIsGenerateSkillTask }"
                                    >
                                      <h4 class="wb-task-detail-section__title">{{ wbTaskConfigIsGenerateSkillTask ? '引用上下文' : '引用资源' }}</h4>
                                      <template v-if="wbTaskConfigIsGenerateSkillTask">
                                        <div class="wb-task-context-chat-wrap nlm-chat-body">
                                          <div class="nlm-chat-messages wb-task-context-chat-messages" role="log" aria-live="polite">
                                            <div
                                              v-for="turn in workbenchSelectedTaskDialogTurns"
                                              :key="turn.id"
                                              :class="['nlm-chat-turn', { 'nlm-chat-turn--tool-trace': turn.role === 'thinking' }]"
                                            >
                                              <div v-if="turn.role === 'thinking'" class="nlm-thinking wb-task-context-thinking">
                                                <div class="nlm-thinking-steps nlm-tool-calls">
                                                  <div
                                                    v-for="(call, ci) in (turn.toolCalls || [])"
                                                    :key="turn.id + '-tc-embed-' + ci"
                                                    class="nlm-tool-call nlm-tool-call--plain"
                                                    :class="{ 'nlm-tool-call--stream': call.type === 'text' }"
                                                  >
                                                    <p v-if="call.type === 'text'" class="nlm-tool-stream-text">{{ call.body }}</p>
                                                    <p
                                                      v-else-if="call.type === 'action'"
                                                      class="nlm-tool-stream-text nlm-tool-stream-text--action nlm-tool-call-line"
                                                      :class="{ 'nlm-tool-call-line--running': call.status === 'running' }"
                                                    >
                                                      <span class="nlm-tool-call-line__ic" aria-hidden="true">
                                                        <a-spin v-if="call.status === 'running'" size="small" class="nlm-tool-call-line__spin" />
                                                        <i v-else-if="call.status === 'fail'" class="fas fa-xmark nlm-tool-call-status--fail"></i>
                                                        <i v-else class="fas fa-check nlm-tool-call-status--ok"></i>
                                                      </span>
                                                      <span class="nlm-tool-call-line__txt">{{ call.label }}</span>
                                                    </p>
                                                  </div>
                                                </div>
                                              </div>
                                              <div v-else class="nlm-msg-row">
                                                <div class="nlm-msg-wrap">
                                                  <div :class="['nlm-msg', turn.role, { 'wb-task-context-msg--system': turn.kind === 'system' }]">{{ turn.text }}</div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </template>
                                      <template v-else>
                                        <ul v-if="workbenchTaskConfigResourcesList.length" class="wb-task-detail-simple-list">
                                          <li
                                            v-for="(row, idx) in workbenchTaskConfigResourcesList"
                                            :key="'wb-tc-res-' + (row.key || idx)"
                                            class="wb-task-detail-simple-row"
                                            role="button"
                                            tabindex="0"
                                            :aria-label="wbTaskConfigResourceRowAriaLabel(row)"
                                            @click="openWbTaskResourcePreview(row)"
                                            @keydown.enter.prevent="openWbTaskResourcePreview(row)"
                                          >
                                            <span class="nlm-tree-leaf-icon wb-task-detail-simple-row__icon" aria-hidden="true">
                                              <i class="fas" :class="[wbTaskConfigResourceIconMeta(row).iconClass, wbTaskConfigResourceIconMeta(row).iconToneClass || '']"></i>
                                            </span>
                                            <span class="wb-task-detail-simple-row__text">{{ wbTaskConfigResourceRowSingleLine(row) }}</span>
                                          </li>
                                        </ul>
                                        <a-empty v-else description="未配置引用资源" />
                                      </template>
                                    </section>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </a-tab-pane>
                          <a-tab-pane v-if="selectedMaterialIsWorkbenchCreatedTask" key="task-context" tab="上下文">
                            <div class="workbench-result-preview-pane workbench-result-preview-pane--body wb-task-context-tab-pane">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--result-body" role="toolbar" aria-label="上下文">
                                  <h3 class="ds-unified-tab-pane-chrome__title">上下文</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions"></div>
                                </div>
                                <div class="workbench-result-preview-tab-inner wb-task-context-chat-wrap nlm-chat-body">
                                  <div class="nlm-chat-messages wb-task-context-chat-messages" role="log" aria-live="polite">
                                    <div
                                      v-for="turn in workbenchSelectedTaskDialogTurns"
                                      :key="turn.id"
                                      :class="['nlm-chat-turn', { 'nlm-chat-turn--tool-trace': turn.role === 'thinking' }]"
                                    >
                                      <div v-if="turn.role === 'thinking'" class="nlm-thinking wb-task-context-thinking">
                                        <div class="nlm-thinking-steps nlm-tool-calls">
                                          <div
                                            v-for="(call, ci) in (turn.toolCalls || [])"
                                            :key="turn.id + '-tc-' + ci"
                                            class="nlm-tool-call nlm-tool-call--plain"
                                            :class="{ 'nlm-tool-call--stream': call.type === 'text' }"
                                          >
                                            <p v-if="call.type === 'text'" class="nlm-tool-stream-text">{{ call.body }}</p>
                                            <p
                                              v-else-if="call.type === 'action'"
                                              class="nlm-tool-stream-text nlm-tool-stream-text--action nlm-tool-call-line"
                                              :class="{ 'nlm-tool-call-line--running': call.status === 'running' }"
                                            >
                                              <span class="nlm-tool-call-line__ic" aria-hidden="true">
                                                <a-spin v-if="call.status === 'running'" size="small" class="nlm-tool-call-line__spin" />
                                                <i v-else-if="call.status === 'fail'" class="fas fa-xmark nlm-tool-call-status--fail"></i>
                                                <i v-else class="fas fa-check nlm-tool-call-status--ok"></i>
                                              </span>
                                              <span class="nlm-tool-call-line__txt">{{ call.label }}</span>
                                            </p>
                                          </div>
                                        </div>
                                      </div>
                                      <div v-else class="nlm-msg-row">
                                        <div class="nlm-msg-wrap">
                                          <div :class="['nlm-msg', turn.role, { 'wb-task-context-msg--system': turn.kind === 'system' }]">{{ turn.text }}</div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </a-tab-pane>
                          <a-tab-pane v-else key="body" tab="输出结果">
                            <div class="workbench-result-preview-pane workbench-result-preview-pane--body">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--result-body" role="toolbar" aria-label="输出结果操作">
                                  <h3 class="ds-unified-tab-pane-chrome__title">输出结果</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions" aria-label="正文与编辑器操作">
                                    <div class="analysis-result-preview-modal__toolbar-icons" role="toolbar" aria-label="复制、下载与保存">
                                      <a-button
                                        type="default"
                                        class="analysis-result-preview-toolbar-outline-btn"
                                        :disabled="!workbenchSelectedAnalysisResultRow || workbenchEmbedAnalysisOutputToolbarDisabled"
                                        title="复制当前内容"
                                        aria-label="复制当前内容"
                                        @click="copyWorkbenchAnalysisEmbedPreview"
                                      >复制</a-button>
                                      <a-dropdown
                                        :trigger="['click']"
                                        :disabled="!workbenchSelectedAnalysisResultRow || workbenchEmbedAnalysisOutputToolbarDisabled"
                                      >
                                        <a-button
                                          type="default"
                                          class="analysis-result-preview-toolbar-outline-btn"
                                          :disabled="!workbenchSelectedAnalysisResultRow || workbenchEmbedAnalysisOutputToolbarDisabled"
                                          title="选择导出格式（演示）"
                                          aria-label="下载，选择格式"
                                          aria-haspopup="true"
                                        >
                                          下载 <i class="fas fa-chevron-down" style="margin-left:4px;font-size:10px;opacity:0.75" aria-hidden="true"></i>
                                        </a-button>
                                        <template #overlay>
                                          <a-menu @click="(info) => onWorkbenchAnalysisResultToolbarExportMenu(info, 'embed')">
                                            <a-menu-item key="export-md">下载为 Markdown</a-menu-item>
                                            <a-menu-item key="export-pdf">下载为 PDF</a-menu-item>
                                            <a-menu-item key="export-docx">下载为 Word</a-menu-item>
                                          </a-menu>
                                        </template>
                                      </a-dropdown>
                                      <a-button
                                        class="analysis-result-preview-toolbar-outline-btn"
                                        :type="workbenchAnalysisEmbedDirty ? 'primary' : 'default'"
                                        :disabled="!workbenchAnalysisEmbedDirty || workbenchEmbedAnalysisOutputToolbarDisabled"
                                        title="保存编辑内容"
                                        aria-label="保存编辑内容"
                                        @click="saveWorkbenchAnalysisEmbedEdit"
                                      >保存</a-button>
                                    </div>
                                  </div>
                                </div>
                                <div class="analysis-result-preview-modal__layout workbench-analysis-embed-wrap">
                                  <div class="preview-modal-content-frame">
                                    <div class="analysis-result-preview-modal__panel analysis-result-preview-modal__panel--editor analysis-result-preview-modal__panel--tab-chrome-only">
                                      <div class="analysis-result-preview-modal__panel-body">
                                        <a-textarea
                                          v-model:value="workbenchAnalysisEmbedDraft"
                                          class="analysis-result-preview-modal__editor-textarea"
                                          :rows="22"
                                          :disabled="workbenchEmbedAnalysisOutputToolbarDisabled"
                                          placeholder="支持编辑 Markdown 正文，保存后写入当前结果（演示）"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </a-tab-pane>
                          <a-tab-pane v-if="!selectedMaterialIsWorkbenchCreatedTask" key="history" tab="历史版本">
                            <div class="workbench-result-preview-pane workbench-result-preview-pane--history">
                              <div class="skill-unified-tab-version-root">
                                <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--version-row" role="toolbar" aria-label="历史版本">
                                  <h3 class="ds-unified-tab-pane-chrome__title">历史版本</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions"></div>
                                </div>
                                <div class="skill-unified-tab-version-root__main skill-wizard-panel">
                                  <template v-if="selectedMaterial && selectedMaterial.type === 'analysis'">
                                    <div
                                      v-if="workbenchAnalysisVersionHistoryOnlyRows.length"
                                      class="skill-version-mgmt-history-section"
                                      role="region"
                                      aria-label="历史版本列表"
                                    >
                                      <h4 class="skill-version-mgmt-history__heading">历史版本 ({{ workbenchAnalysisVersionHistoryOnlyRows.length }})</h4>
                                      <div class="skill-version-mgmt-history">
                                        <div class="ds-l2-table-panel">
                                          <a-table
                                            :columns="workbenchAnalysisVersionMgmtColumns"
                                            :data-source="workbenchAnalysisVersionHistoryOnlyRows"
                                            row-key="key"
                                            size="small"
                                            :pagination="false"
                                            class="skill-library-version-mgmt-table wb-analysis-version-mgmt-table"
                                          >
                                            <template #bodyCell="{ column, record }">
                                              <template v-if="column.key === 'generationDesc'">
                                                <span class="skill-version-table__cell-desc" :title="record.generationDesc">{{ record.generationDesc }}</span>
                                              </template>
                                              <template v-else-if="column.key === 'action'">
                                                <span class="skill-version-mgmt-history__row-actions">
                                                  <a-button type="link" size="small" class="skill-version-table__version-link" @click="openWorkbenchAnalysisHistoryDiff(record, 'embed')">详情</a-button>
                                                  <a-button
                                                    type="link"
                                                    size="small"
                                                    class="skill-version-table__version-link"
                                                    @click="applyWorkbenchAnalysisMarkdownRollbackById(selectedMaterial && selectedMaterial.id, record.markdown)"
                                                  >回退</a-button>
                                                </span>
                                              </template>
                                              <template v-else>{{ record[column.dataIndex] }}</template>
                                            </template>
                                          </a-table>
                                        </div>
                                      </div>
                                    </div>
                                    <a-empty v-else description="暂无历史快照。" />
                                  </template>
                                  <a-empty v-else description="暂无历史版本。" />
                                </div>
                              </div>
                            </div>
                          </a-tab-pane>
                        </a-tabs>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </aside>
          </div>
          <a-modal
            v-model:open="wbTaskCreateModalOpen"
            title="创建任务"
            width="720"
            wrapClassName="modal-w-720 wb-task-create-modal"
            centered
            :maskClosable="false"
            @cancel="closeWorkbenchTaskCreateModal"
          >
            <div class="wb-task-create-modal__body">
              <a-steps :current="wbTaskCreateStep - 1" size="small" class="wb-task-create-modal__steps">
                <a-step title="执行方式" />
                <a-step title="选择资源" />
              </a-steps>
              <template v-if="wbTaskCreateStep === 1">
              <a-form layout="vertical" class="wb-task-create-modal__form">
                <a-form-item label="任务名称" required>
                  <a-input
                    v-model:value="wbTaskCreateForm.taskName"
                    allow-clear
                    placeholder="请输入任务名称"
                    aria-label="任务名称"
                  />
                </a-form-item>
                <a-form-item label="任务类型" required>
                  <a-radio-group v-model:value="wbTaskCreateForm.taskType" @change="onWbTaskCreateTypeChange">
                    <a-radio value="single">单次任务</a-radio>
                    <a-radio value="batch">跑批任务</a-radio>
                  </a-radio-group>
                </a-form-item>
                <a-form-item label="选择技能" required>
                  <a-select
                    v-model:value="wbTaskCreateForm.skillId"
                    :options="wbTaskCreateSkillOptions"
                    placeholder="请选择一个技能"
                    show-search
                    option-filter-prop="label"
                    allow-clear
                    @change="onWbTaskCreateSkillChange"
                  />
                </a-form-item>
                <template v-if="wbTaskCreateForm.taskType === 'batch'">
                  <a-form-item label="数据源文件" required>
                    <div
                      class="wb-task-create-datasource"
                      :class="{ 'wb-task-create-datasource--has-file': !!wbTaskCreateForm.dataSourceFile }"
                    >
                      <div
                        v-if="!wbTaskCreateForm.dataSourceFile"
                        class="wb-task-create-datasource__dragger ant-upload ant-upload-drag"
                        role="button"
                        tabindex="0"
                        @click="mockWbTaskCreateDataSourceUpload"
                        @keydown.enter.prevent="mockWbTaskCreateDataSourceUpload"
                        @keydown.space.prevent="mockWbTaskCreateDataSourceUpload"
                      >
                        <span class="ant-upload ant-upload-btn">
                          <p class="ant-upload-drag-icon"><i class="fas fa-file-arrow-up" aria-hidden="true"></i></p>
                          <div class="wb-task-create-datasource__dragger-text">
                            <p class="ant-upload-text">拖拽文件到此处，或点击上传</p>
                            <p class="ant-upload-hint">支持 .xlsx / .csv，单文件不超过 50MB</p>
                          </div>
                        </span>
                      </div>
                      <div v-else class="wb-task-create-datasource__dragger wb-task-create-datasource__dragger--filled">
                        <div class="wb-task-create-datasource__dragger-inner">
                          <p class="ant-upload-drag-icon">
                            <i
                              :class="wbTaskCreateForm.dataSourceFile.mockKey === 'csv' ? 'fas fa-file-csv' : 'fas fa-file-excel'"
                              aria-hidden="true"
                            ></i>
                          </p>
                          <span class="wb-task-create-datasource__file-name" :title="wbTaskCreateForm.dataSourceFile.name">{{
                            wbTaskCreateForm.dataSourceFile.name
                          }}</span>
                          <a-button
                            type="link"
                            size="small"
                            class="wb-task-create-datasource__change"
                            @click.stop="clearWbTaskCreateDataSource"
                          >
                            更换文件
                          </a-button>
                        </div>
                      </div>
                      <p class="wb-task-create-preview-guide">请选择标识列（可多选），AI 将根据所选标识区分不同的子任务</p>
                      <div
                        class="wb-task-create-preview-table"
                        :class="{ 'wb-task-create-preview-table--empty': !wbTaskCreateForm.dataSourceFile }"
                      >
                        <a-table
                          :columns="wbTaskCreatePreviewColumns"
                          :data-source="wbTaskCreatePreviewRows"
                          :pagination="false"
                          size="small"
                          :scroll="{ x: 'max-content', y: wbTaskCreatePreviewScrollY }"
                          class="skill-library-version-mgmt-table"
                        >
                          <template v-if="!wbTaskCreateForm.dataSourceFile" #emptyText>
                            <div class="wb-task-create-preview-empty">
                              <a-empty :image="false" description="上传文件后预览数据（默认展示前 5 行）" />
                            </div>
                          </template>
                          <template #headerCell="{ column }">
                            <div
                              v-if="wbTaskCreateForm.dataSourceFile"
                              class="wb-task-create-preview-th"
                              role="button"
                              tabindex="0"
                              :class="{ 'wb-task-create-preview-th--active': isWbTaskCreateIdColumnSelected(column.dataIndex) }"
                              @click="toggleWbTaskCreateIdColumn(column.dataIndex)"
                              @keydown.enter.prevent="toggleWbTaskCreateIdColumn(column.dataIndex)"
                              @keydown.space.prevent="toggleWbTaskCreateIdColumn(column.dataIndex)"
                            >
                              <a-checkbox
                                :checked="isWbTaskCreateIdColumnSelected(column.dataIndex)"
                                @click.stop="toggleWbTaskCreateIdColumn(column.dataIndex)"
                              />
                              <span class="wb-task-create-preview-th__title" :title="column.title">{{ column.title }}</span>
                            </div>
                          </template>
                          <template #bodyCell="{ column, text }">
                            <span
                              v-if="wbTaskCreateForm.dataSourceFile"
                              class="wb-task-create-preview-cell"
                              :class="{ 'wb-task-create-preview-cell--id': isWbTaskCreateIdColumnSelected(column.dataIndex) }"
                            >{{ text }}</span>
                          </template>
                        </a-table>
                      </div>
                      <div
                        v-if="wbTaskCreateForm.dataSourceFile"
                        class="wb-task-create-preview-meta"
                      >
                        <span class="wb-task-create-preview-meta__left">数据预览{{ wbTaskCreatePreviewRowCount }}行</span>
                        <span class="wb-task-create-preview-meta__right">
                          <template v-if="wbTaskCreateBatchSelectedColumnCount">
                            已选 {{ wbTaskCreateBatchSelectedColumnCount }} 列，预计生成 {{ wbTaskCreateBatchEstimatedChildCount }} 个子任务
                          </template>
                          <template v-else>请选择标识列</template>
                        </span>
                      </div>
                    </div>
                  </a-form-item>
                </template>
                <a-form-item label="任务指令" required class="wb-task-create-instruction-item">
                  <div class="wb-task-create-instruction-control">
                    <div
                      class="wb-task-create-instruction-field"
                      :class="'wb-task-create-instruction-field--' + wbTaskCreateInstructionState"
                    >
                    <a-textarea
                      v-model:value="wbTaskCreateForm.instruction"
                      :rows="5"
                      :disabled="wbTaskCreateInstructionDisabled"
                      :placeholder="wbTaskCreateInstructionPlaceholder"
                      aria-label="任务指令"
                      :aria-busy="wbTaskCreateInstructionState === 'generating'"
                    />
                    <div
                      v-if="wbTaskCreateInstructionState === 'generating'"
                      class="wb-task-create-instruction-generating"
                      aria-live="polite"
                    >
                      <a-spin size="small" />
                      <span>正在根据配置生成任务指令…</span>
                    </div>
                  </div>
                    <div
                      v-show="wbTaskCreateInstructionState === 'ready'"
                      class="wb-task-create-instruction-hint"
                      role="note"
                      aria-label="任务指令说明"
                    >
                      <i class="fas fa-circle-info wb-task-create-instruction-hint__icon" aria-hidden="true"></i>
                      <span class="wb-task-create-instruction-hint__text">
                        该指令基于配置自动生成/覆盖，将应用于引导大模型创建子任务，请谨慎修改。
                      </span>
                    </div>
                  </div>
                </a-form-item>
              </a-form>
              </template>
              <section
                v-else
                class="wb-task-create-modal__resources"
                aria-labelledby="wb-task-create-resources-heading"
              >
                <div id="wb-task-create-resources-heading" class="wb-task-create-modal__resources-heading">
                  <span class="wb-task-create-modal__resources-required-mark" aria-hidden="true">*</span>
                  <span>请选择资源</span>
                </div>
                <div class="wb-task-create-transfer">
                  <section class="wb-task-create-transfer__panel">
                    <div class="wb-task-create-transfer__panel-head">
                      <a-tabs
                        :activeKey="wbTaskCreateForm.resourceTab"
                        size="small"
                        class="wb-task-create-transfer__tabs"
                        @update:activeKey="onWbTaskCreateResourceTabChange"
                      >
                        <a-tab-pane key="file" tab="文件" />
                        <a-tab-pane key="database" tab="数据库" />
                        <a-tab-pane key="graph" tab="图谱" />
                      </a-tabs>
                    </div>
                    <div class="wb-task-create-transfer__panel-body">
                      <a-input
                        v-model:value="wbTaskCreateForm.resourceQuery"
                        allow-clear
                        placeholder="搜索资源名称"
                        class="ds-input-inline-search ds-input-inline-search--compact wb-task-create-transfer__search"
                      >
                        <template #prefix>
                          <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                        </template>
                      </a-input>
                      <div v-if="wbTaskCreateVisibleResources.length" class="wb-task-create-transfer__list">
                        <div
                          v-for="item in wbTaskCreateVisibleResources"
                          :key="item.key"
                          class="wb-task-create-transfer__list-item nlm-tree-leaf nlm-tree-leaf--analysis"
                          @click="toggleWbTaskCreateResource(item)"
                        >
                          <span class="wb-task-create-transfer__check">
                            <a-checkbox
                              :checked="isWbTaskCreateResourceSelected(item.key)"
                              @click.stop
                              @change="toggleWbTaskCreateResource(item)"
                            />
                          </span>
                          <span class="nlm-tree-leaf-icon">
                            <i class="fas" :class="[item.iconClass, item.iconToneClass || '']" aria-hidden="true"></i>
                          </span>
                          <div class="nlm-tree-leaf-title-wrap">
                            <div class="nlm-tree-leaf-col">
                              <div class="nlm-tree-leaf-title">{{ item.name }}</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <a-empty v-else description="暂无可添加资源" />
                    </div>
                  </section>
                  <section class="wb-task-create-transfer__panel wb-task-create-transfer__panel--selected">
                    <div class="wb-task-create-transfer__selected-head">
                      <span>已选资源（{{ wbTaskCreateForm.selectedResources.length }}）</span>
                      <a-button
                        v-if="wbTaskCreateForm.selectedResources.length"
                        type="link"
                        size="small"
                        @click="clearWbTaskCreateResources"
                      >清空</a-button>
                    </div>
                    <div class="wb-task-create-transfer__panel-body">
                      <div v-if="wbTaskCreateForm.selectedResources.length" class="wb-task-create-transfer__list">
                        <div
                          v-for="item in wbTaskCreateForm.selectedResources"
                          :key="'sel-' + item.key"
                          class="wb-task-create-transfer__list-item wb-task-create-transfer__list-item--selected nlm-tree-leaf nlm-tree-leaf--analysis"
                        >
                          <span class="nlm-tree-leaf-icon">
                            <i class="fas" :class="[item.iconClass, item.iconToneClass || '']" aria-hidden="true"></i>
                          </span>
                          <div class="nlm-tree-leaf-title-wrap">
                            <div class="nlm-tree-leaf-col">
                              <div class="nlm-tree-leaf-title">{{ item.name }}</div>
                            </div>
                          </div>
                          <a-button
                            type="text"
                            size="small"
                            class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn"
                            title="移除"
                            aria-label="移除资源"
                            @click="removeWbTaskCreateResource(item.key)"
                          >
                            <i class="fas fa-xmark" aria-hidden="true"></i>
                          </a-button>
                        </div>
                      </div>
                      <a-empty v-else description="请从左侧添加资源" />
                    </div>
                  </section>
                </div>
              </section>
            </div>
            <template #footer>
              <a-button @click="closeWorkbenchTaskCreateModal">取消</a-button>
              <a-button v-if="wbTaskCreateStep === 2" @click="wbTaskCreateStep = 1">上一步</a-button>
              <a-button
                v-if="wbTaskCreateStep === 1"
                type="primary"
                :disabled="wbTaskCreateStep1NextDisabled"
                @click="goWbTaskCreateStep2"
              >下一步</a-button>
              <a-button
                v-else
                type="primary"
                :disabled="wbTaskCreateSubmitDisabled"
                @click="submitWorkbenchTaskCreate"
              >创建任务</a-button>
            </template>
          </a-modal>
          <a-modal
            v-model:open="wbGenerateSkillConfigModalOpen"
            title="生成技能配置"
            width="560"
            wrapClassName="modal-w-560 wb-generate-skill-config-modal"
            centered
            :maskClosable="false"
            :destroyOnClose="true"
            @cancel="closeGenerateSkillConfigModal"
          >
            <div class="wb-generate-skill-config-modal__body">
              <a-form layout="vertical" class="wb-generate-skill-config-modal__form">
                <a-form-item label="请输入生成技能要求" required>
                  <a-textarea
                    v-model:value="wbGenerateSkillIntentText"
                    :rows="5"
                    :maxlength="2000"
                    :show-count="true"
                    placeholder="请简要描述你期望生成的具体技能要求或目标"
                    class="wb-generate-skill-config-modal__intent"
                    aria-label="请简要描述你期望生成的具体技能要求或目标"
                  />
                </a-form-item>
              </a-form>
              <section class="wb-generate-skill-reco" aria-labelledby="wb-generate-skill-reco-h">
                <h4 id="wb-generate-skill-reco-h" class="wb-generate-skill-reco__title">智能推荐</h4>
                <div class="wb-generate-skill-reco__list" role="list">
                  <div
                    v-for="(reco, idx) in wbGenerateSkillRecommendationItems"
                    :key="'wb-skill-reco-' + idx"
                    class="wb-generate-skill-reco__card"
                    :class="{
                      'wb-generate-skill-reco__card--loading': reco.loading,
                      'wb-generate-skill-reco__card--ready': !reco.loading && reco.text,
                    }"
                    role="listitem"
                    :aria-busy="reco.loading"
                  >
                    <template v-if="reco.loading">
                      <a-spin size="small" />
                      <span class="wb-generate-skill-reco__loading-text">生成中…</span>
                    </template>
                    <template v-else>
                      <button
                        type="button"
                        class="wb-generate-skill-reco__main"
                        :disabled="!reco.text"
                        @click="applyGenerateSkillRecommendation(reco.text)"
                      >
                        <span class="wb-generate-skill-reco__text">{{ reco.text }}</span>
                      </button>
                      <a-button
                        type="primary"
                        size="small"
                        class="wb-generate-skill-reco__use"
                        :disabled="!reco.text"
                        aria-label="使用本条推荐填入意图描述"
                        @click.stop="applyGenerateSkillRecommendation(reco.text)"
                      >
                        使用
                      </a-button>
                    </template>
                  </div>
                </div>
              </section>
            </div>
            <template #footer>
              <a-button @click="closeGenerateSkillConfigModal">取消</a-button>
              <a-button type="primary" :disabled="!wbGenerateSkillIntentTrimmed" @click="submitGenerateSkillConfig">创建任务</a-button>
            </template>
          </a-modal>
          <a-modal
            v-model:open="saveResultModalVisible"
            title="保存结果"
            width="560"
            wrapClassName="modal-w-560"
            @cancel="closeSaveResultModal"
            @ok="confirmSaveResultModal"
            ok-text="保存"
            cancel-text="取消"
          >
            <div style="display:flex;flex-direction:column;gap:var(--ds-space-sm);">
              <a-form layout="vertical">
                <a-form-item label="结果名称" required>
                  <a-input
                    v-model:value="saveResultForm.name"
                    placeholder="例如：合同与发票一致性检查结果"
                    allow-clear
                    :maxlength="60"
                  />
                </a-form-item>
              </a-form>
            </div>
          </a-modal>
          <a-modal
            v-model:open="summaryTaskResultModalVisible"
            title="技能配置确认"
            width="1200"
            wrapClassName="modal-w-920"
            @cancel="closeSummaryTaskResultModal"
            @ok="confirmSummaryTaskResultModal"
            ok-text="确认保存为工作台级技能"
            cancel-text="取消"
          >
            <div class="analysis-template-config-modal-body">
              <div class="analysis-template-config-card">
                <div class="skill-object-field-group">
                  <div class="skill-object-field-label">技能名称<span class="skill-required">*</span></div>
                  <div class="ds-input-ai-polish-wrap">
                    <div
                      class="ds-input-ai-polish-input-shell ds-input-ai-polish-input-shell--with-corner ds-input-ai-polish-input-shell--affix"
                      :class="{ 'is-polishing': freeAuditAiPolishKey === 'summary:name' }"
                    >
                      <a-input v-model:value="summaryTaskResultForm.name" placeholder="请输入技能名称" allow-clear />
                      <div class="ds-input-ai-polish-corner">
                        <span v-show="freeAuditAiPolishKey === 'summary:name'" class="ds-input-ai-polish-status">润色中...</span>
                        <a-button type="text" class="ds-icon-btn ds-input-ai-polish-undo-btn" aria-label="回退" title="回退到润色前" :disabled="freeAuditPolishUndoDisabled('summary:name')" @click.stop="undoSummaryTaskName">
                          <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                        </a-button>
                        <a-button type="text" class="ds-icon-btn ds-input-ai-polish-btn" aria-label="智能润色" title="智能润色" :disabled="!!freeAuditAiPolishKey" @click.stop="demoAiPolishSummaryTaskName">
                          <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                        </a-button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="analysis-template-config-grid">
                <div class="analysis-template-config-card">
                  <div class="skill-config-section-head">
                    <div class="skill-config-section-title-cluster">
                      <h3 class="skill-config-col-title">审计资料</h3>
                    </div>
                    <a-button type="primary" size="small" ghost @click="addSummaryTemplateExtractionRule"><i class="fas fa-plus" style="margin-right: var(--ds-space-xxs);"></i>添加</a-button>
                  </div>
                  <div class="skill-object-list-wrap skill-object-list-wrap--config">
                    <div
                      v-for="(er, idx) in (summaryTaskResultForm.extractionRules || [])"
                      :key="er.id"
                      class="skill-object-row"
                      :class="{ 'is-expanded': summaryTaskResultExpandedRuleId === er.id }"
                    >
                      <div class="skill-object-row-main" @click="toggleSummaryTemplateRuleExpand(er.id)">
                        <span class="skill-object-idx">{{ idx + 1 }}</span>
                        <div class="skill-object-row-text">
                          <div class="skill-object-title-line">{{ (er.title || '').trim() || '（未填写资料说明）' }}</div>
                          <div class="skill-object-body-preview">{{ (er.body || '').trim() || '（未填写抽取或核对字段）' }}</div>
                          <div class="ds-text-micro-secondary" style="margin-top: var(--ds-space-xxs);">已匹配 {{ summaryRuleMatchedMaterialCount(er) }} 份文档</div>
                        </div>
                        <div class="skill-object-row-actions">
                          <a-button
                            type="text"
                            danger
                            size="small"
                            shape="circle"
                            class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--danger skill-object-row-delete-btn"
                            aria-label="删除该分析对象"
                            title="删除"
                            @click.stop="removeSummaryTemplateExtractionRule(idx)"
                            :disabled="(summaryTaskResultForm.extractionRules || []).length <= 1"
                          >
                            <template #icon><i class="fas fa-xmark" aria-hidden="true"></i></template>
                          </a-button>
                        </div>
                      </div>
                      <div v-show="summaryTaskResultExpandedRuleId === er.id" class="skill-object-row-detail" @click.stop>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label-row">
                            <div class="skill-object-field-label skill-object-field-label--inline">请输入资料类型（可输入多个）<span class="skill-required">*</span></div>
                            <div class="skill-object-field-polish">
                              <span v-show="freeAuditAiPolishKey === 'summary-er:' + er.id + ':title'" class="ds-input-ai-polish-status">润色中...</span>
                              <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="freeAuditPolishUndoDisabled('summary-er:' + er.id + ':title')" @click.stop="undoSummaryErField(er, 'title')">
                                <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                              </button>
                              <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="!!freeAuditAiPolishKey" @click.stop="demoAiPolishSummaryErField(er, 'title')">
                                <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-btn__label">润色</span>
                              </button>
                            </div>
                          </div>
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'summary-er:' + er.id + ':title' }">
                              <a-textarea
                                v-model:value="er.title"
                                :rows="2"
                                :placeholder="skillObjectMaterialTypePlaceholder"
                              />
                            </div>
                          </div>
                        </div>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label-row">
                            <div class="skill-object-field-label skill-object-field-label--inline">请详细描述或罗列该审计资料中需要审计的具体内容<span class="skill-required">*</span></div>
                            <div class="skill-object-field-polish">
                              <span v-show="freeAuditAiPolishKey === 'summary-er:' + er.id + ':body'" class="ds-input-ai-polish-status">润色中...</span>
                              <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="freeAuditPolishUndoDisabled('summary-er:' + er.id + ':body')" @click.stop="undoSummaryErField(er, 'body')">
                                <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                              </button>
                              <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="!!freeAuditAiPolishKey" @click.stop="demoAiPolishSummaryErField(er, 'body')">
                                <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-btn__label">润色</span>
                              </button>
                            </div>
                          </div>
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'summary-er:' + er.id + ':body' }">
                              <a-textarea v-model:value="er.body" placeholder="列出后续比对、测算或下结论所依赖的字段及口径（尽量与资料表述一致）。示例：含税金额、业务日期、对方名称、单据编号；涉及明细时的维度字段（如部门、项目、费用类型等）。" :rows="4" />
                            </div>
                          </div>
                        </div>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label">匹配文档（可多选）<span class="skill-required">*</span></div>
                          <a-select
                            v-model:value="er.materialIds"
                            mode="multiple"
                            allow-clear
                            size="small"
                            :max-tag-count="3"
                            class="template-material-multi-select"
                            placeholder="请选择要参与该分析对象的资料"
                            :options="workbenchMaterialSelectOptions"
                          />
                          <div class="ds-text-micro-secondary" style="margin-top: var(--ds-space-xs);">当前已匹配 {{ summaryRuleMatchedMaterialCount(er) }} 份文档</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="analysis-template-config-card">
                  <div class="skill-config-section-head">
                    <div class="skill-config-section-title-cluster">
                      <h3 class="skill-config-col-title">审计思路</h3>
                    </div>
                    <div class="skill-object-field-polish">
                      <span v-show="freeAuditAiPolishKey === 'summary:analysisRule'" class="ds-input-ai-polish-status">润色中...</span>
                      <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="freeAuditPolishUndoDisabled('summary:analysisRule')" @click.stop="undoSummaryTaskAnalysisRule">
                        <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                        <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                      </button>
                      <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="!!freeAuditAiPolishKey" @click.stop="demoAiPolishSummaryTaskAnalysisRule">
                        <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                        <span class="ds-input-ai-polish-btn__label">润色</span>
                      </button>
                    </div>
                  </div>
                  <div class="ds-input-ai-polish-wrap">
                    <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'summary:analysisRule' }">
                      <a-textarea v-model:value="summaryTaskResultForm.analysisRule" :rows="16" :placeholder="getSkillAnalysisRulePlaceholder()" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </a-modal>
          <a-modal
            v-model:open="wbProjectSkillCreateBasicModalOpen"
            title="创建技能"
            width="560"
            centered
            :maskClosable="false"
            @cancel="closeWbProjectSkillCreateBasicModal"
          >
            <a-form layout="vertical">
              <a-form-item label="技能名称" required>
                <a-input
                  v-model:value="wbProjectSkillCreateBasicForm.name"
                  placeholder="请输入技能名称"
                  allow-clear
                  :maxlength="60"
                />
              </a-form-item>
              <a-form-item label="技能描述">
                <a-textarea
                  v-model:value="wbProjectSkillCreateBasicForm.description"
                  placeholder="选填。描述该技能的用途与适用场景"
                  :rows="3"
                  :maxlength="300"
                  show-count
                />
              </a-form-item>
              <a-form-item label="标签" style="margin-bottom: 0;">
                <a-select
                  v-model:value="wbProjectSkillCreateBasicForm.tags"
                  mode="tags"
                  placeholder="回车添加标签，如：函证、凭证核对"
                  style="width: 100%"
                />
              </a-form-item>
            </a-form>
            <template #footer>
              <a-button @click="closeWbProjectSkillCreateBasicModal">取消</a-button>
              <a-button type="primary" :loading="wbProjectSkillCreateBasicSubmitting" @click="submitWbProjectSkillCreateBasic">提交并继续配置</a-button>
            </template>
          </a-modal>
          <a-modal
                v-model:open="wbProjectSkillDetailModalOpen"
                width="1040"
                wrapClassName="modal-skill-config modal-project-skill-config"
                centered
                :footer="null"
                :maskClosable="false"
                @cancel="() => closeWbProjectSkillDetailModal(false)"
              >
                <template #title>
                  <div class="skill-modal-config-title-row">
                    <div class="skill-modal-config-title-main">
                      <span class="skill-modal-config-title-text">{{ wbProjectSkillDetailModalTitle }}</span>
                    </div>
                  </div>
                </template>
                <div v-if="wbDetailSelectedSkill" class="tc-skill-modal-body tc-skill-modal-body--unified">
                  <a-tabs :activeKey="wbProjectSkillDetailActiveTab" class="skill-unified-modal-tabs" tab-position="left" @update:activeKey="onWbProjectSkillTabUpdate">
                    <a-tab-pane key="basic" tab="基本信息">
                      <div class="ds-unified-tab-pane-stack">
                        <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息操作">
                          <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                          <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions">
                            <template v-if="!wbProjectSkillDetailReadOnly">
                              <a-button
                                :type="wbProjectSkillBasicPaneDirty ? 'primary' : 'default'"
                                :disabled="!wbProjectSkillBasicPaneDirty"
                                @click="saveWbProjectSkillBasicPane"
                              >保存</a-button>
                            </template>
                          </div>
                        </div>
                        <a-form layout="vertical" class="skill-modal-form skill-wizard-panel skill-unified-tab-basic">
                          <a-form-item label="名称" required>
                            <a-input
                              v-model:value="wbProjectSkillForm.name"
                              placeholder="如：三公经费异常波动扫描"
                              allow-clear
                              :disabled="wbProjectSkillBasicFieldsLocked"
                            />
                          </a-form-item>
                          <a-form-item label="简介">
                            <a-textarea
                              v-model:value="wbProjectSkillForm.description"
                              placeholder="用途示例：系统自动比对合同与发票金额及时间逻辑，输出异常清单并提示优先核查项。"
                              :rows="2"
                              :disabled="wbProjectSkillBasicFieldsLocked"
                            />
                          </a-form-item>
                          <a-form-item label="标签" style="margin-bottom: 0;">
                            <a-select
                              v-model:value="wbProjectSkillForm.tags"
                              mode="tags"
                              placeholder="回车添加，如：财务、合规"
                              style="width: 100%"
                              :disabled="wbProjectSkillBasicFieldsLocked"
                            />
                          </a-form-item>
                        </a-form>
                      </div>
                    </a-tab-pane>
                    <a-tab-pane key="config" tab="技能配置">
                  <div class="ds-unified-tab-pane-stack">
                    <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="技能配置操作">
                      <h3 class="ds-unified-tab-pane-chrome__title">技能配置</h3>
                      <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions">
                        <template v-if="!wbProjectSkillDetailReadOnly">
                          <a-button type="default" @click="onWbProjectSkillConfigSaveMenuClick({ key: 'publish-new' })">快照</a-button>
                          <a-button
                            :type="wbProjectSkillConfigPaneDirty ? 'primary' : 'default'"
                            :disabled="!wbProjectSkillConfigPaneDirty"
                            @click="saveWbProjectSkillConfigPane"
                          >保存</a-button>
                        </template>
                      </div>
                    </div>
                  <div class="skill-config-master-detail">
                    <aside class="skill-config-nav-pane" aria-label="技能配置结构">
                      <div class="skill-config-nav-tree">
                        <div class="skill-config-nav-tree-head skill-config-nav-tree-head--with-actions">
                          <span>可配置文件</span>
                          <a-dropdown
                            :trigger="['hover', 'click']"
                            placement="bottomRight"
                            overlayClassName="skill-config-add-file-dropdown"
                          >
                            <a-button
                              type="text"
                              size="small"
                              class="ds-icon-btn ds-icon-btn--standard skill-config-nav-add-btn"
                              aria-label="添加文件或文件夹"
                              :disabled="wbProjectSkillConfigTabLocked"
                              @click.stop
                            >
                              <i class="fas fa-plus" aria-hidden="true"></i>
                            </a-button>
                            <template #overlay>
                              <a-menu @click="onWbProjectSkillConfigAddMenuClick">
                                <a-menu-item key="md">Markdown（.md）</a-menu-item>
                                <a-sub-menu key="sub-code" title="代码文件">
                                  <a-menu-item key="code:python">Python</a-menu-item>
                                  <a-menu-item key="code:javascript">JavaScript</a-menu-item>
                                  <a-menu-item key="code:typescript">TypeScript</a-menu-item>
                                  <a-menu-item key="code:shell">Shell</a-menu-item>
                                </a-sub-menu>
                                <a-menu-item key="folder">文件夹</a-menu-item>
                              </a-menu>
                            </template>
                          </a-dropdown>
                        </div>
                        <div class="skill-config-nav-tree-body">
                          <a-tree
                            class="skill-config-ant-tree"
                            block-node
                            show-line
                            :tree-data="wbProjectSkillConfigTreeData"
                            v-model:expanded-keys="wbProjectSkillConfigTreeExpandedKeys"
                            :selected-keys="wbProjectSkillConfigTreeSelectedKeys"
                            :draggable="wbProjectSkillConfigTreeNodeDraggable"
                            @select="onWbProjectSkillConfigTreeSelect"
                            @drop="onWbProjectSkillConfigTreeDrop"
                          >
                            <template #title="{ key, title }">
                              <span class="skill-config-tree-title-row">
                                <span
                                  class="skill-config-tree-title-row__text"
                                  :class="{ 'skill-config-tree-title-row__text--ellipsis': key !== 'rule' }"
                                >{{ title }}</span>
                                <a-button
                                  v-if="wbProjectSkillConfigTreeCanDeleteKey(key) && !wbProjectSkillConfigTabLocked"
                                  type="text"
                                  danger
                                  size="small"
                                  class="ds-icon-btn ds-icon-btn--xs skill-config-tree-title-row__del"
                                  aria-label="删除该项"
                                  @click.stop="removeWbProjectSkillConfigTreeNode(key)"
                                >
                                  <i class="fas fa-xmark" aria-hidden="true"></i>
                                </a-button>
                              </span>
                            </template>
                          </a-tree>
                        </div>
                      </div>
                    </aside>
                    <div class="skill-config-detail-pane">
                      <div v-if="wbProjectSkillConfigNavKey === 'rule'" class="skill-config-detail-inner">
                        <div class="skill-config-section-head">
                          <div class="skill-config-section-title-cluster">
                            <h3 class="skill-config-col-title">审计思路</h3>
                          </div>
                          <div v-if="!wbProjectSkillConfigTabLocked" class="skill-object-field-polish">
                            <span v-show="freeAuditAiPolishKey === 'wb-analysisRule'" class="ds-input-ai-polish-status">润色中...</span>
                            <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="wbFreeAuditPolishUndoDisabled('wb-analysisRule')" @click.stop="undoWbAnalysisRule">
                              <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                              <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                            </button>
                            <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="!!freeAuditAiPolishKey" @click.stop="demoAiPolishWbAnalysisRule">
                              <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                              <span class="ds-input-ai-polish-btn__label">润色</span>
                            </button>
                          </div>
                        </div>
                        <div class="skill-rules-editor">
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'wb-analysisRule' }">
                              <textarea
                                class="skill-rules-editor-textarea"
                                v-model="wbDetailSelectedSkill.analysisRule"
                                :disabled="wbProjectSkillConfigTabLocked"
                                :placeholder="getSkillAnalysisRulePlaceholder()"
                                @blur="scheduleWbProjectSkillDetailSync"
                              ></textarea>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div v-else-if="wbProjectSkillConfigSelectedFolder" class="skill-config-detail-inner">
                        <div class="skill-config-section-head">
                          <div class="skill-config-section-title-cluster">
                            <h3 class="skill-config-col-title">文件夹</h3>
                          </div>
                        </div>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label skill-object-field-label--inline">文件夹名称<span class="skill-required">*</span></div>
                          <a-input
                            v-model:value="wbProjectSkillConfigSelectedFolder.name"
                            placeholder="例如：抽取脚本、辅助说明"
                            :disabled="wbProjectSkillConfigTabLocked"
                            @blur="scheduleWbProjectSkillDetailSync"
                          />
                        </div>
                      </div>
                      <div v-else-if="wbProjectSkillConfigSelectedFile" class="skill-config-detail-inner">
                        <div class="skill-config-section-head">
                          <div class="skill-config-section-title-cluster">
                            <h3 class="skill-config-col-title">配置文件</h3>
                            <UiTagSm
                              v-if="wbProjectSkillConfigSelectedFile.fileKind === 'md'"
                              class="ds-tag--tone-primary"
                            >Markdown</UiTagSm>
                            <UiTagSm v-else>{{ wbProjectSkillConfigSelectedFileCodeLabel }}</UiTagSm>
                          </div>
                        </div>
                        <a-alert
                          v-if="wbProjectSkillConfigDuplicatePaths.length"
                          type="warning"
                          show-icon
                          :message="'文件名路径重复：' + wbProjectSkillConfigDuplicatePaths.join('、')"
                          style="margin-bottom: var(--ds-space-sm);"
                        />
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label-row">
                            <div class="skill-object-field-label skill-object-field-label--inline">文件名<span class="skill-required">*</span></div>
                            <div class="skill-object-field-polish">
                              <span v-show="freeAuditAiPolishKey === 'wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':fn'" class="ds-input-ai-polish-status">润色中...</span>
                              <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="wbFreeAuditPolishUndoDisabled('wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':fn')" @click.stop="undoWbSkillFileField(wbProjectSkillConfigSelectedFile, 'filename')">
                                <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                              </button>
                              <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="wbProjectSkillConfigTabLocked || !!freeAuditAiPolishKey" @click.stop="demoAiPolishWbSkillFileField(wbProjectSkillConfigSelectedFile, 'filename')">
                                <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-btn__label">润色</span>
                              </button>
                            </div>
                          </div>
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':fn' }">
                              <a-input v-model:value="wbProjectSkillConfigSelectedFile.filename" :disabled="wbProjectSkillConfigTabLocked" placeholder="例如：notes.md、extract.py" @blur="scheduleWbProjectSkillDetailSync" />
                            </div>
                          </div>
                        </div>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label-row">
                            <div class="skill-object-field-label skill-object-field-label--inline">具体内容<span class="skill-required">*</span></div>
                            <div class="skill-object-field-polish">
                              <span v-show="freeAuditAiPolishKey === 'wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':ct'" class="ds-input-ai-polish-status">润色中...</span>
                              <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="wbFreeAuditPolishUndoDisabled('wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':ct')" @click.stop="undoWbSkillFileField(wbProjectSkillConfigSelectedFile, 'content')">
                                <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                              </button>
                              <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="wbProjectSkillConfigTabLocked || !!freeAuditAiPolishKey" @click.stop="demoAiPolishWbSkillFileField(wbProjectSkillConfigSelectedFile, 'content')">
                                <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-btn__label">润色</span>
                              </button>
                            </div>
                          </div>
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':ct' }">
                              <textarea
                                v-if="wbProjectSkillConfigSelectedFile.fileKind === 'md'"
                                class="skill-rules-editor-textarea"
                                v-model="wbProjectSkillConfigSelectedFile.content"
                                :disabled="wbProjectSkillConfigTabLocked"
                                placeholder="写入该文件的说明、抽取口径或提示词片段等。"
                                rows="14"
                                @blur="scheduleWbProjectSkillDetailSync"
                              ></textarea>
                              <textarea
                                v-else
                                class="skill-rules-editor-textarea ds-font-mono"
                                v-model="wbProjectSkillConfigSelectedFile.content"
                                :disabled="wbProjectSkillConfigTabLocked"
                                placeholder="代码或脚本内容（演示为纯文本编辑区）。"
                                rows="14"
                                @blur="scheduleWbProjectSkillDetailSync"
                              ></textarea>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  </div>
                    </a-tab-pane>
                  </a-tabs>
                </div>
                <div v-else style="padding: var(--ds-space-m) 0;">
                  <a-empty description="未找到技能，请关闭后重试。" />
                </div>
              </a-modal>
          <a-modal
            v-model:open="wbMaterialMetaEditVisible"
            title="重命名资料"
            width="520"
            wrapClassName="modal-w-560"
            :maskClosable="false"
            @cancel="cancelWorkbenchProjectMaterialMetaEdit"
          >
            <a-form layout="vertical">
              <a-form-item label="资料名称" style="margin-bottom: 0;">
                <a-input v-model:value="wbMaterialMetaEditForm.name" placeholder="请输入资料名称" allow-clear />
              </a-form-item>
            </a-form>
            <template #footer>
              <a-button
                :type="wbMaterialMetaEditDirty ? 'primary' : 'default'"
                :disabled="!wbMaterialMetaEditDirty"
                @click="confirmWorkbenchProjectMaterialMetaEdit"
              >确定</a-button>
            </template>
          </a-modal>
          <a-modal
            v-model:open="wbCreateFolderModalOpen"
            title="新建文件夹"
            width="520"
            wrapClassName="modal-w-560"
            :maskClosable="false"
            @cancel="closeWorkbenchMaterialCreateFolderModal"
          >
            <a-form layout="vertical">
              <a-form-item label="文件夹名称" style="margin-bottom: 0;">
                <a-input v-model:value="wbCreateFolderForm.name" placeholder="请输入文件夹名称" allow-clear />
              </a-form-item>
            </a-form>
            <template #footer>
              <a-button @click="closeWorkbenchMaterialCreateFolderModal">取消</a-button>
              <a-button type="primary" @click="confirmWorkbenchMaterialCreateFolder">创建</a-button>
            </template>
          </a-modal>
          <a-modal
            v-model:open="wbDeleteFolderModalOpen"
            title="删除文件夹"
            width="480"
            wrapClassName="modal-w-560"
            ok-text="确认删除"
            :ok-button-props="{ danger: true }"
            @ok="confirmDeleteWorkbenchMaterialFolder"
            @cancel="wbDeleteFolderModalOpen = false; wbDeleteFolderTarget = null"
          >
            <p v-if="wbDeleteFolderTarget" style="margin:0;line-height:1.6;">
              将删除文件夹「{{ wbDeleteFolderTarget.name }}」及其下的子文件夹与资料（演示数据）。此操作不可恢复，请确认已选中正确目标。
            </p>
          </a-modal>
          <a-modal
            v-model:open="wbArResultCreateFolderModalOpen"
            title="创建文件夹"
            width="520"
            wrapClassName="modal-w-560"
            :maskClosable="false"
            @cancel="closeWorkbenchAnalysisResultCreateFolderModal"
          >
            <a-form layout="vertical">
              <a-form-item label="文件夹名称" style="margin-bottom: 0;">
                <a-input v-model:value="wbArResultCreateFolderName" placeholder="请输入文件夹名称" allow-clear />
              </a-form-item>
            </a-form>
            <template #footer>
              <a-button @click="closeWorkbenchAnalysisResultCreateFolderModal">取消</a-button>
              <a-button type="primary" @click="confirmWorkbenchAnalysisResultCreateFolder">创建</a-button>
            </template>
          </a-modal>
          <a-modal
            v-model:open="wbTaskResourcePreviewOpen"
            width="760"
            wrapClassName="modal-w-760 material-preview-modal material-preview-modal--unified-tabs wb-task-resource-preview-modal"
            centered
            :footer="null"
            :destroyOnClose="true"
            :maskClosable="true"
            @cancel="closeWbTaskResourcePreview"
          >
            <template #title>
              <div class="preview-modal-title-row">
                <span class="preview-modal-title-row__text">{{ wbTaskResourcePreviewModalTitle }}</span>
              </div>
            </template>
            <div class="preview-modal-body-scroll">
              <div class="tc-skill-modal-body tc-skill-modal-body--unified material-preview-unified-body workbench-material-preview-unified-body">
                <a-tabs
                  v-model:activeKey="wbTaskResourcePreviewActiveTab"
                  class="skill-unified-modal-tabs material-preview-unified-tabs"
                  tab-position="left"
                  :aria-label="wbTaskResourcePreviewModalTabsAriaLabel"
                >
                  <a-tab-pane key="basic" tab="基本信息">
                    <div class="ds-unified-tab-pane-stack">
                      <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息">
                        <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                        <div class="ds-unified-tab-pane-chrome__actions"></div>
                      </div>
                      <div class="material-preview-basic-tab">
                        <div
                          v-for="(row, idx) in wbTaskResourcePreviewBasicRows"
                          :key="'wb-trp-meta-' + idx"
                          class="material-preview-meta-dl-row"
                        >
                          <span class="material-preview-meta-dl-label">{{ row.label }}</span>
                          <span class="material-preview-meta-dl-value">{{ row.value }}</span>
                        </div>
                      </div>
                    </div>
                  </a-tab-pane>
                  <a-tab-pane v-if="wbTaskResourcePreviewIsDatabase" key="fields" tab="字段信息">
                    <div class="ds-unified-tab-pane-stack">
                      <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="字段信息">
                        <h3 class="ds-unified-tab-pane-chrome__title">字段信息</h3>
                        <div class="ds-unified-tab-pane-chrome__actions"></div>
                      </div>
                      <div class="preview-modal-content-frame preview-modal-content-frame--material wb-db-ddl-preview-wrap">
                        <div class="material-preview-modal__viewer">
                          <div class="material-preview-modal__viewer-body">
                            <div v-if="wbTaskResourcePreviewDatabaseTables.length" class="nlm-source-read">
                              <div v-for="(t, ti) in wbTaskResourcePreviewDatabaseTables" :key="'wb-trp-ddl-' + ti + '-' + t.name" class="excerpt">
                                <strong>{{ t.name }}</strong>
                                <p style="margin:var(--ds-space-xxs) 0 0 0; white-space:pre-wrap;">{{ t.ddl }}</p>
                              </div>
                            </div>
                            <a-empty v-else description="暂无建表语句" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </a-tab-pane>
                  <a-tab-pane v-if="wbTaskResourcePreviewResolvedMaterial && (wbTaskResourcePreviewResolvedMaterial.type === 'raw' || wbTaskResourcePreviewResolvedMaterial.type === undefined) && wbTaskResourcePreviewResolvedMaterial.projectSource" key="preview" tab="文件预览">
                    <div class="ds-unified-tab-pane-stack">
                      <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="文件预览操作">
                        <h3 class="ds-unified-tab-pane-chrome__title">文件预览</h3>
                        <div class="ds-unified-tab-pane-chrome__actions">
                          <a-button
                            v-if="wbTaskResourcePreviewResolvedRawSubtype !== 'table'"
                            type="default"
                            class="material-preview-download-link"
                            title="下载"
                            aria-label="下载"
                            @click.stop="downloadWbTaskResourcePreview"
                          >下载</a-button>
                        </div>
                      </div>
                      <div class="preview-modal-content-frame preview-modal-content-frame--material">
                        <div v-if="wbTaskResourcePreviewResolvedRawSubtype !== 'table'" class="material-preview-modal__viewer">
                          <div class="material-preview-modal__viewer-body">
                            <div
                              v-for="(page, pi) in wbTaskResourcePreviewDocumentPages"
                              :key="'wb-trp-doc-' + pi"
                              class="nlm-original-doc-page material-preview-modal__page"
                            >{{ page }}</div>
                          </div>
                        </div>
                        <div v-else class="material-preview-modal__viewer">
                          <div class="material-preview-modal__viewer-body">
                            <div v-if="wbTaskResourcePreviewResolvedMaterial.originalView && wbTaskResourcePreviewResolvedMaterial.originalView.headers" class="nlm-original-table-wrap">
                              <table class="nlm-original-table">
                                <thead><tr><th v-for="(h, hi) in wbTaskResourcePreviewResolvedMaterial.originalView.headers" :key="hi">{{ h }}</th></tr></thead>
                                <tbody><tr v-for="(trow, ri) in (wbTaskResourcePreviewResolvedMaterial.originalView.rows || [])" :key="ri"><td v-for="(cell, ci) in trow" :key="ci">{{ cell }}</td></tr></tbody>
                              </table>
                            </div>
                            <a-empty v-else description="暂无表格预览" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </a-tab-pane>
                  <a-tab-pane
                    v-if="wbTaskResourcePreviewResolvedMaterial && (wbTaskResourcePreviewResolvedMaterial.type === 'raw' || wbTaskResourcePreviewResolvedMaterial.type === undefined) && wbTaskResourcePreviewResolvedMaterial.projectSource && wbTaskResourcePreviewResolvedRawSubtype !== 'table'"
                    key="ocr"
                    tab="OCR结果"
                  >
                    <div class="ds-unified-tab-pane-stack">
                      <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="OCR结果">
                        <h3 class="ds-unified-tab-pane-chrome__title">OCR结果</h3>
                        <div class="ds-unified-tab-pane-chrome__actions material-preview-ocr-chrome-actions">
                          <div class="ds-mode-switch-slider material-preview-ocr-mode-switch" :class="{ 'is-assisted': wbTaskResourcePreviewOcrLines, 'is-auto': !wbTaskResourcePreviewOcrLines }" role="tablist" aria-label="OCR预览模式切换">
                            <span class="ds-mode-switch-slider__thumb" aria-hidden="true"></span>
                            <button
                              type="button"
                              class="ds-mode-switch-slider__item"
                              :class="{ 'is-current': !wbTaskResourcePreviewOcrLines }"
                              role="tab"
                              :aria-selected="!wbTaskResourcePreviewOcrLines"
                              :tabindex="!wbTaskResourcePreviewOcrLines ? 0 : -1"
                              title="普通预览"
                              aria-label="普通预览"
                              @click="wbTaskResourcePreviewOcrLines = false"
                            >
                              <i class="fas fa-eye" aria-hidden="true"></i>
                            </button>
                            <button
                              type="button"
                              class="ds-mode-switch-slider__item"
                              :class="{ 'is-current': wbTaskResourcePreviewOcrLines }"
                              role="tab"
                              :aria-selected="wbTaskResourcePreviewOcrLines"
                              :tabindex="wbTaskResourcePreviewOcrLines ? 0 : -1"
                              title="带行号预览"
                              aria-label="带行号预览"
                              @click="wbTaskResourcePreviewOcrLines = true"
                            >
                              <i class="fas fa-code" aria-hidden="true"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                      <div class="material-preview-modal__viewer material-preview-modal__viewer--ocr-tab">
                        <div class="material-preview-modal__viewer-body">
                          <div
                            v-for="(page, oi) in wbTaskResourcePreviewOcrDisplayed"
                            :key="'wb-trp-ocr-' + oi"
                            :class="['nlm-original-doc-page', 'material-preview-modal__page', { 'ds-font-mono': wbTaskResourcePreviewOcrLines }]"
                          >{{ page }}</div>
                        </div>
                      </div>
                    </div>
                  </a-tab-pane>
                </a-tabs>
              </div>
            </div>
          </a-modal>
          <a-modal
            v-model:open="wbAnalysisResultMetaEditVisible"
            title="重命名分析结果"
            width="520"
            wrapClassName="modal-w-560"
            :maskClosable="false"
            @cancel="closeWorkbenchAnalysisResultMetaEdit"
          >
            <a-form layout="vertical">
              <a-form-item label="结果名称" style="margin-bottom: 0;">
                <a-input v-model:value="wbAnalysisResultMetaEditForm.name" placeholder="请输入结果名称" allow-clear />
              </a-form-item>
            </a-form>
            <template #footer>
              <a-button @click="closeWorkbenchAnalysisResultMetaEdit">取消</a-button>
              <a-button type="primary" @click="confirmWorkbenchAnalysisResultMetaEdit">确定</a-button>
            </template>
          </a-modal>
          <a-modal
            v-model:open="wbAnalysisModalOpen"
            width="760"
            wrapClassName="modal-w-760 analysis-result-preview-modal analysis-result-preview-modal--unified-tabs"
            centered
            :footer="null"
            @cancel="closeWbAnalysisModal"
          >
            <template #title>
              <div class="preview-modal-title-row">
                <span class="preview-modal-title-row__text">{{ (wbAnalysisModalRecord && wbAnalysisModalRecord.name) || '结果预览' }}</span>
              </div>
            </template>
            <div class="preview-modal-body-scroll">
              <div v-if="wbAnalysisModalRecord" class="tc-skill-modal-body tc-skill-modal-body--unified analysis-result-unified-body">
                <a-tabs
                  :activeKey="wbAnalysisModalActiveTab"
                  class="skill-unified-modal-tabs analysis-result-unified-tabs"
                  tab-position="left"
                  aria-label="结果预览：基本信息、输出结果与历史版本"
                  @update:activeKey="onWbAnalysisModalTabUpdate"
                >
                  <a-tab-pane key="basic" tab="基本信息">
                    <div class="workbench-result-preview-pane workbench-result-preview-pane--basic">
                      <div class="ds-unified-tab-pane-stack">
                        <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息">
                          <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                          <div class="ds-unified-tab-pane-chrome__actions"></div>
                        </div>
                        <div class="workbench-result-preview-tab-inner">
                          <div class="material-preview-basic-tab">
                            <div
                              v-for="(row, idx) in wbAnalysisModalBasicMetaRows"
                              :key="'wb-am-meta-' + idx"
                              class="material-preview-meta-dl-row"
                            >
                              <span class="material-preview-meta-dl-label">{{ row.label }}</span>
                              <span
                                v-if="row.label === '状态'"
                                class="material-preview-meta-dl-value material-preview-meta-dl-value--status-pill"
                              >
                                <span
                                  class="ds-status-pill"
                                  :class="analysisStatusChipClass(wbAnalysisModalRecord && wbAnalysisModalRecord.status)"
                                >
                                  <span class="ds-status-pill__dot"></span>
                                  <span class="ds-status-pill__label">{{ analysisResultStatusLabel(wbAnalysisModalRecord && wbAnalysisModalRecord.status) }}</span>
                                </span>
                              </span>
                              <span v-else class="material-preview-meta-dl-value">{{ row.value }}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </a-tab-pane>
                  <a-tab-pane key="body" tab="输出结果">
                    <div class="ds-unified-tab-pane-stack">
                      <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--result-body" role="toolbar" aria-label="输出结果操作">
                        <h3 class="ds-unified-tab-pane-chrome__title">输出结果</h3>
                        <div class="ds-unified-tab-pane-chrome__actions" aria-label="正文与编辑器操作">
                          <div class="analysis-result-preview-modal__toolbar-icons" role="toolbar" aria-label="复制、下载与保存">
                            <a-button
                              type="default"
                              class="analysis-result-preview-toolbar-outline-btn"
                              :disabled="!wbAnalysisModalRecord"
                              title="复制当前内容"
                              aria-label="复制当前内容"
                              @click="copyWbAnalysisModalEmbedPreview"
                            >复制</a-button>
                            <a-dropdown :trigger="['click']" :disabled="!wbAnalysisModalRecord">
                              <a-button
                                type="default"
                                class="analysis-result-preview-toolbar-outline-btn"
                                :disabled="!wbAnalysisModalRecord"
                                title="选择导出格式（演示）"
                                aria-label="下载，选择格式"
                                aria-haspopup="true"
                              >
                                下载 <i class="fas fa-chevron-down" style="margin-left:4px;font-size:10px;opacity:0.75" aria-hidden="true"></i>
                              </a-button>
                              <template #overlay>
                                <a-menu @click="(info) => onWorkbenchAnalysisResultToolbarExportMenu(info, 'modal')">
                                  <a-menu-item key="export-md">下载为 Markdown</a-menu-item>
                                  <a-menu-item key="export-pdf">下载为 PDF</a-menu-item>
                                  <a-menu-item key="export-docx">下载为 Word</a-menu-item>
                                </a-menu>
                              </template>
                            </a-dropdown>
                            <a-button
                              class="analysis-result-preview-toolbar-outline-btn"
                              :type="wbAnalysisModalEmbedDirty ? 'primary' : 'default'"
                              :disabled="!wbAnalysisModalEmbedDirty"
                              title="保存编辑内容"
                              aria-label="保存编辑内容"
                              @click="saveWbAnalysisModalEmbedEdit"
                            >保存</a-button>
                          </div>
                        </div>
                      </div>
                      <div class="analysis-result-preview-modal__layout workbench-analysis-embed-wrap">
                        <div class="preview-modal-content-frame">
                          <div class="analysis-result-preview-modal__panel analysis-result-preview-modal__panel--editor analysis-result-preview-modal__panel--tab-chrome-only">
                            <div class="analysis-result-preview-modal__panel-body">
                              <a-textarea
                                v-model:value="wbAnalysisModalEmbedDraft"
                                class="analysis-result-preview-modal__editor-textarea"
                                :rows="22"
                                placeholder="支持编辑 Markdown 正文，保存后写入当前结果（演示）"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </a-tab-pane>
                  <a-tab-pane key="history" tab="历史版本">
                    <div class="skill-unified-tab-version-root">
                      <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--version-row" role="toolbar" aria-label="历史版本">
                        <h3 class="ds-unified-tab-pane-chrome__title">历史版本</h3>
                        <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions"></div>
                      </div>
                      <div class="skill-unified-tab-version-root__main skill-wizard-panel">
                        <template v-if="wbAnalysisModalRecord">
                          <div
                            v-if="wbAnalysisModalVersionHistoryOnlyRows.length"
                            class="skill-version-mgmt-history-section"
                            role="region"
                            aria-label="历史版本列表"
                          >
                            <h4 class="skill-version-mgmt-history__heading">历史版本 ({{ wbAnalysisModalVersionHistoryOnlyRows.length }})</h4>
                            <div class="skill-version-mgmt-history">
                              <div class="ds-l2-table-panel">
                                <a-table
                                  :columns="workbenchAnalysisVersionMgmtColumns"
                                  :data-source="wbAnalysisModalVersionHistoryOnlyRows"
                                  row-key="key"
                                  size="small"
                                  :pagination="false"
                                  class="skill-library-version-mgmt-table wb-analysis-version-mgmt-table"
                                >
                                  <template #bodyCell="{ column, record }">
                                    <template v-if="column.key === 'generationDesc'">
                                      <span class="skill-version-table__cell-desc" :title="record.generationDesc">{{ record.generationDesc }}</span>
                                    </template>
                                    <template v-else-if="column.key === 'action'">
                                      <span class="skill-version-mgmt-history__row-actions">
                                        <a-button type="link" size="small" class="skill-version-table__version-link" @click="openWorkbenchAnalysisHistoryDiff(record, 'modal')">详情</a-button>
                                        <a-button
                                          type="link"
                                          size="small"
                                          class="skill-version-table__version-link"
                                          @click="applyWorkbenchAnalysisMarkdownRollbackById(wbAnalysisModalRecord && wbAnalysisModalRecord.id, record.markdown)"
                                        >回退</a-button>
                                      </span>
                                    </template>
                                    <template v-else>{{ record[column.dataIndex] }}</template>
                                  </template>
                                </a-table>
                              </div>
                            </div>
                          </div>
                          <a-empty v-else description="暂无历史快照。" />
                        </template>
                        <a-empty v-else description="暂无历史版本。" />
                      </div>
                    </div>
                  </a-tab-pane>
                </a-tabs>
              </div>
            </div>
          </a-modal>
          <a-modal
            v-model:open="wbAnalysisHistoryDiffOpen"
            width="800"
            wrapClassName="modal-w-800"
            title="与当前版本对比"
            :footer="null"
            destroy-on-close
            @cancel="closeWorkbenchAnalysisHistoryDiff"
          >
            <div class="nlm-tool-diff-md" role="region" aria-label="Markdown 行级差异">
              <div v-if="!wbAnalysisHistoryDiffLines.length" class="text-secondary">无差异或内容为空。</div>
              <div
                v-for="(ln, di) in wbAnalysisHistoryDiffLines"
                :key="'wb-ar-diff-' + di"
                class="nlm-tool-diff-line"
                :class="toolDiffLineClass(ln)"
              ><span class="nlm-tool-diff-line__gutter">{{ di + 1 }}</span><span class="nlm-tool-diff-line__code">{{ ln }}</span></div>
              <div v-if="wbAnalysisHistoryDiffTruncated" class="text-secondary" style="margin-top:8px;">以下差异已省略展示（演示上限）。</div>
            </div>
          </a-modal>
          <a-modal
            v-model:open="wbAnalysisVersionDetailVisible"
            title="版本详情"
            width="720"
            wrapClassName="modal-w-720 analysis-result-preview-modal"
            centered
            :footer="null"
            destroy-on-close
            @cancel="closeWbAnalysisVersionDetail"
          >
            <div class="analysis-result-preview-modal__md" v-html="wbAnalysisVersionDetailHtml"></div>
          </a-modal>
          <a-modal
            v-model:open="wbDbAddModalOpen"
            wrapClassName="modal-w-640 modal-wb-db-add"
            width="640"
            centered
            destroy-on-close
            :keyboard="false"
            :closable="true"
            :mask-closable="false"
            @cancel="closeWorkbenchDbAddModal"
          >
            <template #title>添加库表</template>
            <div class="nlm-db-add-modal">
              <div class="nlm-db-add-field">
                <label class="nlm-db-add-label" for="wb-db-add-catalog-select">请选择数据库</label>
                <a-select
                  id="wb-db-add-catalog-select"
                  v-model:value="wbDbAddCatalogId"
                  class="nlm-db-add-catalog-select"
                  placeholder="请选择数据库"
                  allow-clear
                  show-search
                  :options="wbDbAddCatalogOptions"
                  :filter-option="filterWbDbAddCatalogOption"
                  option-filter-prop="label"
                  aria-label="选择数据库"
                  @change="onWorkbenchDbAddCatalogChange"
                />
              </div>
              <template v-if="wbDbAddCatalogId">
                <div class="nlm-db-add-table-toolbar">
                  <p class="nlm-db-add-step-hint nlm-db-add-step-hint--after-select nlm-db-add-table-toolbar__line1">请选择要添加的表</p>
                  <div class="nlm-db-add-table-toolbar__line2">
                    <span class="nlm-db-add-table-toolbar__count">当前已选：{{ (wbDbAddSelectedTableNames || []).length }}</span>
                    <a-input
                      v-model:value="wbDbAddTableSearchQuery"
                      allow-clear
                      placeholder="搜索表名或注释"
                      class="ds-input-inline-search ds-input-inline-search--compact nlm-db-add-table-toolbar-search"
                      aria-label="搜索数据表"
                    />
                  </div>
                </div>
                <div class="nlm-db-add-table-panel">
                  <div class="nlm-db-add-table-scroll">
                    <a-table
                      row-key="value"
                      size="small"
                      :columns="wbDbAddTableColumns"
                      :data-source="wbDbAddTableRowsFiltered"
                      :pagination="false"
                      :scroll="{ y: 320 }"
                      :bordered="false"
                      :row-selection="wbDbAddTableRowSelection"
                      :locale="wbDbAddTableLocale"
                      class="nlm-db-add-table-ant"
                      aria-label="待添加的数据表列表"
                    >
                      <template #bodyCell="{ column, record }">
                        <template v-if="column.key === 'name'">
                          <span class="nlm-db-add-cell-name">{{ record.name }}<span v-if="record.disabled" class="nlm-db-add-table-line__badge">已添加</span></span>
                        </template>
                        <template v-else-if="column.key === 'comment'">
                          <span class="nlm-db-add-cell-comment">{{ record.comment }}</span>
                        </template>
                      </template>
                    </a-table>
                  </div>
                </div>
              </template>
              <p v-else class="nlm-db-add-catalog-placeholder ds-text-caption-light">请先选择数据库，系统将列出该库下可选的数据表。</p>
            </div>
            <template #footer>
              <div class="nlm-db-add-modal-footer">
                <a-button @click="closeWorkbenchDbAddModal">取消</a-button>
                <a-button type="primary" :disabled="submitWorkbenchDbAddTablesDisabled" @click="submitWorkbenchDbAddTables">添加</a-button>
              </div>
            </template>
          </a-modal>
          <a-modal
            v-model:open="wbGraphAddModalOpen"
            wrapClassName="modal-w-880 modal-wb-graph-add"
            width="880"
            centered
            destroy-on-close
            :keyboard="false"
            :closable="true"
            :mask-closable="false"
            @cancel="closeWorkbenchGraphAddModal"
          >
            <template #title>添加数据图谱</template>
            <div class="project-detail-template-scroll" style="max-height: 420px; overflow:auto;">
              <a-row v-if="wbGraphAddCatalogCards.length" :gutter="[16, 16]" class="recent-projects-row project-detail-proj-template-grid">
                <a-col v-for="item in wbGraphAddCatalogCards" :key="item.id" :span="8">
                  <div
                    class="tc-template-card ds-page-card ds-list-card project-detail-proj-template-card project-detail-proj-template-card--selectable"
                    :class="{ 'is-skill-library-selected': wbGraphAddSelectedIds.includes(item.id), 'is-row-disabled': item.disabled }"
                    role="button"
                    tabindex="0"
                    :aria-label="'选择图谱：' + item.name"
                    @click="toggleWorkbenchGraphCard(item)"
                    @keydown.enter.prevent="toggleWorkbenchGraphCard(item)"
                    @keydown.space.prevent="toggleWorkbenchGraphCard(item)"
                  >
                    <div
                      class="template-card-select-check project-detail-proj-template-card__chk"
                      @click.stop
                      @mousedown.stop
                    >
                      <a-checkbox
                        :checked="wbGraphAddSelectedIds.includes(item.id)"
                        :disabled="item.disabled"
                        @click.stop
                        @change="onWbGraphAddCheckboxChange(item, $event)"
                      />
                    </div>
                    <div class="ds-list-card-body wb-graph-add-card-body">
                      <h3 class="tc-template-card__name">{{ item.name }}</h3>
                      <p class="project-center-card-desc">{{ item.description || '暂无描述' }}</p>
                      <div
                        class="project-center-card-stats ds-space-stat-row wb-graph-add-card-stats"
                        role="group"
                        :aria-label="(item.entityCount || 0) + ' 个实体，' + (item.edgeCount || 0) + ' 条连线'"
                      >
                        <span class="ds-space-stat-hit ds-space-stat-hit--graph-entity" tabindex="-1">
                          <span class="ds-space-stat-hit__icon" aria-hidden="true"><i class="fas fa-cube"></i></span>
                          <span class="ds-space-stat-hit__num tabular-nums">{{ item.entityCount }}</span>
                        </span>
                        <span class="ds-space-stat-hit ds-space-stat-hit--graph-link" tabindex="-1">
                          <span class="ds-space-stat-hit__icon" aria-hidden="true"><i class="fas fa-share-nodes"></i></span>
                          <span class="ds-space-stat-hit__num tabular-nums">{{ item.edgeCount }}</span>
                        </span>
                      </div>
                      <div class="ds-card-foot wb-graph-add-card-foot" @click.stop>
                        <span v-if="item.disabled" class="ds-text-caption-light wb-graph-add-card-foot__badge">已添加</span>
                        <a-button
                          type="button"
                          class="ds-trigger-btn ds-trigger-btn--icon-text wb-graph-add-card-foot__action"
                          @click.stop="openWorkbenchGraphDetailModal(item)"
                        >
                          <i class="fas fa-circle-info ds-trigger-btn__icon" aria-hidden="true"></i>
                          <span class="ds-trigger-btn__text">详情</span>
                        </a-button>
                      </div>
                    </div>
                  </div>
                </a-col>
              </a-row>
              <a-empty v-else description="暂无可添加图谱" />
            </div>
            <template #footer>
              <div class="ds-modal-footer-end">
                <a-space>
                  <a-button @click="closeWorkbenchGraphAddModal">取消</a-button>
                  <a-button type="primary" :disabled="submitWorkbenchGraphAddDisabled" @click="submitWorkbenchGraphAdd">添加</a-button>
                </a-space>
              </div>
            </template>
          </a-modal>
          <a-modal
            v-model:open="wbGraphDetailModalOpen"
            :title="(wbGraphDetailRecord && wbGraphDetailRecord.name) || '数据图谱详情'"
            width="960"
            wrapClassName="modal-w-960 material-preview-modal material-preview-modal--unified-tabs modal-wb-graph-detail"
            centered
            destroy-on-close
            :mask-closable="false"
            @cancel="closeWorkbenchGraphDetailModal"
          >
            <div class="tc-skill-modal-body tc-skill-modal-body--unified material-preview-unified-body">
              <a-tabs v-model:activeKey="wbGraphDetailActiveTab" class="skill-unified-modal-tabs material-preview-unified-tabs" tab-position="left">
                <a-tab-pane key="basic" tab="基本信息">
                  <div class="ds-unified-tab-pane-stack">
                    <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="图谱基本信息">
                      <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                      <div class="ds-unified-tab-pane-chrome__actions"></div>
                    </div>
                    <div class="material-preview-basic-tab">
                      <div
                        v-for="(row, idx) in wbGraphDetailBasicMetaRows"
                        :key="'wb-graph-meta-' + idx"
                        class="material-preview-meta-dl-row"
                      >
                        <span class="material-preview-meta-dl-label">{{ row.label }}</span>
                        <span class="material-preview-meta-dl-value">{{ row.value }}</span>
                      </div>
                    </div>
                  </div>
                </a-tab-pane>
                <a-tab-pane key="topology" tab="拓扑图">
                  <div class="ds-unified-tab-pane-stack">
                    <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="图谱拓扑图">
                      <h3 class="ds-unified-tab-pane-chrome__title">拓扑图</h3>
                      <div class="ds-unified-tab-pane-chrome__actions"></div>
                    </div>
                    <div class="preview-modal-content-frame preview-modal-content-frame--material">
                      <div class="material-preview-modal__viewer">
                        <div class="material-preview-modal__viewer-body">
                          <div class="nlm-empty-state" style="padding: var(--ds-space-m) var(--ds-space-sm);">
                            <p class="nlm-empty-desc">拓扑图占位：实体 {{ (wbGraphDetailRecord && wbGraphDetailRecord.entityCount) || 0 }}，关系 {{ (wbGraphDetailRecord && wbGraphDetailRecord.edgeCount) || 0 }}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </a-tab-pane>
              </a-tabs>
            </div>
            <template #footer>
              <div class="ds-modal-footer-end">
                <a-space>
                  <a-button @click="closeWorkbenchGraphDetailModal">关闭</a-button>
                </a-space>
              </div>
            </template>
          </a-modal>
            </div>
          </a-layout></a-layout-content></a-layout>`,
      data() {
        return {
          freeAuditAiPolishKey: '',
          freeAuditPolishUndo: {},
          materials: [],
          materialSearchQuery: '',
          workbenchAnalysisSearchQuery: '',
          workbenchAnalysisSearchOpen: false,
          workbenchMaterialFilterPopoverOpen: false,
          workbenchMaterialSearchOpen: false,
          workbenchMaterialStatusView: 'all',
          workbenchFileTreeExpandedKeys: [],
          workbenchAnalysisResultTreeExpandedKeys: [],
          wbCreateFolderModalOpen: false,
          wbCreateFolderForm: { name: '', parentFolderId: '' },
          wbDeleteFolderModalOpen: false,
          wbDeleteFolderTarget: null,
          wbArResultCreateFolderModalOpen: false,
          wbArResultCreateFolderName: '',
          /** @type {null | { type: 'root'|'underFolder', folderId?: string }} */
          wbArResultCreateFolderSpec: null,
          wbTaskResourcePreviewOpen: false,
          wbTaskResourcePreviewItem: null,
          wbTaskResourcePreviewResolvedMaterial: null,
          wbTaskResourcePreviewActiveTab: 'basic',
          wbTaskResourcePreviewOcrLines: false,
          workbenchDbSearchOpen: false,
          workbenchGraphSearchOpen: false,
          workbenchMaterialStatusPopoverOpenQueued: false,
          workbenchMaterialStatusPopoverOpenParsing: false,
          workbenchMaterialStatusPopoverOpenFailed: false,
          workbenchAnalysisStatusPopoverOpenQueued: false,
          workbenchAnalysisStatusPopoverOpenParsing: false,
          workbenchAnalysisStatusPopoverOpenFailed: false,
          workbenchProjectId: null,
          /** 点击「刷新」时递增，驱动技能等从 mock 的只读计算重新求值 */
          workbenchDemoRefreshTick: 0,
          workbenchMaterialId: null,
          workbenchAnalysisResultId: null,
          workbenchReportId: null,
          workbenchAnalysisCitationPopover: { show: false, title: '', excerpt: '', x: 0, y: 0 },
          workbenchAnalysisCitationPopoverTimer: null,
          workbenchAnalysisEmbedDraft: '',
          _workbenchAnalysisEmbedSnap: '',
          /** 审计助手侧栏结果正文：按结果 id 存 Markdown 历史快照（演示），用于历史版本回退 */
          workbenchAnalysisVersionHistoryById: {},
          wbAnalysisResultMetaEditVisible: false,
          wbAnalysisResultMetaEditTargetId: '',
          wbAnalysisResultMetaEditForm: { name: '' },
          wbAnalysisModalEmbedDraft: '',
          _wbAnalysisModalEmbedSnap: '',
          wbMaterialMetaEditVisible: false,
          wbMaterialMetaEditTargetId: '',
          wbMaterialMetaEditForm: { name: '' },
          _wbMaterialMetaSnap: null,
          wbAnalysisModalOpen: false,
          wbAnalysisModalRecord: null,
          wbAnalysisModalActiveTab: 'basic',
          wbMaterialPreviewActiveTab: 'preview',
          /** 资料预览 · OCR 页：是否在正文左侧展示行号 */
          materialPreviewOcrShowLineNumbers: false,
          wbAnalysisResultPreviewActiveTab: 'body',
          wbAnalysisModalCitationPopover: { show: false, title: '', excerpt: '', x: 0, y: 0 },
          wbAnalysisModalCitationPopoverTimer: null,
          wbAnalysisHistoryDiffOpen: false,
          wbAnalysisHistoryDiffLines: [],
          wbAnalysisHistoryDiffTruncated: false,
          wbAnalysisVersionDetailVisible: false,
          wbAnalysisVersionDetailMarkdown: '',
          saveResultModalVisible: false,
          saveResultModalSourceType: 'message',
          saveResultModalSourceMsgId: null,
          saveResultModalSourcePayload: null,
          saveResultForm: { name: '' },
          chatMessages: [],
          chatInput: '',
          /** 输入框内 @ / 触发：浮现引用或技能菜单 */
          chatInputTriggerOpen: false,
          chatInputTriggerKind: null,
          chatTriggerFilter: '',
          chatInputAtRail: 'raw',
          chatAtMenuPanel: 'categories',
          chatAtFloaterStyle: {},
          _chatInputBlurTimer: null,
          _chatAtFloaterReposBound: null,
          sessionHistory: [],
          historyDropdownOpen: false,
          presetSuggestions,
          selectedMaterialId: null,
          sourcesLeftView: 'list',
          sourcesRightView: 'list',
          workbenchLeftPrimaryTab: 'material',
          sourcesLeftFullscreen: false,
          fullscreenMaterialId: null,
          fullscreenLeftView: 'list',
          fullscreenSelectedSourceId: null,
          fullscreenHighlightSourceId: null,
          fullscreenHighlightExcerptIndex: null,
          fullscreenExcerptRefs: {},
          fullscreenOriginalHighlight: null,
          fullscreenOriginalPageRefs: {},
          fullscreenOriginalRowRefs: {},
          citationPopover: { show: false, title: '', excerpt: '', x: 0, y: 0 },
          citationPopoverTimer: null,
          sourceGuideOpen: true,
          resourceDrawerOpen: { file: true, database: false, graph: false, knowledge: false },
          resourceDrawerContentHeights: { file: 1, database: 1, graph: 1, knowledge: 1 },
          resourceDrawerBodyEls: { file: null, database: null, graph: null, knowledge: null },
          dbResourceSearchQuery: '',
          graphResourceSearchQuery: '',
          selectedResourcePreview: null,
          resourcePreviewTab: 'basic',
          /** 工作台侧栏：已加入的数据表扁平行（每项一张表）；默认内置 3 条模拟数据，可继续经由「添加库表」向导勾选加入 */
          dbResourceList: [
            {
              id: 'db-1::payment_order',
              databaseId: 'db-1',
              databaseName: '财政支付库',
              tableName: 'payment_order',
              name: 'payment_order',
              ddl: 'CREATE TABLE payment_order (id bigint, amount decimal(16,2), dept_name varchar(128));',
              comment: '财政集中支付主单',
              rowCount: 124600,
              source: '核心业务库',
              owner: '数据中心',
              updatedAt: '2026-05-08 05:42:35',
            },
            {
              id: 'db-1::payment_detail',
              databaseId: 'db-1',
              databaseName: '财政支付库',
              tableName: 'payment_detail',
              name: 'payment_detail',
              ddl: 'CREATE TABLE payment_detail (order_id bigint, item_name varchar(128), amount decimal(16,2));',
              comment: '支付明细与科目拆分',
              rowCount: 982000,
              source: '核心业务库',
              owner: '数据中心',
              updatedAt: '2026-05-08 05:42:35',
            },
            {
              id: 'db-2::contract_main',
              databaseId: 'db-2',
              databaseName: '合同执行库',
              tableName: 'contract_main',
              name: 'contract_main',
              ddl: 'CREATE TABLE contract_main (contract_no varchar(64), vendor_name varchar(128), signed_at datetime);',
              comment: '合同主数据与履约状态',
              rowCount: 18630,
              source: '合同管理系统',
              owner: '审计组A',
              updatedAt: '2026-05-08 05:42:35',
            },
          ],
          /** 添加库表向导：可选数据源全集 */
          dbCatalogs: DEMO_WORKBENCH_DB_CATALOGS,
          wbDbAddModalOpen: false,
          wbDbAddCatalogId: undefined,
          wbDbAddSelectedTableNames: [],
          wbDbAddTableSearchQuery: '',
          wbGraphAddModalOpen: false,
          wbGraphAddSelectedIds: [],
          wbGraphDetailModalOpen: false,
          wbGraphDetailRecord: null,
          wbGraphDetailActiveTab: 'basic',
          /** 数据库抽屉：按库分组展开状态，key 为 databaseId；缺省视为展开 */
          workbenchDbTableGroupExpanded: {},
          graphResourceList: [
            { id: 'graph-1', name: '采购业务关系图谱', source: '内置图谱中心', entityCount: 1280, edgeCount: 4670, updatedAt: '2026-05-06 11:20:00' },
            { id: 'graph-2', name: '资金流向图谱', source: '内置图谱中心', entityCount: 960, edgeCount: 3320, updatedAt: '2026-05-04 16:45:00' },
          ],
          graphCatalogs: [
            { id: 'graph-1', name: '采购业务关系图谱', description: '覆盖采购申请、审批、合同与支付流转关系。', source: '内置图谱中心', entityCount: 1280, edgeCount: 4670, updatedAt: '2026-05-06 11:20:00' },
            { id: 'graph-2', name: '资金流向图谱', description: '展示预算科目、拨付批次与账户收支链路。', source: '内置图谱中心', entityCount: 960, edgeCount: 3320, updatedAt: '2026-05-04 16:45:00' },
            { id: 'graph-3', name: '合同履约风险图谱', description: '聚焦合同条款、里程碑节点与履约偏差风险。', source: '内置图谱中心', entityCount: 735, edgeCount: 2148, updatedAt: '2026-05-02 14:12:00' },
            { id: 'graph-4', name: '发票-付款关联图谱', description: '关联发票、付款单、供应商与银行流水核对。', source: '内置图谱中心', entityCount: 842, edgeCount: 2816, updatedAt: '2026-05-01 09:33:00' },
          ],
          knowledgeResourceList: [
            { id: 'kb-1', name: '审计制度知识库', scope: '组织级', status: 'coming_soon' },
          ],
          highlightSourceId: null,
          highlightExcerptIndex: null,
          sourcesCollapsed: false,
          studioCollapsed: false,
          sourcesWidth: 300,
          sourcesDetailWidth: 450,
          studioWidth: 340,
          resizing: null,
          lastDetailFocus: null,
          excerptRefs: {},
          toastMessage: '',
          layoutMode: 'A',
          experienceDrafts: { extract: '', analysis: '', report: '' },
          hoveredMaterialId: null,
          treeSectionOpen: { material: true, analysis: true },
          selectedTreeNode: null,
          treeContextMenuNode: null,
          treeContextMenuVisible: false,
          treeContextMenuPosition: { x: 0, y: 0 },
          extractionResults: [],
          selectedExtractionId: null,
          summaryTemplateTasks: [],
          summarySkillTaskByTemplateId: {},
          summaryTaskResultModalVisible: false,
          summaryTaskResultTaskId: null,
          summaryTaskResultExpandedRuleId: '',
          summaryTaskResultForm: { name: '', extractionRules: [], analysisRule: '' },
          analysisTemplatePool: {
            public: SKILL_SEED_PUBLIC.map((x) => toAnalysisTemplateShared(x, 'public')),
            private: demoSharedPrivateAnalysisTemplatePool,
          },
          wbSelectedTemplateKey: '',
          wbSkillSidebarSearchKeyword: '',
          wbSkillSidebarSearchOpen: false,
          /** 侧栏技能行「更多」菜单：受控 open，供右键与三点按钮共用 */
          wbSkillTreeActionMenuKey: null,
          wbProjectSkillDetailModalOpen: false,
          wbProjectSkillCreateBasicModalOpen: false,
          wbProjectSkillCreateBasicSubmitting: false,
          wbProjectSkillCreateBasicForm: { name: '', description: '', tags: [] },
          wbProjectSkillDetailActiveTab: 'basic',
          wbProjectSkillDetailModalIsCreate: false,
          wbProjectSkillDetailReadOnly: false,
          _wbProjectSkillModalSnapshot: null,
          wbSkillResourcePopoverOpen: false,
          wbSkillResourcePopoverSkillId: '',
          wbTaskCreateModalOpen: false,
          wbTaskCreateStep: 1,
          /** 任务指令：idle 待配置 | generating 生成中 | ready 可编辑 */
          wbTaskCreateInstructionState: 'idle',
          _wbTaskCreateInstructionTimer: null,
          _wbTaskCreateInstructionGenToken: 0,
          wbTaskListView: 'main',
          wbActiveBatchParentId: '',
          wbBatchChildStatusView: 'all',
          wbBatchChildPage: 1,
          wbBatchChildPageSize: 5,
          wbTaskCreateForm: {
            taskName: '',
            skillId: '',
            taskType: 'single',
            instruction: '',
            dataSourceFile: null,
            idColumns: [],
            resourceTab: 'file',
            resourceQuery: '',
            selectedResources: [],
          },
          /** 生成技能：配置弹窗与推荐占位（演示） */
          wbGenerateSkillConfigModalOpen: false,
          wbGenerateSkillIntentText: '',
          wbGenerateSkillRecommendationItems: [],
          _wbGenerateSkillRecoTimers: null,
          workbenchCreatedTasks: [],
          wbProjectSkillResourcePaneEditing: false,
          _wbProjectSkillBasicPaneSnap: null,
          _wbProjectSkillConfigPaneSnap: null,
          _wbProjectSkillResourcePaneSnap: null,
          _wbProjectSkillCreateCommitted: false,
          wbProjectSkillDetailId: '',
          wbProjectSkillConfigNavKey: 'rule',
          wbProjectSkillConfigTreeExpandedKeys: [],
          wbProjectSkillForm: { id: '', name: '', description: '', tags: [] },
        };
      },
      computed: {
        /** 生成技能配置弹窗：意图非空才可提交 */
        wbGenerateSkillIntentTrimmed() {
          return String(this.wbGenerateSkillIntentText || '').trim();
        },
        freeAuditChatHost() { return this; },
        skillObjectMaterialTypePlaceholder() {
          return (typeof window !== 'undefined' && window.__DEMO_SKILL_OBJECT_MATERIAL_TYPE_PLACEHOLDER) || '请填写资料名称或类型';
        },
        selectedMaterial() {
          const id = this.selectedMaterialId;
          const m = (this.materials || []).find((x) => x.id === id);
          if (m) return m;
          const created = (this.workbenchCreatedTasks || []).find((x) => x && x.id === id);
          if (created) return created;
          const demo = (this.workbenchTaskDemoRows || []).find((x) => x && x.id === id);
          if (demo) return demo;
          return this.findWorkbenchTaskChildById(id);
        },
        /** 演示任务列表（含已完成 / 执行中 / 失败）；数据源自 demo-mock-data.js 中 Vue 响应式 demoWorkbenchTaskRows */
        workbenchTaskDemoRows() {
          return typeof demoWorkbenchTaskRows !== 'undefined' && Array.isArray(demoWorkbenchTaskRows) ? demoWorkbenchTaskRows : [];
        },
        /** 侧栏任务清单中新建的、仅存在于 workbenchCreatedTasks 的条目（非资料区分析结果物料） */
        selectedMaterialIsWorkbenchCreatedTask() {
          const id = this.selectedMaterialId;
          const inCreated = !!(this.workbenchCreatedTasks || []).find((x) => x && x.id === id);
          if (inCreated) return true;
          if (!!(this.workbenchTaskDemoRows || []).find((x) => x && x.id === id)) return true;
          return !!this.findWorkbenchTaskChildById(id);
        },
        /** 右侧内嵌预览顶栏标题：任务条目与正式结果条目区分布局一致，仅文案区分 */
        workbenchEmbedRightAnalysisHeaderTitle() {
          const fb = this.selectedMaterialIsWorkbenchCreatedTask ? '任务详情' : '结果预览';
          const r = this.workbenchSelectedAnalysisResultRow;
          return (r && r.name) || (this.selectedMaterial && this.selectedMaterial.title) || fb;
        },
        /** 新建任务台账在未成功前仅展示占位型输出说明，不提供复制 / 下载 / 编辑入库能力 */
        workbenchEmbedAnalysisOutputToolbarDisabled() {
          if (!this.selectedMaterialIsWorkbenchCreatedTask || !this.selectedMaterial) return false;
          return this.workbenchAnalysisStatusOf(this.selectedMaterial) !== 'done';
        },
        workbenchAnalysisEmbedDirty() {
          if (this.workbenchEmbedAnalysisOutputToolbarDisabled) return false;
          return String(this.workbenchAnalysisEmbedDraft ?? '') !== String(this._workbenchAnalysisEmbedSnap ?? '');
        },
        wbAnalysisModalEmbedDirty() {
          if (!this.wbAnalysisModalRecord) return false;
          return String(this.wbAnalysisModalEmbedDraft ?? '') !== String(this._wbAnalysisModalEmbedSnap ?? '');
        },
        wbMaterialMetaEditDirty() {
          const snap = this._wbMaterialMetaSnap;
          const f = this.wbMaterialMetaEditForm;
          if (!snap || !f) return false;
          return String(f.name || '').trim() !== String(snap.name || '').trim();
        },
        /** 当前侧栏选中资料对应的工作台资料行（与工作台资料预览同源） */
        workbenchSelectedProjectMaterialRow() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'raw' || !m.projectSource) return null;
          return m.projectSource;
        },
        /** 侧栏/内嵌：当前分析结果对应的工作台内结果行（与工作台「结果预览」弹窗同源字段） */
        workbenchSelectedAnalysisResultRow() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return null;
          const ps = m.projectSource || {};
          const rowStatus = ps.status || m.status || 'done';
          return {
            id: ps.id || m.id,
            name: ps.name || m.title,
            sourceSkillName: ps.sourceSkillName || m.sourceSkillName,
            createdAt: ps.createdAt || m.meta,
            status: rowStatus,
            analysisMarkdown: m.analysisMarkdown || ps.analysisMarkdown,
            analysisMarkdownEditedBy: ps.analysisMarkdownEditedBy,
            analysisMarkdownEditedAt: ps.analysisMarkdownEditedAt,
          };
        },
        workbenchAnalysisDialogueSourceLine() {
          return this.workbenchAnalysisDialogueSourceLineFromRecord(this.workbenchSelectedAnalysisResultRow);
        },
        selectedMaterialDetail() {
          if (!this.selectedMaterial) return null;
          return this.selectedMaterial;
        },
        sourceMaterialCount() { return this.selectedMaterial?.sourceMaterialIds?.length ?? 0; },
        detailExcerpts() {
          if (!this.selectedMaterialDetail) return [];
          const m = this.selectedMaterial;
          if (m && (m.type === 'analysis' || m.type === 'report') && m.excerptsWithCitations) return m.excerptsWithCitations.map(x => x.text);
          return this.selectedMaterialDetail.excerpts || [];
        },
        checkedMaterialCount() { return this.materials.filter(m => m.checked).length; },
        workbenchMaterialSelectOptions() {
          const folders = this.workbenchMaterialFoldersList || [];
          return (this.materials || [])
            .filter((m) => m && (m.type === 'raw' || m.type === undefined))
            .map((m) => {
              const row = m.projectSource || {};
              const prefix = wbMatMaterialPathPrefixForRow(row, folders);
              const title = m.title || m.id;
              return { value: String(m.id), label: prefix ? `${prefix}${title}` : title };
            });
        },
        /** @ 引用菜单：资料 */
        chatAtMenuRawMaterials() {
          return (this.materials || []).filter((m) => m && (m.type === 'raw' || m.type === undefined));
        },
        /** @ 引用菜单：结果 */
        chatAtMenuResultMaterials() {
          return (this.materials || []).filter((m) => m && (m.type === 'analysis' || m.type === 'report'));
        },
        chatAtMenuHasAnythingToRef() {
          return this.chatAtMenuRawMaterials.length > 0 || this.chatAtMenuResultMaterials.length > 0;
        },
        chatAtMenuRailCategories() {
          return [
            { key: 'raw', label: '资料' },
            { key: 'result', label: '结果' },
          ];
        },
        chatAtSubmenuTitle() {
          const k = this.chatInputAtRail;
          if (k === 'raw') return '资料';
          if (k === 'result') return '结果';
          return '';
        },
        chatAtMenuRawMaterialsFiltered() {
          const q = (this.chatTriggerFilter || '').trim().toLowerCase();
          const list = this.chatAtMenuRawMaterials;
          if (!q) return list;
          return list.filter((m) => {
            const t = String(m.title != null ? m.title : m.name != null ? m.name : '').toLowerCase();
            const disp = String(this.chatAtRawMaterialDisplayTitle(m) || '').toLowerCase();
            return t.includes(q) || disp.includes(q);
          });
        },
        chatAtMenuResultMaterialsFiltered() {
          const q = (this.chatTriggerFilter || '').trim().toLowerCase();
          const list = this.chatAtMenuResultMaterials;
          if (!q) return list;
          return list.filter((m) => {
            const t = String(m.title != null ? m.title : m.name != null ? m.name : '').toLowerCase();
            return t.includes(q);
          });
        },
        chatSlashMenuSectionsFiltered() {
          const q = (this.chatTriggerFilter || '').trim().toLowerCase();
          return (this.workbenchTemplateTreeSections || [])
            .map((sec) => ({
              key: sec.key,
              label: sec.label,
              children: (sec.children || []).filter((node) => {
                if (!q) return true;
                const name = String(node.raw && node.raw.name != null ? node.raw.name : '未命名').toLowerCase();
                return name.includes(q);
              }),
            }))
            .filter((sec) => sec.children.length > 0);
        },
        chatSlashMenuHasAnyItem() {
          return this.chatSlashMenuSectionsFiltered.some((s) => (s.children || []).length > 0);
        },
        chatTriggerFilterTrimmed() {
          return (this.chatTriggerFilter || '').trim();
        },
        /** @ 后有关键字时：合并展示匹配的资料 + 结果 */
        chatAtUnifiedMatchRows() {
          if (!this.chatTriggerFilterTrimmed) return [];
          const rows = [];
          this.chatAtMenuRawMaterialsFiltered.forEach((m) => {
            rows.push({ kind: 'raw', m });
          });
          this.chatAtMenuResultMaterialsFiltered.forEach((m) => {
            rows.push({ kind: 'result', m });
          });
          return rows;
        },
        materialsForList() {
          const q = (this.materialSearchQuery || '').trim().toLowerCase();
          const rank = (m) => (m.type === 'raw' || m.type === undefined ? 0 : 1);
          const list = this.materials.filter((m) => {
            if (!q) return true;
            const inTitle = (m.title || '').toLowerCase().includes(q);
            return inTitle;
          });
          const rawRows = list.filter((m) => m.type === 'raw' || m.type === undefined);
          const analysisRows = list.filter((m) => m.type === 'analysis');
          return [...this.filteredWorkbenchRawMaterials(rawRows), ...analysisRows].sort((a, b) => rank(a) - rank(b));
        },
        workbenchAnalysisListSource() {
          return (this.materialsForList || []).filter((m) => m && m.type === 'analysis');
        },
        materialTreeSections() {
          const rawMaterials = this.workbenchRawMaterialsForTree;
          const analysisMaterials = this.materialsForList.filter((m) => m.type === 'analysis');
          const materialNodes = rawMaterials.map((m) => ({ source: 'material', id: m.id, raw: m }));
          const analysisNodes = analysisMaterials.map((m) => ({ source: 'material', id: m.id, raw: m }));
          return [
            { key: 'material', label: '资料', children: materialNodes },
            { key: 'analysis', label: '结果', children: analysisNodes }
          ];
        },
        workbenchLeftTreeSections() {
          return (this.materialTreeSections || []).filter((s) => s.key === 'material');
        },
        workbenchRawMaterialQueuedList() {
          return (this.materials || []).filter((m) => (m.type === 'raw' || m.type === undefined) && this.workbenchMaterialStatusOf(m) === 'queued');
        },
        workbenchRawMaterialParsingList() {
          return (this.materials || []).filter((m) => (m.type === 'raw' || m.type === undefined) && this.workbenchMaterialStatusOf(m) === 'parsing');
        },
        workbenchRawMaterialFailedList() {
          return (this.materials || []).filter((m) => (m.type === 'raw' || m.type === undefined) && this.workbenchMaterialStatusOf(m) === 'failed');
        },
        workbenchRawMaterialStatusSummary() {
          return {
            queued: (this.workbenchRawMaterialQueuedList || []).length,
            parsing: (this.workbenchRawMaterialParsingList || []).length,
            failed: (this.workbenchRawMaterialFailedList || []).length,
          };
        },
        /** 资料存在排队/解析中时在状态条边框展示主色流光（非仅失败态） */
        workbenchRawMaterialFlowBorderActive() {
          const s = this.workbenchRawMaterialStatusSummary || {};
          return (Number(s.queued) || 0) + (Number(s.parsing) || 0) > 0;
        },
        workbenchShouldShowMaterialStatusFooter() {
          const s = this.workbenchRawMaterialStatusSummary || {};
          return Number(s.queued || 0) > 0 || Number(s.parsing || 0) > 0 || Number(s.failed || 0) > 0;
        },
        workbenchMaterialBatchTargets() {
          const view = this.workbenchMaterialStatusView || 'all';
          if (view !== 'queued' && view !== 'parsing' && view !== 'failed') return [];
          return (this.workbenchRawMaterialsForTree || []).filter((m) => this.workbenchMaterialStatusOf(m) === view);
        },
        workbenchMaterialBatchTargetCount() {
          return (this.workbenchMaterialBatchTargets || []).length;
        },
        workbenchRawMaterialsForTree() {
          const rows = (this.materialsForList || []).filter((m) => m.type === 'raw' || m.type === undefined);
          const view = this.workbenchMaterialStatusView || 'all';
          if (view === 'queued' || view === 'parsing' || view === 'failed') {
            return rows.filter((m) => this.workbenchMaterialStatusOf(m) === view);
          }
          return rows.filter((m) => this.workbenchMaterialStatusOf(m) === 'done');
        },
        workbenchMaterialFoldersList() {
          void this.workbenchDemoRefreshTick;
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialFoldersById === 'undefined') return [];
          return Array.isArray(demoProjectMaterialFoldersById[pid]) ? demoProjectMaterialFoldersById[pid] : [];
        },
        workbenchDoneProjectRowsForFileTree() {
          void this.workbenchDemoRefreshTick;
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialsById === 'undefined') return [];
          const rows = demoProjectMaterialsById[pid] || [];
          return rows.filter((r) => String(r.status || '') === 'done');
        },
        workbenchMaterialFileTreePayload() {
          void this.workbenchDemoRefreshTick;
          return buildWorkbenchMaterialAntTreeData({
            folders: this.workbenchMaterialFoldersList,
            doneMaterialProjectRows: this.workbenchDoneProjectRowsForFileTree,
            searchQuery: this.materialSearchQuery || '',
          });
        },
        workbenchMaterialFileTreeData() {
          return (this.workbenchMaterialFileTreePayload || {}).treeData || [];
        },
        workbenchMaterialFileTreeAutoExpandKeys() {
          return (this.workbenchMaterialFileTreePayload || {}).autoExpandKeys || [];
        },
        workbenchAnalysisResultFoldersList() {
          void this.workbenchDemoRefreshTick;
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectAnalysisResultFoldersById === 'undefined') return [];
          return Array.isArray(demoProjectAnalysisResultFoldersById[pid]) ? demoProjectAnalysisResultFoldersById[pid] : [];
        },
        workbenchFileTreeSelectedKeys() {
          const st = this.selectedTreeNode;
          if (st && st.source === 'material' && st.id) {
            const m = (this.materials || []).find((x) => String(x.id) === String(st.id));
            if (m && this.workbenchMaterialStatusOf(m) === 'done') return [wbMatAntTreeKey('raw', st.id)];
          }
          return [];
        },
        workbenchAnalysisQueuedList() {
          return (this.materials || []).filter((m) => m && m.type === 'analysis' && this.workbenchAnalysisStatusOf(m) === 'queued');
        },
        workbenchAnalysisParsingList() {
          return (this.materials || []).filter((m) => m && m.type === 'analysis' && this.workbenchAnalysisStatusOf(m) === 'parsing');
        },
        workbenchAnalysisFailedList() {
          return (this.materials || []).filter((m) => m && m.type === 'analysis' && this.workbenchAnalysisStatusOf(m) === 'failed');
        },
        workbenchAnalysisTaskListSource() {
          const created = this.workbenchCreatedTasks || [];
          const idSet = new Set(created.map((x) => x && x.id).filter(Boolean));
          const demo = (this.workbenchTaskDemoRows || []).filter((x) => x && !idSet.has(x.id));
          return [...created, ...demo];
        },
        workbenchAnalysisStatusSummary() {
          return {
            queued: (this.workbenchAnalysisQueuedList || []).length,
            parsing: (this.workbenchAnalysisParsingList || []).length,
            failed: (this.workbenchAnalysisFailedList || []).length,
          };
        },
        workbenchTaskTreeSections() {
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const list = [...(this.workbenchAnalysisTaskListSource || [])].filter((m) => m && m.taskType !== 'batch-child');
          const createdAtMsOf = (m) => {
            if (!m || typeof m !== 'object') return 0;
            const ps = m.projectSource || {};
            const raw = String(ps.createdAt || m.meta || m.createdAt || '').trim();
            if (!raw) return 0;
            const normalized = raw.includes('T') ? raw : raw.replace(' ', 'T');
            const t = Date.parse(normalized);
            return Number.isNaN(t) ? 0 : t;
          };
          list.sort((a, b) => {
            const diff = createdAtMsOf(b) - createdAtMsOf(a);
            if (diff !== 0) return diff;
            return collator.compare(String(a.title || ''), String(b.title || ''));
          });
          const taskNodes = list.map((m) => ({ source: 'material', id: m.id, raw: m }));
          return [{ key: 'analysis', treeScope: 'task', label: '任务', children: taskNodes }];
        },
        /** 与右侧结果树中与任务同名的文件夹一一对应：仅「已完成」任务，顺序与左侧任务列表一致 */
        workbenchCompletedTasksForResultTree() {
          const sec = (this.workbenchTaskTreeSections || []).find((s) => s.key === 'analysis');
          const nodes = (sec && sec.children) || [];
          return nodes
            .filter((node) => node && node.raw && this.workbenchAnalysisStatusOf(node.raw) === 'done')
            .map((node) => ({
              id: node.id,
              folderTitle: String((node.raw.projectSource && node.raw.projectSource.name) || node.raw.title || '未命名任务').trim() || '未命名任务',
            }));
        },
        /** 右侧「结果」分栏：仅已完成项，应用搜索与排序（与旧版平铺列表同源，供树分组使用） */
        workbenchDoneSortedAnalysisMaterialsForResultPanel() {
          let list = [...(this.workbenchAnalysisListSource || [])];
          const q = String(this.workbenchAnalysisSearchQuery || '').trim().toLowerCase();
          if (q) {
            const rfList = this.workbenchAnalysisResultFoldersList || [];
            list = list.filter((m) => {
              const title = String(m.title || '').toLowerCase();
              const ps = m.projectSource || {};
              const skill = String(ps.sourceSkillName || '').toLowerCase();
              const taskName = String(ps.sourceTaskName || ps.taskName || '').toLowerCase();
              const dlg = ps.resultTreeBucket === 'dialog';
              if (dlg && ['对话', '会话', '助手'].some((kw) => q.includes(kw))) return true;
              const rfd = ps.resultFolderId;
              if (rfd) {
                const fold = rfList.find((f) => String(f.id) === String(rfd));
                if (fold && String(fold.name || '').toLowerCase().includes(q)) return true;
              }
              return title.includes(q) || skill.includes(q) || taskName.includes(q);
            });
          }
          list = list.filter((m) => this.workbenchAnalysisStatusOf(m) === 'done');
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const timeOf = (m) => {
            const v = m.meta || (m.projectSource && m.projectSource.createdAt) || '';
            const t = Date.parse(String(v || '').trim().replace(' ', 'T'));
            return Number.isNaN(t) ? 0 : t;
          };
          list.sort((a, b) => timeOf(b) - timeOf(a) || collator.compare(String(a.title || ''), String(b.title || '')));
          return list;
        },
        workbenchAnalysisResultAntTreePayload() {
          void this.workbenchDemoRefreshTick;
          const list = this.workbenchDoneSortedAnalysisMaterialsForResultPanel || [];
          return buildWorkbenchAnalysisResultAntTreeData({
            materials: list,
            searchQuery: this.workbenchAnalysisSearchQuery || '',
            resultFolders: this.workbenchAnalysisResultFoldersList || [],
          });
        },
        workbenchAnalysisResultAntTreeData() {
          return (this.workbenchAnalysisResultAntTreePayload || {}).treeData || [];
        },
        workbenchAnalysisResultAntTreeAutoExpandKeys() {
          return (this.workbenchAnalysisResultAntTreePayload || {}).autoExpandKeys || [];
        },
        workbenchAnalysisResultAntTreeInitialExpandKeys() {
          return (this.workbenchAnalysisResultAntTreePayload || {}).initialExpandKeys || [];
        },
        filteredDatabaseResources() {
          const rows = this.dbResourceList || [];
          const q = String(this.dbResourceSearchQuery || '').trim().toLowerCase();
          if (!q) return rows;
          return rows.filter((row) => {
            const tn = String(row.tableName || row.name || '').toLowerCase();
            const dn = String(row.databaseName || '').toLowerCase();
            const src = String(row.source || '').toLowerCase();
            const cm = String(row.comment || '').toLowerCase();
            return tn.includes(q) || dn.includes(q) || src.includes(q) || cm.includes(q);
          });
        },
        /** 按 databaseId 分组，组内仅渲染表行（组头展示库名）；组与表名均按 zh-CN 排序 */
        filteredDatabaseResourceGroups() {
          const rows = this.filteredDatabaseResources || [];
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const byId = new Map();
          rows.forEach((row) => {
            const k = String(row.databaseId || '').trim() || `name:${String(row.databaseName || '').trim() || 'unknown'}`;
            if (!byId.has(k)) {
              byId.set(k, {
                databaseId: k,
                databaseName: row.databaseName || '',
                source: row.source || '',
                tables: [],
              });
            }
            byId.get(k).tables.push(row);
          });
          const groups = Array.from(byId.values());
          groups.forEach((g) => {
            g.tables.sort((a, b) => collator.compare(String(a.tableName || a.name || ''), String(b.tableName || b.name || '')));
          });
          groups.sort((a, b) => collator.compare(String(a.databaseName || ''), String(b.databaseName || '')));
          return groups;
        },
        wbDbAddCatalogOptions() {
          return (this.dbCatalogs || []).map((c) => {
            const en = String(c.nameEn != null ? c.nameEn : c.code != null ? c.code : '').trim();
            const zh = String(c.name || '—').trim() || '—';
            const left = en || String(c.id || '').trim() || zh;
            return { label: `${left}（${zh}）`, value: c.id };
          });
        },
        wbDbAddTableRows() {
          const cId = this.wbDbAddCatalogId;
          const c = (this.dbCatalogs || []).find((x) => x.id === cId);
          const tbls = c ? (c.tables || []) : [];
          return tbls.map((t) => ({
            value: t.name,
            name: t.name,
            comment: (t.comment && String(t.comment).trim()) ? String(t.comment) : '—',
            disabled: this.workbenchDbTableRowExists(cId, t.name),
          }));
        },
        wbDbAddTableRowsFiltered() {
          const rows = this.wbDbAddTableRows || [];
          const q = String(this.wbDbAddTableSearchQuery || '').trim().toLowerCase();
          if (!q) return rows;
          return rows.filter((r) => {
            const name = String(r.name || '').toLowerCase();
            const comment = String(r.comment || '').toLowerCase();
            return name.includes(q) || comment.includes(q);
          });
        },
        wbDbAddTableColumns() {
          return [
            { title: '表名', dataIndex: 'name', key: 'name', ellipsis: true, width: 200 },
            { title: '注释', dataIndex: 'comment', key: 'comment', ellipsis: true },
          ];
        },
        wbDbAddTableRowSelection() {
          return {
            selectedRowKeys: this.wbDbAddSelectedTableNames,
            columnWidth: 40,
            onChange: this.onWbDbAddTableRowSelectionChange,
            getCheckboxProps: this.wbDbAddTableGetCheckboxProps,
          };
        },
        wbDbAddTableLocale() {
          const rows = this.wbDbAddTableRows || [];
          const filtered = this.wbDbAddTableRowsFiltered || [];
          const q = String(this.wbDbAddTableSearchQuery || '').trim();
          let emptyText = '暂无数据';
          if (!rows.length) emptyText = '该库下暂无可选表';
          else if (!filtered.length && q) emptyText = '无匹配的表';
          return { emptyText };
        },
        wbGraphAddCatalogCards() {
          const exists = new Set((this.graphResourceList || []).map((g) => String(g.id)));
          return (this.graphCatalogs || []).map((g) => ({
            ...g,
            disabled: exists.has(String(g.id)),
          }));
        },
        wbGraphDetailBasicMetaRows() {
          const r = this.wbGraphDetailRecord;
          if (!r) return [];
          return [
            { label: '图谱名称', value: String(r.name || '').trim() || '—' },
            { label: '描述', value: String(r.description || '').trim() || '—' },
            { label: '节点数量', value: `${Number(r.entityCount || 0)} 个` },
            { label: '边数量', value: `${Number(r.edgeCount || 0)} 条` },
            { label: '来源', value: String(r.source || '').trim() || '—' },
            { label: '更新时间', value: String(r.updatedAt || '').trim() || '—' },
          ];
        },
        submitWorkbenchGraphAddDisabled() {
          return !(this.wbGraphAddSelectedIds && this.wbGraphAddSelectedIds.length);
        },
        submitWorkbenchDbAddTablesDisabled() {
          const id = this.wbDbAddCatalogId;
          if (id === undefined || id === null || id === '') return true;
          return !(this.wbDbAddSelectedTableNames && this.wbDbAddSelectedTableNames.length);
        },
        filteredGraphResources() {
          const q = String(this.graphResourceSearchQuery || '').trim().toLowerCase();
          if (!q) return this.graphResourceList || [];
          return (this.graphResourceList || []).filter((g) => String(g.name || '').toLowerCase().includes(q) || String(g.source || '').toLowerCase().includes(q));
        },
        poolTabMaterialCount() {
          return (this.materials || []).filter((m) => m && (m.type === 'raw' || m.type === undefined)).length;
        },
        poolTabAnalysisCount() {
          const list = this.workbenchDoneSortedAnalysisMaterialsForResultPanel || [];
          return list.length;
        },
        poolTabAnalysisTaskCount() {
          const sec = (this.workbenchTaskTreeSections || []).find((s) => s.key === 'analysis');
          return sec ? sec.children.length : 0;
        },
        allMaterialsChecked() { return this.materials.length > 0 && this.materials.every(m => m.checked); },
        selectedExtractionResult() {
          if (!this.selectedExtractionId) return null;
          return this.extractionResults.find(r => r.id === this.selectedExtractionId) || null;
        },
        effectiveSourcesWidth() {
          if (this.sourcesLeftView === 'detail') return this.sourcesDetailWidth;
          return this.sourcesWidth;
        },
        layoutRatios() {
          const leftDetail = this.sourcesLeftView === 'detail' && !this.sourcesCollapsed;
          const rightDetail = this.sourcesRightView === 'detail' && !this.studioCollapsed;

          if (!leftDetail && !rightDetail) return { left: 2.5, middle: 5, right: 2.5 };
          if (leftDetail && !rightDetail) return { left: 4, middle: 4, right: 2 };
          if (!leftDetail && rightDetail) return { left: 2, middle: 4, right: 4 };

          if (this.lastDetailFocus === 'right') return { left: 2, middle: 4, right: 4 };
          return { left: 4, middle: 4, right: 2 };
        },
        /** 左栏轨 flex：稿面资源面板宽约 300，比例由 layoutRatios.left 与中间栏共同分配 */
        leftWorkbenchRailStyle() {
          if (this.sourcesCollapsed) return { flex: '0 0 0px', minWidth: 0 };
          const g = this.layoutRatios && this.layoutRatios.left != null ? this.layoutRatios.left : 2.5;
          /* 与稿 k9kN5 默认栏宽约 300 对齐，仍随 flex 比例与拖拽放大 */
          return { flex: `${g} 1 0%`, minWidth: 'min(300px, 100%)' };
        },
        rightWorkbenchRailStyle() {
          if (this.studioCollapsed) return { flex: '0 0 0px' };
          const g = this.layoutRatios && this.layoutRatios.right != null ? this.layoutRatios.right : 2.5;
          return { flex: `${g} 1 0%` };
        },
        fullscreenMaterial() { return this.materials.find(m => m.id === this.fullscreenMaterialId) || null; },
        fullscreenSourceMaterials() {
          if (!this.fullscreenMaterial || !this.fullscreenMaterial.sourceMaterialIds) return [];
          return this.fullscreenMaterial.sourceMaterialIds.map(id => this.materials.find(m => m.id === id)).filter(Boolean);
        },
        fullscreenSelectedSource() {
          if (!this.fullscreenSelectedSourceId) return null;
          return this.materials.find(m => m.id === this.fullscreenSelectedSourceId) || null;
        },
        workbenchPageHeadTitle() {
          if (!this.workbenchProjectId) return '审计助手';
          const named = WORKBENCH_PROJECT_NAME_BY_ID[this.workbenchProjectId];
          if (named) return named;
          try {
            const raw = sessionStorage.getItem('pendingNewProject');
            if (raw) {
              const parsed = JSON.parse(raw);
              if (parsed && parsed.id === this.workbenchProjectId && parsed.name) return String(parsed.name);
            }
          } catch (_) {}
          return '工作台 ' + this.workbenchProjectId;
        },
        workbenchProjectTemplates() {
          void this.workbenchDemoRefreshTick;
          const pid = this.workbenchProjectId;
          if (!pid) return [];
          return demoProjectAnalysisTemplatesById[pid] || [];
        },
        workbenchProjectTemplateCount() {
          return (this.workbenchProjectTemplates || []).length;
        },
        workbenchTemplateTreeSections() {
          const q = String(this.wbSkillSidebarSearchKeyword || '').trim().toLowerCase();
          let project = (this.workbenchProjectTemplates || []).filter((tpl) => {
            if (this.isWbProjectSkillSummarizing(tpl)) return false;
            if (q) {
              const name = String(tpl.name || '').toLowerCase();
              const tags = Array.isArray(tpl.tags) ? tpl.tags.map((t) => String(t || '').toLowerCase()) : [];
              if (!name.includes(q) && !tags.some((t) => t.includes(q))) return false;
            }
            return true;
          });
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const byName = (a, b) => collator.compare(String(a.name || ''), String(b.name || ''));
          project = [...project].sort((a, b) => byName(a, b));
          const mapNode = (tpl, scope) => ({
            source: 'template',
            id: tpl.id,
            key: `${scope}:${tpl.id}`,
            scope,
            raw: tpl,
          });
          return [
            { key: 'project', label: '技能', children: project.map((tpl) => mapNode(tpl, 'project')) },
          ];
        },
        workbenchTemplateTotalCount() {
          return (this.workbenchTemplateTreeSections || []).reduce((sum, sec) => sum + ((sec.children || []).length), 0);
        },
        wbTaskCreateSkillOptions() {
          return (this.workbenchProjectTemplates || [])
            .filter((tpl) => !this.isWbProjectSkillSummarizing(tpl))
            .map((tpl) => ({ label: tpl.name || '未命名技能', value: String(tpl.id) }));
        },
        wbTaskCreateResourceTypeLabel() {
          return {
            file: '文件',
            database: '数据库表',
            graph: '知识图谱',
            knowledge: '知识库',
          };
        },
        wbTaskCreateResourceRows() {
          const folders = this.workbenchMaterialFoldersList || [];
          const fileRows = (this.materials || [])
            .filter((m) => (m.type === 'raw' || m.type === undefined))
            .map((m) => {
              const row = m.projectSource || {};
              const prefix = wbMatMaterialPathPrefixForRow(row, folders);
              const base = String(m.title || '未命名文件');
              return {
                key: `file:${m.id}`,
                type: 'file',
                id: String(m.id),
                name: prefix ? `${prefix}${base}` : base,
                iconClass: this.getMaterialIcon({ ...m, type: 'raw' }),
                iconToneClass: this.getMaterialIconColorClass(m),
              };
            });
          const dbRows = (this.dbResourceList || []).map((row) => ({
            key: `database:${row.id}`,
            type: 'database',
            id: String(row.id),
            name: String(row.tableName || row.name || '未命名数据库资源'),
            iconClass: 'fa-table',
            iconToneClass: 'is-data',
          }));
          const graphRows = (this.graphResourceList || []).map((row) => ({
            key: `graph:${row.id}`,
            type: 'graph',
            id: String(row.id),
            name: String(row.name || '未命名图谱'),
            iconClass: 'fa-circle-nodes',
            iconToneClass: 'is-data',
          }));
          return { file: fileRows, database: dbRows, graph: graphRows, knowledge: [] };
        },
        wbTaskCreateResourceTypeCount() {
          const rows = this.wbTaskCreateResourceRows || { file: [], database: [], graph: [], knowledge: [] };
          return {
            file: (rows.file || []).length,
            database: (rows.database || []).length,
            graph: (rows.graph || []).length,
            knowledge: (rows.knowledge || []).length,
          };
        },
        wbTaskCreateAvailableResources() {
          const tab = this.wbTaskCreateForm.resourceTab || 'file';
          const q = String(this.wbTaskCreateForm.resourceQuery || '').trim().toLowerCase();
          const rows = (this.wbTaskCreateResourceRows && this.wbTaskCreateResourceRows[tab]) || [];
          return rows.filter((item) => {
            if (!q) return true;
            return String(item.name || '').toLowerCase().includes(q);
          });
        },
        wbTaskCreateVisibleResources() {
          return (this.wbTaskCreateAvailableResources || []).slice(0, 10);
        },
        wbTaskCreateSubmitDisabled() {
          const name = String(this.wbTaskCreateForm.taskName || '').trim();
          return !name || !this.wbTaskCreateForm.skillId || !(this.wbTaskCreateForm.selectedResources || []).length;
        },
        wbTaskCreateStep1NextDisabled() {
          const f = this.wbTaskCreateForm || {};
          const name = String(f.taskName || '').trim();
          if (!name || !f.skillId) return true;
          if (this.wbTaskCreateInstructionState !== 'ready') return true;
          if (!String(f.instruction || '').trim()) return true;
          if (f.taskType === 'batch') {
            if (!f.dataSourceFile || !this.wbTaskCreateBatchSelectedColumnCount) return true;
          }
          return false;
        },
        wbTaskCreateInstructionDisabled() {
          return this.wbTaskCreateInstructionState !== 'ready';
        },
        wbTaskCreateInstructionPlaceholder() {
          if (this.wbTaskCreateInstructionState === 'generating') return '';
          if (this.wbTaskCreateInstructionState === 'ready') return '可在此微调自动生成的任务指令';
          if (this.wbTaskCreateForm.taskType === 'batch') {
            return '请先选择技能、上传数据源并选择标识列';
          }
          return '请先选择技能';
        },
        wbTaskCreateBatchPreviewSource() {
          return (
            (typeof window !== 'undefined' && window.DEMO_BATCH_DATASOURCE_PREVIEW) ||
            (typeof DEMO_BATCH_DATASOURCE_PREVIEW !== 'undefined' ? DEMO_BATCH_DATASOURCE_PREVIEW : null)
          );
        },
        wbTaskCreatePreviewRowCount() {
          return 5;
        },
        wbTaskCreatePreviewScrollY() {
          return this.wbTaskCreatePreviewRowCount * 39;
        },
        wbTaskCreatePreviewColumns() {
          if (!this.wbTaskCreateForm.dataSourceFile) return [];
          const preview = this.wbTaskCreateBatchPreviewSource;
          const cols = (preview && preview.columns) || [];
          const idCols = this.wbTaskCreateBatchIdColumns;
          return cols.map((c) => ({
            title: c,
            dataIndex: c,
            key: c,
            ellipsis: true,
            customHeaderCell: () => ({
              class: idCols.includes(c) ? 'wb-preview-th--id' : '',
            }),
            customCell: () => ({
              class: idCols.includes(c) ? 'wb-preview-cell--id' : '',
            }),
          }));
        },
        wbTaskCreatePreviewRows() {
          if (!this.wbTaskCreateForm.dataSourceFile) return [];
          const preview = this.wbTaskCreateBatchPreviewSource;
          const cols = (preview && preview.columns) || [];
          const rows = (preview && preview.rows) || [];
          return rows.slice(0, this.wbTaskCreatePreviewRowCount).map((row, i) => {
            const o = { key: 'preview-' + i };
            cols.forEach((col, ci) => {
              o[col] = row[ci];
            });
            return o;
          });
        },
        wbTaskCreateBatchIdColumns() {
          const raw = (this.wbTaskCreateForm && this.wbTaskCreateForm.idColumns) || [];
          if (!Array.isArray(raw)) return [];
          return raw.map((c) => String(c || '').trim()).filter(Boolean);
        },
        wbTaskCreateBatchSelectedColumnCount() {
          return this.wbTaskCreateBatchIdColumns.length;
        },
        wbTaskCreateBatchEstimatedChildCount() {
          if (!this.wbTaskCreateForm.dataSourceFile) return 0;
          const idCols = this.wbTaskCreateBatchIdColumns;
          if (!idCols.length) return 0;
          const preview = this.wbTaskCreateBatchPreviewSource;
          if (!preview) return 0;
          const indices = idCols
            .map((col) => (preview.columns || []).indexOf(col))
            .filter((idx) => idx >= 0);
          if (!indices.length) return 0;
          const seen = new Set();
          (preview.rows || []).forEach((row) => {
            const parts = indices.map((idx) => String((row && row[idx]) || '').trim());
            if (parts.some((p) => p)) seen.add(parts.join('\u0001'));
          });
          return seen.size;
        },
        wbActiveBatchParentTask() {
          return this.findWorkbenchTaskById(this.wbActiveBatchParentId);
        },
        wbTaskListPanelTitle() {
          if (this.wbTaskListView === 'batch-children') {
            const parent = this.wbActiveBatchParentTask;
            const name = parent && String(parent.title || '').trim();
            return name || '子任务';
          }
          return '任务';
        },
        wbBatchChildStatusSummary() {
          const children = (this.wbActiveBatchParentTask && this.wbActiveBatchParentTask.children) || [];
          const sum = { queued: 0, parsing: 0, done: 0, failed: 0 };
          children.forEach((c) => {
            const st = this.workbenchAnalysisStatusOf(c);
            if (st === 'queued') sum.queued += 1;
            else if (st === 'parsing') sum.parsing += 1;
            else if (st === 'done') sum.done += 1;
            else if (st === 'failed') sum.failed += 1;
          });
          return sum;
        },
        wbBatchChildBatchTargetCount() {
          const view = this.wbBatchChildStatusView || 'all';
          if (view === 'all') return 0;
          return ((this.wbActiveBatchParentTask && this.wbActiveBatchParentTask.children) || []).filter(
            (c) => this.workbenchAnalysisStatusOf(c) === view
          ).length;
        },
        filteredBatchChildren() {
          const children = (this.wbActiveBatchParentTask && this.wbActiveBatchParentTask.children) || [];
          const view = this.wbBatchChildStatusView || 'all';
          if (view === 'all') return children.filter((c) => this.workbenchAnalysisStatusOf(c) !== 'queued');
          return children.filter((c) => this.workbenchAnalysisStatusOf(c) === view);
        },
        pagedBatchChildren() {
          const page = Math.max(1, Number(this.wbBatchChildPage) || 1);
          const size = Math.max(1, Number(this.wbBatchChildPageSize) || 1);
          const start = (page - 1) * size;
          return this.filteredBatchChildren.slice(start, start + size);
        },
        selectedMaterialIsBatchParentTask() {
          const m = this.selectedMaterial;
          return !!(m && m.taskType === 'batch');
        },
        selectedMaterialIsBatchChildTask() {
          const m = this.selectedMaterial;
          return !!(m && m.taskType === 'batch-child');
        },
        wbSelectedTaskInstructionDisplay() {
          const m = this.selectedMaterial;
          const tc = (m && m.taskConfig) || {};
          const raw = String(tc.instruction || (m && m.batchMeta && m.batchMeta.instruction) || '').trim();
          return raw || '—';
        },
        workbenchAnalysisPreviewMarkdown() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return '';
          if (m.analysisMarkdown) return m.analysisMarkdown;
          const ps = m.projectSource || {};
          const wbEphemeral = !!(this.workbenchCreatedTasks || []).find((t) => t && t.id === m.id);
          if (wbEphemeral) {
            const st = this.workbenchAnalysisStatusOf(m);
            if (st === 'queued') {
              return ['## 输出结果（任务）', '', '当前为 **排队中**。执行开始后将在此处展示可读输出摘要与结构化段落（演示）。', '', '> 基本信息页签可随时查看本次任务的配置（技能与关联资料）。'].join('\n');
            }
            if (st === 'parsing') {
              return ['## 输出结果（任务）', '', '当前为 **执行中**。', '', '- 系统将按任务详情中的资源配置逐项检索与分析；', '- 完成后本页将与「结果」侧栏条目展示形态对齐（演示）。'].join('\n');
            }
            if (st === 'failed') {
              return ['## 输出结果（任务）', '', '**本次执行失败（演示）。**', '', '可在任务列表中使用 **重跑** 发起新的执行尝试；若在排队/执行中选择 **中止**，也会回到可重试状态（演示口径）。'].join('\n');
            }
          }
          return buildAnalysisResultPreviewMarkdown({ name: m.title || ps.name, createdAt: m.meta || ps.createdAt });
        },
        workbenchAnalysisCitationMap() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return DEMO_ANALYSIS_CITATION_MAP;
          return m.citationMap || DEMO_ANALYSIS_CITATION_MAP;
        },
        workbenchAnalysisPreviewHtml() {
          const md = this.workbenchAnalysisPreviewMarkdown || '';
          const html = (window.marked && typeof window.marked.parse === 'function')
            ? window.marked.parse(md)
            : md.replace(/\n/g, '<br>');
          return html.replace(/\[(E\d+)\]/g, (_, k) => `<span class="analysis-inline-citation" aria-label="引用 ${this.analysisCitationDisplayIndex(k)}">（${this.analysisCitationDisplayIndex(k)}）</span>`);
        },
        workbenchAnalysisVersionMenuList() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return [];
          const list = (this.workbenchAnalysisVersionHistoryById || {})[m.id];
          return Array.isArray(list) ? list : [];
        },
        workbenchAnalysisVersionMgmtColumns() {
          return [
            { title: '生成时间', dataIndex: 'generatedAt', key: 'generatedAt', width: 156 },
            {
              title: '生成说明',
              dataIndex: 'generationDesc',
              key: 'generationDesc',
              ellipsis: true,
              className: 'skill-version-mgmt-col-desc',
            },
            { title: '操作', key: 'action', width: 128, align: 'left', className: 'skill-version-mgmt-col-action' },
          ];
        },
        workbenchAnalysisVersionCurrentRow() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return null;
          const ps = m.projectSource || {};
          const base = this.workbenchSelectedAnalysisResultRow || {};
          const rec = {
            ...ps,
            ...base,
            sourceSkillName: base.sourceSkillName || ps.sourceSkillName,
            sourceMaterialIds: Array.isArray(ps.sourceMaterialIds)
              ? ps.sourceMaterialIds
              : (Array.isArray(m.sourceMaterialIds) ? m.sourceMaterialIds : []),
          };
          const generatedAt = String(ps.analysisMarkdownEditedAt || m.meta || ps.createdAt || '').trim() || '—';
          const resolver = (mid) => this.workbenchAnalysisResolveMaterialNameById(mid);
          const generationDesc =
            typeof buildAnalysisResultGenerationDesc === 'function'
              ? buildAnalysisResultGenerationDesc(rec, resolver)
              : `使用技能「${String(rec.sourceSkillName || '关联技能')}」生成的结果（演示）。`;
          return {
            key: '_current',
            generatedAt,
            generationDesc,
            markdown: this.workbenchAnalysisPreviewMarkdown || '',
          };
        },
        workbenchAnalysisVersionHistoryOnlyRows() {
          const list = this.workbenchAnalysisVersionMenuList || [];
          return list.map((v) => {
            const raw = String(v.markdown || '');
            const gd = String(v.generationDesc || '').trim();
            const savedAt = String(v.savedAt || '').trim();
            const generationDesc = gd || (savedAt ? `历史快照 · ${savedAt}` : '历史快照');
            const generatedAt = savedAt || String(v.label || '').trim() || '—';
            return {
              key: v.key,
              generatedAt,
              generationDesc,
              markdown: raw,
            };
          });
        },
        workbenchAnalysisStatusLabel() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return '—';
          const st = (m.projectSource && m.projectSource.status) || m.status || 'done';
          const map = { queued: '排队中', parsing: '执行中', done: '成功', failed: '失败' };
          return map[st] || map.done;
        },
        workbenchAnalysisStatusChipClass() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return 'is-neutral';
          const st = (m.projectSource && m.projectSource.status) || m.status || 'done';
          return this.analysisStatusChipClass(st);
        },
        /** 工作台侧栏「原始文件」与工作台资料预览同源：文档页 / OCR 页由 demo-mock-data 拆分函数提供 */
        workbenchMaterialDocumentPages() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'raw' || !m.projectSource) return ['暂无内容'];
          return materialPreviewDocumentPagesFromRecord(m.projectSource);
        },
        workbenchMaterialOcrPagesList() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'raw' || !m.projectSource) return ['暂无 OCR 内容'];
          return materialPreviewOcrPagesFromRecord(m.projectSource);
        },
        workbenchMaterialOcrPagesDisplayed() {
          const pages = this.workbenchMaterialOcrPagesList;
          if (!this.materialPreviewOcrShowLineNumbers) return pages;
          return pages.map((p) => materialPreviewOcrPageWithLineNumbers(p, true));
        },
        resourcePreviewBasicMetaRows() {
          const r = this.selectedResourcePreview;
          if (!r) return [];
          const rows = [
            { label: '资源类型', value: r.type === 'database' ? '数据库' : '数据图谱' },
            { label: '名称', value: String(r.name || '').trim() || '—' },
          ];
          if (r.type === 'database') {
            rows.push({ label: '表注释', value: String(r.tableComment || '').trim() || '—' });
            rows.push({ label: '数据量', value: String(r.rowCountLabel || '').trim() || '—' });
          }
          rows.push({ label: '来源', value: String(r.source || '').trim() || '—' });
          rows.push({ label: '更新时间', value: String(r.updatedAt || '').trim() || '—' });
          return rows;
        },
        workbenchMaterialPreviewBasicMetaRows() {
          const r = this.workbenchSelectedProjectMaterialRow;
          return this.materialBasicMetaRowsFromProjectSourceRow(r);
        },
        /** 与工作台结果预览 Modal 的 buildOverviewResultMeta 字段一致 */
        workbenchAnalysisResultBasicMetaRows() {
          return this.analysisResultBasicMetaRowsFromRecord(this.workbenchSelectedAnalysisResultRow);
        },
        /** 大结果预览弹窗 · 基本信息（与同物料在侧栏「结果」下字段一致） */
        wbAnalysisModalBasicMetaRows() {
          return this.analysisResultBasicMetaRowsFromRecord(this.wbAnalysisModalRecord);
        },
        /** 侧栏内嵌「基本信息」：任务仅四字段，结果沿用 workbenchAnalysisResultBasicMetaRows */
        workbenchEmbedBasicMetaRows() {
          if (!this.selectedMaterialIsWorkbenchCreatedTask) return this.workbenchAnalysisResultBasicMetaRows;
          const m = this.selectedMaterial;
          const ps = (m && m.projectSource) || {};
          const status = this.workbenchAnalysisStatusOf(m);
          const stLabel = this.analysisResultStatusLabel(status);
          const name = String(ps.name || (m && m.title) || '').trim() || '—';
          const created = String(ps.createdAt || '').trim() || '—';
          let completed = '—';
          if (status === 'done' || status === 'failed') {
            completed = String(ps.completedAt || ps.failedAt || ps.createdAt || '').trim() || '—';
          }
          return [
            { label: '任务名称', value: name },
            { label: '状态', value: stLabel },
            { label: '生成时间', value: created },
            { label: '完成时间', value: completed },
          ];
        },
        /** 任务详情 Tab：摘要模型（技能名等；资源列表用 workbenchTaskConfigResourcesList） */
        workbenchSelectedTaskConfigDagModel() {
          const m = this.selectedMaterial;
          if (!m || !m.taskConfig) return null;
          const tc = m.taskConfig || {};
          if (tc.taskType === 'generate-skill') {
            const intent = String(tc.intent || '').trim();
            const resArr = Array.isArray(tc.resources)
              ? tc.resources.map((x, i) => ({
                  key: String((x && x.key) || `r-${i}`),
                  label: String((x && (x.title || x.name || x.fileName || x.label)) || '').trim() || '未命名',
                }))
              : [];
            const skillNm = String(tc.skillName || '生成技能配置').trim() || '生成技能配置';
            return {
              dagMode: 'generate-skill',
              resources: resArr.length
                ? resArr
                : [{ key: 'intent', label: intent ? (intent.length > 220 ? intent.slice(0, 220) + '…' : intent) : '—' }],
              skill: { id: 'generate-skill', name: skillNm },
            };
          }
          const skillName =
            String(tc.skillName || (this.workbenchSelectedAnalysisResultRow && this.workbenchSelectedAnalysisResultRow.sourceSkillName) || '')
              .trim() || '—';
          const skillId = String(tc.skillId || '').trim();
          const resources = Array.isArray(tc.resources)
            ? tc.resources.map((x, i) => ({
                key: String((x && x.key) || `r-${i}`),
                label: String((x && (x.title || x.name || x.fileName || x.label)) || '').trim() || '未命名资源',
              }))
            : [];
          return {
            dagMode: 'default',
            resources,
            skill: { id: skillId, name: skillName },
          };
        },
        /** 侧栏选中为「生成技能」类工作台任务 */
        wbTaskConfigIsGenerateSkillTask() {
          const m = this.selectedMaterial;
          const tc = m && m.taskConfig;
          return !!(tc && tc.taskType === 'generate-skill');
        },
        /** 生成技能任务在「产出结果」中展示的产物技能名称（单行主文案，不含状态后缀） */
        wbTaskConfigGenerateSkillProductName() {
          const m = this.selectedMaterial;
          if (!m || !m.taskConfig || m.taskConfig.taskType !== 'generate-skill') return '';
          const tc = m.taskConfig;
          const explicit = String(tc.outputSkillName || tc.generatedSkillName || '').trim();
          if (explicit) return this.wbTaskDetailStripDemoLabel(explicit) || explicit;
          const ps = m.projectSource || {};
          const fromPs = String(ps.outputSkillName || ps.resultSkillName || ps.name || '').trim();
          if (fromPs) return this.wbTaskDetailStripDemoLabel(fromPs) || fromPs;
          return '可复用技能草稿';
        },
        /** 生成技能任务 · 产出结果行：技能名称 + 状态与时间（结构同 wbTaskConfigResultRowSingleLine） */
        wbTaskConfigGenerateSkillOutputRowSingleLine() {
          const nameRaw = String(this.wbTaskConfigGenerateSkillProductName || '').trim() || '—';
          const name = this.wbTaskDetailStripDemoLabel(nameRaw) || '—';
          const sub = String(this.wbTaskConfigResultListSubtitle || '').trim();
          if (!sub || sub === '—') return name;
          return this.wbTaskDetailStripDemoLabel(`${name} · ${sub}`) || name;
        },
        /** 创建任务时在弹窗中填写的「生成技能要求」全文 */
        wbSelectedGenerateSkillIntentDisplay() {
          const m = this.selectedMaterial;
          const tc = m && m.taskConfig;
          if (!tc || tc.taskType !== 'generate-skill') return '—';
          const raw = String(tc.intent || '').trim();
          return raw || '—';
        },
        /** 任务详情：资源列表原始行（含 type / key；生成技能无 resources 时用意图占位） */
        workbenchTaskConfigResourcesList() {
          const m = this.selectedMaterial;
          if (!m || !m.taskConfig) return [];
          const tc = m.taskConfig || {};
          const raw = Array.isArray(tc.resources) ? tc.resources : [];
          if (raw.length) return raw;
          if (tc.taskType === 'generate-skill') {
            const intent = String(tc.intent || '').trim();
            return [{
              key: 'intent',
              name: intent ? (intent.length > 220 ? `${intent.slice(0, 220)}…` : intent) : '—',
              type: 'intent',
            }];
          }
          return [];
        },
        /** 任务详情：结果标题（优先 projectSource 显式名称） */
        workbenchTaskDagResultDisplayName() {
          const m = this.selectedMaterial;
          if (!m) return '—';
          if (!this.selectedMaterialIsWorkbenchCreatedTask) {
            const r = this.workbenchSelectedAnalysisResultRow;
            return (r && String(r.name || '').trim()) || '—';
          }
          const ps = m.projectSource || {};
          const fromPs = String(ps.outputTitle || ps.resultName || ps.name || '').trim();
          if (fromPs) return fromPs;
          const r = this.workbenchSelectedAnalysisResultRow;
          if (r && String(r.name || '').trim()) return String(r.name).trim();
          const t = String(m.title || '').trim();
          const stripped = t.replace(/[（(][^）)]*[）)]\s*$/, '').trim();
          return stripped || t || '—';
        },
        wbTaskConfigResultListSubtitle() {
          const r = this.workbenchSelectedAnalysisResultRow;
          const m = this.selectedMaterial;
          if (!m) return '—';
          const ps = m.projectSource || {};
          const status = (r && r.status) || ps.status || m.status || 'queued';
          const st = this.analysisResultStatusLabel(status);
          const t = String((r && r.createdAt) || ps.createdAt || '').trim();
          return t ? `${st} · ${t}` : st;
        },
        /** 任务详情 · 产出结果：单行（名称 + 状态与时间），不含「（演示）」 */
        wbTaskConfigResultRowSingleLine() {
          const nameRaw = String(this.workbenchTaskDagResultDisplayName || '').trim() || '—';
          const name = this.wbTaskDetailStripDemoLabel(nameRaw) || '—';
          const sub = String(this.wbTaskConfigResultListSubtitle || '').trim();
          if (!sub || sub === '—') return name;
          return this.wbTaskDetailStripDemoLabel(`${name} · ${sub}`) || name;
        },
        /** 任务详情「上下文」页：只读多轮对话与执行轨迹（模拟） */
        workbenchSelectedTaskDialogTurns() {
          const m = this.selectedMaterial;
          if (!m || !this.selectedMaterialIsWorkbenchCreatedTask) return [];
          return this.buildWorkbenchTaskDialogTurnsSnapshot(m);
        },
        /** 任务详情 · 使用技能：单行，名称不含「（演示）」 */
        wbTaskConfigSkillRowSingleLine() {
          const d = this.workbenchSelectedTaskConfigDagModel;
          if (!d || !d.skill) return '—';
          const nmRaw = String(d.skill.name || '').trim() || '—';
          const nm = this.wbTaskDetailStripDemoLabel(nmRaw) || '—';
          const id = String(d.skill.id || '').trim();
          if (!id || id === 'generate-skill') return nm;
          return `${nm} · ${id}`;
        },
        wbTaskResourcePreviewModalTitle() {
          const item = this.wbTaskResourcePreviewItem;
          return item ? this.wbTaskConfigResourceDisplayTitle(item) : '资源预览';
        },
        wbTaskResourcePreviewIsDatabase() {
          if (!this.wbTaskResourcePreviewOpen || !this.wbTaskResourcePreviewItem) return false;
          return this.wbTaskConfigResolveResourceKind(this.wbTaskResourcePreviewItem) === 'database';
        },
        wbTaskResourcePreviewDatabaseTables() {
          if (!this.wbTaskResourcePreviewIsDatabase) return [];
          return this.wbTaskResourceResolveDatabasePreviewTables(this.wbTaskResourcePreviewItem || {});
        },
        wbTaskResourcePreviewModalTabsAriaLabel() {
          if (!this.wbTaskResourcePreviewOpen) return '资源预览';
          if (this.wbTaskResourcePreviewIsDatabase) return '数据库表资源预览：基本信息与建表语句';
          const vm = this.wbTaskResourcePreviewResolvedMaterial;
          const hasFile = vm && (vm.type === 'raw' || vm.type === undefined) && vm.projectSource;
          if (hasFile) return '资源预览：基本信息与文件预览';
          return '资源预览：基本信息';
        },
        wbTaskResourcePreviewBasicRows() {
          if (!this.wbTaskResourcePreviewOpen) return [];
          const vm = this.wbTaskResourcePreviewResolvedMaterial;
          if (vm && (vm.type === 'raw' || vm.type === undefined) && vm.projectSource) {
            return this.materialBasicMetaRowsFromProjectSourceRow(vm.projectSource);
          }
          const item = this.wbTaskResourcePreviewItem;
          return item ? this.wbTaskConfigResourceDetailRowsForItem(item) : [];
        },
        wbTaskResourcePreviewDocumentPages() {
          const vm = this.wbTaskResourcePreviewResolvedMaterial;
          if (!vm || (vm.type !== 'raw' && vm.type !== undefined) || !vm.projectSource) return ['暂无内容'];
          return materialPreviewDocumentPagesFromRecord(vm.projectSource);
        },
        wbTaskResourcePreviewOcrPagesList() {
          const vm = this.wbTaskResourcePreviewResolvedMaterial;
          if (!vm || (vm.type !== 'raw' && vm.type !== undefined) || !vm.projectSource) return ['暂无 OCR 内容'];
          return materialPreviewOcrPagesFromRecord(vm.projectSource);
        },
        wbTaskResourcePreviewOcrDisplayed() {
          const pages = this.wbTaskResourcePreviewOcrPagesList || [];
          if (!this.wbTaskResourcePreviewOcrLines) return pages;
          return pages.map((p) => materialPreviewOcrPageWithLineNumbers(p, true));
        },
        wbTaskResourcePreviewResolvedRawSubtype() {
          const vm = this.wbTaskResourcePreviewResolvedMaterial;
          if (!vm) return 'document';
          return String(vm.rawSubtype || 'document');
        },
        workbenchSelectedTaskResultSummary() {
          const m = this.selectedMaterial;
          if (!m || !this.selectedMaterialIsWorkbenchCreatedTask) return '—';
          const tc = m.taskConfig || {};
          const status = this.workbenchAnalysisStatusOf(m);
          if (tc.taskType === 'generate-skill') {
            if (status === 'parsing' || status === 'queued') {
              return '正在根据意图生成技能配置，完成后将出现在工作台技能列表（演示）。';
            }
            if (status === 'failed') return '生成技能配置失败，可在任务更多菜单中重试（演示）。';
            return '技能配置已生成，可在左侧技能栏查看并与资料关联（演示）。';
          }
          if (status === 'parsing' || status === 'queued') return '任务执行中，结果生成后会同步到结果列表（演示）。';
          if (status === 'failed') return '任务执行失败，可在更多菜单或核心按钮中重跑。';
          return '任务执行成功，已生成结果。';
        },
        wbAnalysisModalPreviewMarkdown() {
          if (!this.wbAnalysisModalOpen) return '';
          const r = this.wbAnalysisModalRecord || {};
          if (r.analysisMarkdown) return r.analysisMarkdown;
          return buildAnalysisResultPreviewMarkdown(r);
        },
        wbAnalysisModalVersionMenuList() {
          const r = this.wbAnalysisModalRecord;
          if (!r || !r.id) return [];
          const list = (this.workbenchAnalysisVersionHistoryById || {})[r.id];
          return Array.isArray(list) ? list : [];
        },
        wbAnalysisModalVersionCurrentRow() {
          const r = this.wbAnalysisModalRecord;
          if (!r || !r.id) return null;
          const generatedAt = String(r.analysisMarkdownEditedAt || r.createdAt || '').trim() || '—';
          const resolver = (mid) => this.workbenchAnalysisResolveMaterialNameById(mid);
          const generationDesc =
            typeof buildAnalysisResultGenerationDesc === 'function'
              ? buildAnalysisResultGenerationDesc(r, resolver)
              : `使用技能「${String(r.sourceSkillName || '关联技能')}」生成的结果（演示）。`;
          return {
            key: '_current',
            generatedAt,
            generationDesc,
            markdown: this.wbAnalysisModalPreviewMarkdown || '',
          };
        },
        wbAnalysisModalVersionHistoryOnlyRows() {
          const list = this.wbAnalysisModalVersionMenuList || [];
          return list.map((v) => {
            const raw = String(v.markdown || '');
            const gd = String(v.generationDesc || '').trim();
            const savedAt = String(v.savedAt || '').trim();
            const generationDesc = gd || (savedAt ? `历史快照 · ${savedAt}` : '历史快照');
            const generatedAt = savedAt || String(v.label || '').trim() || '—';
            return {
              key: v.key,
              generatedAt,
              generationDesc,
              markdown: raw,
            };
          });
        },
        wbAnalysisVersionDetailHtml() {
          const md = this.wbAnalysisVersionDetailMarkdown || '';
          const html = (window.marked && typeof window.marked.parse === 'function')
            ? window.marked.parse(md)
            : md.replace(/\n/g, '<br>');
          return html.replace(/\[(E\d+)\]/g, (_, k) => `<span class="analysis-inline-citation" aria-label="引用 ${this.analysisCitationDisplayIndex(k)}">（${this.analysisCitationDisplayIndex(k)}）</span>`);
        },
        wbAnalysisModalCitationMap() {
          const r = this.wbAnalysisModalRecord;
          if (!r) return DEMO_ANALYSIS_CITATION_MAP;
          return r.citationMap || DEMO_ANALYSIS_CITATION_MAP;
        },
        wbAnalysisModalDialogueSourceLine() {
          return this.workbenchAnalysisDialogueSourceLineFromRecord(this.wbAnalysisModalRecord);
        },
        wbAnalysisModalPreviewHtml() {
          const md = this.wbAnalysisModalPreviewMarkdown || '';
          const html = (window.marked && typeof window.marked.parse === 'function')
            ? window.marked.parse(md)
            : md.replace(/\n/g, '<br>');
          return html.replace(/\[(E\d+)\]/g, (_, k) => `<span class="analysis-inline-citation" aria-label="引用 ${this.analysisCitationDisplayIndex(k)}">（${this.analysisCitationDisplayIndex(k)}）</span>`);
        },
        wbAnalysisModalStatusLabel() {
          const r = this.wbAnalysisModalRecord || {};
          const st = r.status || 'done';
          const map = { queued: '排队中', parsing: '分析中', done: '完成', failed: '失败' };
          return map[st] || '完成';
        },
        wbAnalysisModalStatusChipClass() {
          const r = this.wbAnalysisModalRecord || {};
          const st = r.status || 'done';
          return this.analysisStatusChipClass(st);
        },
        wbDetailSelectedSkill() {
          const pid = this.workbenchProjectId;
          if (!this.wbProjectSkillDetailId || !pid) return null;
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          return list.find((x) => x.id === this.wbProjectSkillDetailId) || null;
        },
        wbProjectSkillDetailModalTitle() {
          if (this.wbProjectSkillDetailModalIsCreate) return '新建技能';
          const s = this.wbDetailSelectedSkill;
          if (!s) return '技能详情';
          const n = String(s.name || '').trim();
          return n || '未命名技能';
        },
        wbProjectSkillDetailModalHeadVersionLabel() {
          if (this.wbProjectSkillDetailModalIsCreate || !this.wbDetailSelectedSkill) return '';
          const s = this.wbDetailSelectedSkill;
          const list = Array.isArray(s.publishedVersions) ? s.publishedVersions : [];
          if (!list.length) return '';
          const sorted = [...list].sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
          const v = sorted[0] && sorted[0].versionLabel;
          return v ? String(v).trim() : '';
        },
        wbProjectSkillConfigSelectedFile() {
          const k = this.wbProjectSkillConfigNavKey;
          if (!k || String(k).indexOf('file:') !== 0 || !this.wbDetailSelectedSkill) return null;
          const id = String(k).slice('file:'.length);
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || typeof T.findFileNodeById !== 'function') return null;
          const hit = T.findFileNodeById(this.wbDetailSelectedSkill.skillFiles || [], id);
          return hit ? hit.node : null;
        },
        wbProjectSkillConfigSelectedFolder() {
          const k = this.wbProjectSkillConfigNavKey;
          if (!k || String(k).indexOf('folder:') !== 0 || !this.wbDetailSelectedSkill) return null;
          const id = String(k).slice('folder:'.length);
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || typeof T.findFolderNodeById !== 'function') return null;
          const hit = T.findFolderNodeById(this.wbDetailSelectedSkill.skillFiles || [], id);
          return hit ? hit.node : null;
        },
        wbProjectSkillConfigDuplicatePaths() {
          const s = this.wbDetailSelectedSkill;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!s || !T || typeof T.findDuplicatePaths !== 'function') return [];
          return T.findDuplicatePaths(s.skillFiles || []);
        },
        wbProjectSkillConfigSelectedFileCodeLabel() {
          const f = this.wbProjectSkillConfigSelectedFile;
          if (!f || f.fileKind !== 'code') return '代码';
          const m = { python: 'Python', javascript: 'JavaScript', typescript: 'TypeScript', shell: 'Shell' };
          return m[f.codeLang] || f.codeLang || '代码';
        },
        wbProjectSkillConfigTreeData() {
          if (!this.wbDetailSelectedSkill) return [];
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (T && typeof T.buildAntTreeData === 'function') return T.buildAntTreeData(this.wbDetailSelectedSkill.skillFiles || []);
          return [{ key: 'rule', title: 'skill.md', isLeaf: true }];
        },
        wbProjectSkillConfigTreeSelectedKeys() {
          const k = this.wbProjectSkillConfigNavKey;
          if (!k || k === 'rule') return ['rule'];
          return [String(k)];
        },
        wbProjectSkillBasicFieldsLocked() {
          return this.wbProjectSkillDetailReadOnly;
        },
        wbProjectSkillConfigTabLocked() {
          return this.wbProjectSkillDetailReadOnly;
        },
        wbProjectSkillBasicPaneDirty() {
          if (this.wbProjectSkillDetailReadOnly) return false;
          const snap = this._wbProjectSkillBasicPaneSnap;
          if (!snap) return false;
          const normTags = (arr) =>
            JSON.stringify(
              [...(arr || [])]
                .map((t) => String(t).trim())
                .filter(Boolean)
                .sort()
            );
          return (
            String(this.wbProjectSkillForm.name || '') !== String(snap.name || '')
            || String(this.wbProjectSkillForm.description || '') !== String(snap.description || '')
            || normTags(this.wbProjectSkillForm.tags) !== normTags(snap.tags)
          );
        },
        wbProjectSkillConfigPaneDirty() {
          if (this.wbProjectSkillDetailReadOnly) return false;
          const snap = this._wbProjectSkillConfigPaneSnap;
          const s = this.wbDetailSelectedSkill;
          if (!snap || !s) return false;
          try {
            return JSON.stringify(JSON.parse(JSON.stringify(s))) !== JSON.stringify(snap);
          } catch (_) {
            return true;
          }
        },
        wbProjectSkillResourceTabLocked() {
          return this.wbProjectSkillDetailReadOnly;
        },
        wbProjectSkillLinkedResourceSelectOptions() {
          const pid = this.workbenchProjectId;
          const mats = pid ? demoProjectMaterialsById[pid] || [] : [];
          return mats.map((m) => ({ value: String(m.id), label: String(m.name || m.id || '') }));
        },
        wbProjectSkillSaveConfigButtonLabel() {
          return '保存配置';
        },
        /** 思考轨未结束或引导语/收尾总结仍在打字时视为「生成中」（此时输入区显示暂停而非发送） */
        chatReplyInProgress() {
          const list = this.chatMessages || [];
          for (let i = 0; i < list.length; i++) {
            const m = list[i];
            if (m.role === 'thinking' && m._finalized === false) return true;
            if (m.role === 'bot') {
              const introLen = (m.chatIntro || '').length;
              if (introLen) {
                const ip = m.chatIntroProgress;
                if (ip != null && ip < introLen) return true;
              }
              const rs = m.chatRunSummary || '';
              if (rs.length) {
                const rp = m.chatRunSummaryProgress ?? 0;
                if (rp < rs.length) return true;
              }
            }
          }
          return false;
        },
      },
      watch: {
        materialSearchQuery() {
          const auto = this.workbenchMaterialFileTreeAutoExpandKeys || [];
          if (!auto.length) return;
          const s = new Set(this.workbenchFileTreeExpandedKeys || []);
          auto.forEach((k) => s.add(k));
          this.workbenchFileTreeExpandedKeys = Array.from(s);
        },
        workbenchAnalysisSearchQuery() {
          const auto = this.workbenchAnalysisResultAntTreeAutoExpandKeys || [];
          if (!auto.length) return;
          const s = new Set(this.workbenchAnalysisResultTreeExpandedKeys || []);
          auto.forEach((k) => s.add(k));
          this.workbenchAnalysisResultTreeExpandedKeys = Array.from(s);
        },
        workbenchEmbedAnalysisOutputToolbarDisabled(disabled) {
          if (!disabled && this.selectedMaterial && this.selectedMaterial.type === 'analysis') {
            this.$nextTick(() => this.resetWorkbenchAnalysisEmbedDraftFromPreview());
          }
        },
        filteredBatchChildren() {
          this.ensureWbBatchChildPageInRange();
        },
      },
      methods: {
        ensureWbBatchChildPageInRange() {
          const size = Math.max(1, Number(this.wbBatchChildPageSize) || 1);
          const total = this.filteredBatchChildren.length;
          const maxPage = Math.max(1, Math.ceil(total / size));
          const nextPage = Math.min(Math.max(1, Number(this.wbBatchChildPage) || 1), maxPage);
          if (nextPage !== this.wbBatchChildPage) this.wbBatchChildPage = nextPage;
        },
        onWbBatchChildPageChange(page) {
          this.wbBatchChildPage = Math.max(1, Number(page) || 1);
        },
        /** @ 合并匹配行：在类型图标上叠加与侧栏一致的状态色（排队 / 进行中 / 失败） */
        chatAtUnifiedRowStatusClass(row) {
          if (!row || !row.m) return '';
          if (row.kind === 'raw') {
            const st = this.workbenchMaterialStatusOf(row.m);
            if (st === 'queued') return 'is-status-queued';
            if (st === 'parsing') return 'is-status-pending';
            if (st === 'failed') return 'is-status-failed';
            return '';
          }
          if (row.kind === 'result') {
            const st = this.workbenchAnalysisStatusOf(row.m);
            if (st === 'queued') return 'is-status-queued';
            if (st === 'parsing') return 'is-status-pending';
            if (st === 'failed') return 'is-status-failed';
            return '';
          }
          return '';
        },
        workbenchMenuItemIcon(key) {
          const map = {
            'upload-file': 'fa-upload',
            'new-folder': 'fa-folder-plus',
            new: 'fa-plus',
            library: 'fa-book-open',
            ref: 'fa-comment-medical',
            chat: 'fa-comment-medical',
            cite: 'fa-comment-medical',
          };
          return map[key] || '';
        },
        /** 与 ProjectCenter 同映射：列表 `.ds-status-pill` 与预览「基本信息·状态」共用 */
        analysisResultStatusLabel(status) {
          const map = { queued: '排队中', parsing: '执行中', done: '成功', failed: '失败' };
          return map[status] || map.done;
        },
        analysisStatusChipClass(status) {
          const s = (status && String(status)) || 'done';
          const map = { queued: 'is-neutral', parsing: 'is-primary', done: 'is-success', failed: 'is-error' };
          return map[s] || map.done;
        },
        toggleResourceDrawer(key) {
          if (!key || !this.resourceDrawerOpen || !(key in this.resourceDrawerOpen)) return;
          this.resourceDrawerOpen[key] = !this.resourceDrawerOpen[key];
          this.$nextTick(() => this.updateResourceDrawerHeights());
        },
        /** 上传 / 添加资源后展开左栏并打开对应资源抽屉（不关闭其它已展开抽屉） */
        ensureResourceDrawerOpen(key) {
          if (!key || !this.resourceDrawerOpen || !(key in this.resourceDrawerOpen)) return;
          this.sourcesCollapsed = false;
          if (!this.resourceDrawerOpen[key]) this.resourceDrawerOpen[key] = true;
          this.$nextTick(() => this.updateResourceDrawerHeights());
        },
        toggleWorkbenchMaterialSearchPanel() {
          this.workbenchMaterialSearchOpen = !this.workbenchMaterialSearchOpen;
          if (!this.workbenchMaterialSearchOpen) this.materialSearchQuery = '';
        },
        toggleWorkbenchAnalysisSearchPanel() {
          this.workbenchAnalysisSearchOpen = !this.workbenchAnalysisSearchOpen;
          if (!this.workbenchAnalysisSearchOpen) this.workbenchAnalysisSearchQuery = '';
        },
        findWorkbenchTaskById(id) {
          const tid = String(id || '');
          if (!tid) return null;
          const created = (this.workbenchCreatedTasks || []).find((x) => x && x.id === tid);
          if (created) return created;
          const demo =
            typeof demoWorkbenchTaskRows !== 'undefined'
              ? (demoWorkbenchTaskRows || []).find((x) => x && x.id === tid)
              : null;
          return demo || null;
        },
        findWorkbenchTaskChildById(id) {
          const tid = String(id || '');
          if (!tid) return null;
          const sources = [...(this.workbenchCreatedTasks || []), ...(this.workbenchTaskDemoRows || [])];
          for (let i = 0; i < sources.length; i += 1) {
            const t = sources[i];
            if (!t || !Array.isArray(t.children)) continue;
            const c = t.children.find((x) => x && x.id === tid);
            if (c) return c;
          }
          return null;
        },
        isWorkbenchBatchParentTask(raw) {
          return !!(raw && raw.taskType === 'batch');
        },
        workbenchBatchProgressText(raw) {
          const children = (raw && raw.children) || [];
          if (!children.length) return '';
          const done = children.filter((c) => this.workbenchAnalysisStatusOf(c) === 'done').length;
          return `${done}/${children.length}`;
        },
        workbenchBatchProgressPercent(raw) {
          const children = (raw && raw.children) || [];
          if (!children.length) return 0;
          const done = children.filter((c) => this.workbenchAnalysisStatusOf(c) === 'done').length;
          return Math.max(0, Math.min(100, (done / children.length) * 100));
        },
        openWorkbenchTaskCreateModal() {
          this.clearWbTaskCreateInstructionTimer();
          this.wbTaskCreateInstructionState = 'idle';
          this.wbTaskCreateStep = 1;
          this.wbTaskCreateForm = {
            taskName: '',
            skillId: '',
            taskType: 'single',
            instruction: '',
            dataSourceFile: null,
            idColumns: [],
            resourceTab: 'file',
            resourceQuery: '',
            selectedResources: [],
          };
          this.wbTaskCreateModalOpen = true;
        },
        closeWorkbenchTaskCreateModal() {
          this.clearWbTaskCreateInstructionTimer();
          this.wbTaskCreateInstructionState = 'idle';
          this.wbTaskCreateModalOpen = false;
          this.wbTaskCreateStep = 1;
        },
        clearWbTaskCreateInstructionTimer() {
          if (this._wbTaskCreateInstructionTimer) {
            clearTimeout(this._wbTaskCreateInstructionTimer);
            this._wbTaskCreateInstructionTimer = null;
          }
        },
        buildWbTaskCreateInstructionText() {
          const skillId = String(this.wbTaskCreateForm.skillId || '');
          const skill = (this.workbenchProjectTemplates || []).find((tpl) => String(tpl.id) === skillId);
          const skillName = (skill && skill.name) || '所选技能';
          if (this.wbTaskCreateForm.taskType === 'batch') {
            const idCols = this.wbTaskCreateBatchIdColumns;
            const colText = idCols.map((col) => `{{${col}}}`).join('、');
            return `请使用技能「${skillName}」，针对数据源中 ${colText} 等标识符组合的每一行，执行分析并输出结构化结果（演示）。`;
          }
          const rule = String((skill && skill.analysisRule) || '').trim();
          return rule || `请使用技能「${skillName}」对所选资源进行分析，输出审计结论与引用依据（演示）。`;
        },
        onWbTaskCreateTypeChange() {
          if (this.wbTaskCreateForm.taskType === 'single') {
            this.wbTaskCreateForm.dataSourceFile = null;
            this.wbTaskCreateForm.idColumns = [];
          }
          this.syncWbTaskCreateInstructionFromSkill();
        },
        onWbTaskCreateSkillChange() {
          this.syncWbTaskCreateInstructionFromSkill();
        },
        wbTaskCreateInstructionPrerequisitesMet() {
          const f = this.wbTaskCreateForm || {};
          if (!String(f.skillId || '').trim()) return false;
          if (f.taskType === 'batch') {
            if (!f.dataSourceFile) return false;
            if (!this.wbTaskCreateBatchSelectedColumnCount) return false;
          }
          return true;
        },
        syncWbTaskCreateInstructionFromSkill() {
          this.clearWbTaskCreateInstructionTimer();
          if (!this.wbTaskCreateInstructionPrerequisitesMet()) {
            this.wbTaskCreateInstructionState = 'idle';
            this.wbTaskCreateForm.instruction = '';
            return;
          }
          this.wbTaskCreateInstructionState = 'generating';
          this.wbTaskCreateForm.instruction = '';
          const token = (this._wbTaskCreateInstructionGenToken = Date.now());
          this._wbTaskCreateInstructionTimer = setTimeout(() => {
            this._wbTaskCreateInstructionTimer = null;
            if (this._wbTaskCreateInstructionGenToken !== token) return;
            if (!this.wbTaskCreateInstructionPrerequisitesMet()) {
              this.wbTaskCreateInstructionState = 'idle';
              this.wbTaskCreateForm.instruction = '';
              return;
            }
            this.wbTaskCreateForm.instruction = this.buildWbTaskCreateInstructionText();
            this.wbTaskCreateInstructionState = 'ready';
          }, 720);
        },
        syncWbTaskCreateBatchInstruction() {
          this.syncWbTaskCreateInstructionFromSkill();
        },
        applyWbTaskCreateDataSourceFile(name) {
          const fileName = String(name || '').trim() || '企业清单-跑批样本.xlsx';
          const lower = fileName.toLowerCase();
          if (!lower.endsWith('.xlsx') && !lower.endsWith('.csv')) {
            message.warning('仅支持 .xlsx 或 .csv 文件');
            return;
          }
          this.wbTaskCreateForm.dataSourceFile = {
            name: fileName,
            mockKey: lower.endsWith('.csv') ? 'csv' : 'xlsx',
          };
          if (!this.wbTaskCreateBatchSelectedColumnCount) {
            const preview = window.DEMO_BATCH_DATASOURCE_PREVIEW;
            const firstCol = preview && preview.columns && preview.columns[0];
            if (firstCol) this.wbTaskCreateForm.idColumns = [firstCol];
          }
          this.syncWbTaskCreateBatchInstruction();
        },
        mockWbTaskCreateDataSourceUpload() {
          if (this.wbTaskCreateForm.dataSourceFile) return;
          this.applyWbTaskCreateDataSourceFile('企业清单-跑批样本.xlsx');
        },
        beforeWbTaskCreateDataSourceUpload(file) {
          const name = String((file && file.name) || '').trim();
          if (!name) return false;
          this.applyWbTaskCreateDataSourceFile(name);
          return false;
        },
        isWbTaskCreateIdColumnSelected(columnName) {
          const col = String(columnName || '').trim();
          if (!col) return false;
          return this.wbTaskCreateBatchIdColumns.includes(col);
        },
        toggleWbTaskCreateIdColumn(columnName) {
          if (!this.wbTaskCreateForm.dataSourceFile) return;
          const col = String(columnName || '').trim();
          if (!col) return;
          const cols = [...this.wbTaskCreateBatchIdColumns];
          const idx = cols.indexOf(col);
          if (idx >= 0) cols.splice(idx, 1);
          else cols.push(col);
          this.wbTaskCreateForm.idColumns = cols;
          this.syncWbTaskCreateBatchInstruction();
        },
        wbBatchMetaIdColumnText(task) {
          const meta = task && task.batchMeta;
          if (!meta) return '—';
          const cols = meta.idColumns;
          if (Array.isArray(cols) && cols.length) return cols.join('、');
          return String(meta.idColumn || '').trim() || '—';
        },
        wbTaskCreateBatchRowLabel(row, preview, idCols) {
          const columns = (preview && preview.columns) || [];
          const parts = (idCols || [])
            .map((col) => {
              const idx = columns.indexOf(col);
              return idx >= 0 ? String((row && row[idx]) || '').trim() : '';
            })
            .filter(Boolean);
          return parts.join(' · ');
        },
        clearWbTaskCreateDataSource() {
          this.wbTaskCreateForm.dataSourceFile = null;
          this.wbTaskCreateForm.idColumns = [];
          this.syncWbTaskCreateInstructionFromSkill();
        },
        goWbTaskCreateStep2() {
          if (this.wbTaskCreateStep1NextDisabled) return;
          this.wbTaskCreateStep = 2;
        },
        enterBatchChildListView(parentTask) {
          if (!parentTask || !this.isWorkbenchBatchParentTask(parentTask)) return;
          this.wbTaskListView = 'batch-children';
          this.wbActiveBatchParentId = parentTask.id;
          this.wbBatchChildStatusView = 'all';
          this.wbBatchChildPage = 1;
          this.selectedTreeNode = { source: 'analysis', id: parentTask.id };
          this.selectedMaterialId = null;
          this.sourcesRightView = 'list';
          this.studioCollapsed = false;
        },
        exitBatchChildListView() {
          this.wbTaskListView = 'main';
          this.wbActiveBatchParentId = '';
          this.wbBatchChildStatusView = 'all';
          this.wbBatchChildPage = 1;
          if (this.selectedMaterial && this.isWorkbenchBatchParentTask(this.selectedMaterial)) {
            this.selectedMaterialId = null;
          }
          if (this.sourcesRightView === 'detail' && !this.selectedMaterialId) {
            this.sourcesRightView = 'list';
          }
        },
        setWbBatchChildStatusView(status) {
          if (!['parsing', 'done', 'failed'].includes(status)) return;
          this.wbBatchChildStatusView = status;
          this.wbBatchChildPage = 1;
        },
        resetWbBatchChildStatusView() {
          this.wbBatchChildStatusView = 'all';
          this.wbBatchChildPage = 1;
        },
        batchAbortWbBatchChildren() {
          const targets = this.filteredBatchChildren.filter((c) =>
            this.workbenchAnalysisStatusOf(c) === 'parsing'
          );
          if (!targets.length) return;
          Modal.confirm({
            centered: true,
            title: '批量中止子任务',
            content: `确认中止 ${targets.length} 个运行中的子任务吗？`,
            okText: '中止',
            cancelText: '取消',
            onOk: () => {
              targets.forEach((c) => this.workbenchTaskRowAbort(c));
              message.success(`已中止 ${targets.length} 个子任务（演示）`);
            },
          });
        },
        batchRerunWbBatchChildren() {
          const targets = this.filteredBatchChildren.filter((c) =>
            ['parsing', 'failed'].includes(this.workbenchAnalysisStatusOf(c))
          );
          if (!targets.length) return;
          Modal.confirm({
            centered: true,
            title: '批量重跑子任务',
            content: `确认重跑 ${targets.length} 个子任务吗？`,
            okText: '重跑',
            cancelText: '取消',
            onOk: () => {
              targets.forEach((c) => this.workbenchTaskRowRerun(c));
              message.success(`已重跑 ${targets.length} 个子任务（演示）`);
            },
          });
        },
        batchDeleteWbBatchChildren() {
          const parent = this.wbActiveBatchParentTask;
          if (!parent || !Array.isArray(parent.children)) return;
          const view = this.wbBatchChildStatusView || 'all';
          const toRemove =
            view === 'all'
              ? new Set(this.filteredBatchChildren.map((c) => c.id))
              : new Set(
                  parent.children.filter((c) => this.workbenchAnalysisStatusOf(c) === view).map((c) => c.id)
                );
          if (!toRemove.size) return;
          Modal.confirm({
            centered: true,
            title: '批量删除子任务',
            content: `确认删除 ${toRemove.size} 个子任务吗？删除后不可恢复（演示）。`,
            okText: '删除',
            cancelText: '取消',
            okButtonProps: { danger: true },
            onOk: () => {
              parent.children = parent.children.filter((c) => !toRemove.has(c.id));
              message.success(`已删除 ${toRemove.size} 个子任务（演示）`);
            },
          });
        },
        onBatchParentRerunMenu(key, raw) {
          if (key === 'rerun-full') message.success('已发起完全重跑（演示）');
          else if (key === 'rerun-continue') message.success('已发起继续跑（演示）');
          else if (key === 'rerun-task') this.workbenchTaskRowRerun(raw);
        },
        onWbTaskCreateResourceTabChange(tab) {
          this.wbTaskCreateForm.resourceTab = String(tab || 'file');
          this.wbTaskCreateForm.resourceQuery = '';
        },
        addWbTaskCreateResource(item) {
          if (!item || !item.key) return;
          const exists = (this.wbTaskCreateForm.selectedResources || []).some((row) => row.key === item.key);
          if (exists) return;
          this.wbTaskCreateForm.selectedResources = [...(this.wbTaskCreateForm.selectedResources || []), { ...item }];
        },
        isWbTaskCreateResourceSelected(key) {
          return (this.wbTaskCreateForm.selectedResources || []).some((item) => item.key === key);
        },
        toggleWbTaskCreateResource(item) {
          if (!item || !item.key) return;
          if (this.isWbTaskCreateResourceSelected(item.key)) {
            this.removeWbTaskCreateResource(item.key);
            return;
          }
          this.addWbTaskCreateResource(item);
        },
        removeWbTaskCreateResource(key) {
          this.wbTaskCreateForm.selectedResources = (this.wbTaskCreateForm.selectedResources || []).filter((item) => item.key !== key);
        },
        clearWbTaskCreateResources() {
          this.wbTaskCreateForm.selectedResources = [];
        },
        handleWorkbenchTaskCreate() {
          this.openWorkbenchTaskCreateModal();
        },
        submitWorkbenchTaskCreate() {
          const taskName = String(this.wbTaskCreateForm.taskName || '').trim();
          const skillId = String(this.wbTaskCreateForm.skillId || '').trim();
          const selected = this.wbTaskCreateForm.selectedResources || [];
          const instruction = String(this.wbTaskCreateForm.instruction || '').trim();
          const taskType = this.wbTaskCreateForm.taskType === 'batch' ? 'batch' : 'single';
          if (!taskName) {
            message.warning('请输入任务名称');
            return;
          }
          if (!skillId) {
            message.warning('请选择一个技能');
            return;
          }
          if (!instruction) {
            message.warning('请填写任务指令');
            return;
          }
          if (!selected.length) {
            message.warning('请至少添加一个资源');
            return;
          }
          const skill = (this.workbenchProjectTemplates || []).find((tpl) => String(tpl.id) === skillId);
          const skillName = (skill && skill.name) || '';
          const resources = selected.map((row) => ({ ...row }));
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          if (taskType === 'batch') {
            const parentId = 'wb-task-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
            const preview = window.DEMO_BATCH_DATASOURCE_PREVIEW || { rows: [] };
            const idColumns = [...this.wbTaskCreateBatchIdColumns];
            const idColumn = idColumns.join('、');
            const rowLabels = (preview.rows || []).slice(0, 8).map((row, i) => {
              const label = this.wbTaskCreateBatchRowLabel(row, preview, idColumns);
              return label || `第 ${i + 1} 行`;
            });
            const children = rowLabels.map((rowLabel, i) => {
              const childId = parentId + '-c-' + (i + 1);
              const st = i < 2 ? 'done' : i === 3 ? 'parsing' : i === 6 ? 'failed' : 'queued';
              return {
                id: childId,
                type: 'analysis',
                title: rowLabel,
                status: st,
                taskType: 'batch-child',
                parentId,
                rowLabel,
                taskConfig: { skillId, skillName, resources, instruction },
                projectSource: {
                  id: childId,
                  status: st,
                  createdAt: now,
                  sourceSkillName: skillName,
                  name: rowLabel,
                },
              };
            });
            const parentStatus = children.some((c) => c.status === 'parsing')
              ? 'parsing'
              : children.every((c) => c.status === 'done')
                ? 'done'
                : 'queued';
            const fileName = (this.wbTaskCreateForm.dataSourceFile && this.wbTaskCreateForm.dataSourceFile.name) || '数据源.xlsx';
            const created = {
              id: parentId,
              type: 'analysis',
              title: taskName,
              checked: false,
              taskType: 'batch',
              status: parentStatus,
              children,
              batchMeta: { fileName, idColumn, idColumns, total: children.length, instruction },
              projectSource: {
                status: parentStatus,
                createdAt: now,
                sourceSkillName: skillName,
                name: taskName,
              },
              taskConfig: { skillId, skillName, resources, instruction },
            };
            this.workbenchCreatedTasks = [created, ...(this.workbenchCreatedTasks || [])];
            this.closeWorkbenchTaskCreateModal();
            message.success(`跑批任务已创建，共 ${children.length} 个子任务（演示）`);
            return;
          }
          const taskId = 'wb-task-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
          const status = 'queued';
          const created = {
            id: taskId,
            type: 'analysis',
            title: taskName,
            taskType: 'single',
            checked: false,
            projectSource: {
              status,
              createdAt: now,
              sourceSkillName: skillName,
              name: `${taskName} · 分析报告（排队中）`,
            },
            status,
            taskConfig: {
              skillId,
              skillName,
              resources,
              instruction,
            },
          };
          this.workbenchCreatedTasks = [created, ...(this.workbenchCreatedTasks || [])];
          this.closeWorkbenchTaskCreateModal();
          message.success('任务已创建');
        },
        setWorkbenchMaterialStatusView(status) {
          if (status !== 'queued' && status !== 'parsing' && status !== 'failed') return;
          this.workbenchMaterialStatusView = status;
          this.selectedTreeNode = null;
        },
        resetWorkbenchMaterialStatusView() {
          this.workbenchMaterialStatusView = 'all';
          this.selectedTreeNode = null;
        },
        toggleWorkbenchDbSearchPanel() {
          this.workbenchDbSearchOpen = !this.workbenchDbSearchOpen;
          if (!this.workbenchDbSearchOpen) this.dbResourceSearchQuery = '';
        },
        toggleWorkbenchGraphSearchPanel() {
          this.workbenchGraphSearchOpen = !this.workbenchGraphSearchOpen;
          if (!this.workbenchGraphSearchOpen) this.graphResourceSearchQuery = '';
        },
        toggleWbSkillSearchPanel() {
          this.wbSkillSidebarSearchOpen = !this.wbSkillSidebarSearchOpen;
          if (!this.wbSkillSidebarSearchOpen) this.wbSkillSidebarSearchKeyword = '';
        },
        setResourceDrawerBodyRef(key, el) {
          if (!key || !this.resourceDrawerBodyEls || !(key in this.resourceDrawerBodyEls)) return;
          const nextEl = el || null;
          if (this.resourceDrawerBodyEls[key] === nextEl) return;
          this.resourceDrawerBodyEls[key] = nextEl;
          this.updateResourceDrawerHeights();
        },
        updateResourceDrawerHeights() {
          const keys = ['file', 'database', 'graph', 'knowledge'];
          const prev = this.resourceDrawerContentHeights || {};
          const next = { ...prev };
          let changed = false;
          keys.forEach((k) => {
            if (!this.resourceDrawerOpen[k]) return;
            const el = this.resourceDrawerBodyEls[k];
            const h = el ? Math.max(1, Math.ceil(el.scrollHeight || el.clientHeight || 1)) : 1;
            if (next[k] !== h) {
              next[k] = h;
              changed = true;
            }
          });
          if (changed) this.resourceDrawerContentHeights = next;
        },
        resourceDrawerSectionStyle(key) {
          const isOpen = !!(this.resourceDrawerOpen && this.resourceDrawerOpen[key]);
          if (!isOpen) return { flex: '0 0 auto', minHeight: '34px' };
          const keys = ['file', 'database', 'graph', 'knowledge'].filter((k) => this.resourceDrawerOpen[k]);
          const openCount = keys.length || 1;
          const minPct = 10;
          const totalMin = minPct * openCount;
          const freePct = Math.max(0, 100 - totalMin);
          const weightSum = keys.reduce((sum, k) => sum + Math.max(1, Number(this.resourceDrawerContentHeights[k] || 1)), 0);
          const w = Math.max(1, Number(this.resourceDrawerContentHeights[key] || 1));
          const growPct = weightSum > 0 ? (w / weightSum) * freePct : freePct / openCount;
          const basis = minPct + growPct;
          return {
            flex: '1 1 0',
            minHeight: '10%',
            height: `${basis}%`,
          };
        },
        closeResourcePreview() {
          this.selectedResourcePreview = null;
          this.resourcePreviewTab = 'basic';
          this.sourcesLeftView = 'list';
        },
        previewResource(type, row) {
          if (!row) return;
          this.selectedResourcePreview = { ...row, type };
          this.resourcePreviewTab = 'basic';
          this.sourcesLeftView = 'detail';
          this.sourcesDetailWidth = 450;
        },
        addResourceToChat(type, row) {
          if (!row) return;
          if (type === 'knowledge') {
            message.info('知识库能力暂未开放');
            return;
          }
          const labelMap = { database: '数据库', graph: '数据图谱' };
          const prefix = labelMap[type] || '资源';
          if (type === 'database' && row.databaseName && row.tableName) {
            this.appendChatInputToken(`@${prefix}:${row.databaseName}.${row.tableName}`);
            return;
          }
          if (type === 'database' && row.databaseName && !row.tableName) {
            this.appendChatInputToken(`@${prefix}:${String(row.databaseName).trim()}`);
            return;
          }
          this.appendChatInputToken(`@${prefix}:${row.name || row.id}`);
        },
        removeResource(type, row) {
          if (!row) return;
          const title = row.name || '未命名资源';
          if (type === 'knowledge') {
            message.info('知识库能力暂未开放');
            return;
          }
          if (type === 'database') {
            this.confirmRemoveDbTableResource(row);
            return;
          }
          Modal.confirm({
            centered: true,
            title: '确定删除该资源？',
            content: '仅删除当前工作台内配置，不影响历史结果与执行中任务。',
            okText: '删除',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              if (type === 'graph') {
                this.graphResourceList = (this.graphResourceList || []).filter((item) => item.id !== row.id);
              }
              message.success(`已删除：${title}`);
            },
          });
        },
        /** 工作台库表行：删除按钮二次确认（两处 Modal） */
        confirmRemoveDbTableResource(row) {
          if (!row) return;
          const label =
            row.databaseName && row.tableName ? `${row.databaseName} / ${row.tableName}` : String(row.tableName || row.name || '该表');
          Modal.confirm({
            centered: true,
            title: '删除库表引用',
            content: '删除后后续对话将无法引用该表中的数据，是否确认删除。',
            okText: '确认',
            cancelText: '取消',
            onOk: () =>
              new Promise((resolve) => {
                Modal.confirm({
                  centered: true,
                  title: '再次确认',
                  content: `请确认删除「${label}」。删除后可通过「添加库表」重新勾选加入。`,
                  okText: '确认删除',
                  okType: 'danger',
                  cancelText: '取消',
                  onOk: () => {
                    this.dbResourceList = (this.dbResourceList || []).filter((item) => item.id !== row.id);
                    message.success(`已删除：${label}`);
                    resolve();
                  },
                  onCancel: () => resolve(),
                });
              }),
          });
        },
        formatWorkbenchDbTableRowCount(n) {
          if (n == null || n === '') return '—';
          const num = Number(n);
          if (!Number.isFinite(num) || num < 0) return String(n);
          if (num >= 100000000) return `${(Math.round((num / 100000000) * 10) / 10).toString().replace(/\.0$/, '')} 亿行`;
          if (num >= 10000) return `${(Math.round((num / 10000) * 10) / 10).toString().replace(/\.0$/, '')} 万行`;
          if (num >= 1000) return `${(Math.round((num / 1000) * 10) / 10).toString().replace(/\.0$/, '')} 千行`;
          return `${num} 行`;
        },
        workbenchDbTableRowExists(databaseId, tableName) {
          const id = String(databaseId || '') + '::' + String(tableName || '');
          return (this.dbResourceList || []).some((r) => r.id === id);
        },
        buildDbTablePreviewPayload(row) {
          if (!row) return {};
          const tc = row.comment != null && String(row.comment).trim() !== '' ? String(row.comment) : '—';
          return {
            id: row.id,
            name: `${row.databaseName} / ${row.tableName}`,
            source: row.source || '',
            owner: row.owner,
            updatedAt: row.updatedAt,
            tableComment: tc,
            rowCountLabel: this.formatWorkbenchDbTableRowCount(row.rowCount),
            tables: [{ name: row.tableName, ddl: row.ddl }],
          };
        },
        previewDbTableResource(row) {
          if (!row) return;
          this.previewResource('database', this.buildDbTablePreviewPayload(row));
        },
        onWorkbenchDbTableContextMenu(key, tbl) {
          if (key === 'chat') this.addResourceToChat('database', tbl);
          else if (key === 'delete') this.confirmRemoveDbTableResource(tbl);
        },
        onWorkbenchDbCatalogMoreMenu(key, grp) {
          if (key === 'remove-catalog') this.removeWorkbenchDatabaseCatalog(grp);
        },
        onWorkbenchDbCatalogContextMenu(key, grp) {
          if (key === 'chat') {
            this.addResourceToChat('database', {
              databaseId: grp && grp.databaseId,
              databaseName: grp && grp.databaseName,
            });
            return;
          }
          if (key === 'remove-catalog') this.removeWorkbenchDatabaseCatalog(grp);
        },
        removeWorkbenchDatabaseCatalog(grp) {
          if (!grp || grp.databaseId == null) return;
          const id = String(grp.databaseId);
          const name = String(grp.databaseName || '').trim() || '该数据源';
          Modal.confirm({
            centered: true,
            title: '移除此数据源？',
            content: `将移除工作台内「${name}」下的全部库表引用（演示），不影响真实数据库。`,
            okText: '移除',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              this.dbResourceList = (this.dbResourceList || []).filter((r) => String(r.databaseId) !== id);
              message.success('已移除数据源及其表引用');
            },
          });
        },
        onWorkbenchGraphContextMenu(key, graph) {
          if (key === 'delete') this.removeResource('graph', graph);
        },
        onWorkbenchGraphRowContextMenu(key, graph) {
          if (key === 'chat') this.addResourceToChat('graph', graph);
          else if (key === 'delete') this.removeResource('graph', graph);
        },
        onResourcePreviewContextMenu(key, row) {
          if (key !== 'delete' || !row) return;
          if (row.type === 'database') {
            this.confirmRemoveDbTableResource(row);
            return;
          }
          if (row.type === 'graph') {
            this.removeResource('graph', row);
          }
        },
        onWbDbAddTableRowSelectionChange(keys) {
          this.wbDbAddSelectedTableNames = Array.isArray(keys) ? keys : [];
        },
        wbDbAddTableGetCheckboxProps(record) {
          return record && record.disabled ? { disabled: true } : { disabled: false };
        },
        isWorkbenchDbTableGroupExpanded(databaseId) {
          const key = String(databaseId);
          const v = this.workbenchDbTableGroupExpanded[key];
          if (v === undefined) return true;
          return !!v;
        },
        toggleWorkbenchDbTableGroup(databaseId) {
          const key = String(databaseId);
          const open = this.isWorkbenchDbTableGroupExpanded(databaseId);
          this.workbenchDbTableGroupExpanded = { ...this.workbenchDbTableGroupExpanded, [key]: !open };
        },
        openWorkbenchDbAddModal() {
          this.wbDbAddCatalogId = undefined;
          this.wbDbAddSelectedTableNames = [];
          this.wbDbAddTableSearchQuery = '';
          this.wbDbAddModalOpen = true;
        },
        closeWorkbenchDbAddModal() {
          this.wbDbAddModalOpen = false;
          this.wbDbAddCatalogId = undefined;
          this.wbDbAddSelectedTableNames = [];
          this.wbDbAddTableSearchQuery = '';
        },
        onWorkbenchDbAddCatalogChange() {
          this.wbDbAddSelectedTableNames = [];
          this.wbDbAddTableSearchQuery = '';
        },
        openWorkbenchGraphAddModal() {
          this.wbGraphAddSelectedIds = [];
          this.wbGraphAddModalOpen = true;
        },
        closeWorkbenchGraphAddModal() {
          this.wbGraphAddModalOpen = false;
          this.wbGraphAddSelectedIds = [];
        },
        openWorkbenchGraphDetailModal(item) {
          if (!item) return;
          this.wbGraphDetailRecord = { ...item };
          this.wbGraphDetailActiveTab = 'basic';
          this.wbGraphDetailModalOpen = true;
        },
        closeWorkbenchGraphDetailModal() {
          this.wbGraphDetailModalOpen = false;
          this.wbGraphDetailRecord = null;
          this.wbGraphDetailActiveTab = 'basic';
        },
        toggleWorkbenchGraphCard(item) {
          if (!item || item.disabled) return;
          const id = String(item.id);
          const set = new Set(this.wbGraphAddSelectedIds || []);
          if (set.has(id)) set.delete(id);
          else set.add(id);
          this.wbGraphAddSelectedIds = Array.from(set);
        },
        onWbGraphAddCheckboxChange(item, e) {
          if (!item || item.disabled) return;
          const id = String(item.id);
          const checked = !!(e && e.target && e.target.checked);
          const set = new Set(this.wbGraphAddSelectedIds || []);
          if (checked) set.add(id);
          else set.delete(id);
          this.wbGraphAddSelectedIds = Array.from(set);
        },
        submitWorkbenchGraphAdd() {
          const selected = new Set((this.wbGraphAddSelectedIds || []).map((x) => String(x)));
          if (!selected.size) {
            message.warning('请至少勾选一个数据图谱');
            return;
          }
          const exists = new Set((this.graphResourceList || []).map((g) => String(g.id)));
          const toAdd = (this.graphCatalogs || []).filter((g) => selected.has(String(g.id)) && !exists.has(String(g.id)));
          if (!toAdd.length) {
            message.info('所选图谱均已存在于工作台，未新增');
            this.closeWorkbenchGraphAddModal();
            return;
          }
          this.graphResourceList = [...toAdd.map((g) => ({ ...g })), ...(this.graphResourceList || [])];
          message.success(`已添加 ${toAdd.length} 个数据图谱`);
          this.closeWorkbenchGraphAddModal();
          this.ensureResourceDrawerOpen('graph');
        },
        filterWbDbAddCatalogOption(input, option) {
          const q = String(input || '').trim().toLowerCase();
          if (!q) return true;
          const lab = option && option.label != null ? String(option.label).toLowerCase() : '';
          return lab.includes(q);
        },
        submitWorkbenchDbAddTables() {
          const catalog = (this.dbCatalogs || []).find((x) => x.id === this.wbDbAddCatalogId);
          if (!catalog) {
            message.warning('请先选择数据库');
            return;
          }
          const names = Array.isArray(this.wbDbAddSelectedTableNames) ? this.wbDbAddSelectedTableNames : [];
          if (!names.length) {
            message.warning('请至少勾选一张数据表');
            return;
          }
          const stamp = new Date().toISOString().slice(0, 19).replace('T', ' ');
          let added = 0;
          names.forEach((tableName) => {
            const t = (catalog.tables || []).find((x) => x.name === tableName);
            if (!t) return;
            if (this.workbenchDbTableRowExists(catalog.id, tableName)) return;
            this.dbResourceList = this.dbResourceList || [];
            this.dbResourceList.push({
              id: `${catalog.id}::${tableName}`,
              databaseId: catalog.id,
              databaseName: catalog.name,
              tableName,
              name: tableName,
              ddl: t.ddl,
              comment: t.comment != null ? String(t.comment) : '',
              rowCount: t.rowCount,
              source: catalog.source,
              owner: catalog.owner,
              updatedAt: stamp,
            });
            added += 1;
          });
          if (!added) {
            message.info('所选表均已存在于工作台，未新增');
          } else {
            message.success(`已添加 ${added} 张表`);
            this.closeWorkbenchDbAddModal();
            this.ensureResourceDrawerOpen('database');
          }
        },
        addGraphResource() {
          const now = Date.now();
          this.graphResourceList = [
            {
              id: 'graph-added-' + now,
              name: '新建图谱配置',
              source: '内置图谱中心',
              entityCount: 0,
              edgeCount: 0,
              updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' '),
            },
            ...(this.graphResourceList || []),
          ];
          message.success('已添加数据图谱配置');
          this.ensureResourceDrawerOpen('graph');
        },
        getSkillAnalysisRulePlaceholder() {
          if (typeof window !== 'undefined' && typeof window.__demoGetSkillAnalysisRulePlaceholder === 'function') {
            return window.__demoGetSkillAnalysisRulePlaceholder();
          }
          return (typeof window !== 'undefined' && window.__DEMO_SKILL_ANALYSIS_RULE_PLACEHOLDER) || '';
        },
        analysisCitationDisplayIndex(key) {
          const raw = String(key || '').trim();
          const matched = raw.match(/(\d+)$/);
          return matched ? matched[1] : raw;
        },
        buildAnalysisCitationEntries(markdown, citationMap) {
          const text = String(markdown || '');
          const map = citationMap || {};
          const seen = new Set();
          const keys = [];
          text.replace(/\[(E\d+)\]/g, (_, key) => {
            if (!seen.has(key)) {
              seen.add(key);
              keys.push(key);
            }
            return _;
          });
          return keys.map((key) => {
            const data = map[key] || {};
            return {
              key,
              indexLabel: this.analysisCitationDisplayIndex(key),
              sourceLabel: String(data.sourceLabel || '引用来源').trim() || '引用来源',
              excerpt: String(data.sourceExcerpt || data.sourceFullText || '').trim() || '暂无可展示的引用内容',
            };
          });
        },
        normalizeResultInlineCitationText(text) {
          return String(text || '')
            .replace(/【(\d+)】/g, '（$1）')
            .replace(/\[(\d+)\]/g, '（$1）')
            .replace(/\[(E\d+)\]/g, (_, key) => `（${this.analysisCitationDisplayIndex(key)}）`);
        },
        buildMessageResultCitationEntries(msg) {
          const list = Array.isArray(msg && msg.citations) ? msg.citations : [];
          const seen = new Set();
          return list.reduce((acc, item, index) => {
            const sourceId = String(item && item.sourceId || '').trim();
            const excerptIndex = Number(item && item.excerptIndex);
            const dedupeKey = `${sourceId}::${Number.isFinite(excerptIndex) ? excerptIndex : 0}`;
            if (!sourceId || seen.has(dedupeKey)) return acc;
            seen.add(dedupeKey);
            const sourceLabel = this.getCitationSourceLabel(sourceId);
            const excerpt = this.buildCitationPopoverExcerpt(this.getExcerptTextForCitation(sourceId, Number.isFinite(excerptIndex) ? excerptIndex : 0));
            acc.push({
              indexLabel: index + 1,
              sourceLabel: sourceLabel || '引用来源',
              excerpt: excerpt || '暂无可展示的引用内容',
            });
            return acc;
          }, []);
        },
        buildPlainTextCitationSection(entries) {
          if (!entries || !entries.length) return '';
          const lines = ['### 引用信息', ''];
          entries.forEach((item) => {
            lines.push(`**（${item.indexLabel}）${item.sourceLabel}**`);
            String(item.excerpt || '').split('\n').forEach((line) => {
              lines.push(`> ${line}`);
            });
            lines.push('');
          });
          return lines.join('\n').trim();
        },
        formatSavedResultBodyFromMessage(msg) {
          const text = this.normalizeResultInlineCitationText(this.getMessageResultPlainText(msg));
          const appendix = this.buildPlainTextCitationSection(this.buildMessageResultCitationEntries(msg));
          return [text, appendix].filter(Boolean).join('\n\n');
        },
        freeAuditPolishUndoDisabled(key) {
          return (
            !!this.freeAuditAiPolishKey || !Object.prototype.hasOwnProperty.call(this.freeAuditPolishUndo, key)
          );
        },
        wbFreeAuditPolishUndoDisabled(key) {
          return this.wbProjectSkillConfigTabLocked || this.freeAuditPolishUndoDisabled(key);
        },
        beginFreeAuditAiPolish(key, getText, setText, onDone) {
          if (this.freeAuditAiPolishKey) return;
          this.freeAuditPolishUndo[key] = String(getText() == null ? '' : getText());
          this.freeAuditAiPolishKey = key;
          window.setTimeout(() => {
            const sample =
              typeof window.__demoPolishSampleForKey === 'function' ? window.__demoPolishSampleForKey(key) : '';
            setText(sample);
            this.freeAuditAiPolishKey = '';
            if (typeof onDone === 'function') onDone();
          }, 1300);
        },
        undoFreeAuditPolish(key, setText, onDone) {
          if (this.freeAuditAiPolishKey) return;
          if (key.startsWith('wb-') && this.wbProjectSkillConfigTabLocked) return;
          if (!Object.prototype.hasOwnProperty.call(this.freeAuditPolishUndo, key)) return;
          const prev = this.freeAuditPolishUndo[key];
          delete this.freeAuditPolishUndo[key];
          setText(prev);
          if (typeof onDone === 'function') onDone();
        },
        demoAiPolishSummaryTaskName() {
          this.beginFreeAuditAiPolish(
            'summary:name',
            () => this.summaryTaskResultForm.name,
            (t) => {
              this.summaryTaskResultForm.name = t;
            }
          );
        },
        undoSummaryTaskName() {
          this.undoFreeAuditPolish('summary:name', (t) => {
            this.summaryTaskResultForm.name = t;
          });
        },
        demoAiPolishSummaryTaskAnalysisRule() {
          this.beginFreeAuditAiPolish(
            'summary:analysisRule',
            () => this.summaryTaskResultForm.analysisRule,
            (t) => {
              this.summaryTaskResultForm.analysisRule = t;
            }
          );
        },
        undoSummaryTaskAnalysisRule() {
          this.undoFreeAuditPolish('summary:analysisRule', (t) => {
            this.summaryTaskResultForm.analysisRule = t;
          });
        },
        demoAiPolishSummaryErField(er, field) {
          const key = 'summary-er:' + er.id + ':' + field;
          this.beginFreeAuditAiPolish(
            key,
            () => er[field],
            (t) => {
              er[field] = t;
            }
          );
        },
        undoSummaryErField(er, field) {
          const key = 'summary-er:' + er.id + ':' + field;
          this.undoFreeAuditPolish(key, (t) => {
            er[field] = t;
          });
        },
        demoAiPolishWbSkillFileField(file, field) {
          if (this.wbProjectSkillConfigTabLocked || !file) return;
          const short = field === 'filename' ? 'fn' : 'ct';
          const key = 'wb-sf:' + file.id + ':' + short;
          this.beginFreeAuditAiPolish(
            key,
            () => (field === 'filename' ? file.filename : file.content),
            (t) => {
              if (field === 'filename') file.filename = t;
              else file.content = t;
            },
            () => this.scheduleWbProjectSkillDetailSync()
          );
        },
        undoWbSkillFileField(file, field) {
          if (this.wbProjectSkillConfigTabLocked || !file) return;
          const short = field === 'filename' ? 'fn' : 'ct';
          const key = 'wb-sf:' + file.id + ':' + short;
          this.undoFreeAuditPolish(
            key,
            (t) => {
              if (field === 'filename') file.filename = t;
              else file.content = t;
            },
            () => this.scheduleWbProjectSkillDetailSync()
          );
        },
        demoAiPolishWbAnalysisRule() {
          if (this.wbProjectSkillConfigTabLocked) return;
          const s = this.wbDetailSelectedSkill;
          if (!s) return;
          this.beginFreeAuditAiPolish(
            'wb-analysisRule',
            () => s.analysisRule,
            (t) => {
              s.analysisRule = t;
            },
            () => this.scheduleWbProjectSkillDetailSync()
          );
        },
        undoWbAnalysisRule() {
          if (this.wbProjectSkillConfigTabLocked) return;
          const s = this.wbDetailSelectedSkill;
          if (!s) return;
          this.undoFreeAuditPolish(
            'wb-analysisRule',
            (t) => {
              s.analysisRule = t;
            },
            () => this.scheduleWbProjectSkillDetailSync()
          );
        },
        initFromUrl() {
          const rawRoute = (window.location.hash || '').replace(/^#/, '');
          /* hash 已切到 project/ 等其它路由时仍会触发本组件的 hashchange，勿按「无 projectId」误跳工作台 */
          if (!rawRoute.startsWith('freeaudit')) return;
          const q = getFreeAuditQuery();
          if (!q.projectId) {
            message.warning('请先选择或创建工作台后再打开审计助手');
            window.location.hash = 'project';
            return;
          }
          let auxiliaryEnterStaged = false;
          try {
            if (sessionStorage.getItem('demoAuxiliaryEnterAnim') === '1') {
              sessionStorage.removeItem('demoAuxiliaryEnterAnim');
              auxiliaryEnterStaged = true;
            }
          } catch (_) { /* ignore */ }
          if (auxiliaryEnterStaged) {
            this.sourcesCollapsed = true;
            this.studioCollapsed = true;
          }
          this.workbenchProjectId = q.projectId;
          this.workbenchMaterialId = q.materialId || null;
          this.workbenchAnalysisResultId = q.analysisResultId || null;
          this.workbenchReportId = q.reportId || null;
          const pid = this.workbenchProjectId;
          const pRows = demoProjectMaterialsById[pid] || [];
          const aRows = demoProjectAnalysisResultsById[pid] || [];
          const mappedRaw = pRows.map((r) => mapProjectRowToWorkbenchMaterial(r, pid));
          const mappedAnalysis = aRows.map((r) => mapAnalysisResultRowToWorkbench(r, pid));
          this.materials = [...mappedRaw, ...mappedAnalysis];
          this.$nextTick(() => {
            this.ensureWorkbenchAnalysisResultTaskFolders();
            const keys = this.workbenchAnalysisResultAntTreeInitialExpandKeys || [];
            if (keys.length) this.workbenchAnalysisResultTreeExpandedKeys = keys.slice();
          });
          this.workbenchMaterialFilterPopoverOpen = false;
          this.wbSkillSidebarSearchKeyword = '';
          this.workbenchAnalysisSearchQuery = '';
          if (this.workbenchMaterialId && this.materials.some((x) => x.id === this.workbenchMaterialId)) this.selectedMaterialId = this.workbenchMaterialId;
          else if (this.workbenchAnalysisResultId && this.materials.some((x) => x.id === this.workbenchAnalysisResultId)) this.selectedMaterialId = this.workbenchAnalysisResultId;
          else if (this.workbenchReportId) this.selectedMaterialId = this.materials.find((x) => x.type === 'analysis')?.id || this.materials[0]?.id;
          else if (this.materials.length) this.selectedMaterialId = this.materials[0].id;
          else this.selectedMaterialId = null;
          const sel = this.selectedMaterialId ? this.materials.find((m) => m.id === this.selectedMaterialId) : null;
          this.sourcesRightView = 'list';
          if (sel) sel.checked = true;
          if (q.openTemplate) {
            this.$nextTick(() => this.openTemplateLibrary());
            const raw2 = (window.location.hash || '').replace(/^#/, '');
            if (raw2.startsWith('freeaudit?')) {
              const [base2, query2 = ''] = raw2.split('?');
              const params2 = new URLSearchParams(query2);
              params2.delete('openTemplate');
              const next2 = params2.toString() ? `${base2}?${params2.toString()}` : base2;
              window.history.replaceState(null, '', '#' + next2);
            }
          }
          if (auxiliaryEnterStaged) {
            this.$nextTick(() => {
              window.setTimeout(() => {
                this.sourcesCollapsed = false;
                this.studioCollapsed = false;
              }, 70);
            });
          }
          this.$nextTick(() => this.ensureDefaultDemoConversation());
        },
        refreshWorkbenchDemoResources(listScope) {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先进入工作台');
            return;
          }
          const pRows = demoProjectMaterialsById[pid] || [];
          const aRows = demoProjectAnalysisResultsById[pid] || [];
          const mappedRaw = pRows.map((r) => mapProjectRowToWorkbenchMaterial(r, pid));
          const mappedAnalysis = aRows.map((r) => mapAnalysisResultRowToWorkbench(r, pid));
          this.materials = [...mappedRaw, ...mappedAnalysis];
          this.ensureWorkbenchAnalysisResultTaskFolders();
          this.syncTaskOutputsIntoLinkedResultFolders();
          this.$nextTick(() => {
            const keys = this.workbenchAnalysisResultAntTreeInitialExpandKeys || [];
            if (keys.length) this.workbenchAnalysisResultTreeExpandedKeys = keys.slice();
          });
          const prevSel = this.selectedMaterialId;
          if (prevSel && this.materials.some((x) => x.id === prevSel)) {
            this.selectedMaterialId = prevSel;
          } else if (this.workbenchMaterialId && this.materials.some((x) => x.id === this.workbenchMaterialId)) {
            this.selectedMaterialId = this.workbenchMaterialId;
          } else if (this.workbenchAnalysisResultId && this.materials.some((x) => x.id === this.workbenchAnalysisResultId)) {
            this.selectedMaterialId = this.workbenchAnalysisResultId;
          } else if (this.workbenchReportId) {
            this.selectedMaterialId = this.materials.find((x) => x.type === 'analysis')?.id || this.materials[0]?.id || null;
          } else if (this.materials.length) {
            this.selectedMaterialId = this.materials[0].id;
          } else {
            this.selectedMaterialId = null;
          }
          const sel = this.selectedMaterialId ? this.materials.find((m) => m.id === this.selectedMaterialId) : null;
          if (sel) sel.checked = true;
          this.workbenchMaterialStatusPopoverOpenQueued = false;
          this.workbenchMaterialStatusPopoverOpenParsing = false;
          this.workbenchMaterialStatusPopoverOpenFailed = false;
          this.workbenchAnalysisStatusPopoverOpenQueued = false;
          this.workbenchAnalysisStatusPopoverOpenParsing = false;
          this.workbenchAnalysisStatusPopoverOpenFailed = false;
          this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          const scope = listScope === 'skill' ? 'skill' : listScope === 'result' ? 'result' : listScope === 'task' ? 'task' : 'material';
          const hint =
            scope === 'result'
              ? '结果列表已与演示数据同步；助手对话未刷新。'
              : scope === 'skill'
                ? '技能列表已与演示数据同步；助手对话未刷新。'
                : scope === 'task'
                  ? '任务列表已与演示数据同步；助手对话未刷新。'
                  : '资料列表已与演示数据同步；助手对话未刷新。';
          message.success(hint);
        },
        openProjectCenterUpload() {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先进入工作台并打开审计助手后再上传资料');
            return;
          }
          const bridge = window.__demoQuoteSkillBridge;
          if (bridge && typeof bridge.openUploadForWorkbenchProject === 'function') {
            bridge.openUploadForWorkbenchProject(pid, null);
            return;
          }
          message.warning('上传入口暂不可用，请稍后重试');
        },
        openProjectCenterUploadForFolder(folderId) {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先进入工作台并打开审计助手后再上传资料');
            return;
          }
          const fid = folderId != null ? String(folderId).trim() : '';
          if (!fid) {
            this.openProjectCenterUpload();
            return;
          }
          const bridge = window.__demoQuoteSkillBridge;
          if (bridge && typeof bridge.openUploadForWorkbenchProject === 'function') {
            bridge.openUploadForWorkbenchProject(pid, { parentFolderId: fid });
            return;
          }
          message.warning('上传入口暂不可用，请稍后重试');
        },
        onWorkbenchMaterialAddMenu(key, folderId) {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先进入工作台并打开审计助手后再上传资料');
            return;
          }
          const targetFolderId = folderId != null ? String(folderId).trim() : '';
          if (key === 'upload-file') {
            if (targetFolderId) this.openProjectCenterUploadForFolder(targetFolderId);
            else this.openProjectCenterUpload();
            return;
          }
          if (key === 'new-folder') {
            this.openWorkbenchMaterialCreateFolderModal(targetFolderId);
          }
        },
        openWorkbenchMaterialCreateFolderModal(parentFolderId) {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialFoldersById === 'undefined') {
            message.warning('请先进入工作台并打开审计助手后再新建文件夹');
            return;
          }
          this.wbCreateFolderForm = {
            name: '',
            parentFolderId: parentFolderId != null ? String(parentFolderId).trim() : '',
          };
          this.wbCreateFolderModalOpen = true;
        },
        closeWorkbenchMaterialCreateFolderModal() {
          this.wbCreateFolderModalOpen = false;
          this.wbCreateFolderForm = { name: '', parentFolderId: '' };
        },
        wbTaskConfigResolveResourceKind(item) {
          if (!item || typeof item !== 'object') return 'unknown';
          const t = String(item.type || '').trim().toLowerCase();
          if (t === 'file' || t === 'database' || t === 'graph' || t === 'knowledge' || t === 'intent') return t;
          const k = String(item.key || '');
          if (k.startsWith('file:')) return 'file';
          if (k.startsWith('database:')) return 'database';
          if (k.startsWith('graph:')) return 'graph';
          if (k.startsWith('knowledge:')) return 'knowledge';
          if (k === 'dialog-intent' || k === 'intent') return 'intent';
          return 'unknown';
        },
        wbTaskConfigResourceTypeLabelZh(kind) {
          const map = {
            file: '文件',
            database: '数据库表',
            graph: '知识图谱',
            knowledge: '知识库',
            intent: '意图',
            unknown: '资料',
          };
          return map[kind] || map.unknown;
        },
        wbTaskConfigResourceDisplayTitle(item) {
          if (!item || typeof item !== 'object') return '—';
          const v = item.name || item.title || item.fileName || item.label;
          return String(v != null ? v : '').trim() || '未命名';
        },
        /** 任务详情 · 引用资源：仅标题（类型靠左侧图标），不含「（演示）」 */
        wbTaskConfigResourceRowSingleLine(item) {
          if (!item || typeof item !== 'object') return '—';
          const title = this.wbTaskConfigResourceDisplayTitle(item);
          const cleaned = this.wbTaskDetailStripDemoLabel(title);
          return cleaned || '未命名';
        },
        /** 引用资源行无障碍说明（类型不写入可见文案） */
        wbTaskConfigResourceRowAriaLabel(item) {
          if (!item || typeof item !== 'object') return '引用资源';
          const k = this.wbTaskConfigResolveResourceKind(item);
          const t = this.wbTaskConfigResourceRowSingleLine(item);
          const typeZh = this.wbTaskConfigResourceTypeLabelZh(k);
          return `${t}，${typeZh}`;
        },
        wbTaskConfigResourceIconMeta(item) {
          if (!item || typeof item !== 'object') return { iconClass: 'fa-folder', iconToneClass: '' };
          if (item.iconClass) {
            const ic = String(item.iconClass).trim();
            const normalized = ic.startsWith('fa-') ? ic : `fa-${ic}`;
            return { iconClass: normalized, iconToneClass: item.iconToneClass || '' };
          }
          const kind = this.wbTaskConfigResolveResourceKind(item);
          if (kind === 'file') {
            const fmt = String(item.format || item.mimeType || item.mime || '').toUpperCase();
            const nm = String(item.name || item.fileName || item.title || '').toLowerCase();
            if (fmt.includes('PDF') || nm.endsWith('.pdf')) {
              return { iconClass: 'fa-file-pdf', iconToneClass: 'is-pdf' };
            }
            return { iconClass: 'fa-file-lines', iconToneClass: '' };
          }
          if (kind === 'database') return { iconClass: 'fa-table', iconToneClass: 'is-data' };
          if (kind === 'graph') return { iconClass: 'fa-circle-nodes', iconToneClass: 'is-data' };
          if (kind === 'knowledge') return { iconClass: 'fa-book', iconToneClass: '' };
          if (kind === 'intent') return { iconClass: 'fa-bullseye', iconToneClass: 'is-primary' };
          return { iconClass: 'fa-file', iconToneClass: '' };
        },
        wbTaskConfigResourceDetailRowsForItem(item) {
          const rows = [];
          if (!item || typeof item !== 'object') return rows;
          const kind = this.wbTaskConfigResolveResourceKind(item);
          rows.push({ label: '资源类型', value: this.wbTaskConfigResourceTypeLabelZh(kind) });
          if (item.key != null && String(item.key).trim()) rows.push({ label: '标识', value: String(item.key).trim() });
          if (item.id != null && String(item.id).trim()) rows.push({ label: 'ID', value: String(item.id).trim() });
          const title = this.wbTaskConfigResourceDisplayTitle(item);
          if (title && title !== '—') rows.push({ label: '名称', value: title });
          if (kind === 'database') {
            if (item.connectionLabel) rows.push({ label: '数据源', value: String(item.connectionLabel).trim() });
            if (item.logicalTableName) rows.push({ label: '逻辑表名', value: String(item.logicalTableName).trim() });
            if (item.tableSchema) rows.push({ label: 'Schema', value: String(item.tableSchema).trim() });
            if (item.physicalTable) rows.push({ label: '物理表', value: String(item.physicalTable).trim() });
            if (item.rowEstimate != null && String(item.rowEstimate).trim() !== '') {
              const n = Number(item.rowEstimate);
              rows.push({
                label: '行数（估算）',
                value: Number.isFinite(n) ? n.toLocaleString('zh-CN') : String(item.rowEstimate).trim(),
              });
            }
          }
          if (kind === 'unknown') rows.push({ label: '说明', value: '演示数据条目；未标注类型时可从「创建任务」侧资源选择器获得完整类型信息。' });
          return rows;
        },
        materialBasicMetaRowsFromProjectSourceRow(r) {
          if (!r) return [];
          const statusMap = { queued: '排队中', parsing: '解析中', done: '完成', failed: '失败' };
          const st = statusMap[r.status] || '排队中';
          const size = r.size == null || r.size === '' ? '—' : `${Number(r.size).toFixed(1)} MB`;
          return [
            { label: '名称', value: String(r.name || '').trim() || '—' },
            { label: '大小', value: size },
            { label: '格式', value: String(r.format || '').trim() || '—' },
            { label: '状态', value: st },
            { label: '上传人', value: String(r.uploader || r.uploadedBy || '').trim() || '—' },
            { label: '上传时间', value: String(r.uploadedAt || '').trim() || '—' },
          ];
        },
        analysisResultBasicMetaRowsFromRecord(r) {
          if (!r) return [];
          const statusMap = { queued: '排队中', parsing: '执行中', done: '成功', failed: '失败' };
          const st = statusMap[r.status] || statusMap.done;
          return [
            { label: '名称', value: String(r.name || '').trim() || '—' },
            { label: '来源技能', value: String(r.sourceSkillName || '').trim() || '—' },
            { label: '状态', value: st },
            { label: '生成时间', value: String(r.createdAt || '').trim() || '—' },
          ];
        },
        wbResolveTaskResourceMaterialVm(item) {
          if (!item || typeof item !== 'object') return null;
          const key = String(item.key != null ? item.key : '').trim();
          const mats = this.materials || [];
          const tryMatch = (k) => {
            if (!k) return null;
            for (let i = 0; i < mats.length; i++) {
              const m = mats[i];
              if (!m) continue;
              const t = m.type;
              if (t !== 'raw' && t !== undefined) continue;
              const id = String(m.id || '').trim();
              const psId = m.projectSource && String(m.projectSource.id || '').trim();
              if (id === k || psId === k) return m;
            }
            return null;
          };
          let hit = tryMatch(key);
          if (hit) return hit;
          if (key.startsWith('file:')) hit = tryMatch(key.replace(/^file:/, '').trim());
          return hit;
        },
        /** 无 ddl 时由字段元数据拼出演示用建表语句（与资源侧「字段信息」页展示形态一致） */
        wbTaskResourceBuildDdlFromFieldDefinitions(item) {
          if (!item || typeof item !== 'object') return '';
          const defs = Array.isArray(item.fieldDefinitions) ? item.fieldDefinitions.filter(Boolean) : [];
          if (!defs.length) return '';
          const schema = String(item.tableSchema || '').trim();
          const table = String(item.physicalTable || item.tableName || 'DEMO_TABLE').trim();
          const qual = schema ? `"${schema}"."${table}"` : `"${table}"`;
          const cols = defs.map((f) => {
            const cn = String(f.columnName || f.name || 'COL').trim();
            const dt = String(f.dataType || f.type || 'VARCHAR(64)').trim();
            const nullableZh = String(f.nullable != null ? f.nullable : '是').trim();
            const nn = nullableZh === '否' ? ' NOT NULL' : '';
            return `  "${cn}" ${dt}${nn}`;
          }).join(',\n');
          return `CREATE TABLE ${qual} (\n${cols}\n);`;
        },
        /** 与 `buildDbTablePreviewPayload` / 侧栏库表预览同源：{ name, ddl }[] */
        wbTaskResourceResolveDatabasePreviewTables(item) {
          if (!item || typeof item !== 'object') return [];
          const tablesIn = Array.isArray(item.tables) ? item.tables : [];
          const normalized = tablesIn.map((t) => ({
            name: String(t.name || t.tableName || '—').trim() || '—',
            ddl: String(t.ddl || '').trim(),
          })).filter((t) => t.ddl);
          if (normalized.length) return normalized;
          const ddlDirect = String(item.ddl || '').trim();
          if (ddlDirect) {
            const nm = String(item.physicalTable || item.tableName || item.logicalTableName || item.name || '表').trim();
            const clean = nm.replace(/（演示）/g, '').replace(/\(演示\)/g, '').trim() || '表';
            return [{ name: clean, ddl: ddlDirect }];
          }
          const key = String(item.key != null ? item.key : '').trim();
          const idFromKey = key.startsWith('database:') ? key.slice('database:'.length).trim() : '';
          const list = this.dbResourceList || [];
          const row = list.find((r) => {
            const id = String(r.id || '').trim();
            return id && (id === key || id === idFromKey);
          });
          if (row && String(row.ddl || '').trim()) {
            return [{ name: String(row.tableName || row.name || '—').trim(), ddl: String(row.ddl).trim() }];
          }
          const built = this.wbTaskResourceBuildDdlFromFieldDefinitions(item);
          if (built) {
            const nm = String(item.physicalTable || item.logicalTableName || '表')
              .replace(/（演示）/g, '')
              .replace(/\(演示\)/g, '')
              .trim() || '表';
            return [{ name: nm, ddl: built }];
          }
          return [];
        },
        openWbTaskResourcePreview(item) {
          const resolved = this.wbResolveTaskResourceMaterialVm(item);
          this.wbTaskResourcePreviewItem = item;
          this.wbTaskResourcePreviewResolvedMaterial = resolved;
          this.wbTaskResourcePreviewActiveTab = 'basic';
          this.wbTaskResourcePreviewOcrLines = false;
          this.wbTaskResourcePreviewOpen = true;
        },
        /** 任务详情列表：去掉名称中的「（演示）」等后缀，避免与图标类型重复强调 */
        wbTaskDetailStripDemoLabel(s) {
          let t = String(s == null ? '' : s).trim();
          if (!t) return t;
          t = t
            .replace(/（演示）/g, '')
            .replace(/\(演示\)/g, '')
            .replace(/\s{2,}/g, ' ')
            .trim();
          return t;
        },
        closeWbTaskResourcePreview() {
          this.wbTaskResourcePreviewOpen = false;
          this.wbTaskResourcePreviewItem = null;
          this.wbTaskResourcePreviewResolvedMaterial = null;
          this.wbTaskResourcePreviewActiveTab = 'basic';
          this.wbTaskResourcePreviewOcrLines = false;
        },
        wbOpenTaskDetailSkill() {
          const m = this.selectedMaterial;
          if (!m || !m.taskConfig) return;
          const tc = m.taskConfig;
          if (tc.taskType === 'generate-skill' || String(tc.skillId || '').trim() === 'generate-skill') {
            message.info('生成技能类任务请在左侧技能栏查看产物（演示）');
            return;
          }
          const pid = this.workbenchProjectId;
          const sid = String(tc.skillId || '').trim();
          if (!pid || !sid) return;
          this.openWbProjectSkillDetail({ id: sid }, { readOnly: true });
        },
        downloadWbTaskResourcePreview() {
          const vm = this.wbTaskResourcePreviewResolvedMaterial;
          if (!vm || !vm.projectSource) return;
          const pages = this.wbTaskResourcePreviewDocumentPages || [];
          const body = pages.join('\n\n---\n\n');
          const base = String(vm.projectSource.name || '资料').replace(/\.[^.]+$/, '');
          const safe = base.replace(/[/\\?%*:|"<>]/g, '_');
          const blob = new Blob([body], { type: 'text/plain;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${safe}-预览.txt`;
          a.click();
          URL.revokeObjectURL(url);
          message.success('已开始下载');
        },
        confirmWorkbenchMaterialCreateFolder() {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialFoldersById === 'undefined') {
            this.closeWorkbenchMaterialCreateFolderModal();
            return;
          }
          const folds = demoProjectMaterialFoldersById[pid] || [];
          const name = String((this.wbCreateFolderForm && this.wbCreateFolderForm.name) || '').trim();
          if (!name) {
            message.warning('名称不能为空');
            return;
          }
          const parentFolderId = this.wbCreateFolderForm && this.wbCreateFolderForm.parentFolderId != null
            ? String(this.wbCreateFolderForm.parentFolderId).trim()
            : '';
          const siblings = folds.filter((f) => String(f.parentId || '') === parentFolderId);
          const nextSort = siblings.reduce((acc, f) => Math.max(acc, Number(f.sort) || 0), -1) + 1;
          const newFolderId = this.wbMatNewFolderId();
          folds.push({
            id: newFolderId,
            name,
            parentId: parentFolderId,
            sort: nextSort,
          });
          if (parentFolderId) {
            const expanded = new Set(this.workbenchFileTreeExpandedKeys || []);
            expanded.add(wbMatAntTreeKey('folder', parentFolderId));
            this.workbenchFileTreeExpandedKeys = Array.from(expanded);
          }
          this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          this.closeWorkbenchMaterialCreateFolderModal();
          message.success('已新建文件夹');
        },
        wbMaterialVmById(materialId) {
          const id = materialId != null ? String(materialId) : '';
          if (!id) return null;
          return (this.materials || []).find((m) => m && String(m.id) === id) || null;
        },
        wbMaterialFileTreeSlotNodeData(node) {
          if (!node) return null;
          const direct = node.dataRef || node;
          if (direct && direct.materialId) return direct;
          const rawKey = direct && (direct.key != null ? direct.key : direct.eventKey != null ? direct.eventKey : '');
          const key = String(rawKey || '');
          if (!key.startsWith('raw:')) return direct;
          const materialId = key.slice('raw:'.length);
          const row = (this.workbenchDoneProjectRowsForFileTree || []).find((r) => String(r.id) === materialId) || null;
          return {
            materialId,
            rawProjectRow: row,
          };
        },
        /** 资料树文件行：优先 materials 池，否则用 rawProjectRow 合成与列表一致的图标字段（仅「全部」树用，不影响排队/解析/失败列表） */
        wbWorkbenchMaterialVmForTreeFile(d) {
          if (!d) return null;
          const vm = this.wbMaterialVmById(d.materialId);
          if (vm) return vm;
          const r = d.rawProjectRow;
          if (!r) return { type: 'raw', id: d.materialId, projectSource: {} };
          const fmt = String(r.format || '').toUpperCase();
          const rawSubtype = fmt === 'XLSX' || fmt === 'XLS' || fmt === 'CSV' ? 'table' : 'document';
          return {
            type: 'raw',
            id: String(r.id),
            title: r.name,
            rawSubtype,
            format: r.format,
            projectSource: r,
          };
        },
        wbMatNewFolderId() {
          return typeof newSkillId === 'function' ? newSkillId('mf') : `mf-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
        },
        collectWorkbenchMaterialFolderSubtreeIds(rootFolderId) {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialFoldersById === 'undefined') return new Set();
          const folds = demoProjectMaterialFoldersById[pid] || [];
          const root = String(rootFolderId || '');
          if (!root) return new Set();
          const out = new Set([root]);
          let added = true;
          while (added) {
            added = false;
            folds.forEach((f) => {
              const id = String(f.id || '');
              const p = f.parentId != null && f.parentId !== '' ? String(f.parentId) : '';
              if (!id || out.has(id)) return;
              if (p && out.has(p)) {
                out.add(id);
                added = true;
              }
            });
          }
          return out;
        },
        /** 资料文件夹下（含子夹）已解析完成的资料行 id */
        collectDoneRawProjectRowsInMaterialFolder(folderId) {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialsById === 'undefined' || !folderId) return [];
          const folderIds = this.collectWorkbenchMaterialFolderSubtreeIds(folderId);
          const mats = demoProjectMaterialsById[pid] || [];
          return mats.filter((r) => {
            if (String(r.status || '') !== 'done') return false;
            const p = r.parentId != null && r.parentId !== '' ? String(r.parentId) : '';
            return folderIds.has(p);
          });
        },
        workbenchMaterialFolderChatRefMenuLabel() {
          return '添加到对话';
        },
        toggleWorkbenchMaterialFolderInChat(d) {
          const rows = this.collectDoneRawProjectRowsInMaterialFolder(d && d.folderId);
          if (!rows.length) {
            message.info('该文件夹下暂无已解析完成的文件');
            return;
          }
          const pid = this.workbenchProjectId;
          let folderName = String((d && d.title) || '').trim();
          if (!folderName && pid && typeof demoProjectMaterialFoldersById !== 'undefined') {
            const folds = demoProjectMaterialFoldersById[pid] || [];
            const row = folds.find((f) => String(f.id) === String(d && d.folderId));
            folderName = String((row && row.name) || '').trim();
          }
          if (!folderName) folderName = '文件夹';
          this.appendChatInputToken('@' + folderName);
          this.toastMessage = '已添加文件夹引用到对话';
          setTimeout(() => { this.toastMessage = ''; }, 1800);
        },
        collectDoneAnalysisMaterialsInResultFolder(d) {
          const fid = d && d.userFolderId ? String(d.userFolderId) : '';
          const pid = this.workbenchProjectId;
          if (!fid || !pid || typeof demoProjectAnalysisResultFoldersById === 'undefined') return [];
          const folds = demoProjectAnalysisResultFoldersById[pid] || [];
          const folderMeta = folds.find((f) => String(f.id) === fid);
          const ltid = folderMeta ? String(folderMeta.linkedTaskId || '').trim() : '';
          const subtreeIds = this.collectWorkbenchAnalysisResultFolderSubtreeIds(fid, folds);
          const list = this.workbenchDoneSortedAnalysisMaterialsForResultPanel || [];
          return list.filter((m) => {
            const ps = m.projectSource || {};
            const rid = String(ps.resultFolderId || '').trim();
            if (rid && subtreeIds.has(rid)) return true;
            if (ltid && !rid && String(ps.sourceTaskId || '').trim() === ltid) return true;
            return false;
          });
        },
        workbenchAnalysisResultFolderChatRefMenuLabel() {
          return '添加到对话';
        },
        toggleWorkbenchAnalysisResultFolderInChat(d) {
          const mats = this.collectDoneAnalysisMaterialsInResultFolder(d);
          if (!mats.length) {
            message.info('该文件夹下暂无可引用的结果');
            return;
          }
          const pid = this.workbenchProjectId;
          const fid = d && d.userFolderId ? String(d.userFolderId) : '';
          let folderName = String((d && d.title) || '').trim();
          if (!folderName && fid && pid && typeof demoProjectAnalysisResultFoldersById !== 'undefined') {
            const folds = demoProjectAnalysisResultFoldersById[pid] || [];
            const row = folds.find((f) => String(f.id) === fid);
            folderName = String((row && row.name) || '').trim();
          }
          if (!folderName) folderName = '文件夹';
          this.appendChatInputToken('@' + folderName);
          this.toastMessage = '已添加文件夹引用到对话';
          setTimeout(() => { this.toastMessage = ''; }, 1800);
        },
        onWorkbenchMaterialFileTreeDrop(info) {
          const pid = this.workbenchProjectId;
          if (!pid) return;
          const res = applyWorkbenchMaterialTreeDrop(pid, info);
          if (!res.ok) {
            if (res.message) message.warning(res.message);
            return;
          }
          this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          message.success('已更新目录顺序');
        },
        onWorkbenchAnalysisResultTreeDrop(info) {
          const pid = this.workbenchProjectId;
          if (!pid) return;
          const res = applyWorkbenchAnalysisResultTreeDrop(pid, info);
          if (!res.ok) {
            if (res.message) message.warning(res.message);
            return;
          }
          this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          message.success('已更新结果树顺序');
        },
        onWorkbenchMaterialFolderRowClick(d) {
          if (!d || !d.folderId) return;
          const key = d.key != null ? String(d.key) : wbMatAntTreeKey('folder', d.folderId);
          const expanded = new Set(this.workbenchFileTreeExpandedKeys || []);
          if (expanded.has(key)) expanded.delete(key);
          else expanded.add(key);
          this.workbenchFileTreeExpandedKeys = Array.from(expanded);
        },
        onWorkbenchMaterialFolderMenu(key, d) {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialFoldersById === 'undefined' || !d || !d.folderId) return;
          const folds = demoProjectMaterialFoldersById[pid];
          if (key === 'upload-file' || key === 'new-folder') {
            this.onWorkbenchMaterialAddMenu(key, d.folderId);
            return;
          }
          if (key === 'ref') {
            this.toggleWorkbenchMaterialFolderInChat(d);
            return;
          }
          if (key === 'rename') {
            const row = folds.find((f) => String(f.id) === String(d.folderId));
            if (!row) return;
            const name = window.prompt('重命名文件夹', row.name || '');
            if (name == null) return;
            const trimmed = String(name).trim();
            if (!trimmed) {
              message.warning('名称不能为空');
              return;
            }
            const idx = folds.findIndex((f) => String(f.id) === String(d.folderId));
            if (idx >= 0) folds.splice(idx, 1, { ...folds[idx], name: trimmed });
            this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
            message.success('已重命名');
            return;
          }
          if (key === 'delete') {
            const row = folds.find((f) => String(f.id) === String(d.folderId));
            this.wbDeleteFolderTarget = { folderId: String(d.folderId), name: (row && row.name) || d.title || '文件夹' };
            this.wbDeleteFolderModalOpen = true;
          }
        },
        onWorkbenchFileTreeFolderContextMenu(key, d) {
          if (key === 'ref') {
            this.toggleWorkbenchMaterialFolderInChat(d);
            return;
          }
          if (key === 'upload-file' || key === 'new-folder') {
            this.onWorkbenchMaterialAddMenu(key, d && d.folderId);
            return;
          }
          this.onWorkbenchMaterialFolderMenu(key, d);
        },
        onWorkbenchMaterialStatusListContextMenu(key, raw) {
          if (key === 'abort') {
            this.abortWorkbenchMaterial(raw);
            return;
          }
          if (key === 'rerun') {
            this.rerunWorkbenchMaterial(raw);
            return;
          }
          if (key === 'delete') {
            this.deleteMaterial(raw);
          }
        },
        confirmDeleteWorkbenchMaterialFolder() {
          const pid = this.workbenchProjectId;
          const t = this.wbDeleteFolderTarget;
          if (!pid || !t || !t.folderId || typeof demoProjectMaterialFoldersById === 'undefined') {
            this.wbDeleteFolderModalOpen = false;
            this.wbDeleteFolderTarget = null;
            return;
          }
          const delIds = this.collectWorkbenchMaterialFolderSubtreeIds(t.folderId);
          const mats = demoProjectMaterialsById[pid] || [];
          for (let i = mats.length - 1; i >= 0; i--) {
            const p = mats[i].parentId != null && mats[i].parentId !== '' ? String(mats[i].parentId) : '';
            if (p && delIds.has(p)) mats.splice(i, 1);
          }
          const folds = demoProjectMaterialFoldersById[pid] || [];
          demoProjectMaterialFoldersById[pid] = folds.filter((f) => !delIds.has(String(f.id)));
          this.wbDeleteFolderModalOpen = false;
          this.wbDeleteFolderTarget = null;
          this.refreshWorkbenchDemoResources('material');
          message.success('已删除文件夹及下属内容（演示）');
        },
        isWorkbenchFileTreeRawSelected(d) {
          const st = this.selectedTreeNode;
          return !!(st && st.source === 'material' && d && d.materialId && String(st.id) === String(d.materialId));
        },
        onWorkbenchMaterialFileTreeRawClick(d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return;
          this.selectTreeNode({ id: m.id, raw: m }, 'material');
        },
        ensureWorkbenchAnalysisResultTaskFolders() {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectAnalysisResultFoldersById === 'undefined') return;
          if (!Array.isArray(demoProjectAnalysisResultFoldersById[pid])) demoProjectAnalysisResultFoldersById[pid] = [];
          const folds = demoProjectAnalysisResultFoldersById[pid];
          const tasks = this.workbenchCompletedTasksForResultTree || [];
          const rootFolds = folds.filter((f) => {
            const p = f.parentId != null && f.parentId !== '' ? String(f.parentId) : '';
            const pt = String(f.parentTaskId || '').trim();
            return !p && !pt;
          });
          let added = false;
          tasks.forEach((t) => {
            if (!t || !t.id) return;
            const tid = String(t.id);
            if (folds.some((f) => String(f.linkedTaskId || '') === tid)) return;
            const title = String(t.folderTitle || tid).trim() || tid;
            const maxSort = rootFolds.reduce((acc, f) => Math.max(acc, Number(f.sort) || 0), -1);
            folds.push({
              id: `arf-tr-${tid}-${Date.now().toString(36)}`,
              name: title,
              parentId: null,
              sort: maxSort + 1,
              linkedTaskId: tid,
            });
            added = true;
          });
          if (added) this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          this.syncTaskOutputsIntoLinkedResultFolders();
        },
        /** 将已完成且未指定夹子的任务产出行挂入对应 linkedTaskId 文件夹（演示） */
        syncTaskOutputsIntoLinkedResultFolders() {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectAnalysisResultsById === 'undefined' || typeof demoProjectAnalysisResultFoldersById === 'undefined') return;
          const rows = demoProjectAnalysisResultsById[pid] || [];
          const folds = demoProjectAnalysisResultFoldersById[pid] || [];
          let changed = false;
          folds.forEach((f) => {
            const tid = String(f.linkedTaskId || '').trim();
            if (!tid) return;
            const fid = String(f.id);
            for (let i = rows.length - 1; i >= 0; i--) {
              const r = rows[i];
              if (String(r.sourceTaskId || '') !== tid) continue;
              if (String(r.status || '') !== 'done') continue;
              if (String(r.resultFolderId || '').trim()) continue;
              const maxSort = Math.max(
                -1,
                ...rows.filter((x) => String(x.resultFolderId || '') === fid).map((x) => Number(x.sort) || 0),
                ...folds.filter((x) => String(x.parentId || '') === fid).map((x) => Number(x.sort) || 0),
              );
              rows.splice(i, 1, { ...r, resultFolderId: fid, sort: maxSort + 1 });
              changed = true;
            }
          });
          if (changed) this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
        },
        openWorkbenchAnalysisResultCreateFolderModal(spec) {
          let s = spec;
          if (spec == null || spec === '') s = { type: 'root' };
          else if (typeof spec === 'string') s = { type: 'underFolder', folderId: String(spec) };
          else if (typeof spec === 'object' && spec.type) s = { ...spec };
          else s = { type: 'root' };
          this.wbArResultCreateFolderSpec = s;
          this.wbArResultCreateFolderName = '';
          this.wbArResultCreateFolderModalOpen = true;
        },
        closeWorkbenchAnalysisResultCreateFolderModal() {
          this.wbArResultCreateFolderModalOpen = false;
          this.wbArResultCreateFolderName = '';
          this.wbArResultCreateFolderSpec = null;
        },
        openWorkbenchAnalysisResultCreateFolderForNode(d) {
          if (!d || !d.isFolder) return;
          if (d.userFolderId) {
            this.openWorkbenchAnalysisResultCreateFolderModal({ type: 'underFolder', folderId: String(d.userFolderId) });
          }
        },
        onWorkbenchAnalysisResultAnyFolderMenu(key, d) {
          if (key === 'ref') {
            this.toggleWorkbenchAnalysisResultFolderInChat(d);
            return;
          }
          if (key === 'download-folder-zip-keep' || key === 'download-folder-zip-flat') {
            this.downloadWorkbenchAnalysisResultFolderZip(d, key === 'download-folder-zip-keep' ? 'keep' : 'flat');
            return;
          }
          if (key === 'new-folder') {
            this.openWorkbenchAnalysisResultCreateFolderForNode(d);
            return;
          }
          if (d && d.userFolderId) {
            this.onWorkbenchAnalysisResultUserFolderMenu(key, d);
          }
        },
        downloadWorkbenchAnalysisResultFolderZip(d, mode) {
          const folderName = String((d && d.title) || '文件夹').trim() || '文件夹';
          const modeLabel = mode === 'flat' ? '剔除层级打包' : '保留层级打包';
          message.success(`已开始${modeLabel}：将「${folderName}」下目录与文件按 Markdown 格式打包为 ZIP（演示）`);
        },
        confirmWorkbenchAnalysisResultCreateFolder() {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectAnalysisResultFoldersById === 'undefined') return;
          const trimmed = String(this.wbArResultCreateFolderName || '').trim();
          if (!trimmed) {
            message.warning('名称不能为空');
            return;
          }
          if (!Array.isArray(demoProjectAnalysisResultFoldersById[pid])) demoProjectAnalysisResultFoldersById[pid] = [];
          const folds = demoProjectAnalysisResultFoldersById[pid];
          const sp = this.wbArResultCreateFolderSpec || { type: 'root' };
          const pnorm = (v) => (v === undefined || v === null || v === '' ? '' : String(v));
          const matchesSibling = (f) => {
            const p = pnorm(f.parentId);
            const pt = String((f && f.parentTaskId) || '').trim();
            if (sp.type === 'underFolder') {
              return p === String(sp.folderId || '');
            }
            return !p && !pt;
          };
          const maxSort = folds.filter(matchesSibling).reduce((acc, f) => Math.max(acc, Number(f.sort) || 0), -1);
          const row = {
            id: 'arf-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 5),
            name: trimmed,
            parentId: sp.type === 'underFolder' ? String(sp.folderId) : null,
            sort: maxSort + 1,
          };
          folds.push(row);
          this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          message.success(sp.type === 'underFolder' ? '已创建子文件夹' : '已创建文件夹');
          this.closeWorkbenchAnalysisResultCreateFolderModal();
        },
        buildGenerateSkillTaskDialogTurnsSnapshot(m) {
          const tc = (m && m.taskConfig) || {};
          const intent = String(tc.intent || '').trim() || '（未填写生成技能要求）';
          const title = String(m.title || '任务').trim() || '任务';
          const st = this.workbenchAnalysisStatusOf(m);
          const outSkill = String(tc.outputSkillName || tc.generatedSkillName || '').trim()
            || this.wbTaskDetailStripDemoLabel((m.projectSource && m.projectSource.name) || '') || '可复用技能草稿';
          const idBase = String(m.id || 'task');
          const turns = [];
          turns.push({
            id: `${idBase}-gs-u1`,
            role: 'user',
            text: `【生成技能要求】\n\n${intent}`,
          });
          if (st === 'queued') {
            turns.push({
              id: `${idBase}-gs-think`,
              role: 'thinking',
              toolCalls: [
                { type: 'text', body: `已接收「${title}」，将把对话与面板上下文一并送入技能生成管线。` },
                { type: 'text', body: `目标产物技能：${outSkill}` },
                { type: 'action', label: '等待调度：生成技能任务在队列中', status: 'running' },
              ],
            });
            turns.push({
              id: `${idBase}-gs-b1`,
              role: 'bot',
              text: '任务已进入队列；绑定工作台上下文与引用摘要后，将按生成要求产出可复用技能草稿。',
            });
            return turns;
          }
          if (st === 'parsing') {
            turns.push({
              id: `${idBase}-gs-think`,
              role: 'thinking',
              toolCalls: [
                { type: 'text', body: `正在根据生成要求提炼技能结构：${outSkill}` },
                { type: 'text', body: '已载入当前对话与引用资料摘要作为上下文。' },
                { type: 'action', label: '解析生成要求并生成技能元数据', status: 'ok' },
                { type: 'action', label: '对齐工作台资料边界与输出模板', status: 'running' },
              ],
            });
            turns.push({
              id: `${idBase}-gs-b1`,
              role: 'bot',
              text: '正在生成技能：规则段落、引用位与复核要点写入中，完成后将出现在左侧技能栏。',
            });
            return turns;
          }
          if (st === 'failed') {
            turns.push({
              id: `${idBase}-gs-think`,
              role: 'thinking',
              toolCalls: [
                { type: 'text', body: `尝试根据生成要求生成技能：${outSkill}` },
                { type: 'text', body: '已载入工作台上下文与引用摘要。' },
                { type: 'action', label: '解析生成要求并生成技能元数据', status: 'ok' },
                { type: 'action', label: '写入技能草稿与引用模板', status: 'fail' },
              ],
            });
            turns.push({
              id: `${idBase}-gs-b1`,
              role: 'bot',
              text: '生成失败：技能草稿未能落库。可在任务更多菜单中重试，或微调生成要求后再次创建任务。',
            });
            return turns;
          }
          turns.push({
            id: `${idBase}-gs-think`,
            role: 'thinking',
            toolCalls: [
              { type: 'text', body: `已根据生成要求产出技能：${outSkill}` },
              { type: 'text', body: '已合并对话上下文与引用资料摘要。' },
              { type: 'action', label: '解析生成要求并生成技能元数据', status: 'ok' },
              { type: 'action', label: '写入技能草稿、引用位与复核要点', status: 'ok' },
              { type: 'action', label: '同步到工作台技能列表', status: 'ok' },
            ],
          });
          turns.push({
            id: `${idBase}-gs-b1`,
            role: 'bot',
            text: `技能已生成。可在左侧技能栏打开「${outSkill}」查看配置，并与资料建立关联后复用。`,
          });
          return turns;
        },
        buildWorkbenchTaskDialogTurnsSnapshot(m) {
          const tcEarly = m && m.taskConfig;
          if (tcEarly && tcEarly.taskType === 'generate-skill') {
            return this.buildGenerateSkillTaskDialogTurnsSnapshot(m);
          }
          const skill = (m.taskConfig && m.taskConfig.skillName) || (m.projectSource && m.projectSource.sourceSkillName) || '技能';
          const title = String(m.title || '任务').trim() || '任务';
          const st = this.workbenchAnalysisStatusOf(m);
          const resources = (m.taskConfig && m.taskConfig.resources) || [];
          const resNames = resources.map((r) => String(r.name || r.key || '引用资料').trim()).filter(Boolean);
          const resLine = resNames.length
            ? `引用资源（${resNames.length}）：${resNames.slice(0, 3).join('、')}${resNames.length > 3 ? ' 等' : ''}`
            : '未在任务中配置引用资源';
          const idBase = String(m.id || 'task');
          const turns = [];
          turns.push({
            id: `${idBase}-u1`,
            role: 'user',
            text: `请使用「${skill}」完成本任务分析。\n\n约束：\n· 输出为可审计的 Markdown，关键结论需能在正文中点回资料段落。\n· ${resLine}`,
          });
          if (st === 'queued') {
            turns.push({
              id: `${idBase}-think`,
              role: 'thinking',
              toolCalls: [
                { type: 'text', body: `已将任务「${title}」绑定到面板上下文，等待调度。` },
                { type: 'text', body: resLine },
                { type: 'action', label: '等待调度：任务在队列中，未占用执行槽位', status: 'running' },
              ],
            });
            turns.push({
              id: `${idBase}-b1`,
              role: 'bot',
              text: '任务已进入队列；资源与规则包校验将在分配执行槽后自动开始。',
            });
            return turns;
          }
          if (st === 'parsing') {
            turns.push({
              id: `${idBase}-think`,
              role: 'thinking',
              toolCalls: [
                { type: 'text', body: `已将任务「${title}」绑定到面板上下文，准备执行技能沙箱。` },
                { type: 'text', body: resLine },
                { type: 'action', label: `调用技能「${skill}」并装载规则模板`, status: 'ok' },
                { type: 'action', label: '规则校验：词条白名单 + 口径表加载', status: 'ok' },
                { type: 'action', label: '抽取段落候选并写入中间索引', status: 'running' },
              ],
            });
            turns.push({
              id: `${idBase}-b1`,
              role: 'bot',
              text: '已开始执行：助手正在抽取与对齐字段，完成后将把 Markdown 结果挂到右侧「结果」中与任务同名的文件夹。',
            });
            return turns;
          }
          if (st === 'failed') {
            turns.push({
              id: `${idBase}-think`,
              role: 'thinking',
              toolCalls: [
                { type: 'text', body: `已将任务「${title}」绑定到面板上下文，准备执行技能沙箱。` },
                { type: 'text', body: resLine },
                { type: 'action', label: `调用技能「${skill}」并装载规则模板`, status: 'ok' },
                { type: 'action', label: '规则校验：词条白名单 + 口径表加载', status: 'ok' },
                { type: 'action', label: '抽取段落候选并写入中间索引', status: 'ok' },
                { type: 'action', label: '核对金额口径与合同条款对齐', status: 'fail' },
              ],
            });
            turns.push({
              id: `${idBase}-b1`,
              role: 'bot',
              text: '执行失败：在金额口径对齐步骤出现异常退出。建议检查引用资料的时间范围与字段单位后重跑。',
            });
            return turns;
          }
          const readActions = resNames.slice(0, 2).map((nm) => ({
            type: 'action',
            label: `阅读《${nm}》并定位关键字段`,
            status: 'ok',
          }));
          turns.push({
            id: `${idBase}-think`,
            role: 'thinking',
            toolCalls: [
              { type: 'text', body: `已将任务「${title}」绑定到面板上下文，准备执行技能沙箱。` },
              { type: 'text', body: resLine },
              { type: 'action', label: `调用技能「${skill}」并装载规则模板`, status: 'ok' },
              ...readActions,
              { type: 'action', label: '生成结论段落与差异表（中间 Markdown）', status: 'ok' },
              { type: 'action', label: '同步结果到工作台结果树', status: 'ok' },
            ],
          });
          turns.push({
            id: `${idBase}-b1`,
            role: 'bot',
            text: `分析已完成。主要结论与证据链已写入当前任务的 Markdown 结果，可在右侧「结果」中打开「${title}」文件夹查看与历史版本。`,
          });
          turns.push({
            id: `${idBase}-u2`,
            role: 'user',
            text: '请把「异常金额」相关的三处证据按条款号排序，并补一句口径说明。',
          });
          turns.push({
            id: `${idBase}-b2`,
            role: 'bot',
            text: '已在结果稿中追加异常段落重排与口径脚注，可在右侧预览中查看最新稿。',
          });
          return turns;
        },
        onWorkbenchAnalysisResultFolderRowClick(d) {
          if (!d || d.key == null) return;
          const key = String(d.key);
          const expanded = new Set(this.workbenchAnalysisResultTreeExpandedKeys || []);
          if (expanded.has(key)) expanded.delete(key);
          else expanded.add(key);
          this.workbenchAnalysisResultTreeExpandedKeys = Array.from(expanded);
        },
        isWorkbenchAnalysisResultTreeLeafSelected(d) {
          const st = this.selectedTreeNode;
          return !!(st && st.source === 'analysis' && d && d.materialId && String(st.id) === String(d.materialId));
        },
        onWorkbenchAnalysisResultTreeLeafClick(d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return;
          this.selectTreeNode({ id: m.id, raw: m }, 'analysis');
        },
        openWorkbenchAnalysisResultTreeLeafDetail(d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return;
          this.openDetailFromTreeTitle({ id: m.id, raw: m }, 'analysis');
        },
        collectWorkbenchAnalysisResultFolderSubtreeIds(rootFolderId, folderList) {
          const list = Array.isArray(folderList) ? folderList : [];
          const root = String(rootFolderId || '');
          if (!root) return new Set();
          const out = new Set([root]);
          let added = true;
          while (added) {
            added = false;
            list.forEach((f) => {
              const id = String(f.id || '');
              const p = f.parentId != null && f.parentId !== '' ? String(f.parentId) : '';
              if (!id || out.has(id)) return;
              if (p && out.has(p)) {
                out.add(id);
                added = true;
              }
            });
          }
          return out;
        },
        onWorkbenchAnalysisResultUserFolderMenu(key, d) {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectAnalysisResultFoldersById === 'undefined' || !d || !d.userFolderId) return;
          const folds = demoProjectAnalysisResultFoldersById[pid] || [];
          const fid = String(d.userFolderId);
          if (key === 'rename') {
            const row = folds.find((f) => String(f.id) === fid);
            if (!row) return;
            const name = window.prompt('重命名文件夹', row.name || '');
            if (name == null) return;
            const trimmed = String(name).trim();
            if (!trimmed) {
              message.warning('名称不能为空');
              return;
            }
            const idx = folds.findIndex((f) => String(f.id) === fid);
            if (idx >= 0) folds.splice(idx, 1, { ...folds[idx], name: trimmed });
            this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
            message.success('已重命名');
            return;
          }
          if (key === 'delete') {
            this.confirmDeleteWorkbenchAnalysisResultFolder(fid);
          }
        },
        onWorkbenchAnalysisResultUserFolderContextMenu(key, d) {
          this.onWorkbenchAnalysisResultAnyFolderMenu(key, d);
        },
        confirmDeleteWorkbenchAnalysisResultFolder(folderId) {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectAnalysisResultFoldersById === 'undefined' || !folderId) return;
          const folds = demoProjectAnalysisResultFoldersById[pid] || [];
          const row = folds.find((f) => String(f.id) === String(folderId));
          Modal.confirm({
            centered: true,
            title: '删除结果文件夹',
            content: `将删除「${(row && row.name) || '文件夹'}」及其子文件夹；其中的结果条目将移回任务默认分组（演示）。`,
            okText: '删除',
            cancelText: '取消',
            okButtonProps: { danger: true },
            onOk: () => {
              const delIds = this.collectWorkbenchAnalysisResultFolderSubtreeIds(folderId, folds);
              const mats = this.materials || [];
              mats.forEach((m) => {
                if (!m || m.type !== 'analysis') return;
                const ps = m.projectSource || {};
                const rid = String(ps.resultFolderId || '');
                if (rid && delIds.has(rid)) {
                  const nextPs = { ...ps, resultFolderId: null };
                  m.projectSource = nextPs;
                  const j = (demoProjectAnalysisResultsById[pid] || []).findIndex((r) => String(r.id) === String(m.id));
                  if (j >= 0) {
                    const r0 = demoProjectAnalysisResultsById[pid][j];
                    demoProjectAnalysisResultsById[pid].splice(j, 1, { ...r0, resultFolderId: null });
                  }
                }
              });
              demoProjectAnalysisResultFoldersById[pid] = folds.filter((f) => !delIds.has(String(f.id)));
              this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
              message.success('已删除文件夹（演示）');
            },
          });
        },
        resolveDemoWorkbenchTaskRef(m) {
          if (!m || !m.id) return null;
          const id = String(m.id);
          if (typeof demoWorkbenchTaskRows === 'undefined') return null;
          for (let i = 0; i < demoWorkbenchTaskRows.length; i += 1) {
            const row = demoWorkbenchTaskRows[i];
            if (!row) continue;
            if (String(row.id) === id) return row;
            const children = row.children || [];
            for (let j = 0; j < children.length; j += 1) {
              if (children[j] && String(children[j].id) === id) return children[j];
            }
          }
          return null;
        },
        resolveCreatedWorkbenchTaskRef(m) {
          if (!m || !m.id) return null;
          const id = String(m.id);
          for (let i = 0; i < (this.workbenchCreatedTasks || []).length; i += 1) {
            const row = this.workbenchCreatedTasks[i];
            if (!row) continue;
            if (String(row.id) === id) return row;
            const children = row.children || [];
            for (let j = 0; j < children.length; j += 1) {
              if (children[j] && String(children[j].id) === id) return children[j];
            }
          }
          return null;
        },
        handleBatchChildContextMenu(key, child) {
          if (!child) return;
          if (key === 'abort-task') this.workbenchTaskRowAbort(child);
          else if (key === 'rerun-task') this.workbenchTaskRowRerun(child);
          else if (key === 'delete') {
            const parent = this.wbActiveBatchParentTask;
            if (!parent || !Array.isArray(parent.children)) return;
            Modal.confirm({
              centered: true,
              title: '删除子任务',
              content: '删除后该子任务将从列表移除（演示数据）。',
              okText: '删除',
              cancelText: '取消',
              okButtonProps: { danger: true },
              onOk: () => {
                parent.children = parent.children.filter((c) => c && c.id !== child.id);
                if (this.selectedMaterialId === child.id) this.selectedMaterialId = null;
                message.success('已删除子任务（演示）');
              },
            });
          }
        },
        handleBatchParentHeaderMenu(key) {
          const parent = this.wbActiveBatchParentTask;
          if (!parent) return;
          this.handleTreeContextMenu(key, { id: parent.id, raw: parent }, 'analysis', 'task');
        },
        workbenchTaskRowAbort(raw) {
          if (!raw || !raw.id) return;
          if (this.resolveDemoWorkbenchTaskRef(raw)) {
            this.abortWorkbenchDemoTask(raw);
            return;
          }
          if (this.resolveCreatedWorkbenchTaskRef(raw)) {
            this.abortWorkbenchCreatedTask(raw);
            return;
          }
        },
        workbenchTaskRowRerun(raw) {
          if (!raw || !raw.id) return;
          if (this.resolveDemoWorkbenchTaskRef(raw)) {
            this.rerunWorkbenchDemoTask(raw);
            return;
          }
          if (this.resolveCreatedWorkbenchTaskRef(raw)) {
            this.rerunWorkbenchCreatedTask(raw);
            return;
          }
        },
        abortWorkbenchDemoTask(m) {
          if (!m || !m.id) return;
          const st = this.workbenchAnalysisStatusOf(m);
          if (st !== 'queued' && st !== 'parsing') return;
          Modal.confirm({
            centered: true,
            title: '中止任务',
            content: '中止后任务将进入失败态，可通过重跑再次执行（演示）。',
            okText: '中止',
            cancelText: '取消',
            onOk: () => {
              const t = this.resolveDemoWorkbenchTaskRef(m);
              if (!t) return;
              t.status = 'failed';
              t.projectSource = t.projectSource || {};
              t.projectSource.status = 'failed';
              message.info('已中止（演示）');
            },
          });
        },
        rerunWorkbenchDemoTask(m) {
          if (!m || !m.id) return;
          Modal.confirm({
            centered: true,
            title: '重跑任务',
            content: '重跑将清空之前已产出的结果（演示）。是否继续？',
            okText: '重跑',
            cancelText: '取消',
            onOk: () => {
              const t = this.resolveDemoWorkbenchTaskRef(m);
              if (!t) return;
              t.status = 'parsing';
              t.projectSource = t.projectSource || {};
              t.projectSource.status = 'parsing';
              window.setTimeout(() => {
                const cur = this.resolveDemoWorkbenchTaskRef(m);
                if (!cur || cur.status !== 'parsing') return;
                cur.status = 'done';
                cur.projectSource = cur.projectSource || {};
                cur.projectSource.status = 'done';
                const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
                cur.projectSource.completedAt = cur.projectSource.completedAt || now;
                this.ensureWorkbenchAnalysisResultTaskFolders();
              }, 1400);
              message.success('已提交重跑（演示）');
            },
          });
        },
        deleteWorkbenchDemoTask(m) {
          if (!m || !m.id) return;
          Modal.confirm({
            centered: true,
            title: '删除任务',
            content: '删除后该任务将从任务列表移除（演示数据）。',
            okText: '删除',
            cancelText: '取消',
            okButtonProps: { danger: true },
            onOk: () => {
              if (typeof demoWorkbenchTaskRows === 'undefined') return;
              const i = demoWorkbenchTaskRows.findIndex((x) => x && x.id === m.id);
              if (i < 0) return;
              demoWorkbenchTaskRows.splice(i, 1);
              if (this.selectedMaterialId === m.id) {
                this.closeWorkbenchMaterialDetail();
              }
              this.selectedTreeNode = null;
              message.success('任务已删除（演示）');
            },
          });
        },
        onWorkbenchAnalysisResultTreeRawToggleRef(d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return;
          this.handleTreeContextMenu('ref', { id: m.id, raw: m }, 'analysis', 'result');
        },
        onWorkbenchAnalysisResultTreeRawMenu(key, d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return;
          this.handleTreeContextMenu(key, { id: m.id, raw: m }, 'analysis', 'result');
        },
        onWorkbenchAnalysisResultTreeDragStart(ev, d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m || m.loading) {
            ev.preventDefault();
            return;
          }
          this.onTreeLeafDragStart(ev, { id: m.id, raw: m }, 'analysis');
        },
        openWorkbenchFileTreeRawDetail(d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return;
          this.openDetailFromTreeTitle({ id: m.id, raw: m }, 'material');
        },
        onWorkbenchFileTreeRawToggleRef(d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return;
          this.handleTreeContextMenu('ref', { id: m.id, raw: m }, 'material');
        },
        onWorkbenchFileTreeRawMenu(key, d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return;
          this.handleTreeContextMenu(key, { id: m.id, raw: m }, 'material');
        },
        chatAtRawMaterialDisplayTitle(m) {
          if (!m) return '';
          const row = m.projectSource || {};
          const folders = this.workbenchMaterialFoldersList || [];
          const prefix = wbMatMaterialPathPrefixForRow(row, folders);
          const title = String(m.title != null ? m.title : m.name != null ? m.name : '未命名').trim() || '未命名';
          return prefix ? `${prefix}${title}` : title;
        },
        onWorkbenchTemplateAddMenu(info) {
          const key = info && info.key;
          if (key === 'library') {
            this.openTemplateLibrary();
            return;
          }
          if (key === 'new') {
            const pid = this.workbenchProjectId;
            if (!pid) {
              message.warning('请先通过工作台进入本工作台的审计助手后再创建技能');
              return;
            }
            this.openWbProjectSkillCreateBasicModal();
          }
        },
        openTemplateLibrary() {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先通过工作台进入本工作台的审计助手后再引用技能');
            return;
          }
          const bridge = window.__demoQuoteSkillBridge;
          if (bridge && typeof bridge.openForWorkbenchProject === 'function') {
            bridge.openForWorkbenchProject(pid);
            return;
          }
          message.warning('引用技能面板暂不可用，请先从「工作台」进入一次后再试');
        },
        selectWorkbenchSkillTemplate(node) {
          if (!node || !node.key) return;
          if (this.isWbProjectSkillSummarizing(node.raw)) {
            message.info('该工作台技能正在总结中，暂不可引用');
            return;
          }
          this.wbSelectedTemplateKey = this.wbSelectedTemplateKey === node.key ? '' : node.key;
        },
        onWbSkillTreeLeafContextMenu(node) {
          if (!node || !node.key) return;
          this.wbSkillTreeActionMenuKey = node.key;
        },
        onWbSkillTreeActionMenuOpenUpdate(open, node) {
          if (open) {
            this.wbSkillTreeActionMenuKey = node && node.key ? node.key : null;
          } else if (node && node.key && this.wbSkillTreeActionMenuKey === node.key) {
            this.wbSkillTreeActionMenuKey = null;
          }
        },
        onWbProjectSkillTreeMenu(info, node) {
          const key = info && info.key;
          const tpl = node && node.raw;
          if (!tpl) return;
          if (this.isWbProjectSkillSummarizing(tpl) && key !== 'delete') {
            message.info('该工作台技能正在总结中，完成后可查看与操作');
            return;
          }
          if (key === 'cite') {
            const name = String(tpl.name != null ? tpl.name : '未命名').trim() || '未命名';
            this.appendChatInputToken('/' + name);
          } else if (key === 'archive') {
            this.wbArchiveProjectTemplatesToMyLibrary([tpl]);
          } else if (key === 'delete') {
            this.wbDeleteProjectAnalysisTemplate(tpl, node.key);
          }
        },
        wbArchiveProjectTemplatesToMyLibrary(templates) {
          const pid = this.workbenchProjectId;
          if (!pid) return;
          const selected = (templates || []).filter(Boolean);
          if (!selected.length) {
            message.warning('没有可入库的技能');
            return;
          }
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const privatePool = this.analysisTemplatePool.private || [];
          const usedIds = new Set(privatePool.map((x) => x.id));
          const inserted = [];
          selected.forEach((tpl) => {
            let newId = typeof newSkillId === 'function' ? newSkillId('priv-arch') : 'priv-arch-' + Date.now();
            while (usedIds.has(newId)) {
              newId = typeof newSkillId === 'function' ? newSkillId('priv-arch') : newId + 'x';
            }
            usedIds.add(newId);
            let skillFiles = [];
            if (typeof window.DemoSkillFileTree !== 'undefined' && window.DemoSkillFileTree.remapSkillFilesTree) {
              skillFiles = window.DemoSkillFileTree.remapSkillFilesTree(tpl.skillFiles || []);
            } else if (Array.isArray(tpl.extractionRules) && tpl.extractionRules.length) {
              skillFiles = tpl.extractionRules.map((r, ri) => ({
                id: newId + '-sf' + (ri + 1),
                kind: 'file',
                fileKind: 'md',
                codeLang: '',
                filename: (String(r.title || '').trim() || '条目' + (ri + 1)) + '.md',
                content: String(r.body || ''),
              }));
            }
            const row = {
              id: newId,
              name: tpl.name,
              description: (tpl.description != null ? tpl.description : '') || '',
              tags: Array.isArray(tpl.tags) ? tpl.tags.slice() : [],
              skillFiles,
              extractionRules: [],
              analysisRule: tpl.analysisRule || '',
              applicableScenario: tpl.applicableScenario != null ? String(tpl.applicableScenario) : '',
              createdAt: now,
              updatedAt: now,
              library: 'private',
              publishedVersions: [],
              sourceSkillId: tpl.id,
              sourceLibrary: 'project',
              sourceSkillName: tpl.name || tpl.id,
              sourceVersionLabel: '工作台实例',
            };
            if (typeof window.DemoSkillFileTree !== 'undefined' && window.DemoSkillFileTree.syncExtractionRulesFromSkillFiles) {
              window.DemoSkillFileTree.syncExtractionRulesFromSkillFiles(row);
            }
            inserted.push(row);
          });
          const priv = this.analysisTemplatePool.private || [];
          inserted.forEach((row) => priv.push(row));
          message.success(`已将 ${inserted.length} 个技能入库到「我的技能」`);
        },
        wbDeleteProjectAnalysisTemplate(template, nodeKey) {
          if (!template || !this.workbenchProjectId) return;
          const id = String(template.id || '');
          const pid = this.workbenchProjectId;
          Modal.confirm({
            centered: true,
            title: '确定删除该技能？',
            content: '删除后将从当前工作台移除该技能。',
            okText: '删除',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              const taskId = this.summarySkillTaskByTemplateId && this.summarySkillTaskByTemplateId[id];
              if (taskId) {
                this._clearSummaryTaskTimers(taskId);
                this.summaryTemplateTasks = (this.summaryTemplateTasks || []).filter((x) => x.id !== taskId);
                const map = { ...(this.summarySkillTaskByTemplateId || {}) };
                delete map[id];
                this.summarySkillTaskByTemplateId = map;
              }
              const list = demoProjectAnalysisTemplatesById[pid] || [];
              demoProjectAnalysisTemplatesById[pid] = list.filter((x) => String(x.id) !== id);
              if (nodeKey && this.wbSelectedTemplateKey === nodeKey) this.wbSelectedTemplateKey = '';
              if (String(this.wbProjectSkillDetailId) === id) {
                this._wbProjectSkillModalSnapshot = null;
                this.closeWbProjectSkillDetailModal(false);
              }
              message.success('技能已删除');
            },
          });
        },
        openWbProjectSkillDetailFromNode(node, options) {
          if (!node || !node.raw) return;
          if (this.isWbProjectSkillSummarizing(node.raw)) {
            message.info('该工作台技能正在总结中，完成后可查看');
            return;
          }
          const readOnly = !!(options && options.readOnly);
          this.openWbProjectSkillDetail(node.raw, { readOnly });
        },
        isWbProjectSkillSummarizing(template) {
          const id = template && template.id ? String(template.id) : '';
          if (!id) return false;
          return !!(this.summarySkillTaskByTemplateId && this.summarySkillTaskByTemplateId[id]);
        },
        syncWbProjectSkillFormFromSkill(s) {
          if (!s) return;
          this.wbProjectSkillForm = {
            id: s.id,
            name: s.name || '',
            description: s.description != null ? String(s.description) : '',
            tags: Array.isArray(s.tags) ? [...s.tags] : [],
          };
        },
        syncWbProjectSkillFormToSelected() {
          const s = this.wbDetailSelectedSkill;
          if (!s || this.wbProjectSkillDetailReadOnly) return;
          const name = String(this.wbProjectSkillForm.name || '').trim();
          const desc = String(this.wbProjectSkillForm.description || '').trim();
          const tagList = [...(this.wbProjectSkillForm.tags || [])].map((t) => String(t).trim()).filter(Boolean);
          const tags = tagList.length ? Array.from(new Set(tagList)) : ['技能'];
          s.name = name;
          s.description = desc;
          s.tags = tags;
        },
        validateWbProjectSkillFilesForSave() {
          const s = this.wbDetailSelectedSkill;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!s || !T) return false;
          const dups = T.findDuplicatePaths(s.skillFiles || []);
          if (dups.length) {
            message.warning('文件名路径重复：' + dups.join('、'));
            return false;
          }
          if (!String(s.analysisRule || '').trim()) {
            message.warning('请填写审计思路');
            return false;
          }
          let bad = false;
          const walk = (nodes) => {
            (nodes || []).forEach((n) => {
              if (!n) return;
              if (n.kind === 'folder') {
                if (!String(n.name || '').trim()) bad = true;
                walk(n.children);
              } else if (n.kind === 'file') {
                if (!String(n.filename || '').trim() || !String(n.content || '').trim()) bad = true;
              }
            });
          };
          walk(s.skillFiles || []);
          if (bad) {
            message.warning('每个文件夹须有名称；每个文件须填写文件名与具体内容');
            return false;
          }
          return true;
        },
        hydrateWbProjectSkillForModal(target) {
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!target || !T) return target;
          if (T.ensureSkillFiles) T.ensureSkillFiles(target);
          if (T.syncExtractionRulesFromSkillFiles) T.syncExtractionRulesFromSkillFiles(target);
          if (Array.isArray(target.extractionRules)) {
            target.extractionRules = target.extractionRules.map((x) =>
              window.DemoProjectSkillMatch ? window.DemoProjectSkillMatch.dedupeRuleMaterialIds(x) : x
            );
          }
          return target;
        },
        refreshWbProjectSkillModalSnapshotAfterPaneSave() {
          const s = this.wbDetailSelectedSkill;
          const pid = this.workbenchProjectId;
          if (!s || !pid) return;
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          const f = list.find((x) => String(x.id) === String(s.id));
          if (f) this._wbProjectSkillModalSnapshot = JSON.parse(JSON.stringify(f));
        },
        captureWbProjectSkillBasicPaneSnap() {
          if (this.wbProjectSkillDetailReadOnly) return;
          this._wbProjectSkillBasicPaneSnap = {
            name: this.wbProjectSkillForm.name,
            description: this.wbProjectSkillForm.description,
            tags: Array.isArray(this.wbProjectSkillForm.tags) ? [...this.wbProjectSkillForm.tags] : [],
          };
        },
        captureWbProjectSkillConfigPaneSnap() {
          const s = this.wbDetailSelectedSkill;
          if (!s || this.wbProjectSkillDetailReadOnly) return;
          this._wbProjectSkillConfigPaneSnap = JSON.parse(JSON.stringify(s));
        },
        captureWbProjectSkillPaneSnapshotsAfterOpen() {
          if (this.wbProjectSkillDetailReadOnly) {
            this._wbProjectSkillBasicPaneSnap = null;
            this._wbProjectSkillConfigPaneSnap = null;
            return;
          }
          this.captureWbProjectSkillBasicPaneSnap();
          this.captureWbProjectSkillConfigPaneSnap();
        },
        cancelWbProjectSkillBasicPaneEdit() {
          const snap = this._wbProjectSkillBasicPaneSnap;
          if (snap) {
            this.wbProjectSkillForm.name = snap.name;
            this.wbProjectSkillForm.description = snap.description;
            this.wbProjectSkillForm.tags = snap.tags ? [...snap.tags] : [];
          }
          this.captureWbProjectSkillBasicPaneSnap();
        },
        saveWbProjectSkillBasicPane() {
          if (this.wbProjectSkillDetailReadOnly) return;
          const name = String(this.wbProjectSkillForm.name || '').trim();
          if (!name) {
            message.warning('请填写名称');
            return;
          }
          if (this._wbProjectSkillDetailSyncTimer) {
            window.clearTimeout(this._wbProjectSkillDetailSyncTimer);
            this._wbProjectSkillDetailSyncTimer = null;
          }
          this.syncWbProjectSkillFormToSelected();
          this.syncWbProjectSkillDetailNow();
          this._wbProjectSkillCreateCommitted = true;
          this.refreshWbProjectSkillModalSnapshotAfterPaneSave();
          this.captureWbProjectSkillPaneSnapshotsAfterOpen();
          if (this.wbProjectSkillDetailModalIsCreate) this.wbProjectSkillDetailModalIsCreate = false;
          message.success('保存成功');
        },
        cancelWbProjectSkillConfigPaneEdit() {
          const snap = this._wbProjectSkillConfigPaneSnap;
          const pid = this.workbenchProjectId;
          if (snap && pid) {
            const list = demoProjectAnalysisTemplatesById[pid] || [];
            const idx = list.findIndex((x) => String(x.id) === String(snap.id));
            if (idx >= 0) {
              list.splice(idx, 1, JSON.parse(JSON.stringify(snap)));
              demoProjectAnalysisTemplatesById[pid] = [...list];
            }
          }
          this.$nextTick(() => {
            this.captureWbProjectSkillConfigPaneSnap();
            this.ensureWbProjectSkillFirstObjectExpanded();
          });
        },
        saveWbProjectSkillConfigPane() {
          if (this.wbProjectSkillDetailReadOnly) return;
          if (!this.validateWbProjectSkillFilesForSave()) return;
          if (this._wbProjectSkillDetailSyncTimer) {
            window.clearTimeout(this._wbProjectSkillDetailSyncTimer);
            this._wbProjectSkillDetailSyncTimer = null;
          }
          this.syncWbProjectSkillFormToSelected();
          this.syncWbProjectSkillDetailNow();
          this._wbProjectSkillCreateCommitted = true;
          this.refreshWbProjectSkillModalSnapshotAfterPaneSave();
          this.captureWbProjectSkillPaneSnapshotsAfterOpen();
          if (this.wbProjectSkillDetailModalIsCreate) this.wbProjectSkillDetailModalIsCreate = false;
          message.success('保存成功');
        },
        startWbProjectSkillResourcePaneEdit() {
          if (this.wbProjectSkillDetailReadOnly) return;
          const s = this.wbDetailSelectedSkill;
          if (!s) return;
          this._wbProjectSkillResourcePaneSnap = this.getWbSkillLinkedResourceIds(s);
          this.wbProjectSkillResourcePaneEditing = true;
        },
        cancelWbProjectSkillResourcePaneEdit() {
          const s = this.wbDetailSelectedSkill;
          if (s && Array.isArray(this._wbProjectSkillResourcePaneSnap)) {
            s.linkedResourceIds = this._wbProjectSkillResourcePaneSnap.slice();
          }
          this._wbProjectSkillResourcePaneSnap = null;
          this.wbProjectSkillResourcePaneEditing = false;
        },
        saveWbProjectSkillResourcePane() {
          if (this.wbProjectSkillDetailReadOnly) return;
          const s = this.wbDetailSelectedSkill;
          if (!s) return;
          s.linkedResourceIds = this.getWbSkillLinkedResourceIds(s);
          this.syncWbProjectSkillDetailNow();
          this._wbProjectSkillCreateCommitted = true;
          this.refreshWbProjectSkillModalSnapshotAfterPaneSave();
          this.wbProjectSkillResourcePaneEditing = false;
          this._wbProjectSkillResourcePaneSnap = null;
          message.success('关联资源已保存');
        },
        onWbProjectSkillTabUpdate(key) {
          const next = String(key || 'basic');
          if (next === String(this.wbProjectSkillDetailActiveTab)) return;
          const leaving = String(this.wbProjectSkillDetailActiveTab);
          if (
            (leaving === 'basic' && this.wbProjectSkillBasicPaneDirty)
            || (leaving === 'config' && this.wbProjectSkillConfigPaneDirty)
            || (leaving === 'resource' && this.wbProjectSkillResourcePaneEditing)
          ) {
            Modal.confirm({
              centered: true,
              title: '有未保存的编辑',
              content: '切换页签将放弃当前页签的未保存修改，是否继续？',
              okText: '放弃并切换',
              cancelText: '留在本页',
              onOk: () => {
                if (leaving === 'basic') this.cancelWbProjectSkillBasicPaneEdit();
                if (leaving === 'config') this.cancelWbProjectSkillConfigPaneEdit();
                if (leaving === 'resource') this.cancelWbProjectSkillResourcePaneEdit();
                this.wbProjectSkillDetailActiveTab = next;
              },
            });
            return;
          }
          this.wbProjectSkillDetailActiveTab = next;
        },
        openWbProjectSkillDetail(template, options) {
          const pid = this.workbenchProjectId;
          if (!template || !template.id || !pid) return;
          const readOnly = !!(options && options.readOnly);
          this.wbProjectSkillResourcePaneEditing = false;
          this._wbProjectSkillBasicPaneSnap = null;
          this._wbProjectSkillConfigPaneSnap = null;
          this._wbProjectSkillResourcePaneSnap = null;
          this._wbProjectSkillCreateCommitted = false;
          this.wbProjectSkillDetailReadOnly = readOnly;
          this.wbProjectSkillDetailModalIsCreate = false;
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          const idx = list.findIndex((x) => x.id === template.id);
          if (idx < 0) return;
          const target = list[idx];
          this.hydrateWbProjectSkillForModal(target);
          demoProjectAnalysisTemplatesById[pid] = [...list];
          const fresh = (demoProjectAnalysisTemplatesById[pid] || []).find((x) => x.id === target.id) || target;
          if (!readOnly) {
            this._wbProjectSkillModalSnapshot = JSON.parse(JSON.stringify(fresh));
          } else {
            this._wbProjectSkillModalSnapshot = null;
          }
          this.wbProjectSkillDetailId = fresh.id;
          this.wbProjectSkillDetailActiveTab = readOnly ? 'config' : 'basic';
          this.syncWbProjectSkillFormFromSkill(fresh);
          this.wbProjectSkillConfigNavKey = 'rule';
          this.wbProjectSkillDetailModalOpen = true;
          this.$nextTick(() => {
            this.ensureWbProjectSkillFirstObjectExpanded();
            this.captureWbProjectSkillPaneSnapshotsAfterOpen();
          });
        },
        openWbProjectSkillCreateBasicModal() {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先通过工作台进入本工作台的审计助手后再创建技能');
            return;
          }
          this.wbProjectSkillCreateBasicSubmitting = false;
          this.wbProjectSkillCreateBasicForm = { name: '', description: '', tags: [] };
          this.wbProjectSkillCreateBasicModalOpen = true;
        },
        closeWbProjectSkillCreateBasicModal() {
          this.wbProjectSkillCreateBasicSubmitting = false;
          this.wbProjectSkillCreateBasicModalOpen = false;
        },
        submitWbProjectSkillCreateBasic() {
          if (this.wbProjectSkillCreateBasicSubmitting) return;
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先通过工作台进入本工作台的审计助手后再创建技能');
            return;
          }
          const name = String(this.wbProjectSkillCreateBasicForm.name || '').trim();
          if (!name) {
            message.warning('请填写技能名称');
            return;
          }
          this.wbProjectSkillCreateBasicSubmitting = true;
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const newId = 'sk-prj-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
          const row = {
            id: newId,
            library: 'project',
            name,
            description: String(this.wbProjectSkillCreateBasicForm.description || '').trim(),
            tags: Array.from(new Set((this.wbProjectSkillCreateBasicForm.tags || []).map((t) => String(t).trim()).filter(Boolean))),
            autoMatchOnSave: true,
            skillFiles: [],
            extractionRules: [],
            analysisRule: '',
            applicableScenario: '',
            createdAt: now,
            updatedAt: now,
            createdBy: '我',
            matchStatus: 'pending_config',
            matchPhase: '待配置',
            matchProgress: 0,
          };
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          list.unshift(row);
          demoProjectAnalysisTemplatesById[pid] = [...list];
          this.wbProjectSkillDetailModalIsCreate = true;
          this.wbProjectSkillDetailReadOnly = false;
          this._wbProjectSkillModalSnapshot = null;
          this.wbProjectSkillResourcePaneEditing = false;
          this._wbProjectSkillBasicPaneSnap = null;
          this._wbProjectSkillConfigPaneSnap = null;
          this._wbProjectSkillResourcePaneSnap = null;
          this._wbProjectSkillCreateCommitted = false;
          this.wbProjectSkillDetailId = row.id;
          this.wbProjectSkillDetailActiveTab = 'config';
          this.syncWbProjectSkillFormFromSkill(row);
          this.wbProjectSkillConfigNavKey = 'rule';
          this.wbProjectSkillCreateBasicSubmitting = false;
          this.wbProjectSkillCreateBasicModalOpen = false;
          this.wbProjectSkillDetailModalOpen = true;
          this.$nextTick(() => {
            this.ensureWbProjectSkillFirstObjectExpanded();
            this.captureWbProjectSkillPaneSnapshotsAfterOpen();
          });
        },
        openWbProjectSkillCreateUnified() {
          this.openWbProjectSkillCreateBasicModal();
        },
        ensureWbProjectSkillFirstObjectExpanded() {
          const s = this.wbDetailSelectedSkill;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (s && T && T.ensureSkillFiles) T.ensureSkillFiles(s);
          this.wbProjectSkillConfigNavKey = 'rule';
          this.wbProjectSkillConfigTreeExpandedKeys = s && T && T.defaultExpandedKeys ? T.defaultExpandedKeys(s.skillFiles || []) : [];
        },
        closeWbProjectSkillDetailModal(fromSave) {
          const saved = fromSave === true;
          const createCommitted = this._wbProjectSkillCreateCommitted;
          if (this._wbProjectSkillDetailSyncTimer) {
            window.clearTimeout(this._wbProjectSkillDetailSyncTimer);
            this._wbProjectSkillDetailSyncTimer = null;
          }
          const templateId = this.wbProjectSkillDetailId;
          const pid = this.workbenchProjectId;
          const wasCreate = this.wbProjectSkillDetailModalIsCreate;
          const wasReadOnly = this.wbProjectSkillDetailReadOnly;
          if (!saved && pid) {
            if (wasCreate && templateId && !createCommitted) {
              const list = demoProjectAnalysisTemplatesById[pid] || [];
              demoProjectAnalysisTemplatesById[pid] = list.filter((x) => String(x.id) !== String(templateId));
            } else if (!wasReadOnly && this._wbProjectSkillModalSnapshot && templateId) {
              const list = demoProjectAnalysisTemplatesById[pid] || [];
              const idx = list.findIndex((x) => String(x.id) === String(templateId));
              if (idx >= 0) {
                list.splice(idx, 1, JSON.parse(JSON.stringify(this._wbProjectSkillModalSnapshot)));
                demoProjectAnalysisTemplatesById[pid] = [...list];
              }
            }
          }
          this._wbProjectSkillModalSnapshot = null;
          this.wbProjectSkillDetailModalIsCreate = false;
          this.wbProjectSkillDetailModalOpen = false;
          this.wbProjectSkillDetailReadOnly = false;
          this.wbProjectSkillDetailId = '';
          this.wbProjectSkillConfigNavKey = 'rule';
          this.wbProjectSkillConfigTreeExpandedKeys = [];
          this.wbProjectSkillDetailActiveTab = 'basic';
          this.wbProjectSkillResourcePaneEditing = false;
          this._wbProjectSkillBasicPaneSnap = null;
          this._wbProjectSkillConfigPaneSnap = null;
          this._wbProjectSkillResourcePaneSnap = null;
          this._wbProjectSkillCreateCommitted = false;
        },
        scheduleWbProjectSkillDetailSync() {
          if (this.wbProjectSkillDetailReadOnly) return;
          if (this._wbProjectSkillDetailSyncTimer) window.clearTimeout(this._wbProjectSkillDetailSyncTimer);
          this._wbProjectSkillDetailSyncTimer = window.setTimeout(() => {
            this.syncWbProjectSkillDetailNow();
            this._wbProjectSkillDetailSyncTimer = null;
          }, 250);
        },
        syncWbProjectSkillDetailNow() {
          const s = this.wbDetailSelectedSkill;
          const pid = this.workbenchProjectId;
          if (!s || !pid) return;
          if (this.wbProjectSkillDetailReadOnly) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (T && T.ensureSkillFiles) T.ensureSkillFiles(s);
          if (T && T.syncExtractionRulesFromSkillFiles) T.syncExtractionRulesFromSkillFiles(s);
          if (!Array.isArray(s.extractionRules)) s.extractionRules = [];
          s.extractionRules = s.extractionRules.map((x) => ({
            id: x.id || newSkillId('er'),
            title: String(x.title || ''),
            body: String(x.body || ''),
            materialIds: Array.isArray(x.materialIds) ? Array.from(new Set(x.materialIds.map((mid) => String(mid)))) : [],
          }));
          s.analysisRule = String(s.analysisRule || '');
          s.applicableScenario = String(s.applicableScenario || '');
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          s.updatedAt = now;
          if (!s.createdAt) {
            s.createdAt = now;
            if (!s.createdBy) s.createdBy = '我';
          }
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          const idx = list.findIndex((x) => x.id === s.id);
          if (idx >= 0) {
            list.splice(idx, 1, { ...s });
            demoProjectAnalysisTemplatesById[pid] = [...list];
          }
        },
        onWbProjectSkillConfigSaveMenuClick(info) {
          const k = info && info.key;
          if (k !== 'publish-new') return;
          message.info('保存为新版本仅在「我的技能」资产库中支持，请在工作台将技能入库后再于技能库发布版本。');
        },
        onWbProjectSkillConfigAddMenuClick(info) {
          if (this.wbProjectSkillConfigTabLocked || !this.wbDetailSelectedSkill) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T) return;
          const root = T.ensureSkillFiles(this.wbDetailSelectedSkill);
          const key = info && info.key;
          let node;
          if (key === 'md') node = T.newFileNode('md', '');
          else if (key === 'folder') node = T.newFolderNode();
          else if (String(key || '').startsWith('code:')) node = T.newFileNode('code', String(key).slice(5));
          else return;
          const parentRef = T.findAddParentRef(root, this.wbProjectSkillConfigNavKey);
          T.insertChild(root, parentRef, node);
          if (node.kind === 'file') {
            this.wbProjectSkillConfigNavKey = 'file:' + node.id;
          } else {
            this.wbProjectSkillConfigNavKey = 'folder:' + node.id;
            const ek = new Set(this.wbProjectSkillConfigTreeExpandedKeys || []);
            ek.add('folder:' + node.id);
            this.wbProjectSkillConfigTreeExpandedKeys = Array.from(ek);
          }
          this.scheduleWbProjectSkillDetailSync();
        },
        wbProjectSkillConfigTreeCanDeleteKey(treeKey) {
          if (!treeKey || treeKey === 'rule') return false;
          return String(treeKey).startsWith('file:') || String(treeKey).startsWith('folder:');
        },
        removeWbProjectSkillConfigTreeNode(treeKey) {
          if (this.wbProjectSkillConfigTabLocked || !this.wbDetailSelectedSkill) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || !treeKey || treeKey === 'rule') return;
          const id = String(treeKey).startsWith('file:')
            ? String(treeKey).slice('file:'.length)
            : String(treeKey).startsWith('folder:')
              ? String(treeKey).slice('folder:'.length)
              : '';
          if (!id) return;
          const root = T.ensureSkillFiles(this.wbDetailSelectedSkill);
          const wasNav = String(this.wbProjectSkillConfigNavKey) === String(treeKey);
          T.removeNodeById(root, id);
          if (wasNav) this.wbProjectSkillConfigNavKey = 'rule';
          this.scheduleWbProjectSkillDetailSync();
        },
        onWbProjectSkillConfigTreeSelect(selectedKeys) {
          if (!selectedKeys || !selectedKeys.length) return;
          const key = selectedKeys[0];
          this.wbProjectSkillConfigNavKey = key === 'rule' ? 'rule' : String(key);
        },
        wbProjectSkillConfigTreeNodeDraggable(node) {
          if (this.wbProjectSkillConfigTabLocked) return false;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          return !!(T && T.treeNodeIsDraggable && T.treeNodeIsDraggable(node));
        },
        onWbProjectSkillConfigTreeDrop(info) {
          if (this.wbProjectSkillConfigTabLocked || !this.wbDetailSelectedSkill) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || !T.applyTreeDropFromAntEvent) return;
          const res = T.applyTreeDropFromAntEvent(this.wbDetailSelectedSkill, info);
          if (!res.ok) {
            message.warning(res.message || '无法放置到此处');
            return;
          }
          this.scheduleWbProjectSkillDetailSync();
        },
        wbNormalizeRuleForProjectTemplate(rule) {
          const pid = this.workbenchProjectId;
          const mats = pid ? demoProjectMaterialsById[pid] || [] : [];
          return window.DemoProjectSkillMatch
            ? window.DemoProjectSkillMatch.normalizeRuleForProjectTemplate(rule, (r) =>
                window.DemoProjectSkillMatch.autoMatchMaterialIdsForRule(r, mats))
            : { ...(rule || {}), materialIds: [] };
        },
        getWbSkillLinkedResourceIds(template) {
          const t = template || {};
          const direct = Array.isArray(t.linkedResourceIds) ? t.linkedResourceIds.map((id) => String(id)).filter(Boolean) : [];
          if (direct.length) return Array.from(new Set(direct));
          const ids = new Set();
          if (Array.isArray(t.manualMaterialIds)) t.manualMaterialIds.forEach((id) => ids.add(String(id)));
          (Array.isArray(t.extractionRules) ? t.extractionRules : []).forEach((rule) => {
            (Array.isArray(rule && rule.materialIds) ? rule.materialIds : []).forEach((id) => ids.add(String(id)));
          });
          return Array.from(ids);
        },
        getWbSkillLinkedResourceCount(template) {
          return this.getWbSkillLinkedResourceIds(template).length;
        },
        getWbSkillLinkedResourceBylineState(template) {
          const ids = this.getWbSkillLinkedResourceIds(template);
          const total = ids.length;
          if (!total) {
            return {
              kind: 'idle',
              text: '未匹配到资料',
              ariaLabel: '查看匹配资料，当前未匹配',
            };
          }
          const pid = this.workbenchProjectId;
          const mats = pid ? demoProjectMaterialsById[pid] || [] : [];
          const byId = new Map(mats.map((m) => [String(m.id), m]));
          let done = 0;
          let pending = 0;
          let failed = 0;
          for (let i = 0; i < ids.length; i += 1) {
            const row = byId.get(String(ids[i]));
            const status = row && row.status ? String(row.status) : '';
            if (status === 'done') {
              done += 1;
            } else if (status === 'queued' || status === 'parsing') {
              pending += 1;
            } else if (status === 'failed') {
              failed += 1;
            } else {
              done += 1;
            }
          }
          if (pending > 0) {
            return {
              kind: 'running',
              text: '匹配中…',
              ariaLabel: '查看匹配资料，匹配中，当前完成 ' + done + ' 条，共 ' + total + ' 条',
            };
          }
          if (failed > 0) {
            return {
              kind: 'failed',
              text: '未匹配到资料',
              ariaLabel: '查看匹配资料，未匹配到资料',
            };
          }
          return {
            kind: 'success',
            text: '已匹配到 ' + total + ' 份资料',
            ariaLabel: '查看匹配资料，已匹配到 ' + total + ' 份资料',
          };
        },
        getWbSkillLinkedResources(template) {
          const pid = this.workbenchProjectId;
          const mats = pid ? demoProjectMaterialsById[pid] || [] : [];
          const byId = new Map(mats.map((m) => [String(m.id), m]));
          const ids = this.getWbSkillLinkedResourceIds(template);
          const metaMap = template && template.linkedResourceMeta && typeof template.linkedResourceMeta === 'object'
            ? template.linkedResourceMeta
            : {};
          return ids.map((id) => {
            const row = byId.get(String(id));
            return {
              id: String(id),
              name: row && row.name ? String(row.name) : String(id),
              format: row && row.format ? String(row.format) : '—',
              updatedAt: row && row.uploadedAt ? String(row.uploadedAt) : '—',
              matchSource: String(metaMap[id] || '命中配置规则'),
            };
          });
        },
        openWbSkillResourcePopover(template) {
          if (!template || !template.id) return;
          this.wbSkillResourcePopoverSkillId = String(template.id);
          this.wbSkillResourcePopoverOpen = true;
        },
        closeWbSkillResourcePopover() {
          this.wbSkillResourcePopoverOpen = false;
          this.wbSkillResourcePopoverSkillId = '';
        },
        openWbSkillResourceEditor(template) {
          if (!template) return;
          this.closeWbSkillResourcePopover();
          this.openWbProjectSkillDetail(template, { readOnly: false });
          this.wbProjectSkillDetailActiveTab = 'resource';
        },
        saveWbProjectSkillConfig() {
          const pid = this.workbenchProjectId;
          if (!pid || !this.wbDetailSelectedSkill || !window.DemoProjectSkillMatch) return;
          this.syncWbProjectSkillDetailNow();
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          const fresh = list.find((x) => x.id === this.wbDetailSelectedSkill.id);
          if (!fresh || !window.DemoProjectSkillMatch.validateProjectSkillConfigForMatch(fresh, message)) return;
          const idx = list.findIndex((x) => x.id === fresh.id);
          if (idx < 0) return;
          const row = { ...list[idx] };
          row.extractionRules = (row.extractionRules || [])
            .map((x) => ({
              id: x.id || newSkillId('er'),
              title: String(x.title || '').trim(),
              body: String(x.body || '').trim(),
              materialIds: Array.isArray(x.materialIds) ? Array.from(new Set(x.materialIds.map((mid) => String(mid)))) : [],
            }))
            .filter((x) => String(x.title || '').trim() && String(x.body || '').trim());
          row.analysisRule = String(row.analysisRule || '').trim();
          row.applicableScenario = String(row.applicableScenario || '').trim();
          const normRules = row.extractionRules.map((r) => this.wbNormalizeRuleForProjectTemplate(r));
          row.extractionRules = normRules;
          row.manualMaterialIds = Array.from(
            new Set(normRules.flatMap((r) => (Array.isArray(r.materialIds) ? r.materialIds : []).map((x) => String(x)))),
          );
          list.splice(idx, 1, row);
          demoProjectAnalysisTemplatesById[pid] = [...list];
          this.closeWbProjectSkillDetailModal(true);
          message.success('配置已保存');
        },
        wbProjectSkillModalCreator(sk) {
          if (!sk) return '—';
          return sk.createdBy || '我';
        },
        wbProjectSkillModalCreatedDateYmd(sk) {
          if (!sk || sk.createdAt == null || sk.createdAt === '') return '—';
          const t = String(sk.createdAt).trim();
          const m = t.match(/^(\d{4}-\d{2}-\d{2})/);
          if (m) return m[1];
          return t.slice(0, 10) || '—';
        },
        wbProjectSkillModalUpdatedCompact(sk) {
          if (!sk) return '—';
          const raw = sk.updatedAt != null && sk.updatedAt !== '' ? sk.updatedAt : sk.createdAt;
          if (raw == null || raw === '') return '—';
          const t = String(raw).trim();
          const m = t.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/);
          if (m) return `${m[2]}-${m[3]} ${m[4]}:${m[5]}`;
          const m2 = t.match(/^(\d{4})-(\d{2})-(\d{2})/);
          if (m2) return `${m2[2]}-${m2[3]}`;
          return t.slice(0, 16) || '—';
        },
        buildDemoAnalysisBotMessage(userText) {
          const atTitles = this.parseChatInputAtReferences(userText);
          let mat = null;
          for (let i = 0; i < atTitles.length; i++) {
            const title = atTitles[i];
            mat = this.materials.find((m) => String(m.title != null ? m.title : '未命名').trim() === title);
            if (mat) break;
          }
          if (!mat) mat = this.materials.find((m) => m.checked) || this.materials[0];
          const materials = this.materials || [];
          const rawList = materials.filter((m) => m && (m.type === 'raw' || m.type === undefined));
          const analysisTarget = (this.selectedMaterial && this.selectedMaterial.type === 'analysis')
            ? this.selectedMaterial
            : materials.find((m) => m.type === 'analysis');
          const baseRaw = mat && (mat.type === 'raw' || mat.type === undefined) ? mat : (rawList[0] || mat || materials[0]);
          const secondRaw = rawList.find((m) => m.id !== baseRaw?.id) || baseRaw;
          const thirdRaw = rawList.find((m) => m.id !== baseRaw?.id && m.id !== secondRaw?.id) || secondRaw;
          /** 与 SUMMARY 正文 [1][2][3][4] 一一对应，保证均可点击溯源 */
          const citationSlots = [
            baseRaw,
            analysisTarget && analysisTarget.id ? analysisTarget : baseRaw,
            secondRaw,
            thirdRaw || analysisTarget || baseRaw,
          ];
          let citations = citationSlots
            .filter((m) => m && m.id)
            .map((m) => ({ sourceId: m.id, excerptIndex: 0 }));
          while (citations.length < 4 && baseRaw && baseRaw.id) {
            citations.push({ sourceId: baseRaw.id, excerptIndex: 0 });
          }
          if (!citations.length && materials.length) {
            const fb = materials[0];
            citations = [{ sourceId: fb.id, excerptIndex: 0 }];
            while (citations.length < 4) citations.push({ sourceId: fb.id, excerptIndex: 0 });
          }
          const fullText = SUMMARY_RESPONSE_DEMO.replace('总结当前工作台中的主要疑点', userText ? `「${userText}」` : '所选资料');
          const splitIdx = fullText.indexOf('\n\n');
          let chatIntro = null;
          let bodyText = fullText;
          if (splitIdx > 0) {
            const intro = fullText.slice(0, splitIdx).trimEnd();
            const body = fullText.slice(splitIdx + 2).trimStart();
            if (intro) {
              chatIntro = intro;
              bodyText = body;
            }
          }
          return {
            id: 'm' + Date.now() + 2,
            role: 'bot',
            text: bodyText,
            ...(chatIntro ? { chatIntro, chatIntroProgress: 0 } : {}),
            chatRunSummary: DEMO_RUN_SUMMARY_TEXT,
            chatRunSummaryProgress: 0,
            citations,
            saved: false,
            chatResultTitle: (analysisTarget && String(analysisTarget.title || analysisTarget.name || '').trim()) || '',
          };
        },
        /** 演示用：旁白（text）、深度思考（deep_think）、工具步；技能调用后进入「规划中」清单（仅计划+勾选），执行过程在卡片下方以对话行追加（与真实模型无关） */
        buildDemoToolCalls(refTitles, userText) {
          const rawTitle = (Array.isArray(refTitles) && refTitles[0]) || (this.materials[0] && this.materials[0].title) || '工作台已加载资料';
          const fileLabel = String(rawTitle != null ? rawTitle : '资料').trim() || '资料';
          const q = String(userText || '').trim();
          const queryText = q.length >= 2 ? q.slice(0, 48) + (q.length > 48 ? '…' : '') : '合同金额 · 发票 · 审批流水';
          const lead = q.length >= 2
            ? `针对「${q.length > 20 ? q.slice(0, 18) + '…' : q}」，先对齐本次要用的资料范围与期望产出（疑点描述、证据指向、后续核查建议）。`
            : '先对齐本次问题的范围：结合工作台内已选资料与既有分析结果，输出可追溯的疑点与证据链。';
          const readActionDetailBody = [
            `文档：《${fileLabel}》`,
            `读取行号：L10–L30（演示）`,
            '',
            '回读片段（演示数据，非真实 OCR）：',
            '',
            '「……第四条 付款方式及进度',
            '（1）主体结构封顶后累计支付至合同价款的 50%；',
            '（2）竣工验收合格且资料移交完毕后支付尾款 50%；',
            '（3）乙方须在每次付款前提供等额合法有效的增值税专用发票……」',
          ].join('\n');
          const mkQueryActionDetailBody = (kw) => [
            '检索 / 关键词扩展（演示）',
            `主检索表达式：${kw}`,
            '',
            '命中统计（示意）：段落 12、表格 3、批注 0',
            '',
            'Top 命中标题：',
            '1) 付款方式与进度里程碑对照表',
            '2) 工程变更对合同价款的影响说明',
            '3) 质保金释放条件与尾款支付前提',
          ].join('\n');
          const skillActionDetailBody = [
            '技能（编排）调用明细（演示）',
            '技能名称：疑点归纳与交叉核对',
            '',
            '本次绑定上下文：',
            `- 主资料：${fileLabel}`,
            `- 用户问题摘要：${queryText}`,
            '',
            '运行参数（JSON）：',
            '{"runner":"skill_sandbox_v1","maxFindings":12,"strictCitations":true,"export":"csv"}',
          ].join('\n');
          const analysisArtifact = this.buildDemoAnalysisArtifact(refTitles, userText);
          return [
            { type: 'text', body: lead },
            {
              type: 'deep_think',
              body:
                '从「尾款 50%」与发票价税合计两条线索出发，优先验证时间先后：若发票早于合同约定的里程碑节点，需区分是预开票、暂估还是流程倒置；若晚于付款审批，则重点核对银行回单摘要与会计科目归集。\n\n'
                + '另需交叉核对：合同含税总额与采购订单、验收单是否闭环；若存在拆分开票或负数调整行，是否在备注与附件索引中可追溯；同时将「尾款」触发条件与保函/质保金释放条款对照，避免把制度性尾款与商务尾款混为一谈。',
            },
            { type: 'read', fileLabel, lineStart: 10, lineEnd: 30, actionDetailBody: readActionDetailBody },
            {
              type: 'text',
              body: '这一段同时出现付款节点、比例与「尾款」表述，和发票开具金额、审批流水里的实际支付时点可能对不上。下面在资料与结果里分多轮关键词检索，缩小需要人工核对的片段。',
            },
            { type: 'query', text: queryText, actionDetailBody: mkQueryActionDetailBody(queryText) },
            { type: 'query', text: '尾款 · 付款节点 · 合同 50%', actionDetailBody: mkQueryActionDetailBody('尾款 · 付款节点 · 合同 50%') },
            { type: 'query', text: '应付账款 · 银行流水 · 实际支付日期', demoToolStatus: 'fail', actionDetailBody: mkQueryActionDetailBody('应付账款 · 银行流水 · 实际支付日期') },
            { type: 'query', text: '采购审批单 · 发票号码 · 价税合计', actionDetailBody: mkQueryActionDetailBody('采购审批单 · 发票号码 · 价税合计') },
            {
              type: 'text',
              body: '检索命中若干段落；从金额、日期、科目三个维度粗对齐后，把仍无法解释的差额标成待核实项。接下来调用结构化技能做归纳与引用编号，再由技能要求驱动后续落地步骤。',
            },
            { type: 'skill', name: '疑点归纳与交叉核对', actionDetailBody: skillActionDetailBody },
            {
              type: 'text',
              body: '技能先给出检查框架与疑点口径（金额口径、时点先后、主体一致性）。下面按技能规则把核查动作拆成任务，先执行检索与回读，再统一产出结构化中间结果。',
            },
            {
              type: 'todo',
              contextFileLabel: fileLabel,
              items: [
                '按技能检查项核对「付款节点—发票—流水」时间链',
                '对未命中检索构造替代关键词并写入扩展备忘',
                '汇总异常并形成结构化中间结果，准备落入审计备忘录',
              ],
            },
            {
              type: 'analysis',
              id: 'analysis-' + Date.now().toString(36),
              fileName: '中间结果.csv',
              analysisArtifact,
            },
            {
              type: 'text',
              body: '核查任务已完成并生成中间结果：疑点条目、证据引用与风险分级已结构化。现在把可读结论同步写入审计备忘录草案，便于你继续追问或直接保存到结果。',
            },
            {
              type: 'edit',
              fileName: '审计备忘录-疑点摘录.md',
              /** 演示：点击 diff 卡标题栏时在结果栏打开的分析结果标题（正式环境可由接口返回结果 ID） */
              previewResultTitle: '合同与发票一致性检查结果',
              added: 2,
              removed: 1,
              diffExpanded: false,
              diffLines: [
                '- 待核实：合同金额与已开发票差异（演示）',
                '+ 待核实：合同金额与已开发票差异 [高风险]（演示）',
                '+ 建议：补充 2024Q4 对账单及剩余发票复印件',
                '  （上下文）第四条 付款方式按进度支付，尾款 50%。',
                '- 备注：原草稿行，仅在展开后可见',
                '+ 备注：已关联采购审批单 PR-2026-014',
              ],
            },
          ];
        },
        /** 与 type===text 相同：按字符流式输出（深度思考 deep_think） */
        isToolCallTextStream(call) {
          return !!(call && (call.type === 'text' || call.type === 'deep_think'));
        },
        /** deep_think 步已结束（进入后续 toolCalls）后收起为一行「思考 Ns」 */
        isDeepThinkCollapsed(msg, i) {
          if (!msg || msg.role !== 'thinking') return true;
          if (msg.thinkPhaseIndex == null) {
            return i < (msg.currentStep ?? 0);
          }
          return i < (msg.thinkPhaseIndex ?? 0);
        },
        formatDeepThinkSeconds(call) {
          const ms = call && call.deepThinkDurationMs;
          if (ms == null || Number.isNaN(ms)) return '1秒';
          const sec = Math.max(1, Math.round(ms / 1000));
          return sec + '秒';
        },
        toggleDeepThinkUserExpand(call) {
          if (!call || call.type !== 'deep_think') return;
          call.deepThinkUserExpanded = !call.deepThinkUserExpanded;
        },
        todoItemIsDone(call, ti) {
          return !!(call && call.todoDoneFlags && call.todoDoneFlags[ti]);
        },
        /** 规划中 | 执行中 | 执行完成（已翻篇的步骤固定为执行完成） */
        todoCardHeaderLabel(msg, i, call) {
          if (!call || call.type !== 'todo') return '规划中';
          const phase = msg.thinkPhaseIndex ?? 0;
          const past =
            msg.thinkPhaseIndex == null ? i < (msg.currentStep ?? 0) : i < phase;
          if (past) return '执行完成';
          if (call._todoUiPhase === 'planning') return '规划中';
          if (call._todoUiPhase === 'executing') return '执行中';
          if (call._todoUiPhase === 'complete') return '执行完成';
          return '执行完成';
        },
        /** 仅执行中及之后展示任务清单与下方动作流 */
        todoTaskListVisible(msg, i, call) {
          if (!call || call.type !== 'todo') return false;
          const phase = msg.thinkPhaseIndex ?? 0;
          const past =
            msg.thinkPhaseIndex == null ? i < (msg.currentStep ?? 0) : i < phase;
          if (past) return true;
          return call._todoUiPhase === 'executing' || call._todoUiPhase === 'complete';
        },
        /** 技能调用后「规划中」模拟步骤：思考 + 查询/编辑/阅读 + 勾选（渲染在规划卡下方的 todoExecutionLog） */
        buildTodoSimPlan(contextFileLabel) {
          const fl = String(contextFileLabel || '资料').trim() || '资料';
          return [
            { kind: 'think', text: '任务 1（技能检查项）：把合同付款节点、发票开具日与银行回单摘要映射到同一时间轴，标出「先票后款」「先款后票」类异常。', delayMs: 580 },
            { kind: 'query', text: '里程碑 · 开票日期 · 银行摘要 · 尾款 50%', delayMs: 760 },
            { kind: 'markDone', itemIndex: 0, delayMs: 440 },
            { kind: 'think', text: '任务 2（检索扩展）：对上一轮未命中段落做同义词与科目别名扩展，覆盖暂估、预开票、价税拆分等常见表述。', delayMs: 560 },
            { kind: 'query', text: '暂估 · 预开票 · 科目重分类 · 价税合计', delayMs: 720 },
            { kind: 'edit', fileName: '检索扩展备忘.md', detail: '追加候选关键词组', delayMs: 980 },
            { kind: 'markDone', itemIndex: 1, delayMs: 420 },
            { kind: 'think', text: '任务 3（汇总成型）：把已核对片段映射到疑点条目与引用编号字段，并回读资料头部摘要避免漏引。', delayMs: 540 },
            { kind: 'read', fileLabel: fl, lineStart: 1, lineEnd: 12, delayMs: 840 },
            { kind: 'markDone', itemIndex: 2, delayMs: 440 },
          ];
        },
        appendTodoExecutionLogEntry(call, step) {
          if (!call || !step || step.kind === 'markDone') return;
          if (!Array.isArray(call.todoExecutionLog)) call.todoExecutionLog = [];
          const id = 'tlog-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
          if (step.kind === 'think') {
            call.todoExecutionLog.push({ id, kind: 'think', text: step.text });
          } else if (step.kind === 'query') {
            call.todoExecutionLog.push({ id, kind: 'query', text: step.text, running: true });
          } else if (step.kind === 'read') {
            call.todoExecutionLog.push({
              id,
              kind: 'read',
              fileLabel: step.fileLabel,
              lineStart: step.lineStart,
              lineEnd: step.lineEnd,
              running: true,
            });
          } else if (step.kind === 'edit') {
            call.todoExecutionLog.push({
              id,
              kind: 'edit',
              fileName: step.fileName,
              detail: step.detail,
              running: true,
            });
          }
        },
        finalizeTodoExecutionLogEntryForStep(call, step) {
          if (!step || step.kind === 'markDone' || step.kind === 'think') return;
          const log = call.todoExecutionLog;
          if (!log || !log.length) return;
          const last = log[log.length - 1];
          if (last && last.running) last.running = false;
        },
        applyTodoMarkDoneStep(call, step) {
          if (step && step.kind === 'markDone' && call.todoDoneFlags && step.itemIndex != null) {
            const ix = step.itemIndex;
            if (ix >= 0 && ix < call.todoDoneFlags.length) {
              call.todoDoneFlags[ix] = true;
            }
          }
        },
        /** 三态：规划中（仅标题）→ 执行中（清单 1/2/3 + 下方动作）→ 执行完成；清单不在规划中展示 */
        advanceTodoPlanningDemo(thinking, idx) {
          const calls = thinking.toolCalls || [];
          const call = calls[idx];
          if (!call || call.type !== 'todo') return;
          const items = call.items || [];
          const planningHoldMs = 560;
          if (!call._todoPlanBuilt) {
            call._todoPlanBuilt = true;
            call._todoPlan = this.buildTodoSimPlan(call.contextFileLabel);
            call.todoDoneFlags = items.map(() => false);
            call._todoPlanIdx = 0;
            call.todoExecutionLog = [];
            call._todoUiPhase = 'planning';
            call._todoPlanningUntil = Date.now() + planningHoldMs;
            thinking.thinkToolStartedAt = null;
            return;
          }
          if (call._todoUiPhase === 'planning') {
            if (Date.now() < (call._todoPlanningUntil || 0)) return;
            call._todoUiPhase = 'executing';
            return;
          }
          const plan = call._todoPlan || [];
          const pi = call._todoPlanIdx ?? 0;
          if (pi >= plan.length) {
            call._todoUiPhase = 'complete';
            thinking.thinkPhaseIndex = idx + 1;
            thinking.thinkToolStartedAt = null;
            thinking.thinkTextChars = 0;
            if (thinking.thinkPhaseIndex >= calls.length) this.finalizeThinkingDemo(thinking);
            return;
          }
          const step = plan[pi];
          if (thinking.thinkToolStartedAt == null) {
            this.appendTodoExecutionLogEntry(call, step);
            thinking.thinkToolStartedAt = Date.now();
            return;
          }
          const need = step.delayMs != null ? step.delayMs : 650;
          if (Date.now() - thinking.thinkToolStartedAt < need) return;
          this.finalizeTodoExecutionLogEntryForStep(call, step);
          this.applyTodoMarkDoneStep(call, step);
          call._todoPlanIdx = pi + 1;
          thinking.thinkToolStartedAt = null;
        },
        /** 旧版 currentStep 演示兼容；新版用 thinkPhaseIndex + thinkTextChars */
        toolCallIsDone(msg, i) {
          if (msg.thinkPhaseIndex == null) {
            return i < (msg.currentStep ?? 0);
          }
          return i < (msg.thinkPhaseIndex ?? 0);
        },
        thinkingTextSlice(msg, call, i) {
          if (!this.isToolCallTextStream(call)) return '';
          const body = call.body || '';
          if (msg.thinkPhaseIndex == null) {
            const cur = msg.currentStep ?? 0;
            return i <= cur ? body : '';
          }
          const phase = msg.thinkPhaseIndex ?? 0;
          if (i < phase) return body;
          if (i > phase) return '';
          return body.slice(0, Math.min(body.length, msg.thinkTextChars ?? 0));
        },
        toolCallStepPending(msg, i) {
          const calls = msg.toolCalls || [];
          if (!calls.length) return false;
          if (msg.thinkPhaseIndex == null) {
            const cur = msg.currentStep ?? 0;
            if (cur >= calls.length) return false;
            return i === cur;
          }
          const phase = msg.thinkPhaseIndex ?? 0;
          if (phase >= calls.length || i !== phase) return false;
          const c = calls[i];
          return !!(c && !this.isToolCallTextStream(c));
        },
        /** read / query / skill / edit / todo 行首状态：进行中 | 成功 | 失败（演示） */
        toolCallActionStatus(msg, i, call) {
          if (!call || this.isToolCallTextStream(call)) return null;
          if (call.type === 'todo') {
            const plan = call._todoPlan || [];
            const pi = call._todoPlanIdx ?? 0;
            const planRunning = pi < plan.length;
            if (msg.thinkPhaseIndex == null) {
              const cur = msg.currentStep ?? 0;
              if (i < cur) return 'ok';
              if (i !== cur) return null;
              if (call._todoUiPhase === 'planning') return 'running';
              if (call._todoUiPhase === 'executing') return planRunning ? 'running' : 'ok';
              return 'ok';
            }
            const phase = msg.thinkPhaseIndex ?? 0;
            if (i < phase) return 'ok';
            if (i > phase) return null;
            if (call._todoUiPhase === 'planning') return 'running';
            if (call._todoUiPhase === 'executing') return planRunning ? 'running' : 'ok';
            return 'ok';
          }
          const calls = msg.toolCalls || [];
          if (msg.thinkPhaseIndex == null) {
            const cur = msg.currentStep ?? 0;
            if (i < cur) return call.demoToolStatus === 'fail' ? 'fail' : 'ok';
            if (i === cur && cur < calls.length) {
              const c = calls[i];
              if (c && !this.isToolCallTextStream(c)) return 'running';
            }
            return null;
          }
          const phase = msg.thinkPhaseIndex ?? 0;
          if (i < phase) return call.demoToolStatus === 'fail' ? 'fail' : 'ok';
          if (i > phase) return null;
          if (this.toolCallStepPending(msg, i)) return 'running';
          return 'ok';
        },
        advanceThinkingDemo(thinking) {
          if (!thinking || thinking._finalized) return;
          const calls = thinking.toolCalls || [];
          if (!calls.length) {
            this.finalizeThinkingDemo(thinking);
            return;
          }
          let idx = thinking.thinkPhaseIndex ?? 0;
          if (idx >= calls.length) {
            this.finalizeThinkingDemo(thinking);
            return;
          }
          const c = calls[idx];
          if (this.isToolCallTextStream(c)) {
            const body = c.body || '';
            if (!body.length) {
              if (c.type === 'deep_think') {
                c.deepThinkDurationMs = 0;
                delete c._deepThinkStart;
              }
              thinking.thinkPhaseIndex = idx + 1;
              thinking.thinkTextChars = 0;
              thinking.thinkToolStartedAt = null;
              if (thinking.thinkPhaseIndex >= calls.length) this.finalizeThinkingDemo(thinking);
              return;
            }
            let chars = thinking.thinkTextChars ?? 0;
            if (chars < body.length) {
              if (c.type === 'deep_think' && c._deepThinkStart == null) {
                c._deepThinkStart = Date.now();
              }
              const n = body.length;
              const perTick = n > 140 ? 3 : n > 55 ? 2 : 1;
              thinking.thinkTextChars = Math.min(body.length, chars + perTick);
              return;
            }
            if (c.type === 'deep_think') {
              if (c._deepThinkStart != null) {
                c.deepThinkDurationMs = Date.now() - c._deepThinkStart;
                delete c._deepThinkStart;
              } else {
                c.deepThinkDurationMs = c.deepThinkDurationMs ?? 0;
              }
            }
            thinking.thinkPhaseIndex = idx + 1;
            thinking.thinkTextChars = 0;
            thinking.thinkToolStartedAt = null;
            if (thinking.thinkPhaseIndex >= calls.length) this.finalizeThinkingDemo(thinking);
            return;
          }
          if (c.type === 'todo') {
            this.advanceTodoPlanningDemo(thinking, idx);
            return;
          }
          if (thinking.thinkToolStartedAt == null) {
            thinking.thinkToolStartedAt = Date.now();
            return;
          }
          const delays = { read: 920, query: 780, skill: 1200, analysis: 1350, edit: 1400 };
          const need = delays[c.type] || 850;
          if (Date.now() - thinking.thinkToolStartedAt < need) return;
          thinking.thinkPhaseIndex = idx + 1;
          thinking.thinkToolStartedAt = null;
          thinking.thinkTextChars = 0;
          if (thinking.thinkPhaseIndex >= calls.length) this.finalizeThinkingDemo(thinking);
        },
        /** 有 chatIntro 时先逐字显示引导句，结束后再露出 Markdown 并启动收尾总结打字 */
        displayChatIntroSlice(msg) {
          if (!msg || !msg.chatIntro) return '';
          const full = msg.chatIntro;
          const p = msg.chatIntroProgress;
          if (p == null) return full;
          return full.slice(0, Math.min(full.length, p));
        },
        chatIntroRevealMarkdown(msg) {
          if (!msg || !msg.chatIntro) return true;
          const len = (msg.chatIntro || '').length;
          const p = msg.chatIntroProgress;
          if (p == null) return true;
          return p >= len;
        },
        scheduleChatIntroTypewriter(botMsg) {
          if (!botMsg || !botMsg.chatIntro) {
            this.scheduleBotRunSummary(botMsg);
            return;
          }
          const msgId = botMsg.id;
          botMsg.chatIntroProgress = 0;
          if (botMsg._chatIntroIv) {
            clearInterval(botMsg._chatIntroIv);
            botMsg._chatIntroIv = null;
          }
          const iv = setInterval(() => {
            const cur = this.chatMessages.find((x) => x.id === msgId);
            if (!cur || !cur.chatIntro) {
              clearInterval(iv);
              return;
            }
            const len = cur.chatIntro.length;
            const step = len > 80 ? 2 : 1;
            const next = Math.min(len, (cur.chatIntroProgress || 0) + step);
            cur.chatIntroProgress = next;
            if (next >= len) {
              clearInterval(iv);
              cur._chatIntroIv = null;
              this.scheduleBotRunSummary(cur);
            }
            this.$nextTick(() => {
              const w = this.$refs.chatMessages;
              if (w) w.scrollTop = w.scrollHeight;
            });
          }, 42);
          const m = this.chatMessages.find((x) => x.id === msgId);
          if (m) m._chatIntroIv = iv;
        },
        scheduleBotRunSummary(botMsg) {
          if (!botMsg || !botMsg.chatRunSummary) return;
          const msgId = botMsg.id;
          botMsg.chatRunSummaryProgress = 0;
          if (botMsg._runSummaryIv) {
            clearInterval(botMsg._runSummaryIv);
            botMsg._runSummaryIv = null;
          }
          if (botMsg._runSummaryStartTid) {
            clearTimeout(botMsg._runSummaryStartTid);
            botMsg._runSummaryStartTid = null;
          }
          const tid = setTimeout(() => {
            const m = this.chatMessages.find((x) => x.id === msgId);
            if (m) m._runSummaryStartTid = null;
            if (!m || !m.chatRunSummary) return;
            const iv = setInterval(() => {
              const cur = this.chatMessages.find((x) => x.id === msgId);
              if (!cur || !cur.chatRunSummary) {
                clearInterval(iv);
                return;
              }
              const len = cur.chatRunSummary.length;
              const step = len > 100 ? 2 : 1;
              const next = Math.min(len, (cur.chatRunSummaryProgress || 0) + step);
              cur.chatRunSummaryProgress = next;
              if (next >= len) {
                clearInterval(iv);
                cur._runSummaryIv = null;
              }
              this.$nextTick(() => {
                const w = this.$refs.chatMessages;
                if (w) w.scrollTop = w.scrollHeight;
              });
            }, 46);
            m._runSummaryIv = iv;
          }, 520);
          botMsg._runSummaryStartTid = tid;
        },
        finalizeThinkingDemo(thinking) {
          if (!thinking || thinking._finalized) return;
          thinking._finalized = true;
          if (thinking._intervalId) {
            clearInterval(thinking._intervalId);
            thinking._intervalId = null;
          }
          const thinkId = thinking.id;
          const userText = thinking._demoSendText || '';
          const botMsg = this.buildDemoAnalysisBotMessage(userText);
          const ins = this.chatMessages.findIndex((m) => m.id === thinkId);
          if (ins >= 0) this.chatMessages.splice(ins + 1, 0, botMsg);
          else this.chatMessages.push(botMsg);
          this.$nextTick(() => {
            const w = this.$refs.chatMessages;
            if (w) w.scrollTop = w.scrollHeight;
            this.scheduleChatIntroTypewriter(botMsg);
          });
        },
        toolDiffLineClass(line) {
          return demoToolDiffLineClass(line);
        },
        visibleToolDiffLines(call, expanded) {
          const lines = call.diffLines || [];
          if (expanded) return lines;
          return lines.slice(0, 4);
        },
        toggleToolDiffExpand(toolCall) {
          if (!toolCall || toolCall.type !== 'edit') return;
          toolCall.diffExpanded = !toolCall.diffExpanded;
        },
        /** 查询 / 阅读 / 调用 / 分析 工具行下方「展开详情」正文（演示数据，接口可写入 actionDetailBody 覆盖） */
        toolCallActionDetailBody(call) {
          if (!call) return '';
          const custom = call.actionDetailBody != null ? String(call.actionDetailBody).trim() : '';
          if (custom) return String(call.actionDetailBody);
          if (call.type === 'analysis' && call.analysisArtifact && typeof call.analysisArtifact.csvData === 'string' && call.analysisArtifact.csvData.trim()) {
            return ['结构化中间结果（CSV）', '', String(call.analysisArtifact.csvData)].join('\n');
          }
          return '';
        },
        toolCallActionDetailLines(call) {
          const t = this.toolCallActionDetailBody(call);
          if (!t) return [];
          return t.split(/\r?\n/);
        },
        toolCallActionDetailTitle(call) {
          const map = { query: '查询详情', read: '阅读详情', skill: '调用详情', analysis: '分析详情' };
          return map[call && call.type] || '详情';
        },
        toggleToolCallActionDetailExpand(call) {
          if (!call || !['query', 'read', 'skill', 'analysis'].includes(call.type)) return;
          if (!this.toolCallActionDetailBody(call)) return;
          call._actionDetailExpanded = !call._actionDetailExpanded;
        },
        copyToolCallActionDetail(call) {
          const body = this.toolCallActionDetailBody(call);
          if (!body) {
            message.info('暂无可复制内容');
            return;
          }
          navigator.clipboard?.writeText(body);
          this.toastMessage = '已复制';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        chatBotResultHasBody(msg) {
          return !!(msg && msg.role === 'bot' && String(msg.text || '').trim());
        },
        chatBotResultWriteTitle(msg) {
          if (!this.chatBotResultHasBody(msg)) return '分析结果';
          const explicit = String(msg.chatResultTitle || '').trim();
          if (explicit) return explicit.slice(0, 80);
          const raw = String(msg.text || '').trim();
          const m = raw.match(/^#{1,6}\s+(.+)$/m);
          if (m) return m[1].trim().slice(0, 80) || '分析结果';
          const first = raw.split(/\r?\n/).find((ln) => String(ln || '').trim());
          const t = String(first || '').trim().replace(/^[-*\d.\s]+/, '');
          return (t || '分析结果').slice(0, 80);
        },
        chatBotResultWriteLine(msg) {
          return `写入《${this.chatBotResultWriteTitle(msg)}》`;
        },
        toggleChatBotResultMdExpand(msg) {
          if (!this.chatBotResultHasBody(msg)) return;
          msg._chatResultMdExpanded = !msg._chatResultMdExpanded;
        },
        copyChatBotResultMarkdown(msg) {
          const t = String(msg && msg.text || '').trim();
          if (!t) {
            message.info('暂无可复制内容');
            return;
          }
          navigator.clipboard?.writeText(t);
          this.toastMessage = '已复制';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        buildDemoAnalysisArtifact(refTitles, userText) {
          const selected = (Array.isArray(refTitles) ? refTitles : []).filter(Boolean);
          const fallbackTitles = (this.materials || [])
            .filter((m) => m && m.type === 'raw')
            .slice(0, 3)
            .map((m) => m.title || m.name || '未命名资料');
          const sourceLabels = (selected.length ? selected : fallbackTitles).slice(0, 3);
          const displayPrompt = String(userText || '').trim() || '当前工作台资料一致性分析';
          const generatedAt = new Date().toISOString().slice(0, 19).replace('T', ' ');
          return {
            fileName: '中间结果.csv',
            toolName: '分析工具',
            generatedAt,
            sourceLabels,
            hitCount: 6,
            objectCount: 3,
            summaryItems: [
              { label: '命中对象', value: '3 个对象' },
              { label: '异常条目', value: '3 条高风险疑点' },
              { label: '来源资料', value: `${sourceLabels.length} 份资料` },
              { label: '处理状态', value: '已生成' },
            ],
            jsonData: {
              task: 'analysis_tool',
              prompt: displayPrompt,
              sourceMaterials: sourceLabels.map((label, index) => ({ id: `src-${index + 1}`, label })),
              summary: { objectCount: 3, hitCount: 6, riskLevel: 'high' },
              findings: [
                { id: 'finding-1', title: '合同金额与累计开票金额不一致', severity: 'high', evidenceRefs: ['E1'], suggestion: '补充补充协议与红冲记录核对口径' },
                { id: 'finding-2', title: '付款日期早于验收节点', severity: 'high', evidenceRefs: ['E2'], suggestion: '核查是否存在先付后验的审批豁免' },
                { id: 'finding-3', title: '供应商主体名称存在近似差异', severity: 'medium', evidenceRefs: ['E3'], suggestion: '补充主体授权与开户证明资料' },
              ],
            },
            csvData: [
              '疑点ID,疑点标题,风险等级,证据引用,建议动作',
              '"finding-1","合同金额与累计开票金额不一致","高","E1","补充补充协议与红冲记录核对口径"',
              '"finding-2","付款日期早于验收节点","高","E2","核查是否存在先付后验的审批豁免"',
              '"finding-3","供应商主体名称存在近似差异","中","E3","补充主体授权与开户证明资料"',
            ].join('\n'),
            resultMarkdown: [
              '## 一、分析结论',
              `围绕“${displayPrompt}”，分析工具对 ${sourceLabels.join('、')} 进行了结构化对齐，识别出金额口径差异、付款时点异常与主体名称近似不一致三类问题。`,
              '',
              '## 二、关键发现',
              '- 合同金额与累计开票金额存在差异，需补充核验变更与红冲记录。（1）',
              '- 付款发生在验收完成前，存在流程倒置风险。（2）',
              '- 供应商主体名称在合同与开户信息中表述不一致，需确认是否为同一主体。（3）',
              '',
              '## 三、建议动作',
              '- 先核对金额差异的变更依据与对账口径。',
              '- 再复核付款、验收、审批三者的时间链。',
              '- 最后补齐主体授权、开户与工商登记资料。',
              '',
              '---',
              '',
              '### 引用信息',
              '',
              `**（1）${DEMO_ANALYSIS_CITATION_MAP.E1.sourceLabel}**`,
              ...String(DEMO_ANALYSIS_CITATION_MAP.E1.sourceExcerpt || '').split('\n').map((line) => `> ${line}`),
              '',
              `**（2）${DEMO_ANALYSIS_CITATION_MAP.E2.sourceLabel}**`,
              ...String(DEMO_ANALYSIS_CITATION_MAP.E2.sourceExcerpt || '').split('\n').map((line) => `> ${line}`),
              '',
              `**（3）${DEMO_ANALYSIS_CITATION_MAP.E3.sourceLabel}**`,
              ...String(DEMO_ANALYSIS_CITATION_MAP.E3.sourceExcerpt || '').split('\n').map((line) => `> ${line}`),
            ].join('\n'),
          };
        },
        analysisToolCallLabel(call) {
          const labels = Array.isArray(call && call.analysisArtifact && call.analysisArtifact.sourceLabels)
            ? call.analysisArtifact.sourceLabels.filter(Boolean)
            : [];
          if (!labels.length) return '分析已选资料并生成结构化中间结果';
          return `分析 ${labels.join('、')}`;
        },
        /** 思考轨内「编辑」diff 卡标题栏：在右侧结果区打开对应分析结果（演示用 previewResultTitle / 文件名启发式） */
        openChatToolEditPreview(call) {
          if (!call || call.type !== 'edit') return;
          const materials = this.materials || [];
          const analyses = materials.filter((m) => m && m.type === 'analysis');
          let target = null;
          const hint = String(call.previewResultTitle || '').trim();
          if (hint) {
            target =
              analyses.find((m) => String(m.title || '').trim() === hint) ||
              analyses.find((m) => String(m.title || '').includes(hint));
          }
          if (!target) {
            const stem = String(call.fileName || '')
              .replace(/\.(md|markdown)$/i, '')
              .trim();
            if (stem) {
              target = analyses.find((m) => {
                const t = String(m.title || '');
                return t.includes(stem) || stem.includes(t);
              });
            }
          }
          if (!target) {
            target = analyses.find((m) => this.canOpenAnalysisPreview(m)) || analyses[0];
          }
          if (!target) {
            message.info('当前工作台暂无可预览的分析结果');
            return;
          }
          if (!this.canOpenAnalysisPreview(target)) {
            message.info('该结果尚未完成，暂不可预览');
            return;
          }
          this.sourcesCollapsed = false;
          this.studioCollapsed = false;
          this.clearWorkbenchAnalysisCitationFloats();
          this.openMaterialDetail(target);
        },
        createWorkbenchResultRowFromMarkdown(payload) {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('缺少工作台上下文');
            return null;
          }
          const title = String(payload && payload.name || '').trim();
          const markdown = String(payload && payload.markdown || '').trim();
          if (!title || !markdown) return null;
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const id = 'ar-msg-' + Date.now();
          const row = {
            id,
            name: title,
            resultTreeBucket: 'dialog',
            resultFolderId: null,
            sourceSkillName: '审计助手对话',
            createdAt: now,
            status: 'done',
            analysisMarkdown: markdown,
          };
          if (!demoProjectAnalysisResultsById[pid]) demoProjectAnalysisResultsById[pid] = [];
          demoProjectAnalysisResultsById[pid].unshift(row);
          const material = mapAnalysisResultRowToWorkbench(row, pid);
          material.analysisMarkdown = row.analysisMarkdown;
          material.excerpts = [row.analysisMarkdown];
          material.excerptsWithCitations = [{ text: row.analysisMarkdown, citations: [] }];
          material.overview = String(payload && payload.overview || markdown).slice(0, 150) + (markdown.length > 150 ? '...' : '');
          this.materials.push(material);
          this.selectedMaterialId = material.id;
          this.sourcesCollapsed = false;
          this.studioCollapsed = false;
          this.clearWorkbenchAnalysisCitationFloats();
          this.sourcesRightView = 'detail';
          this.sourcesLeftView = 'list';
          this.sourcesDetailWidth = 450;
          material.checked = true;
          return { row, material };
        },
        clearChatThinkingIntervals() {
          (this.chatMessages || []).forEach((m) => {
            if (m._intervalId) {
              clearInterval(m._intervalId);
              m._intervalId = null;
            }
            if (m._runSummaryStartTid) {
              clearTimeout(m._runSummaryStartTid);
              m._runSummaryStartTid = null;
            }
            if (m._runSummaryIv) {
              clearInterval(m._runSummaryIv);
              m._runSummaryIv = null;
            }
            if (m._chatIntroIv) {
              clearInterval(m._chatIntroIv);
              m._chatIntroIv = null;
            }
          });
        },
        /** 停止当前轮演示定时器：思考轨中途停止不再插入 bot；已出现的 bot 则瞬间补全引导语与收尾总结 */
        pauseChatGeneration() {
          const list = this.chatMessages || [];
          for (let i = list.length - 1; i >= 0; i--) {
            const m = list[i];
            if (m.role !== 'bot') continue;
            const introLen = (m.chatIntro || '').length;
            const introGoing = !!(m.chatIntro && introLen && m.chatIntroProgress != null && m.chatIntroProgress < introLen);
            const rs = m.chatRunSummary || '';
            const runGoing = !!(rs.length && (m.chatRunSummaryProgress ?? 0) < rs.length);
            if (!introGoing && !runGoing) continue;
            if (m._chatIntroIv) {
              clearInterval(m._chatIntroIv);
              m._chatIntroIv = null;
            }
            if (introLen) m.chatIntroProgress = introLen;
            if (m._runSummaryStartTid) {
              clearTimeout(m._runSummaryStartTid);
              m._runSummaryStartTid = null;
            }
            if (m._runSummaryIv) {
              clearInterval(m._runSummaryIv);
              m._runSummaryIv = null;
            }
            if (rs.length) m.chatRunSummaryProgress = rs.length;
            this.toastMessage = '已暂停生成';
            setTimeout(() => {
              this.toastMessage = '';
            }, 1500);
            return;
          }
          for (let i = list.length - 1; i >= 0; i--) {
            const m = list[i];
            if (m.role !== 'thinking' || m._finalized) continue;
            if (m._intervalId) {
              clearInterval(m._intervalId);
              m._intervalId = null;
            }
            m._finalized = true;
            m._generationPaused = true;
            this.toastMessage = '已暂停生成';
            setTimeout(() => {
              this.toastMessage = '';
            }, 1500);
            return;
          }
        },
        viewExtractionResult(id) {
          this.clearWorkbenchAnalysisCitationFloats();
          this.selectedExtractionId = id;
          this.sourcesLeftView = 'detail';
          this.sourcesRightView = 'list';
          this.sourcesDetailWidth = 450;
        },
        removeExtractionResult(id) {
          this.extractionResults = this.extractionResults.filter(r => r.id !== id);
          if (this.selectedExtractionId === id) {
            this.selectedExtractionId = null;
            this.selectedTreeNode = null;
            this.sourcesLeftView = 'list';
            this.sourcesWidth = 300;
          }
        },
        importExtractionResult(item) {
          if (item.status !== 'done' || !item.snippets) return;
          const pid = this.workbenchProjectId;
          if (!pid) return;
          const id = 'ar-ext-' + Date.now();
          const title = item.dataSourceName + ' 抽取结果';
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const row = {
            id,
            name: title,
            resultTreeBucket: 'dialog',
            resultFolderId: null,
            sourceSkillName: String(item.dataSourceName || '结构化抽取').trim() || '结构化抽取',
            createdAt: now,
            status: 'done',
          };
          if (!demoProjectAnalysisResultsById[pid]) demoProjectAnalysisResultsById[pid] = [];
          demoProjectAnalysisResultsById[pid].unshift(row);
          const material = mapAnalysisResultRowToWorkbench(row, pid);
          material.excerpts = item.snippets.map((s) => s.title + '\n' + s.desc);
          material.excerptsWithCitations = item.snippets.map((s) => ({ text: s.title + '：' + s.desc, citations: [] }));
          material.overview = '从 ' + item.dataSourceName + ' 抽取的 ' + item.snippets.length + ' 条结果';
          this.materials.push(material);
          this.selectedMaterialId = material.id;
          this.extractionResults = this.extractionResults.filter((r) => r.id !== item.id);
          if (this.selectedExtractionId === item.id) {
            this.selectedExtractionId = null;
            this.selectedTreeNode = null;
            this.sourcesLeftView = 'list';
          }
          this.toastMessage = '已导入到结果';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        goBackToProjectCenter() {
          window.location.hash = 'project' + (this.workbenchProjectId ? '/' + this.workbenchProjectId : '');
          window.dispatchEvent(new HashChangeEvent('hashchange'));
        },
        goBackToProjectCenterList() {
          window.location.hash = 'project';
          window.dispatchEvent(new HashChangeEvent('hashchange'));
        },
        openWorkbenchProjectEdit() {
          const pid = this.workbenchProjectId;
          if (!pid) return;
          const bridge = window.__demoQuoteSkillBridge;
          if (bridge && typeof bridge.openEditForWorkbenchProject === 'function') {
            bridge.openEditForWorkbenchProject(pid);
            return;
          }
          message.warning('工作台编辑入口暂不可用，请稍后重试');
        },
        onWorkbenchHeaderMenu(info) {
          if (info && info.key === 'edit') this.openWorkbenchProjectEdit();
        },
        enterExperienceDraftMode() {
          this.layoutMode = 'B';
          this.experienceDrafts = { extract: '（抽取技能草案占位）', analysis: '（分析技能草案占位）', report: '（报告技能草案占位）' };
        },
        exitExperienceDraftMode() { this.layoutMode = 'A'; },
        saveExperienceToTemplate() {
          this.layoutMode = 'A';
          this.toastMessage = '已保存至技能库';
          window.location.hash = 'template';
          setTimeout(() => { this.toastMessage = ''; window.dispatchEvent(new HashChangeEvent('hashchange')); }, 1500);
        },
        setExcerptRef(sourceId, index, el) {
          if (!el) return;
          if (!this.excerptRefs[sourceId]) this.excerptRefs[sourceId] = {};
          this.excerptRefs[sourceId][index] = el;
        },
        /** 与 `wbMaterialTypeIcon` 同源：仅返回 `fa-*` 后缀，供 `class="fas …"` 拼接 */
        wbFileIconSuffixFromFormatName(format, fileName) {
          let f = String(format || '').trim();
          const nm = String(fileName || '').trim();
          const guessFromName = () => {
            const lower = nm.toLowerCase();
            if (lower.endsWith('.pdf')) return 'PDF';
            if (/\.(xlsx|xls|csv)$/i.test(lower)) return 'XLSX';
            if (/\.(docx|doc)$/i.test(lower)) return 'DOCX';
            if (/\.json$/i.test(lower)) return 'JSON';
            return '';
          };
          if (!f && nm) f = guessFromName();
          const u = String(f).toUpperCase();
          if (u === 'PDF') return 'fa-file-pdf';
          if (u === 'XLSX' || u === 'XLS' || u === 'CSV') return 'fa-file-excel';
          if (u === 'DOCX' || u === 'DOC') return 'fa-file-word';
          if (u === 'JSON') return 'fa-file-code';
          return 'fa-file-lines';
        },
        getMaterialIcon(m) {
          if (!m) return 'fa-file-lines';
          if (m.type === 'raw') {
            if (m.rawSubtype === 'table') return 'fa-file-excel';
            const ps = m.projectSource || {};
            return this.wbFileIconSuffixFromFormatName(m.format || ps.format, m.title || ps.name);
          }
          if (m.type === 'analysis') {
            const ps = m.projectSource || {};
            const fmt = String((m.format || ps.format) || '').toUpperCase();
            const name = String(m.title || ps.name || '').trim();
            if (fmt === 'MD' || fmt === 'MARKDOWN' || /\.md$/i.test(name)) return 'fa-file-lines';
            return 'fa-file-signature';
          }
          return 'fa-file-lines';
        },
        getMaterialIconColorClass(m) {
          if (!m) return '';
          const doneOk = m.type === 'analysis' ? this.workbenchAnalysisStatusOf(m) === 'done' : this.isWorkbenchMaterialDone(m);
          if (!doneOk) return '';
          const ps = m.projectSource || {};
          let fmt = String((m.format || ps.format) || '').toUpperCase();
          const name = String(m.title || ps.name || '').trim();
          if (!fmt && name) {
            const lower = name.toLowerCase();
            if (lower.endsWith('.pdf')) fmt = 'PDF';
            else if (/\.(xlsx|xls|csv)$/i.test(lower)) fmt = 'XLSX';
            else if (/\.(docx|doc)$/i.test(lower)) fmt = 'DOCX';
            else if (/\.json$/i.test(lower)) fmt = 'JSON';
          }
          if (fmt === 'MD' || fmt === 'MARKDOWN') return 'is-md';
          if (fmt === 'PDF') return 'is-pdf';
          if (fmt === 'XLSX' || fmt === 'XLS' || fmt === 'CSV') return 'is-sheet';
          if (fmt === 'DOCX' || fmt === 'DOC') return 'is-doc';
          if (fmt === 'JSON') return 'is-data';
          if (m.type === 'analysis') {
            if (/\.md$/i.test(name)) return 'is-md';
          }
          return '';
        },
        workbenchMaterialStatusOf(m) {
          const status = (m && m.projectSource && m.projectSource.status) || (m && m.status) || 'queued';
          if (status === 'queued' || status === 'parsing' || status === 'done' || status === 'failed') return status;
          return 'queued';
        },
        workbenchAnalysisStatusOf(m) {
          const status = (m && m.projectSource && m.projectSource.status) || (m && m.status) || 'done';
          if (status === 'queued' || status === 'parsing' || status === 'done' || status === 'failed') return status;
          return 'done';
        },
        canOpenAnalysisPreview(m) {
          if (!m || m.type !== 'analysis') return true;
          return this.workbenchAnalysisStatusOf(m) === 'done';
        },
        canOpenMaterialPreview(m) {
          if (!m || m.type !== 'raw') return true;
          return this.workbenchMaterialStatusOf(m) === 'done';
        },
        workbenchMaterialProgressOf(m) {
          const p = Number((m && m.projectSource && m.projectSource.progress) ?? (m && m.progress) ?? 0);
          if (Number.isNaN(p)) return 0;
          return Math.max(0, Math.min(100, p));
        },
        workbenchMaterialStatusLabel(status) {
          const map = { queued: '排队中', parsing: '解析中', done: '完成', failed: '失败' };
          return map[status] || '排队中';
        },
        workbenchMaterialProgressStatus(m) {
          const status = this.workbenchMaterialStatusOf(m);
          if (status === 'failed') return 'exception';
          if (status === 'done') return 'success';
          return 'active';
        },
        isWorkbenchMaterialDone(m) {
          return this.workbenchMaterialStatusOf(m) === 'done';
        },
        filteredWorkbenchRawMaterials(rawRows) {
          const rows = Array.isArray(rawRows) ? rawRows : [];
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const timeOf = (v) => {
            const t = Date.parse(String(v || '').trim());
            return Number.isNaN(t) ? 0 : t;
          };
          return [...rows].sort((a, b) => {
            const aSource = a.projectSource || {};
            const bSource = b.projectSource || {};
            const byName = () => collator.compare(String(a.title || ''), String(b.title || ''));
            return timeOf(bSource.uploadedAt || b.meta) - timeOf(aSource.uploadedAt || a.meta) || byName();
          });
        },
        rerunWorkbenchMaterial(m) {
          if (!m || (m.type && m.type !== 'raw') || !this.workbenchProjectId) return;
          if (this.workbenchMaterialStatusOf(m) === 'done') return;
          const arr = demoProjectMaterialsById[this.workbenchProjectId] || [];
          const idx = arr.findIndex((x) => x.id === m.id);
          if (idx < 0) return;
          arr.splice(idx, 1, { ...arr[idx], status: 'parsing', progress: 12 });
          if (m.projectSource) {
            m.projectSource.status = 'parsing';
            m.projectSource.progress = 12;
          }
          this.toastMessage = '已加入重跑队列';
          setTimeout(() => { this.toastMessage = ''; }, 1200);
        },
        abortWorkbenchMaterial(m) {
          if (!m || (m.type && m.type !== 'raw') || !this.workbenchProjectId) return;
          if (this.workbenchMaterialStatusOf(m) !== 'parsing') return;
          const arr = demoProjectMaterialsById[this.workbenchProjectId] || [];
          const idx = arr.findIndex((x) => x.id === m.id);
          if (idx < 0) return;
          arr.splice(idx, 1, { ...arr[idx], status: 'failed', progress: 0 });
          if (m.projectSource) {
            m.projectSource.status = 'failed';
            m.projectSource.progress = 0;
          }
          this.toastMessage = '已中止解析';
          setTimeout(() => { this.toastMessage = ''; }, 1200);
        },
        _setWorkbenchBatchToast(text, timeout = 1200) {
          this.toastMessage = text;
          setTimeout(() => { this.toastMessage = ''; }, timeout);
        },
        batchAbortWorkbenchMaterials() {
          const targets = this.workbenchMaterialBatchTargets || [];
          if (!targets.length || this.workbenchMaterialStatusView !== 'parsing' || !this.workbenchProjectId) return;
          const arr = demoProjectMaterialsById[this.workbenchProjectId] || [];
          if (!arr.length) return;
          const idSet = new Set(targets.map((m) => m.id));
          let changed = 0;
          arr.forEach((row) => {
            if (!row || !idSet.has(row.id) || row.status !== 'parsing') return;
            row.status = 'failed';
            row.progress = 0;
            changed += 1;
          });
          if (!changed) return;
          (this.materials || []).forEach((m) => {
            if (!m || !idSet.has(m.id) || this.workbenchMaterialStatusOf(m) !== 'parsing') return;
            if (m.projectSource) {
              m.projectSource.status = 'failed';
              m.projectSource.progress = 0;
            } else {
              m.status = 'failed';
              m.progress = 0;
            }
          });
          this._setWorkbenchBatchToast(`已中止 ${changed} 个资料`);
        },
        batchRerunWorkbenchMaterials() {
          const targets = this.workbenchMaterialBatchTargets || [];
          const view = this.workbenchMaterialStatusView || 'all';
          if (!targets.length || (view !== 'parsing' && view !== 'failed') || !this.workbenchProjectId) return;
          const arr = demoProjectMaterialsById[this.workbenchProjectId] || [];
          if (!arr.length) return;
          const idSet = new Set(targets.map((m) => m.id));
          let changed = 0;
          arr.forEach((row) => {
            if (!row || !idSet.has(row.id)) return;
            row.status = 'parsing';
            row.progress = 12;
            changed += 1;
          });
          if (!changed) return;
          (this.materials || []).forEach((m) => {
            if (!m || !idSet.has(m.id)) return;
            if (m.projectSource) {
              m.projectSource.status = 'parsing';
              m.projectSource.progress = 12;
            } else {
              m.status = 'parsing';
              m.progress = 12;
            }
          });
          this._setWorkbenchBatchToast(`已重跑 ${changed} 个资料`);
        },
        batchClearWorkbenchMaterials() {
          const targets = this.workbenchMaterialBatchTargets || [];
          if (!targets.length || !this.workbenchProjectId) return;
          const idSet = new Set(targets.map((m) => m.id));
          const arr = demoProjectMaterialsById[this.workbenchProjectId] || [];
          if (arr.length) {
            for (let i = arr.length - 1; i >= 0; i -= 1) {
              if (idSet.has(arr[i].id)) arr.splice(i, 1);
            }
          }
          const removedSelected = this.selectedMaterialId && idSet.has(this.selectedMaterialId);
          for (let i = (this.materials || []).length - 1; i >= 0; i -= 1) {
            if (idSet.has(this.materials[i].id)) this.materials.splice(i, 1);
          }
          if (removedSelected) {
            const next = (this.workbenchRawMaterialsForTree || [])[0] || this.materials[0] || null;
            this.selectedMaterialId = next ? next.id : null;
            if (!next) {
              this.selectedTreeNode = null;
              this.sourcesLeftView = 'list';
            }
          }
          this._setWorkbenchBatchToast(`已清空 ${targets.length} 个资料`, 1500);
        },
        materialMeta(m) {
          if (!m) return '—';
          if (m.meta) return m.meta;
          if (m.createdAt) return typeof m.createdAt === 'string' ? m.createdAt : '—';
          return '—';
        },
        noop() {},
        toggleAllMaterials() {
          const checked = !this.allMaterialsChecked;
          this.materials.forEach(m => { m.checked = checked; });
        },
        handleMaterialMenuClick(key, m) {
          if (!m) return;
          if (key === 'rerun') {
            if (m.type && m.type !== 'raw') return;
            if (this.workbenchMaterialStatusOf(m) === 'done') return;
            this.rerunWorkbenchMaterial(m);
            return;
          }
          if (key === 'delete') {
            if ((this.workbenchCreatedTasks || []).some((t) => t && t.id === m.id)) {
              this.deleteWorkbenchCreatedTask(m);
              return;
            }
            this.deleteMaterial(m);
          }
        },
        deleteWorkbenchCreatedTask(m) {
          if (!m || !m.id) return;
          Modal.confirm({
            centered: true,
            title: '删除任务',
            content: '删除后该任务从工作台任务列表移除（演示，不保留历史）。',
            okText: '删除',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              this.workbenchCreatedTasks = (this.workbenchCreatedTasks || []).filter((t) => t.id !== m.id);
              if (this.selectedMaterialId === m.id) {
                this.closeWorkbenchMaterialDetail();
              }
              this.selectedTreeNode = null;
              message.success('任务已删除');
            },
          });
        },
        rerunWorkbenchCreatedTask(m) {
          if (!m || !m.id) return;
          Modal.confirm({
            centered: true,
            title: '重跑任务',
            content: '重跑将清空之前已产出的结果（演示）。是否继续？',
            okText: '重跑',
            cancelText: '取消',
            onOk: () => {
              const t = this.resolveCreatedWorkbenchTaskRef(m);
              if (!t) return;
              t.status = 'queued';
              t.projectSource = t.projectSource || {};
              t.projectSource.status = 'queued';
              message.success('已提交重跑（演示）');
            },
          });
        },
        abortWorkbenchCreatedTask(m) {
          if (!m || !m.id) return;
          const st = this.workbenchAnalysisStatusOf(m);
          if (st !== 'queued' && st !== 'parsing') return;
          Modal.confirm({
            centered: true,
            title: '中止任务',
            content: '中止后任务将进入失败态，可通过重跑再次执行（演示）。',
            okText: '中止',
            cancelText: '取消',
            onOk: () => {
              const t = this.resolveCreatedWorkbenchTaskRef(m);
              if (!t) return;
              t.status = 'failed';
              t.projectSource = t.projectSource || {};
              t.projectSource.status = 'failed';
              message.info('已中止（演示）');
            },
          });
        },
        deleteMaterial(m) {
          const pid = this.workbenchProjectId;
          if (m && m.projectSource && pid) {
            if (m.type === 'analysis') {
              const arr = demoProjectAnalysisResultsById[pid];
              if (arr) {
                const j = arr.findIndex((x) => x.id === m.id);
                if (j >= 0) arr.splice(j, 1);
              }
            } else {
              const arr = demoProjectMaterialsById[pid];
              if (arr) {
                const j = arr.findIndex((x) => x.id === m.id);
                if (j >= 0) arr.splice(j, 1);
              }
            }
          }
          const i = this.materials.findIndex((x) => x.id === m.id);
          if (i < 0) return;
          this.materials.splice(i, 1);
          if (this.selectedMaterialId === m.id) {
            const next = this.materials[i] || this.materials[i - 1];
            this.selectedMaterialId = next ? next.id : null;
            if (!next) {
              this.selectedTreeNode = null;
              this.sourcesLeftView = 'list';
            }
          }
          this.toastMessage = '已删除资料';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        openWorkbenchTreeItemMetaEdit(m, sectionKey) {
          if (!m) return;
          const ps = m.projectSource;
          if (!ps || !ps.id) {
            message.info('该条目暂不支持在此编辑');
            return;
          }
          if (sectionKey === 'material' && m.type === 'raw') {
            this.openWorkbenchProjectMaterialMetaEdit(ps);
            return;
          }
          if (sectionKey === 'analysis' && m.type === 'analysis') {
            this.openWorkbenchAnalysisResultMetaEdit(ps);
            return;
          }
          message.info('该条目暂不支持在此编辑');
        },
        openMaterialDetail(m) {
          if (m && m.loading) return;
          if (this.isWorkbenchBatchParentTask(m)) {
            this.enterBatchChildListView(m);
            return;
          }
          if (!this.canOpenMaterialPreview(m)) {
            message.info('该资料尚未完成解析，暂不可预览');
            return;
          }
          const isEphemeralBenchTask =
            !!(m && Array.isArray(this.workbenchCreatedTasks) && this.workbenchCreatedTasks.some((t) => t && t.id === m.id));
          /** 与 selectedMaterialIsWorkbenchCreatedTask 一致：含演示任务行，否则默认页签会落到不存在的「输出结果」导致首屏空白 */
          const isWorkbenchTaskSidebarRow =
            isEphemeralBenchTask ||
            !!(m && Array.isArray(this.workbenchTaskDemoRows) && this.workbenchTaskDemoRows.some((t) => t && t.id === m.id));
          if (!isWorkbenchTaskSidebarRow && !this.canOpenAnalysisPreview(m)) {
            message.info('该结果尚未完成，暂不可预览');
            return;
          }
          this.clearWorkbenchAnalysisCitationFloats();
          this.workbenchAnalysisEmbedDraft = '';
          this._workbenchAnalysisEmbedSnap = '';
          /** 先于页签状态写入，便于任务详情下 task-config / basic 等 v-if 与 Tabs activeKey 对齐 */
          this.selectedMaterialId = m.id;
          if (m.type === 'analysis') {
            this.wbMaterialPreviewActiveTab = 'basic';
            this.wbAnalysisResultPreviewActiveTab = 'basic';
          } else {
            this.wbMaterialPreviewActiveTab = 'preview';
            this.wbAnalysisResultPreviewActiveTab = 'basic';
          }
          this.studioCollapsed = false;
          if (m.type === 'analysis') {
            this.lastDetailFocus = 'right';
            this.sourcesRightView = 'detail';
            this.sourcesLeftView = 'list';
          } else {
            this.lastDetailFocus = 'left';
            this.sourcesLeftView = 'detail';
            this.sourcesRightView = 'list';
            this.sourcesDetailWidth = 450;
          }
          if (m.type === 'analysis') {
            this.$nextTick(() => this.resetWorkbenchAnalysisEmbedDraftFromPreview());
          }
        },
        closeWorkbenchMaterialDetail() {
          this.clearWorkbenchAnalysisCitationFloats();
          this.workbenchAnalysisEmbedDraft = '';
          this._workbenchAnalysisEmbedSnap = '';
          if (this.sourcesRightView === 'detail' && this.selectedMaterial && this.selectedMaterial.type === 'analysis') {
            this.sourcesRightView = 'list';
          } else {
            this.sourcesLeftView = 'list';
          }
          this.selectedTreeNode = null;
          this.sourcesWidth = 300;
        },
        clearWorkbenchAnalysisCitationFloats() {
          this.workbenchAnalysisCitationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
          if (this.workbenchAnalysisCitationPopoverTimer) {
            window.clearTimeout(this.workbenchAnalysisCitationPopoverTimer);
            this.workbenchAnalysisCitationPopoverTimer = null;
          }
        },
        showWorkbenchAnalysisCitationPopoverByKey(key, rect) {
          const map = this.workbenchAnalysisCitationMap || {};
          const data = map[key];
          if (!data) return;
          if (this.workbenchAnalysisCitationPopoverTimer) {
            window.clearTimeout(this.workbenchAnalysisCitationPopoverTimer);
            this.workbenchAnalysisCitationPopoverTimer = null;
          }
          let x = rect.left;
          let y = rect.bottom + 4;
          const maxW = 320;
          const maxH = 220;
          if (x + maxW > window.innerWidth) x = window.innerWidth - maxW - 8;
          if (x < 8) x = 8;
          if (y + maxH > window.innerHeight) y = rect.top - maxH - 4;
          if (y < 8) y = 8;
          const title = `${key} · ${data.sourceLabel || '溯源信息'}`;
          const excerpt = String(data.sourceExcerpt || data.sourceFullText || '').trim() || '暂无溯源内容';
          this.workbenchAnalysisCitationPopover = { show: true, title, excerpt, x, y };
        },
        onWorkbenchAnalysisPreviewCitationHover(event) {
          const el = event && event.target ? event.target.closest('.analysis-inline-citation') : null;
          if (!el) return;
          const key = String(el.getAttribute('data-cite') || '').trim();
          if (!key) return;
          this.showWorkbenchAnalysisCitationPopoverByKey(key, el.getBoundingClientRect());
        },
        onWorkbenchAnalysisPreviewCitationLeave() {
          this.workbenchAnalysisCitationPopoverTimer = window.setTimeout(() => {
            this.workbenchAnalysisCitationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
            this.workbenchAnalysisCitationPopoverTimer = null;
          }, 120);
        },
        onWorkbenchAnalysisCitationPopoverEnter() {
          if (this.workbenchAnalysisCitationPopoverTimer) {
            window.clearTimeout(this.workbenchAnalysisCitationPopoverTimer);
            this.workbenchAnalysisCitationPopoverTimer = null;
          }
        },
        onWorkbenchAnalysisCitationPopoverLeave() {
          this.onWorkbenchAnalysisPreviewCitationLeave();
        },
        workbenchAnalysisDialogueSourceLineFromRecord(r) {
          if (!r) return '';
          const base = '初始结果通过对话生成';
          const who = String(r.analysisMarkdownEditedBy || '').trim();
          const when = String(r.analysisMarkdownEditedAt || '').trim();
          if (who && when) return `${base}（${who} 于 ${when} 编辑）`;
          return base;
        },
        workbenchAnalysisResultBasicMetaLine(record) {
          const r = record || {};
          const when = this.wbToOverviewMetaValue(r.createdAt, '—');
          return `${when} 生成`;
        },
        workbenchAnalysisMarkdownFromMaterial(m) {
          if (!m || m.type !== 'analysis') return '';
          if (m.analysisMarkdown) return m.analysisMarkdown;
          const ps = m.projectSource || {};
          return buildAnalysisResultPreviewMarkdown({ name: m.title || ps.name, createdAt: m.meta || ps.createdAt });
        },
        pushWorkbenchAnalysisVersionEntry(resultId, label, markdown, savedAt, sourceSummary) {
          if (!resultId || markdown == null) return;
          const key = `v-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
          const at =
            savedAt != null && String(savedAt).trim()
              ? String(savedAt).trim()
              : new Date().toISOString().slice(0, 19).replace('T', ' ');
          const sum = String(sourceSummary || '').trim();
          const prev = (this.workbenchAnalysisVersionHistoryById || {})[resultId] || [];
          const next = [
            {
              key,
              label: String(label || '快照').trim() || '快照',
              markdown: String(markdown),
              savedAt: at,
              ...(sum ? { sourceSummary: sum } : {}),
            },
            ...prev,
          ].slice(0, 30);
          this.workbenchAnalysisVersionHistoryById = { ...(this.workbenchAnalysisVersionHistoryById || {}), [resultId]: next };
        },
        /** 当前版本行由 computed 合成；此处仅保留钩子供切换 Tab 时触发（可扩展预拉取） */
        ensureWorkbenchAnalysisVersionHistoryForSelected() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return;
        },
        ensureWorkbenchAnalysisVersionHistoryForRecord(record) {
          const r = record || this.wbAnalysisModalRecord;
          if (!r || !r.id) return;
        },
        closeWorkbenchAnalysisHistoryDiff() {
          this.wbAnalysisHistoryDiffOpen = false;
          this.wbAnalysisHistoryDiffLines = [];
          this.wbAnalysisHistoryDiffTruncated = false;
        },
        workbenchAnalysisResolveMaterialNameById(materialId) {
          const id = String(materialId || '').trim();
          if (!id) return '';
          const rows = this.materials || [];
          const r = rows.find((x) => x && String(x.id) === id);
          return (r && r.title) ? String(r.title).trim() : id;
        },
        openWbAnalysisVersionDetail(record) {
          if (!record) return;
          this.wbAnalysisVersionDetailMarkdown = String(record.markdown || '');
          this.wbAnalysisVersionDetailVisible = true;
        },
        closeWbAnalysisVersionDetail() {
          this.wbAnalysisVersionDetailVisible = false;
          this.wbAnalysisVersionDetailMarkdown = '';
        },
        openWorkbenchAnalysisHistoryDiff(record, scope) {
          if (!record || record.key === '_current') {
            message.info('已为当前版本');
            return;
          }
          const hist = String(record.markdown ?? '');
          const cur =
            scope === 'modal'
              ? String(this.wbAnalysisModalPreviewMarkdown || '')
              : String(this.workbenchAnalysisPreviewMarkdown || '');
          const { lines, truncated } = demoLinesUnifiedDiff(hist, cur, { maxOut: 500 });
          this.wbAnalysisHistoryDiffLines = lines;
          this.wbAnalysisHistoryDiffTruncated = truncated;
          this.wbAnalysisHistoryDiffOpen = true;
        },
        onWbAnalysisModalTabUpdate(key) {
          const next = String(key || 'basic');
          if (next === String(this.wbAnalysisModalActiveTab)) return;
          if (String(this.wbAnalysisModalActiveTab) === 'body' && this.wbAnalysisModalEmbedDirty && next !== 'body') {
            Modal.confirm({
              centered: true,
              title: '有未保存的编辑',
              content: '切换页签将放弃对正文的未保存修改，是否继续？',
              okText: '放弃并切换',
              cancelText: '留在本页',
              onOk: () => {
                this.cancelWbAnalysisModalEmbedEdit();
                if (next === 'history') this.ensureWorkbenchAnalysisVersionHistoryForRecord(this.wbAnalysisModalRecord);
                this.wbAnalysisModalActiveTab = next;
              },
            });
            return;
          }
          if (next === 'history') this.ensureWorkbenchAnalysisVersionHistoryForRecord(this.wbAnalysisModalRecord);
          this.wbAnalysisModalActiveTab = next;
        },
        applyWorkbenchAnalysisMarkdownRollbackById(resultId, md) {
          const pid = this.workbenchProjectId;
          const id = String(resultId || '');
          if (!id || !pid) return;
          const m = (this.materials || []).find((x) => x && x.type === 'analysis' && String(x.id) === id);
          const text = String(md ?? '');
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const patch = {
            analysisMarkdown: text,
            analysisMarkdownEditedBy: '我',
            analysisMarkdownEditedAt: now,
          };
          const rows = demoProjectAnalysisResultsById[pid];
          if (Array.isArray(rows)) {
            const idx = rows.findIndex((r) => r && r.id === id);
            if (idx >= 0) rows.splice(idx, 1, { ...rows[idx], ...patch });
          }
          if (m) {
            m.analysisMarkdown = text;
            if (m.projectSource) Object.assign(m.projectSource, patch);
          }
          if (this.wbAnalysisModalOpen && this.wbAnalysisModalRecord && this.wbAnalysisModalRecord.id === id) {
            this.wbAnalysisModalRecord = { ...this.wbAnalysisModalRecord, ...patch };
          }
          this.resetWorkbenchAnalysisEmbedDraftFromPreview();
          this.resetWbAnalysisModalEmbedDraftFromPreview();
          message.success('已回退到所选版本');
        },
        onWorkbenchAnalysisResultPreviewTabUpdate(key) {
          const next = String(key || 'basic');
          if (next === String(this.wbAnalysisResultPreviewActiveTab)) return;
          if (String(this.wbAnalysisResultPreviewActiveTab) === 'body' && this.workbenchAnalysisEmbedDirty && next !== 'body') {
            Modal.confirm({
              centered: true,
              title: '有未保存的编辑',
              content: '切换页签将放弃对正文的未保存修改，是否继续？',
              okText: '放弃并切换',
              cancelText: '留在本页',
              onOk: () => {
                this.cancelWorkbenchAnalysisEmbedEdit();
                if (next === 'history') this.ensureWorkbenchAnalysisVersionHistoryForSelected();
                this.wbAnalysisResultPreviewActiveTab = next;
                // #region agent log
                if (next === 'history') this._debugLogWorkbenchEmbedHistoryLayout('modal_ok');
                // #endregion
              },
            });
            return;
          }
          if (next === 'history') this.ensureWorkbenchAnalysisVersionHistoryForSelected();
          this.wbAnalysisResultPreviewActiveTab = next;
          // #region agent log
          if (next === 'history') this._debugLogWorkbenchEmbedHistoryLayout('direct');
          // #endregion
        },
        // #region agent log
        _debugLogWorkbenchEmbedHistoryLayout(tag) {
          this.$nextTick(() => {
            requestAnimationFrame(() => {
              try {
                const root = this.$el;
                const embed = root && root.querySelector
                  ? root.querySelector('.analysis-result-preview-modal.analysis-result-preview-modal--workbench-embed')
                  : null;
                const panel = embed ? embed.querySelector('.ds-l2-table-panel') : null;
                const tableWrap = embed ? embed.querySelector('.wb-analysis-version-mgmt-table') : null;
                const cols = this.workbenchAnalysisVersionMgmtColumns || [];
                const rows = this.workbenchAnalysisVersionHistoryOnlyRows || [];
                const colWidths = cols.map((c) => ({ key: c.key, w: c.width }));
                const sumW = colWidths.reduce((s, x) => s + (Number(x.w) || 0), 0);
                const panelRect = panel ? { cw: panel.clientWidth, sw: panel.scrollWidth } : null;
                const twRect = tableWrap ? { cw: tableWrap.clientWidth, sw: tableWrap.scrollWidth } : null;
                const innerTable = tableWrap
                  ? tableWrap.querySelector('.ant-table-content table') || tableWrap.querySelector('table')
                  : null;
                const innerTableLayout = innerTable && typeof window.getComputedStyle === 'function'
                  ? window.getComputedStyle(innerTable).tableLayout
                  : '';
                let thInfo = [];
                if (tableWrap) {
                  const headerTable = tableWrap.querySelector('.ant-table-header table');
                  const ths = headerTable ? headerTable.querySelectorAll('thead th') : [];
                  thInfo = Array.from(ths).map((th) => ({
                    w: th.offsetWidth,
                    t: String(th.textContent || '').trim().slice(0, 12),
                  }));
                }
                let td0 = [];
                if (tableWrap) {
                  const bodyTable =
                    tableWrap.querySelector('.ant-table-body table') ||
                    tableWrap.querySelector('.ant-table-content table');
                  const tr = bodyTable && bodyTable.querySelector('tbody tr:not(.ant-table-measure-row)');
                  if (tr) td0 = Array.from(tr.querySelectorAll('td')).map((td) => td.offsetWidth);
                }
                fetch('http://127.0.0.1:7513/ingest/4f092e80-cdeb-409f-b8b0-4a397bd0359b', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', 'X-Debug-Session-Id': 'be30db' },
                  body: JSON.stringify({
                    sessionId: 'be30db',
                    hypothesisId: 'H1_H3_H5',
                    location: 'demo-cmp-freeaudit.js:_debugLogWorkbenchEmbedHistoryLayout',
                    message: 'embed_history_layout',
                    data: {
                      tag,
                      activeTab: this.wbAnalysisResultPreviewActiveTab,
                      colWidths,
                      sumW,
                      rowCount: rows.length,
                      panelRect,
                      twRect,
                      innerTableLayout,
                      thCount: thInfo.length,
                      thInfo,
                      td0,
                    },
                    timestamp: Date.now(),
                    runId: 'post-fix-v2',
                  }),
                }).catch(() => {});
              } catch (e) {
                fetch('http://127.0.0.1:7513/ingest/4f092e80-cdeb-409f-b8b0-4a397bd0359b', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', 'X-Debug-Session-Id': 'be30db' },
                  body: JSON.stringify({
                    sessionId: 'be30db',
                    hypothesisId: 'H4',
                    location: 'demo-cmp-freeaudit.js:_debugLogWorkbenchEmbedHistoryLayout',
                    message: 'embed_history_layout_error',
                    data: { tag, err: String(e && e.message) },
                    timestamp: Date.now(),
                    runId: 'post-fix-v2',
                  }),
                }).catch(() => {});
              }
            });
          });
        },
        // #endregion
        resetWorkbenchAnalysisEmbedDraftFromPreview() {
          const md = String(this.workbenchAnalysisPreviewMarkdown || '');
          this.workbenchAnalysisEmbedDraft = md;
          this._workbenchAnalysisEmbedSnap = md;
        },
        resetWbAnalysisModalEmbedDraftFromPreview() {
          const md = String(this.wbAnalysisModalPreviewMarkdown || '');
          this.wbAnalysisModalEmbedDraft = md;
          this._wbAnalysisModalEmbedSnap = md;
        },
        cancelWorkbenchAnalysisEmbedEdit() {
          this.workbenchAnalysisEmbedDraft = String(this._workbenchAnalysisEmbedSnap ?? '');
        },
        saveWorkbenchAnalysisEmbedEdit() {
          const m = this.selectedMaterial;
          const pid = this.workbenchProjectId;
          if (!m || m.type !== 'analysis' || !pid) return;
          const oldMd = this.workbenchAnalysisMarkdownFromMaterial(m);
          const md = String(this.workbenchAnalysisEmbedDraft ?? '');
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          if (oldMd !== md) {
            this.pushWorkbenchAnalysisVersionEntry(m.id, `${now} · 保存前`, oldMd, now, '编辑前版本');
          }
          const patch = {
            analysisMarkdown: md,
            analysisMarkdownEditedBy: '我',
            analysisMarkdownEditedAt: now,
          };
          const id = m.id;
          const list = demoProjectAnalysisResultsById[pid];
          if (Array.isArray(list)) {
            const idx = list.findIndex((r) => r && r.id === id);
            if (idx >= 0) {
              list.splice(idx, 1, { ...list[idx], ...patch });
            }
          }
          m.analysisMarkdown = md;
          if (m.projectSource) Object.assign(m.projectSource, patch);
          if (this.wbAnalysisModalOpen && this.wbAnalysisModalRecord && this.wbAnalysisModalRecord.id === id) {
            this.wbAnalysisModalRecord = { ...this.wbAnalysisModalRecord, ...patch };
            this.$nextTick(() => this.resetWbAnalysisModalEmbedDraftFromPreview());
          }
          this._workbenchAnalysisEmbedSnap = md;
          message.success('保存成功');
        },
        copyWorkbenchAnalysisEmbedPreview() {
          if (!this.workbenchSelectedAnalysisResultRow) return;
          const text = String(this.workbenchAnalysisEmbedDraft ?? '');
          const ok = () => message.success('已复制到剪贴板');
          const fail = () => message.warning('复制失败');
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(ok).catch(fail);
          } else {
            try {
              const ta = document.createElement('textarea');
              ta.value = text;
              ta.style.cssText = 'position:fixed;left:-9999px;top:0';
              document.body.appendChild(ta);
              ta.select();
              document.execCommand('copy');
              document.body.removeChild(ta);
              ok();
            } catch (_) {
              fail();
            }
          }
        },
        /** 分析结果导出为 Markdown / PDF / Word：演示环境仅提示，不生成真实文件 */
        simulateWorkbenchAnalysisResultExport(format) {
          const map = { md: 'Markdown', pdf: 'PDF', docx: 'Word' };
          const label = map[format] || format;
          message.success(`已开始下载为 ${label}（演示）`);
        },
        onWorkbenchAnalysisResultToolbarExportMenu(info, scope) {
          const key = info && info.key;
          if (!key || String(key).indexOf('export-') !== 0) return;
          const fmt = String(key).slice('export-'.length);
          if (fmt !== 'md' && fmt !== 'pdf' && fmt !== 'docx') return;
          if (scope === 'embed') {
            if (!this.workbenchSelectedAnalysisResultRow || this.workbenchEmbedAnalysisOutputToolbarDisabled) return;
          } else if (scope === 'modal') {
            if (!this.wbAnalysisModalRecord) return;
          } else {
            return;
          }
          this.simulateWorkbenchAnalysisResultExport(fmt);
        },
        openWorkbenchAnalysisResultMetaEdit(record) {
          if (!record || !record.id) return;
          this.wbAnalysisResultMetaEditForm = {
            name: String(record.name || '').trim(),
          };
          this.wbAnalysisResultMetaEditTargetId = record.id;
          this.wbAnalysisResultMetaEditVisible = true;
        },
        closeWorkbenchAnalysisResultMetaEdit() {
          this.wbAnalysisResultMetaEditVisible = false;
          this.wbAnalysisResultMetaEditTargetId = '';
        },
        confirmWorkbenchAnalysisResultMetaEdit() {
          const id = this.wbAnalysisResultMetaEditTargetId;
          const pid = this.workbenchProjectId;
          const name = String((this.wbAnalysisResultMetaEditForm && this.wbAnalysisResultMetaEditForm.name) || '').trim();
          if (!pid || !id) return;
          if (!name) {
            message.warning('请填写结果名称');
            return;
          }
          const rows = demoProjectAnalysisResultsById[pid] || [];
          const idx = rows.findIndex((x) => x.id === id);
          if (idx < 0) return;
          rows.splice(idx, 1, { ...rows[idx], name });
          const m = (this.materials || []).find((x) => x.id === id && x.type === 'analysis');
          if (m) {
            m.title = name;
            if (m.projectSource) {
              m.projectSource = { ...m.projectSource, name };
            }
          }
          if (this.wbAnalysisModalRecord && this.wbAnalysisModalRecord.id === id) {
            this.wbAnalysisModalRecord = { ...this.wbAnalysisModalRecord, name };
          }
          this.closeWorkbenchAnalysisResultMetaEdit();
          message.success('已重命名');
        },
        wbToOverviewMetaValue(v, fallback = '—') {
          const s = String(v == null ? '' : v).trim();
          return s || fallback;
        },
        wbMaterialPreviewSizeFormatLine(record) {
          const r = record || {};
          const sizePart =
            r.size == null || r.size === ''
              ? '—'
              : `${Number(r.size).toFixed(1)} MB`;
          const fmt = String(r.format || '').trim() || '—';
          return `大小 ${sizePart} · 格式 ${fmt}`;
        },
        wbMaterialPreviewBasicMetaLine(record) {
          const r = record || {};
          const who = String(r.uploader || r.uploadedBy || '').trim() || '—';
          const when = this.wbToOverviewMetaValue(r.uploadedAt, '—');
          return `${who} 于 ${when} 上传`;
        },
        wbMaterialTypeIcon(record) {
          const r = record || {};
          return `fas ${this.wbFileIconSuffixFromFormatName(r.format, r.name)}`;
        },
        wbMaterialTypeIconClass(record) {
          if (!record || record.status !== 'done') return '';
          let fmt = String((record && record.format) || '').toUpperCase();
          const name = String((record && record.name) || '').trim();
          if (!fmt && name) {
            const lower = name.toLowerCase();
            if (lower.endsWith('.pdf')) fmt = 'PDF';
            else if (/\.(xlsx|xls|csv)$/i.test(lower)) fmt = 'XLSX';
            else if (/\.(docx|doc)$/i.test(lower)) fmt = 'DOCX';
            else if (/\.json$/i.test(lower)) fmt = 'JSON';
          }
          if (fmt === 'PDF') return 'is-pdf';
          if (fmt === 'XLSX' || fmt === 'XLS' || fmt === 'CSV') return 'is-sheet';
          if (fmt === 'DOCX' || fmt === 'DOC') return 'is-doc';
          if (fmt === 'JSON') return 'is-data';
          return '';
        },
        openWorkbenchProjectMaterialMetaEdit(record) {
          if (!record || !record.id) return;
          this.wbMaterialMetaEditForm = {
            name: String(record.name || '').trim(),
          };
          this._wbMaterialMetaSnap = { name: this.wbMaterialMetaEditForm.name };
          this.wbMaterialMetaEditTargetId = record.id;
          this.wbMaterialMetaEditVisible = true;
        },
        closeWorkbenchProjectMaterialMetaEdit() {
          this.wbMaterialMetaEditVisible = false;
          this.wbMaterialMetaEditTargetId = '';
          this._wbMaterialMetaSnap = null;
        },
        cancelWorkbenchProjectMaterialMetaEdit() {
          const snap = this._wbMaterialMetaSnap;
          if (snap) {
            this.wbMaterialMetaEditForm = { name: snap.name };
          }
          this.closeWorkbenchProjectMaterialMetaEdit();
        },
        confirmWorkbenchProjectMaterialMetaEdit() {
          const id = this.wbMaterialMetaEditTargetId;
          const pid = this.workbenchProjectId;
          const name = String((this.wbMaterialMetaEditForm && this.wbMaterialMetaEditForm.name) || '').trim();
          if (!pid || !id) return;
          if (!name) {
            message.warning('请填写资料名称');
            return;
          }
          const rows = demoProjectMaterialsById[pid] || [];
          const idx = rows.findIndex((x) => x.id === id);
          if (idx < 0) return;
          rows.splice(idx, 1, { ...rows[idx], name });
          const m = (this.materials || []).find((x) => x.projectSource && x.projectSource.id === id);
          if (m) {
            m.title = name;
            m.projectSource = { ...m.projectSource, name };
            if (m.paired) {
              m.paired.title = `${name} - 提取结果（演示）`;
            }
          }
          this.closeWorkbenchProjectMaterialMetaEdit();
          message.success('已重命名');
        },
        downloadWorkbenchMaterialPreview() {
          const rec = this.workbenchSelectedProjectMaterialRow;
          if (!rec) return;
          const pages = this.workbenchMaterialDocumentPages || [];
          const body = pages.join('\n\n---\n\n');
          const base = String(rec.name || '资料').replace(/\.[^.]+$/, '');
          const safe = base.replace(/[/\\?%*:|"<>]/g, '_');
          const blob = new Blob([body], { type: 'text/plain;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${safe}-预览.txt`;
          a.click();
          URL.revokeObjectURL(url);
          message.success('已开始下载');
        },
        cancelWbAnalysisModalEmbedEdit() {
          this.wbAnalysisModalEmbedDraft = String(this._wbAnalysisModalEmbedSnap ?? '');
        },
        saveWbAnalysisModalEmbedEdit() {
          const rec = this.wbAnalysisModalRecord;
          const pid = this.workbenchProjectId;
          if (!rec || !rec.id || !pid) return;
          const oldMd = String(this.wbAnalysisModalPreviewMarkdown || '');
          const md = String(this.wbAnalysisModalEmbedDraft ?? '');
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          if (oldMd !== md) {
            this.pushWorkbenchAnalysisVersionEntry(rec.id, `${now} · 保存前`, oldMd, now, '编辑前版本');
          }
          const patch = {
            analysisMarkdown: md,
            analysisMarkdownEditedBy: '我',
            analysisMarkdownEditedAt: now,
          };
          const id = rec.id;
          const list = demoProjectAnalysisResultsById[pid];
          if (Array.isArray(list)) {
            const idx = list.findIndex((r) => r && r.id === id);
            if (idx >= 0) list.splice(idx, 1, { ...list[idx], ...patch });
          }
          const m = (this.materials || []).find((x) => x.id === id && x.type === 'analysis');
          if (m) {
            m.analysisMarkdown = md;
            if (m.projectSource) Object.assign(m.projectSource, patch);
          }
          this.wbAnalysisModalRecord = { ...rec, ...patch };
          this._wbAnalysisModalEmbedSnap = md;
          this.$nextTick(() => this.resetWorkbenchAnalysisEmbedDraftFromPreview());
          message.success('保存成功');
        },
        copyWbAnalysisModalEmbedPreview() {
          if (!this.wbAnalysisModalRecord) return;
          const text = String(this.wbAnalysisModalEmbedDraft ?? '');
          const ok = () => message.success('已复制到剪贴板');
          const fail = () => message.warning('复制失败');
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(ok).catch(fail);
          } else {
            try {
              const ta = document.createElement('textarea');
              ta.value = text;
              ta.style.cssText = 'position:fixed;left:-9999px;top:0';
              document.body.appendChild(ta);
              ta.select();
              document.execCommand('copy');
              document.body.removeChild(ta);
              ok();
            } catch (_) {
              fail();
            }
          }
        },
        openWorkbenchAnalysisModal() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return;
          this.clearWbAnalysisModalCitationFloats();
          this.wbAnalysisModalEmbedDraft = '';
          this._wbAnalysisModalEmbedSnap = '';
          const ps = m.projectSource || {};
          this.wbAnalysisModalRecord = {
            id: ps.id || m.id,
            name: ps.name || m.title,
            createdAt: ps.createdAt || m.meta,
            status: ps.status || 'done',
            sourceSkillName: ps.sourceSkillName || m.sourceSkillName,
            analysisMarkdown: m.analysisMarkdown || ps.analysisMarkdown,
            analysisMarkdownEditedBy: ps.analysisMarkdownEditedBy,
            analysisMarkdownEditedAt: ps.analysisMarkdownEditedAt,
            citationMap: m.citationMap || ps.citationMap,
          };
          this.wbAnalysisModalActiveTab = 'basic';
          this.ensureWorkbenchAnalysisVersionHistoryForRecord(this.wbAnalysisModalRecord);
          this.wbAnalysisModalOpen = true;
          this.$nextTick(() => this.resetWbAnalysisModalEmbedDraftFromPreview());
        },
        closeWbAnalysisModal() {
          this.wbAnalysisModalOpen = false;
          this.wbAnalysisModalRecord = null;
          this.wbAnalysisModalActiveTab = 'basic';
          this.wbAnalysisModalEmbedDraft = '';
          this._wbAnalysisModalEmbedSnap = '';
          this.clearWbAnalysisModalCitationFloats();
        },
        clearWbAnalysisModalCitationFloats() {
          this.wbAnalysisModalCitationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
          if (this.wbAnalysisModalCitationPopoverTimer) {
            window.clearTimeout(this.wbAnalysisModalCitationPopoverTimer);
            this.wbAnalysisModalCitationPopoverTimer = null;
          }
        },
        showWbAnalysisModalCitationPopoverByKey(key, rect) {
          const map = this.wbAnalysisModalCitationMap || {};
          const data = map[key];
          if (!data) return;
          if (this.wbAnalysisModalCitationPopoverTimer) {
            window.clearTimeout(this.wbAnalysisModalCitationPopoverTimer);
            this.wbAnalysisModalCitationPopoverTimer = null;
          }
          let x = rect.left;
          let y = rect.bottom + 4;
          const maxW = 320;
          const maxH = 220;
          if (x + maxW > window.innerWidth) x = window.innerWidth - maxW - 8;
          if (x < 8) x = 8;
          if (y + maxH > window.innerHeight) y = rect.top - maxH - 4;
          if (y < 8) y = 8;
          const title = `${key} · ${data.sourceLabel || '溯源信息'}`;
          const excerpt = String(data.sourceExcerpt || data.sourceFullText || '').trim() || '暂无溯源内容';
          this.wbAnalysisModalCitationPopover = { show: true, title, excerpt, x, y };
        },
        onWbAnalysisModalPreviewCitationHover(event) {
          const el = event && event.target ? event.target.closest('.analysis-inline-citation') : null;
          if (!el) return;
          const key = String(el.getAttribute('data-cite') || '').trim();
          if (!key) return;
          this.showWbAnalysisModalCitationPopoverByKey(key, el.getBoundingClientRect());
        },
        onWbAnalysisModalPreviewCitationLeave() {
          this.wbAnalysisModalCitationPopoverTimer = window.setTimeout(() => {
            this.wbAnalysisModalCitationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
            this.wbAnalysisModalCitationPopoverTimer = null;
          }, 120);
        },
        onWbAnalysisModalCitationPopoverEnter() {
          if (this.wbAnalysisModalCitationPopoverTimer) {
            window.clearTimeout(this.wbAnalysisModalCitationPopoverTimer);
            this.wbAnalysisModalCitationPopoverTimer = null;
          }
        },
        onWbAnalysisModalCitationPopoverLeave() {
          this.onWbAnalysisModalPreviewCitationLeave();
        },
        isTreeNodeSelected(node, sectionKey) {
          if (!this.selectedTreeNode) return false;
          return node.id === this.selectedTreeNode.id;
        },
        selectTreeNode(node, sectionKey) {
          if (node.raw.loading) return;
          this.selectedTreeNode = { source: sectionKey === 'analysis' ? 'analysis' : 'material', id: node.id };
          if (sectionKey === 'analysis' && this.isWorkbenchBatchParentTask(node.raw)) {
            this.enterBatchChildListView(node.raw);
            return;
          }
          if (sectionKey === 'material' || sectionKey === 'analysis') {
            const ephemeralTask = !!(this.workbenchCreatedTasks || []).find((t) => t && t.id === node.raw.id);
            const demoTask =
              !!(typeof demoWorkbenchTaskRows !== 'undefined' && demoWorkbenchTaskRows.some((t) => t && t.id === node.raw.id));
            const taskSidebarRow = ephemeralTask || demoTask;
            if (
              taskSidebarRow ||
              (this.canOpenMaterialPreview(node.raw) && this.canOpenAnalysisPreview(node.raw))
            ) {
              this.openMaterialDetail(node.raw);
            }
          }
        },
        openDetailFromTreeTitle(node, sectionKey) {
          this.selectedTreeNode = { source: sectionKey === 'analysis' ? 'analysis' : 'material', id: node.id };
          if (sectionKey === 'analysis' && this.isWorkbenchBatchParentTask(node.raw)) {
            this.enterBatchChildListView(node.raw);
            return;
          }
          this.openMaterialDetail(node.raw);
        },
        handleTreeContextMenu(key, node, sectionKey, treeScope) {
          const ts = treeScope || null;
          const raw = node && node.raw;
          const demoTask = !!(raw && typeof demoWorkbenchTaskRows !== 'undefined' && demoWorkbenchTaskRows.some((t) => t && t.id === raw.id));
          const ephemeralTask = !!(raw && (this.workbenchCreatedTasks || []).find((t) => t && t.id === raw.id));
          if (key === 'delete' && demoTask && ts === 'task') {
            this.deleteWorkbenchDemoTask(raw);
            return;
          }
          if (key === 'delete' && ephemeralTask) {
            this.deleteWorkbenchCreatedTask(raw);
            return;
          }
          if (ts === 'task' && demoTask && (key === 'rerun-full' || key === 'rerun-continue')) {
            this.onBatchParentRerunMenu(key, raw);
            return;
          }
          if (ts === 'task' && demoTask && key === 'rerun-task') {
            this.rerunWorkbenchDemoTask(raw);
            return;
          }
          if (ts === 'task' && demoTask && key === 'abort-task') {
            this.abortWorkbenchDemoTask(raw);
            return;
          }
          if (ts === 'task' && ephemeralTask && (key === 'rerun-full' || key === 'rerun-continue')) {
            this.onBatchParentRerunMenu(key, raw);
            return;
          }
          if (ts === 'task' && ephemeralTask && key === 'rerun-task') {
            this.rerunWorkbenchCreatedTask(raw);
            return;
          }
          if (ts === 'task' && ephemeralTask && key === 'abort-task') {
            this.abortWorkbenchCreatedTask(raw);
            return;
          }
          if (ts === 'task' && ephemeralTask && ['edit', 'download', 'rename'].includes(key)) {
            return;
          }
          if (ts === 'task' && demoTask && ['edit', 'download', 'rename'].includes(key)) {
            return;
          }
          if (key === 'ref') {
            if (!raw) return;
            const isMatRaw = sectionKey === 'material' && (raw.type === 'raw' || raw.type === undefined);
            const title = isMatRaw
              ? String(this.chatAtRawMaterialDisplayTitle(raw) || '').trim() || '未命名'
              : String(raw.title != null ? raw.title : '未命名').trim() || '未命名';
            this.appendChatInputToken('@' + title);
            this.toastMessage = '已添加到对话并已插入 @';
            setTimeout(() => { this.toastMessage = ''; }, 1500);
            return;
          }
          if (typeof key === 'string' && key.indexOf('export-') === 0 && sectionKey === 'analysis') {
            const fmt = key.slice('export-'.length);
            if (fmt === 'md' || fmt === 'pdf' || fmt === 'docx') {
              this.simulateWorkbenchAnalysisResultExport(fmt);
            }
            return;
          }
          if (key === 'download' && sectionKey === 'material') {
            this.downloadWorkbenchMaterialPreview();
            return;
          }
          if (key === 'edit' || key === 'rename') {
            this.openWorkbenchTreeItemMetaEdit(node.raw, sectionKey);
            return;
          }
          this.handleMaterialMenuClick(key, node.raw);
        },
        onMaterialListAreaClick() {},
        onTreeLeafDragStart(ev, node, sectionKey) {
          if (node.raw.loading) { ev.preventDefault(); return; }
          const payload = { source: 'material', id: node.id };
          const raw = JSON.stringify(payload);
          ev.dataTransfer.setData('application/json', raw);
          ev.dataTransfer.setData('text/plain', raw);
          ev.dataTransfer.effectAllowed = 'copy';
        },
        onChatAreaDrop(ev) {
          ev.preventDefault();
          let raw = ev.dataTransfer.getData('application/json');
          if (!raw) raw = ev.dataTransfer.getData('text/plain');
          if (!raw) return;
          try {
            const payload = JSON.parse(raw);
            this.onTreeLeafDropInChat(ev, payload);
          } catch (e) { /* ignore */ }
        },
        onTreeLeafDropInChat(ev, payload) {
          ev.preventDefault();
          if (!payload || payload.source !== 'material' || payload.id == null) return;
          const m = this.materials.find((x) => x.id === payload.id);
          if (m) {
            const isMatRaw = m.type === 'raw' || m.type === undefined;
            const title = isMatRaw
              ? String(this.chatAtRawMaterialDisplayTitle(m) || '').trim() || '未命名'
              : String(m.title != null ? m.title : '未命名').trim() || '未命名';
            this.appendChatInputToken('@' + title);
          }
          this.toastMessage = '已添加到对话并已插入 @';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        openFullscreenDual(m) {
          this.fullscreenMaterialId = m.id;
          this.fullscreenLeftView = 'list';
          this.fullscreenSelectedSourceId = null;
          this.fullscreenHighlightSourceId = null;
          this.fullscreenHighlightExcerptIndex = null;
          this.fullscreenOriginalHighlight = null;
          this.fullscreenOriginalPageRefs = {};
          this.fullscreenOriginalRowRefs = {};
          this.sourcesLeftFullscreen = true;
        },
        setFullscreenOriginalPageRef(pi, el) {
          if (!el) return;
          this.fullscreenOriginalPageRefs[pi] = el;
        },
        setFullscreenOriginalRowRef(ri, el) {
          if (!el) return;
          this.fullscreenOriginalRowRefs[ri] = el;
        },
        onExtractCitationEnter(ev, ref, paired) {
          if (!paired || !paired.citations) return;
          const c = paired.citations.find((x) => x.ref === ref);
          if (!c || c.excerpt == null) return;
          if (this.citationPopoverTimer) {
            clearTimeout(this.citationPopoverTimer);
            this.citationPopoverTimer = null;
          }
          const rect = ev.target.getBoundingClientRect();
          let x = rect.left;
          let y = rect.bottom + 4;
          const maxW = 320;
          const maxH = 200;
          if (x + maxW > window.innerWidth) x = window.innerWidth - maxW - 8;
          if (x < 8) x = 8;
          if (y + maxH > window.innerHeight) y = rect.top - maxH - 4;
          if (y < 8) y = 8;
          this.citationPopover = {
            show: true,
            title: '来源片段',
            excerpt: this.buildCitationPopoverExcerpt(c.excerpt),
            x,
            y,
          };
        },
        onCitationPopoverEnter() {
          if (this.citationPopoverTimer) {
            clearTimeout(this.citationPopoverTimer);
            this.citationPopoverTimer = null;
          }
        },
        onExtractCitationLeave() {
          this.citationPopoverTimer = setTimeout(() => {
            this.citationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
            this.citationPopoverTimer = null;
          }, 150);
        },
        onExtractCitationClick(ref, paired) {
          if (!this.sourcesLeftFullscreen || !paired || !paired.citations) return;
          const c = paired.citations.find((x) => x.ref === ref);
          if (!c) return;
          if (c.pageIndex != null) {
            this.fullscreenOriginalHighlight = { pageIndex: c.pageIndex };
            this.$nextTick(() => {
              const el = this.fullscreenOriginalPageRefs[c.pageIndex];
              if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              setTimeout(() => { this.fullscreenOriginalHighlight = null; }, 2000);
            });
          } else if (c.rowIndex != null) {
            this.fullscreenOriginalHighlight = { rowIndex: c.rowIndex };
            this.$nextTick(() => {
              const el = this.fullscreenOriginalRowRefs[c.rowIndex];
              if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              setTimeout(() => { this.fullscreenOriginalHighlight = null; }, 2000);
            });
          }
        },
        setFullscreenExcerptRef(sourceId, index, el) {
          if (!el) return;
          if (!this.fullscreenExcerptRefs[sourceId]) this.fullscreenExcerptRefs[sourceId] = {};
          this.fullscreenExcerptRefs[sourceId][index] = el;
        },
        renderFullscreenAnalysisContent(material) {
          if (!material || !material.excerptsWithCitations) return (material?.excerpts || []).map(e => (e || '').replace(/</g, '&lt;').replace(/>/g, '&gt;')).join('<br><br>');
          let html = '';
          material.excerptsWithCitations.forEach((block, bi) => {
            let text = (block.text || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            (block.citations || []).forEach((c, ci) => {
              const num = String(ci + 1);
              const regex = new RegExp('\\[' + (ci + 1) + '\\]');
              text = text.replace(
                regex,
                '<span class="nlm-citation" data-source-id="' +
                  c.sourceId +
                  '" data-excerpt-index="' +
                  c.excerptIndex +
                  '" aria-label="引用 ' +
                  num +
                  '">' +
                  num +
                  '</span>'
              );
            });
            html += (bi ? '<br><br>' : '') + '<div class="excerpt">' + text + '</div>';
          });
          return html;
        },
        handleFullscreenCitationClick(e) {
          const el = e.target.closest('.nlm-citation');
          if (!el) return;
          const sourceId = el.dataset.sourceId;
          const excerptIndex = parseInt(el.dataset.excerptIndex, 10);
          this.fullscreenLeftView = 'detail';
          this.fullscreenSelectedSourceId = sourceId;
          this.fullscreenHighlightSourceId = sourceId;
          this.fullscreenHighlightExcerptIndex = excerptIndex;
          this.$nextTick(() => {
            const ref = this.fullscreenExcerptRefs[sourceId] && this.fullscreenExcerptRefs[sourceId][excerptIndex];
            if (ref) ref.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setTimeout(() => { this.fullscreenHighlightSourceId = null; this.fullscreenHighlightExcerptIndex = null; }, 2000);
          });
        },
        getMessageFullPlainText(msg) {
          if (!msg) return '';
          if (msg.role === 'user') return String(msg.text || '');
          const t = msg.text || '';
          if (msg.chatIntro) {
            let s = `${msg.chatIntro}\n\n${t}`;
            if (msg.chatRunSummary) s += `\n\n${msg.chatRunSummary}`;
            return s;
          }
          return t;
        },
        getMessageResultPlainText(msg) {
          if (!msg) return '';
          if (msg.role === 'user') return String(msg.text || '');
          const t = String(msg.text || '');
          if (msg.chatIntro) {
            return `${msg.chatIntro}\n\n${t}`;
          }
          return t;
        },
        renderMarkdownFromBotText(raw, msg) {
          let out;
          if (typeof marked !== 'undefined') {
            try {
              const parsed = marked.parse(raw, { gfm: true, breaks: true, async: false });
              out = (typeof parsed === 'string' ? parsed : String(parsed || '')).replace(/<script\b[\s\S]*?<\/script>/gi, '').replace(/\s(on\w+)=["'][^"']*["']/g, '');
            } catch (err) {
              out = raw.replace(/</g, '&lt;').replace(/>/g, '&gt;');
            }
          } else {
            out = raw.replace(/</g, '&lt;').replace(/>/g, '&gt;');
          }
          if (msg.citations && msg.citations.length) {
            msg.citations.forEach((c, i) => {
              const idx = i + 1;
              const num = String(idx);
              const squarePattern = new RegExp(`\\[${idx}\\]`, 'g');
              const fullPattern = new RegExp(`【${idx}】`, 'g');
              const span = `<span class="nlm-citation" data-source-id="${c.sourceId}" data-excerpt-index="${c.excerptIndex}" aria-label="引用 ${num}">${num}</span>`;
              out = out.replace(squarePattern, span);
              out = out.replace(fullPattern, span);
            });
          }
          out = out.replace(/\[(E\d+)\]/g, (_, k) => `<span class="analysis-inline-citation" data-cite="${k}" aria-label="引用 ${k}">${k}</span>`);
          return out;
        },
        renderMessage(msg) {
          if (msg.role === 'user') return msg.text.replace(/</g, '&lt;').replace(/>/g, '&gt;');
          return this.renderMarkdownFromBotText(msg.text || '', msg);
        },
        renderMessageBodyHtml(msg) {
          return this.renderMarkdownFromBotText(msg.text || '', msg);
        },
        onChatMarkdownBodyClick(e) {
          if (!e.target.closest('.nlm-citation')) return;
          e.preventDefault();
          this.handleCitationClick(e);
        },
        onMsgBubbleClick(msg, e) {
          if (e.target.closest('.analysis-inline-citation')) {
            e.stopPropagation();
            this.handleChatAnalysisInlineCitationClick(e);
            return;
          }
          if (e.target.closest('.nlm-citation')) {
            e.stopPropagation();
            this.handleCitationClick(e);
            return;
          }
        },
        handleChatAnalysisInlineCitationClick(e) {
          const el = e.target.closest('.analysis-inline-citation');
          if (!el) return;
          const key = String(el.getAttribute('data-cite') || '').trim();
          if (!key || !this.workbenchAnalysisCitationMap[key]) return;
          const current = this.selectedMaterial;
          let target = null;
          if (current && current.type === 'analysis') target = current;
          else target = (this.materials || []).find((m) => m.type === 'analysis') || null;
          if (!target) return;
          this.sourcesCollapsed = false;
          this.studioCollapsed = false;
          this.lastDetailFocus = 'right';
          this.sourcesRightView = 'detail';
          this.sourcesLeftView = 'list';
          this.sourcesDetailWidth = 450;
          this.selectedMaterialId = target.id;
        },
        handleCitationClick(e) {
          const el = e.target.closest('.nlm-citation');
          if (!el) return;
          const sourceId = el.dataset.sourceId;
          const excerptIndex = parseInt(el.dataset.excerptIndex, 10);
          const found = this.findMaterialBySourceId(sourceId);
          if (!found) return;
          const m = found.material;
          if (m.loading) return;
          if (!this.canOpenMaterialPreview(m)) {
            message.info('该资料尚未完成解析，暂不可预览');
            return;
          }
          if (!this.canOpenAnalysisPreview(m)) {
            message.info('该结果尚未完成，暂不可预览');
            return;
          }
          this.sourcesCollapsed = false;
          this.studioCollapsed = false;
          this.clearWorkbenchAnalysisCitationFloats();
          this.openMaterialDetail(m);
          if (m.type === 'analysis') {
            this.$nextTick(() => {
              const root = this.$el && this.$el.querySelector ? this.$el : document.body;
              const scrollEl = root.querySelector('.analysis-result-preview-modal--workbench-embed.nlm-fill-scroll');
              if (scrollEl) scrollEl.scrollTo({ top: 0, behavior: 'smooth' });
            });
            return;
          }
          this.highlightSourceId = m.id;
          this.highlightExcerptIndex = excerptIndex;
          this.$nextTick(() => {
            const ref = this.excerptRefs[m.id] && this.excerptRefs[m.id][excerptIndex];
            if (ref) ref.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setTimeout(() => {
              this.highlightSourceId = null;
              this.highlightExcerptIndex = null;
            }, 2000);
          });
        },
        findMaterialBySourceId(sourceId) {
          for (const m of this.materials) {
            if (m.id === sourceId) return { material: m };
            if (m.paired && m.paired.id === sourceId) return { material: m };
          }
          return null;
        },
        getExcerptTextForCitation(sourceId, excerptIndex) {
          const found = this.findMaterialBySourceId(sourceId);
          if (!found) return '';
          const m = found.material;
          if (m.type === 'analysis' || m.type === 'report') {
            const block = m.excerptsWithCitations && m.excerptsWithCitations[excerptIndex];
            return block && block.text != null ? block.text : '';
          }
          if (m.excerpts && m.excerpts[excerptIndex] != null) return m.excerpts[excerptIndex];
          if (m.paired && m.paired.citations && m.paired.citations[excerptIndex]) return m.paired.citations[excerptIndex].excerpt || '';
          return '';
        },
        getCitationSourceLabel(sourceId) {
          const found = this.findMaterialBySourceId(sourceId);
          if (!found || !found.material) return '引用来源';
          return String(found.material.title || '引用来源');
        },
        buildCitationPopoverExcerpt(text) {
          const raw = String(text || '').trim();
          if (!raw) return '暂无可展示的溯源内容';
          const compact = raw.replace(/\s+/g, ' ').trim();
          return compact.length > 120 ? `${compact.slice(0, 120)}...` : compact;
        },
        onChatMsgMouseEnter(ev) {
          const analysisEl = ev.target.closest('.analysis-inline-citation');
          if (analysisEl) {
            const key = String(analysisEl.getAttribute('data-cite') || '').trim();
            const data = this.workbenchAnalysisCitationMap[key];
            if (!data) return;
            if (this.citationPopoverTimer) {
              clearTimeout(this.citationPopoverTimer);
              this.citationPopoverTimer = null;
            }
            const rect = analysisEl.getBoundingClientRect();
            let x = rect.left;
            let y = rect.bottom + 4;
            const maxW = 320;
            const maxH = 200;
            if (x + maxW > window.innerWidth) x = window.innerWidth - maxW - 8;
            if (x < 8) x = 8;
            if (y + maxH > window.innerHeight) y = rect.top - maxH - 4;
            if (y < 8) y = 8;
            this.citationPopover = {
              show: true,
              title: data.sourceLabel ? `来源：${data.sourceLabel}` : '引用来源',
              excerpt: this.buildCitationPopoverExcerpt(data.sourceExcerpt || ''),
              x,
              y,
            };
            return;
          }
          const el = ev.target.closest('.nlm-citation');
          if (!el) return;
          const sourceId = el.dataset.sourceId;
          const excerptIndex = parseInt(el.dataset.excerptIndex, 10);
          if (isNaN(excerptIndex)) return;
          const excerpt = this.getExcerptTextForCitation(sourceId, excerptIndex);
          if (this.citationPopoverTimer) {
            clearTimeout(this.citationPopoverTimer);
            this.citationPopoverTimer = null;
          }
          const rect = el.getBoundingClientRect();
          let x = rect.left;
          let y = rect.bottom + 4;
          const maxW = 320;
          const maxH = 200;
          if (x + maxW > window.innerWidth) x = window.innerWidth - maxW - 8;
          if (x < 8) x = 8;
          if (y + maxH > window.innerHeight) y = rect.top - maxH - 4;
          if (y < 8) y = 8;
          this.citationPopover = {
            show: true,
            title: `来源：${this.getCitationSourceLabel(sourceId)}`,
            excerpt: this.buildCitationPopoverExcerpt(excerpt || ''),
            x,
            y,
          };
        },
        onChatMsgMouseLeave(ev) {
          if (ev.relatedTarget && ev.relatedTarget.closest('.nlm-extract-citation-popover')) return;
          this.onExtractCitationLeave();
        },
        copyMessage(msg) {
          navigator.clipboard?.writeText(this.getMessageFullPlainText(msg));
          this.toastMessage = '已复制';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        pinMessage(msg) {
          if (msg.pinned === undefined) msg.pinned = false;
          msg.pinned = !msg.pinned;
          this.toastMessage = msg.pinned ? '已钉住' : '已取消钉住';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        openSaveResultModal(msg, payload) {
          if (!msg || msg.role !== 'bot') return;
          const seedText = this.getMessageFullPlainText(msg);
          const seedName = (seedText.slice(0, 28) + (seedText.length > 28 ? '...' : '') || '对话结果').trim();
          this.saveResultModalSourceType = 'message';
          this.saveResultModalSourceMsgId = msg.id;
          this.saveResultModalSourcePayload = null;
          this.saveResultForm = { name: seedName };
          this.saveResultModalVisible = true;
        },
        closeSaveResultModal() {
          this.saveResultModalVisible = false;
          this.saveResultModalSourceType = 'message';
          this.saveResultModalSourceMsgId = null;
          this.saveResultModalSourcePayload = null;
          this.saveResultForm = { name: '' };
        },
        confirmSaveResultModal() {
          const name = String((this.saveResultForm && this.saveResultForm.name) || '').trim();
          if (!name) {
            message.warning('请先输入结果名称');
            return;
          }
          const msg = (this.chatMessages || []).find((x) => x.id === this.saveResultModalSourceMsgId);
          if (!msg) {
            message.warning('未找到对应消息，无法保存');
            return;
          }
          this.addMessageToMaterialPool(msg, name);
          this.closeSaveResultModal();
        },
        addMessageToMaterialPool(msg, customName) {
          const text = this.getMessageFullPlainText(msg);
          const title = String(customName || '').trim() || text.slice(0, 28) + (text.length > 28 ? '...' : '') || '对话结果';
          this.createWorkbenchResultRowFromMarkdown({
            name: title,
            markdown: this.formatSavedResultBodyFromMessage(msg),
            overview: text,
          });
          msg.saved = true;
          this.toastMessage = '已保存到结果';
          setTimeout(() => { this.toastMessage = ''; }, 2000);
        },
        summaryTaskStatusLabel(task) {
          const map = { queued: '排队中', running: '总结中', done: '总结完成' };
          return map[String((task && task.status) || 'queued')] || '排队中';
        },
        makeSummaryTemplateDraftFromMessage(msg) {
          const text = String((msg && this.getMessageFullPlainText(msg)) || '').trim();
          const plain = text.replace(/\s+/g, ' ').trim();
          const nameSeed = plain ? plain.slice(0, 18) : '对话总结';
          const tags = ['技能', '对话总结', '审计助手'];
          return {
            name: `${nameSeed}技能`,
            description: `基于审计助手对话内容提炼，可复用于同类审计分析任务。`,
            tags,
            analysisRule: plain || '请结合当前资料与审计发现进行结构化分析，输出关键风险、证据链和复核建议。',
            extractionRules: [
              {
                id: 'sum-er-' + Date.now().toString(36),
                title: '对话上下文与已引用资料',
                body: '提炼核心事实、关键金额/日期/主体及异常线索，形成可复用分析输入。',
                materialIds: [],
              },
            ],
          };
        },
        /** 打开「生成技能配置」弹窗（含意图与三条逐步展示的推荐）；兼容旧入口 */
        summarizeLatestBotMessageToTemplate() {
          this.openGenerateSkillConfigModal();
        },
        openGenerateSkillConfigModal() {
          if (!this.workbenchProjectId) {
            message.warning('请先进入具体工作台后再生成技能');
            return;
          }
          this.clearWbGenerateSkillRecoTimers();
          this.wbGenerateSkillIntentText = '';
          this.wbGenerateSkillRecommendationItems = [
            { loading: true, text: '' },
            { loading: true, text: '' },
            { loading: true, text: '' },
          ];
          this.wbGenerateSkillConfigModalOpen = true;
          this.$nextTick(() => {
            this.startGenerateSkillRecommendationSimulation();
          });
        },
        closeGenerateSkillConfigModal() {
          this.wbGenerateSkillConfigModalOpen = false;
          this.clearWbGenerateSkillRecoTimers();
        },
        clearWbGenerateSkillRecoTimers() {
          (this._wbGenerateSkillRecoTimers || []).forEach((tid) => window.clearTimeout(tid));
          this._wbGenerateSkillRecoTimers = [];
        },
        getLatestBotMessagePlainSeed() {
          const list = this.chatMessages || [];
          for (let i = list.length - 1; i >= 0; i--) {
            const m = list[i];
            if (m && m.role === 'bot') {
              const t = String(this.getMessageFullPlainText(m) || '').trim();
              if (t) return t.replace(/\s+/g, ' ').slice(0, 80);
            }
          }
          return '';
        },
        buildGenerateSkillRecommendationTexts() {
          const seed = this.getLatestBotMessagePlainSeed();
          const topic = seed || '当前审计主题与已引用资料';
          const short = topic.length > 28 ? `${topic.slice(0, 28)}…` : topic;
          return [
            `针对「${short}」提炼可复用核查技能：输出结构化风险清单、证据引用位与复核要点。`,
            '围绕对话中的关键实体与金额口径，生成对标检查步骤、输出段落模板与禁运项说明。',
            '结合当前结论与待复核疑点，生成后续同类任务可一键复用的分析技能（含输入边界与引用资料范围）。',
          ];
        },
        startGenerateSkillRecommendationSimulation() {
          this.clearWbGenerateSkillRecoTimers();
          const texts = this.buildGenerateSkillRecommendationTexts();
          const delays = [320, 760, 1280];
          this._wbGenerateSkillRecoTimers = [];
          texts.forEach((text, idx) => {
            const tid = window.setTimeout(() => {
              const rows = this.wbGenerateSkillRecommendationItems || [];
              if (!rows[idx]) return;
              rows[idx].text = text;
              rows[idx].loading = false;
            }, delays[idx]);
            this._wbGenerateSkillRecoTimers.push(tid);
          });
        },
        applyGenerateSkillRecommendation(text) {
          const t = String(text || '').trim();
          if (!t) return;
          this.wbGenerateSkillIntentText = t;
        },
        submitGenerateSkillConfig() {
          const intent = String(this.wbGenerateSkillIntentTrimmed || '').trim();
          if (!intent) {
            message.warning('请填写意图，或待推荐生成完成后点选一条');
            return;
          }
          const taskId = 'wb-gen-skill-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const nameLine = intent.length > 36 ? `${intent.slice(0, 36)}…` : intent;
          const created = {
            id: taskId,
            type: 'analysis',
            title: `生成技能任务 · ${nameLine}`,
            checked: false,
            projectSource: {
              status: 'queued',
              createdAt: now,
              sourceSkillName: '按意图生成技能配置',
              name: '按意图生成的技能配置（演示）',
            },
            status: 'queued',
            taskConfig: {
              taskType: 'generate-skill',
              skillName: '生成技能配置',
              intent,
              outputSkillName: `可复用核查技能 · ${nameLine}`,
              resources: [
                { key: 'dialog-intent', name: intent.length > 160 ? `${intent.slice(0, 160)}…` : intent },
              ],
            },
          };
          this.workbenchCreatedTasks = [created, ...(this.workbenchCreatedTasks || [])];
          this.closeGenerateSkillConfigModal();
          message.success('已在右侧任务区创建「生成技能任务」');
          this.studioCollapsed = false;
        },
        openSummarizeToTemplateModal(msg) {
          if (!msg || msg.role !== 'bot') return;
          if (!this.workbenchProjectId) {
            message.warning('请先进入具体工作台后再总结为技能');
            return;
          }
          const draft = this.makeSummaryTemplateDraftFromMessage(msg);
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('缺少工作台上下文，无法创建工作台级技能');
            return;
          }
          if (!demoProjectAnalysisTemplatesById[pid]) demoProjectAnalysisTemplatesById[pid] = [];
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const placeholderId = 'sk-prj-sum-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 5);
          const placeholder = {
            id: placeholderId,
            library: 'project',
            name: draft.name,
            description: draft.description || '',
            tags: Array.from(new Set([...(draft.tags || []), '总结中'])),
            extractionRules: Array.isArray(draft.extractionRules) && draft.extractionRules.length ? draft.extractionRules.map((x) => ({ ...x })) : [{ id: 'sum-er-' + Date.now().toString(36), title: '总结中', body: '正在根据对话生成技能配置，请稍候。', materialIds: [] }],
            analysisRule: String(draft.analysisRule || '').trim(),
            manualMaterialIds: [],
            createdAt: now,
            updatedAt: now,
          };
          demoProjectAnalysisTemplatesById[pid] = [placeholder, ...(demoProjectAnalysisTemplatesById[pid] || [])];
          this.enqueueSummaryTemplateTask({
            sourceMsgId: msg.id,
            name: draft.name,
            draftTemplate: draft,
            templateId: placeholderId,
            projectId: pid,
          });
          this.workbenchLeftPrimaryTab = 'skill';
          this.sourcesCollapsed = false;
          this.sourcesLeftView = 'list';
          this.studioCollapsed = false;
          this.toastMessage = '已开始总结，已在技能栏新增工作台级技能（总结中）';
          setTimeout(() => { this.toastMessage = ''; }, 1200);
        },
        enqueueSummaryTemplateTask(payload) {
          const id = 'sum-task-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
          const task = {
            id,
            taskName: payload.name || '对话总结技能任务',
            sourceMsgId: payload.sourceMsgId || null,
            status: 'queued',
            progress: 8,
            draftTemplate: payload.draftTemplate || null,
            templateId: payload.templateId || '',
            projectId: payload.projectId || '',
            savedTemplateId: null,
          };
          this.summaryTemplateTasks = [task, ...(this.summaryTemplateTasks || [])];
          if (task.templateId) {
            this.summarySkillTaskByTemplateId = {
              ...(this.summarySkillTaskByTemplateId || {}),
              [task.templateId]: id,
            };
          }
          this.runSummaryTemplateTask(id);
          return task;
        },
        _clearSummaryTaskTimers(taskId) {
          if (!this._summaryTaskTimers) return;
          const key = String(taskId || '');
          const pair = this._summaryTaskTimers[key];
          if (!pair) return;
          if (pair.startTimer) window.clearTimeout(pair.startTimer);
          if (pair.progressTimer) window.clearInterval(pair.progressTimer);
          if (pair.doneTimer) window.clearTimeout(pair.doneTimer);
          delete this._summaryTaskTimers[key];
        },
        runSummaryTemplateTask(taskId) {
          const key = String(taskId || '');
          if (!key) return;
          if (!this._summaryTaskTimers) this._summaryTaskTimers = {};
          this._clearSummaryTaskTimers(key);
          const startTimer = window.setTimeout(() => {
            const idx = (this.summaryTemplateTasks || []).findIndex((x) => x.id === key);
            if (idx < 0) return;
            const startTask = this.summaryTemplateTasks[idx];
            this.summaryTemplateTasks.splice(idx, 1, { ...startTask, status: 'running', progress: 20 });
          }, 400);
          const progressTimer = window.setInterval(() => {
            const idx = (this.summaryTemplateTasks || []).findIndex((x) => x.id === key);
            if (idx < 0) { this._clearSummaryTaskTimers(key); return; }
            const task = this.summaryTemplateTasks[idx];
            if (task.status !== 'running') return;
            const next = Math.min(92, Number(task.progress || 20) + Math.max(3, Math.round(Math.random() * 10)));
            this.summaryTemplateTasks.splice(idx, 1, { ...task, progress: next });
          }, 520);
          const doneTimer = window.setTimeout(() => {
            const idx = (this.summaryTemplateTasks || []).findIndex((x) => x.id === key);
            if (idx < 0) return;
            const task = this.summaryTemplateTasks[idx];
            const doneTask = { ...task, status: 'done', progress: 100 };
            this.summaryTemplateTasks.splice(idx, 1, doneTask);
            this._clearSummaryTaskTimers(key);
            this.finalizeSummaryProjectSkill(doneTask);
          }, 3200);
          this._summaryTaskTimers[key] = { startTimer, progressTimer, doneTimer };
        },
        finalizeSummaryProjectSkill(task) {
          const pid = String((task && task.projectId) || '');
          const templateId = String((task && task.templateId) || '');
          if (!pid || !templateId) return;
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          const idx = list.findIndex((x) => String(x.id) === templateId);
          if (idx < 0) return;
          const current = list[idx];
          const draft = task.draftTemplate || {};
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          let rules = Array.isArray(draft.extractionRules) ? draft.extractionRules : [];
          if (!rules.length) {
            rules = [{ id: 'sum-er-' + Date.now().toString(36), title: '对话上下文与已引用资料', body: '提炼核心事实并组织为可复用输入。', materialIds: [] }];
          }
          const mats = demoProjectMaterialsById[pid] || [];
          if (window.DemoProjectSkillMatch) {
            rules = rules.map((r) =>
              window.DemoProjectSkillMatch.normalizeRuleForProjectTemplate(r, (rule) =>
                window.DemoProjectSkillMatch.autoMatchMaterialIdsForRule(rule, mats),
              ),
            );
          }
          const manualMaterialIds = Array.from(
            new Set(rules.flatMap((r) => (Array.isArray(r.materialIds) ? r.materialIds : []).map((x) => String(x)))),
          );
          const tags = (Array.isArray(draft.tags) ? draft.tags : []).filter((t) => String(t || '').trim() && String(t || '').trim() !== '总结中');
          const merged = {
            ...current,
            name: String(draft.name || current.name || '未命名技能').trim(),
            description: String(draft.description || current.description || '').trim(),
            tags: tags.length ? tags : (current.tags || []).filter((t) => String(t || '').trim() !== '总结中'),
            extractionRules: rules,
            analysisRule: String(draft.analysisRule || current.analysisRule || '').trim(),
            manualMaterialIds,
            updatedAt: now,
          };
          list.splice(idx, 1, merged);
          demoProjectAnalysisTemplatesById[pid] = [...list];
          const map = { ...(this.summarySkillTaskByTemplateId || {}) };
          delete map[templateId];
          this.summarySkillTaskByTemplateId = map;
          this.toastMessage = `技能「${merged.name || '未命名'}」已总结完成`;
          setTimeout(() => { this.toastMessage = ''; }, 1600);
        },
        cancelSummaryTemplateTask(task) {
          if (!task || !task.id) return;
          Modal.confirm({
            title: '确定取消该任务？',
            content: '取消后任务卡片会消失，且本次总结结果不会保存。',
            okText: '确认取消',
            okType: 'danger',
            cancelText: '继续执行',
            onOk: () => {
              const id = String(task.id);
              const templateId = String(task.templateId || '');
              this._clearSummaryTaskTimers(id);
              this.summaryTemplateTasks = (this.summaryTemplateTasks || []).filter((x) => x.id !== id);
              if (templateId) {
                const map = { ...(this.summarySkillTaskByTemplateId || {}) };
                delete map[templateId];
                this.summarySkillTaskByTemplateId = map;
              }
              this.toastMessage = '任务已取消';
              setTimeout(() => { this.toastMessage = ''; }, 1200);
            },
          });
        },
        openSummaryTaskResultModal(task) {
          if (!task || task.status !== 'done' || !task.draftTemplate) return;
          const d = task.draftTemplate;
          const rules = Array.isArray(d.extractionRules) && d.extractionRules.length
            ? d.extractionRules.map((r) => ({
              id: r.id || ('sum-er-' + Date.now().toString(36)),
              title: String(r.title || '').trim(),
              body: String(r.body || '').trim(),
              materialIds: Array.isArray(r.materialIds) ? Array.from(new Set(r.materialIds.map((id) => String(id)))) : [],
            }))
            : [{ id: 'sum-er-' + Date.now().toString(36), title: '', body: '', materialIds: [] }];
          this.summaryTaskResultTaskId = task.id;
          this.summaryTaskResultForm = {
            name: d.name || '',
            extractionRules: rules,
            analysisRule: d.analysisRule || '',
          };
          this.summaryTaskResultExpandedRuleId = (rules[0] && rules[0].id) || '';
          this.summaryTaskResultModalVisible = true;
        },
        closeSummaryTaskResultModal() {
          this.summaryTaskResultModalVisible = false;
          this.summaryTaskResultTaskId = null;
          this.summaryTaskResultExpandedRuleId = '';
          this.summaryTaskResultForm = { name: '', extractionRules: [], analysisRule: '' };
        },
        summaryRuleMatchedMaterialCount(rule) {
          const ids = Array.isArray(rule && rule.materialIds) ? rule.materialIds : [];
          return Array.from(new Set(ids.map((x) => String(x)))).length;
        },
        toggleSummaryTemplateRuleExpand(ruleId) {
          const id = String(ruleId || '');
          if (!id) return;
          this.summaryTaskResultExpandedRuleId = this.summaryTaskResultExpandedRuleId === id ? '' : id;
        },
        addSummaryTemplateExtractionRule() {
          if (!Array.isArray(this.summaryTaskResultForm.extractionRules)) this.summaryTaskResultForm.extractionRules = [];
          const newRule = {
            id: 'sum-er-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6),
            title: '',
            body: '',
            materialIds: [],
          };
          this.summaryTaskResultForm.extractionRules.push(newRule);
          this.summaryTaskResultExpandedRuleId = newRule.id;
        },
        removeSummaryTemplateExtractionRule(index) {
          const list = Array.isArray(this.summaryTaskResultForm.extractionRules) ? this.summaryTaskResultForm.extractionRules : [];
          if (list.length <= 1) return;
          const removed = list[index];
          list.splice(index, 1);
          this.summaryTaskResultForm.extractionRules = [...list];
          if (removed && this.summaryTaskResultExpandedRuleId === removed.id) {
            this.summaryTaskResultExpandedRuleId = (list[0] && list[0].id) || '';
          }
        },
        confirmSummaryTaskResultModal() {
          const taskId = this.summaryTaskResultTaskId;
          if (!taskId) return;
          const idx = (this.summaryTemplateTasks || []).findIndex((x) => x.id === taskId);
          if (idx < 0) return;
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('缺少工作台上下文，无法保存技能');
            return;
          }
          const name = String(this.summaryTaskResultForm.name || '').trim();
          if (!name) {
            message.warning('请填写技能名称');
            return;
          }
          const draft = this.summaryTemplateTasks[idx].draftTemplate || {};
          const tags = Array.isArray(draft.tags) && draft.tags.length ? draft.tags : ['技能', '对话总结'];
          const description = String(draft.description || '').trim();
          const analysisRule = String(this.summaryTaskResultForm.analysisRule || '').trim();
          if (!demoProjectAnalysisTemplatesById[pid]) demoProjectAnalysisTemplatesById[pid] = [];
          const newId = 'sk-prj-sum-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 5);
          let rules = (this.summaryTaskResultForm.extractionRules || [])
            .map((x) => ({
              id: x.id || ('sum-er-' + Date.now().toString(36)),
              title: String(x.title || '').trim(),
              body: String(x.body || '').trim(),
              materialIds: [],
            }))
            .filter((x) => x.title && x.body);
          if (!rules.length) {
            rules = [{ id: 'sum-er-' + Date.now().toString(36), title: '对话上下文与已引用资料', body: '提炼核心事实并组织为可复用输入。', materialIds: [] }];
          }
          const mats = demoProjectMaterialsById[pid] || [];
          if (window.DemoProjectSkillMatch) {
            rules = rules.map((r) =>
              window.DemoProjectSkillMatch.normalizeRuleForProjectTemplate(r, (rule) =>
                window.DemoProjectSkillMatch.autoMatchMaterialIdsForRule(rule, mats),
              ),
            );
          }
          const manualMaterialIds = Array.from(
            new Set(rules.flatMap((r) => (Array.isArray(r.materialIds) ? r.materialIds : []).map((x) => String(x)))),
          );
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          let skillFiles = [];
          if (T && rules.length) {
            skillFiles = rules.map((r, ri) => ({
              id: newId + '-sf' + (ri + 1),
              kind: 'file',
              fileKind: 'md',
              codeLang: '',
              filename: (String(r.title || '').trim() || '条目' + (ri + 1)) + '.md',
              content: String(r.body || ''),
              materialIds: Array.isArray(r.materialIds) ? r.materialIds.slice() : [],
            }));
          }
          const row = {
            id: newId,
            library: 'project',
            name,
            description,
            tags,
            skillFiles,
            extractionRules: T && skillFiles.length ? [] : rules,
            analysisRule,
            manualMaterialIds,
            createdAt: new Date().toISOString().slice(0, 19).replace('T', ' '),
            updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' '),
          };
          if (T && T.syncExtractionRulesFromSkillFiles && skillFiles.length) {
            T.syncExtractionRulesFromSkillFiles(row);
          }
          demoProjectAnalysisTemplatesById[pid] = [row, ...(demoProjectAnalysisTemplatesById[pid] || [])];
          const currentTask = this.summaryTemplateTasks[idx];
          this.summaryTemplateTasks.splice(idx, 1, { ...currentTask, savedTemplateId: newId });
          this.closeSummaryTaskResultModal();
          this.toastMessage = '已保存为工作台级技能';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        parseChatInputAtReferences(text) {
          const t = String(text || '');
          const candidates = [];
          (this.materials || []).forEach((m) => {
            const title = String(m.title != null ? m.title : '未命名').trim() || '未命名';
            candidates.push({ id: m.id, title });
          });
          candidates.sort((a, b) => b.title.length - a.title.length);
          const used = new Set();
          const titles = [];
          let pos = 0;
          while (pos < t.length) {
            const at = t.indexOf('@', pos);
            if (at < 0) break;
            const after = t.slice(at + 1);
            let matched = null;
            for (let c = 0; c < candidates.length; c++) {
              const cand = candidates[c];
              if (after.startsWith(cand.title)) {
                const nextCh = after[cand.title.length];
                if (nextCh === undefined || /\s/.test(nextCh) || '，。、；：!！?？）]}'.includes(nextCh)) {
                  matched = cand;
                  break;
                }
              }
            }
            if (matched) {
              const ukey = 'm:' + matched.id;
              if (!used.has(ukey)) {
                used.add(ukey);
                titles.push(matched.title);
              }
              pos = at + 1 + matched.title.length;
            } else {
              pos = at + 1;
            }
          }
          return titles;
        },
        appendChatInputToken(token) {
          const raw = String(token || '').trim();
          if (!raw) return;
          const cur = this.chatInput || '';
          const sep = cur.length && !/\s$/.test(cur) ? ' ' : '';
          this.chatInput = cur + sep + raw + (/\s$/.test(raw) ? '' : ' ');
          this.$nextTick(() => {
            this.adjustInputHeight();
            const el = this.$refs.chatInputEl;
            if (el && el.focus) el.focus();
          });
        },
        closeChatInputTriggerMenu() {
          this.unbindChatAtFloaterReposition();
          this.chatAtFloaterStyle = {};
          this.chatInputTriggerOpen = false;
          this.chatInputTriggerKind = null;
          this.chatTriggerFilter = '';
          this.chatAtMenuPanel = 'categories';
        },
        pickDefaultChatInputAtRail() {
          if (this.chatAtMenuRawMaterials.length) return 'raw';
          if (this.chatAtMenuResultMaterials.length) return 'result';
          return 'raw';
        },
        syncChatInputTriggerFromCaret(text, pos) {
          const t = String(text || '');
          const p = pos == null ? t.length : Math.min(Math.max(0, pos), t.length);
          const prefix = t.slice(0, p);
          const atM = prefix.match(/(?:^|[\s\n])@([^\s\n@]*)$/);
          const slashM = prefix.match(/(?:^|[\s\n])\/([^\s\n/]*)$/);
          let pick = null;
          let atFilter = '';
          let slashFilter = '';
          if (atM) {
            atFilter = atM[1] || '';
            pick = 'at';
          }
          if (slashM) {
            slashFilter = slashM[1] || '';
            if (!pick) pick = 'slash';
            else {
              const atTrig = prefix.length - atM[0].length + (atM[0][0] === '@' ? 0 : 1);
              const slashTrig = prefix.length - slashM[0].length + (slashM[0][0] === '/' ? 0 : 1);
              pick = atTrig >= slashTrig ? 'at' : 'slash';
            }
          }
          if (pick === 'at') {
            const prev = this.chatInputTriggerKind;
            this.chatInputTriggerOpen = true;
            this.chatInputTriggerKind = 'at';
            this.chatTriggerFilter = atFilter;
            if (prev !== 'at') {
              this.chatAtMenuPanel = 'categories';
              this.chatInputAtRail = this.pickDefaultChatInputAtRail();
            }
            this.$nextTick(() => {
              this.bindChatAtFloaterReposition();
              this.scheduleUpdateChatAtFloaterPosition();
            });
            return;
          }
          if (pick === 'slash') {
            this.unbindChatAtFloaterReposition();
            this.chatAtFloaterStyle = {};
            this.chatInputTriggerOpen = true;
            this.chatInputTriggerKind = 'slash';
            this.chatTriggerFilter = slashFilter;
            return;
          }
          this.closeChatInputTriggerMenu();
        },
        onChatInputInput(e) {
          this.adjustInputHeight();
          const el = e && e.target;
          if (!el) return;
          this.syncChatInputTriggerFromCaret(el.value, el.selectionStart);
          if (this.chatInputTriggerKind === 'at' && this.chatInputTriggerOpen) {
            this.$nextTick(() => this.scheduleUpdateChatAtFloaterPosition());
          }
        },
        onChatInputKeydown(e) {
          if (e.isComposing || e.keyCode === 229) return;
          if (e.key === 'Escape' && this.chatInputTriggerOpen) {
            e.preventDefault();
            this.closeChatInputTriggerMenu();
            return;
          }
          if (e.key === 'Enter' && !e.shiftKey && this.chatInputTriggerOpen) {
            e.preventDefault();
            return;
          }
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            this.sendChat();
          }
        },
        onChatInputFocus() {
          if (this._chatInputBlurTimer) {
            window.clearTimeout(this._chatInputBlurTimer);
            this._chatInputBlurTimer = null;
          }
        },
        onChatInputBlur() {
          if (this._chatInputBlurTimer) window.clearTimeout(this._chatInputBlurTimer);
          this._chatInputBlurTimer = window.setTimeout(() => {
            this._chatInputBlurTimer = null;
            this.closeChatInputTriggerMenu();
          }, 180);
        },
        computeChatAtTriggerCharIndex(text, caretPos) {
          const t = String(text || '');
          const p = caretPos == null ? t.length : Math.min(Math.max(0, caretPos), t.length);
          const prefix = t.slice(0, p);
          const m = prefix.match(/(?:^|[\s\n])@([^\s\n@]*)$/);
          if (!m) return -1;
          return prefix.length - m[0].length + (m[0][0] === '@' ? 0 : 1);
        },
        getTextareaCaretViewportRectAtIndex(textarea, index) {
          if (!textarea || index == null || index < 0) return null;
          const text = String(textarea.value || '');
          const pos = Math.min(Math.max(0, index), text.length);
          const computed = window.getComputedStyle(textarea);
          const mirror = document.createElement('div');
          const ms = mirror.style;
          ms.position = 'fixed';
          ms.visibility = 'hidden';
          ms.pointerEvents = 'none';
          ms.whiteSpace = 'pre-wrap';
          ms.wordBreak = 'break-word';
          ms.overflow = 'hidden';
          ms.boxSizing = computed.boxSizing;
          ms.width = `${textarea.clientWidth}px`;
          ms.maxHeight = `${textarea.clientHeight}px`;
          ms.font = computed.font;
          ms.fontSize = computed.fontSize;
          ms.fontFamily = computed.fontFamily;
          ms.fontWeight = computed.fontWeight;
          ms.fontStyle = computed.fontStyle;
          ms.letterSpacing = computed.letterSpacing;
          ms.lineHeight = computed.lineHeight;
          ms.padding = computed.padding;
          ms.border = computed.border;
          ms.textAlign = computed.textAlign;
          ms.textTransform = computed.textTransform;
          ms.textIndent = computed.textIndent;
          const taRect = textarea.getBoundingClientRect();
          const pl = parseFloat(computed.paddingLeft) || 0;
          const pt = parseFloat(computed.paddingTop) || 0;
          const bl = parseFloat(computed.borderLeftWidth) || 0;
          const bt = parseFloat(computed.borderTopWidth) || 0;
          ms.top = `${taRect.top + bt + pt}px`;
          ms.left = `${taRect.left + bl + pl}px`;
          mirror.textContent = text.slice(0, pos);
          const span = document.createElement('span');
          span.textContent = text.slice(pos, pos + 1) || '\u200b';
          mirror.appendChild(span);
          document.body.appendChild(mirror);
          mirror.scrollTop = textarea.scrollTop;
          const rect = span.getBoundingClientRect();
          document.body.removeChild(mirror);
          const lineHeight = parseFloat(computed.lineHeight) || 20;
          const h = rect.height > 0 ? rect.height : lineHeight;
          return { left: rect.left, top: rect.top, height: h };
        },
        scheduleUpdateChatAtFloaterPosition() {
          if (this.chatInputTriggerKind !== 'at' || !this.chatInputTriggerOpen) return;
          this.$nextTick(() => {
            requestAnimationFrame(() => {
              requestAnimationFrame(() => {
                const ta = this.$refs.chatInputEl;
                if (!ta || this.chatInputTriggerKind !== 'at' || !this.chatInputTriggerOpen) return;
                const idx = this.computeChatAtTriggerCharIndex(this.chatInput || '', ta.selectionStart);
                if (idx < 0) return;
                const caret = this.getTextareaCaretViewportRectAtIndex(ta, idx);
                if (!caret) return;
                const gap = 6;
                const floater = this.$refs.chatAtTriggerFloater;
                const fw = floater && floater.offsetWidth ? floater.offsetWidth : 280;
                const fh = floater && floater.offsetHeight ? floater.offsetHeight : 220;
                const vw = window.innerWidth;
                const vh = window.innerHeight;
                const pad = 8;
                let left = caret.left;
                left = Math.min(Math.max(pad, left), vw - fw - pad);
                let top = caret.top - gap;
                const minTop = pad + fh;
                if (top < minTop) top = minTop;
                if (top > vh - pad) top = vh - pad;
                this.chatAtFloaterStyle = {
                  position: 'fixed',
                  left: `${Math.round(left)}px`,
                  top: `${Math.round(top)}px`,
                  transform: 'translateY(-100%)',
                  zIndex: 1100,
                };
              });
            });
          });
        },
        bindChatAtFloaterReposition() {
          if (this._chatAtFloaterReposBound) return;
          const fn = () => {
            if (this.chatInputTriggerKind === 'at' && this.chatInputTriggerOpen) this.scheduleUpdateChatAtFloaterPosition();
          };
          this._chatAtFloaterReposBound = fn;
          window.addEventListener('scroll', fn, true);
          window.addEventListener('resize', fn);
          if (window.visualViewport) {
            window.visualViewport.addEventListener('scroll', fn);
            window.visualViewport.addEventListener('resize', fn);
          }
        },
        unbindChatAtFloaterReposition() {
          if (!this._chatAtFloaterReposBound) return;
          const fn = this._chatAtFloaterReposBound;
          window.removeEventListener('scroll', fn, true);
          window.removeEventListener('resize', fn);
          if (window.visualViewport) {
            window.visualViewport.removeEventListener('scroll', fn);
            window.visualViewport.removeEventListener('resize', fn);
          }
          this._chatAtFloaterReposBound = null;
        },
        openChatInputAtSubmenu(key) {
          if (key !== 'raw' && key !== 'result') return;
          this.chatInputAtRail = key;
          this.chatAtMenuPanel = 'items';
          this.$nextTick(() => this.scheduleUpdateChatAtFloaterPosition());
        },
        backChatInputAtSubmenu() {
          this.chatAtMenuPanel = 'categories';
          this.$nextTick(() => this.scheduleUpdateChatAtFloaterPosition());
        },
        replaceChatInputTriggerWith(insertion) {
          const el = this.$refs.chatInputEl;
          if (!el) return;
          const text = this.chatInput || '';
          const pos = el.selectionStart;
          const prefix = text.slice(0, pos);
          const kind = this.chatInputTriggerKind;
          let start = -1;
          if (kind === 'at') {
            const m = prefix.match(/(?:^|[\s\n])@([^\s\n@]*)$/);
            if (m) start = prefix.length - m[0].length + (m[0][0] === '@' ? 0 : 1);
          } else if (kind === 'slash') {
            const m = prefix.match(/(?:^|[\s\n])\/([^\s\n/]*)$/);
            if (m) start = prefix.length - m[0].length + (m[0][0] === '/' ? 0 : 1);
          }
          if (start < 0) {
            this.closeChatInputTriggerMenu();
            return;
          }
          this.chatInput = text.slice(0, start) + insertion + text.slice(pos);
          this.closeChatInputTriggerMenu();
          this.$nextTick(() => {
            this.adjustInputHeight();
            el.focus();
            const np = start + insertion.length;
            el.selectionStart = el.selectionEnd = np;
          });
        },
        onChatInputTriggerPickMaterial(m) {
          if (!m) return;
          const isRaw = m.type === 'raw' || m.type === undefined;
          const t = isRaw
            ? String(this.chatAtRawMaterialDisplayTitle(m) || '').trim() || '未命名'
            : String(m.title != null ? m.title : m.name != null ? m.name : '未命名').trim() || '未命名';
          this.replaceChatInputTriggerWith('@' + t + ' ');
          this.chatAtMenuPanel = 'categories';
        },
        onChatInputTriggerSlashMenuClick(info) {
          const key = info && info.key;
          if (!key || key === 'chat-trg-slash-empty') return;
          const secs = this.workbenchTemplateTreeSections || [];
          for (let s = 0; s < secs.length; s++) {
            const node = (secs[s].children || []).find((c) => c.key === key);
            if (node && node.raw) {
              const name = String(node.raw.name != null ? node.raw.name : '未命名').trim() || '未命名';
              this.replaceChatInputTriggerWith('/' + name + ' ');
              return;
            }
          }
        },
        adjustInputHeight() {
          this.$nextTick(() => {
            const el = this.$refs.chatInputEl;
            if (!el) return;
            el.style.height = 'auto';
            const minH = 40;
            const maxH = 176;
            const h = Math.min(maxH, Math.max(minH, el.scrollHeight));
            el.style.height = h + 'px';
            if (this.chatInputTriggerKind === 'at' && this.chatInputTriggerOpen) {
              this.scheduleUpdateChatAtFloaterPosition();
            }
          });
        },
        startDemoConversation(text, refTitles) {
          const cleanText = String(text || '').trim();
          const refs = Array.isArray(refTitles) ? refTitles.slice() : [];
          const userMsg = { id: 'm' + Date.now(), role: 'user', text: cleanText, refCount: refs.length, refTitles: refs };
          this.chatMessages.push(userMsg);
          const toolCalls = this.buildDemoToolCalls(refs, cleanText);
          const thinkId = 'think-' + Date.now();
          const thinkingMsg = {
            id: thinkId,
            role: 'thinking',
            toolCalls,
            thinkPhaseIndex: 0,
            thinkTextChars: 0,
            thinkToolStartedAt: null,
            _demoSendText: cleanText,
            _finalized: false,
            _intervalId: null,
          };
          this.chatMessages.push(thinkingMsg);
          this.$nextTick(() => {
            const wrap = this.$refs.chatMessages;
            if (wrap) wrap.scrollTop = wrap.scrollHeight;
          });
          const tickMs = 48;
          const iv = setInterval(() => {
            const thinking = this.chatMessages.find((m) => m.id === thinkId && m.role === 'thinking');
            if (!thinking || thinking._finalized) {
              clearInterval(iv);
              return;
            }
            this.advanceThinkingDemo(thinking);
            this.$nextTick(() => {
              const wrap = this.$refs.chatMessages;
              if (wrap) wrap.scrollTop = wrap.scrollHeight;
            });
          }, tickMs);
          thinkingMsg._intervalId = iv;
        },
        buildSeededDemoConversation(text, refTitles) {
          const cleanText = String(text || '').trim();
          const refs = Array.isArray(refTitles) ? refTitles.slice() : [];
          const userMsg = {
            id: 'm-seed-' + Date.now(),
            role: 'user',
            text: cleanText,
            refCount: refs.length,
            refTitles: refs,
          };
          const toolCalls = this.buildDemoToolCalls(refs, cleanText).map((call) => {
            const cloned = JSON.parse(JSON.stringify(call));
            if (cloned.type === 'todo') {
              cloned.todoDoneFlags = Array.isArray(cloned.items) ? cloned.items.map(() => true) : [];
              cloned._todoUiPhase = 'complete';
              cloned.todoExecutionLog = [];
            }
            return cloned;
          });
          const thinkingMsg = {
            id: 'think-seed-' + Date.now(),
            role: 'thinking',
            toolCalls,
            thinkPhaseIndex: toolCalls.length,
            thinkTextChars: 0,
            thinkToolStartedAt: null,
            _demoSendText: cleanText,
            _finalized: true,
            _intervalId: null,
          };
          const botMsg = this.buildDemoAnalysisBotMessage(cleanText);
          if (botMsg.chatIntro) botMsg.chatIntroProgress = botMsg.chatIntro.length;
          if (botMsg.chatRunSummary) botMsg.chatRunSummaryProgress = botMsg.chatRunSummary.length;
          return [userMsg, thinkingMsg, botMsg];
        },
        ensureDefaultDemoConversation() {
          if (!this.workbenchProjectId) return;
          if ((this.chatMessages || []).length > 0) return;
          const defaultRefs = (this.materials || [])
            .filter((m) => m && m.type === 'raw')
            .slice(0, 3)
            .map((m) => m.title || m.name || '未命名资料');
          this.chatMessages = this.buildSeededDemoConversation('总结当前工作台中的主要疑点', defaultRefs);
          this.$nextTick(() => {
            const wrap = this.$refs.chatMessages;
            if (wrap) wrap.scrollTop = wrap.scrollHeight;
          });
        },
        sendChat() {
          if (this.chatReplyInProgress) return;
          let text = String(this.chatInput || '').trim();
          const refTitles = this.parseChatInputAtReferences(text);
          const hasRefs = refTitles.length > 0;
          if (!text && !hasRefs) return;
          if (!text && hasRefs) text = '请根据 @引用 内容进行分析';
          this.chatInput = '';
          this.closeChatInputTriggerMenu();
          this.adjustInputHeight();
          this.startDemoConversation(text, refTitles);
        },
        visibleToolCalls(msg) {
          const calls = msg.toolCalls || [];
          if (!calls.length) return [];
          if (msg.thinkPhaseIndex == null) {
            const current = msg.currentStep ?? 0;
            return calls.slice(0, Math.min((current ?? 0) + 1, calls.length));
          }
          const phase = msg.thinkPhaseIndex ?? 0;
          return calls.slice(0, Math.min(phase + 1, calls.length));
        },
        newSession() {
          if (this.chatMessages.length === 0) {
            this.toastMessage = '当前无对话内容';
            setTimeout(() => { this.toastMessage = ''; }, 1500);
            return;
          }
          this.clearChatThinkingIntervals();
          const now = new Date();
          const title = '会话 ' + now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0') + ' ' + String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
          this.sessionHistory.unshift({
            id: 'session-' + Date.now(),
            title,
            createdAt: title,
            messages: JSON.parse(JSON.stringify(this.chatMessages))
          });
          this.chatMessages = [];
          this.chatInput = '';
          this.historyDropdownOpen = false;
          this.toastMessage = '已保存为历史会话';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        restoreSession(session) {
          this.historyDropdownOpen = false;
          const messages = JSON.parse(JSON.stringify(session.messages));
          messages.forEach((m) => {
            if (m._intervalId != null) {
              m._intervalId = undefined;
            }
            if (m._runSummaryStartTid != null) {
              m._runSummaryStartTid = undefined;
            }
            if (m._runSummaryIv != null) {
              m._runSummaryIv = undefined;
            }
            if (m._chatIntroIv != null) {
              m._chatIntroIv = undefined;
            }
            if (m.role === 'thinking' && Array.isArray(m.toolCalls)) {
              m.toolCalls.forEach((tc) => {
                delete tc._deepThinkStart;
                if (tc.type === 'todo') {
                  delete tc._todoPlanBuilt;
                  delete tc._todoPlan;
                  delete tc._todoPlanIdx;
                  delete tc.todoScratch;
                  delete tc.todoExecutionLog;
                  delete tc._todoUiPhase;
                  delete tc._todoPlanningUntil;
                }
              });
            }
          });
          this.chatMessages = messages;
          this.$nextTick(() => {
            const wrap = this.$refs.chatMessages;
            if (wrap) wrap.scrollTop = wrap.scrollHeight;
          });
        },
        beginResize(side, e) {
          e.preventDefault();
          this.resizing = { side, startX: e.clientX, sourcesWidth: this.sourcesWidth, sourcesDetailWidth: this.sourcesDetailWidth, studioWidth: this.studioWidth };
          document.addEventListener('mousemove', this.onResizeMove);
          document.addEventListener('mouseup', this.stopResize);
        },
        onResizeMove(e) {
          if (!this.resizing || !this.$refs.mainBody) return;
          const delta = e.clientX - this.resizing.startX;
          if (this.resizing.side === 'sources') {
            if (this.sourcesLeftView === 'detail') {
              this.sourcesDetailWidth = Math.min(600, Math.max(350, this.resizing.sourcesDetailWidth + delta));
            } else {
              this.sourcesWidth = Math.min(500, Math.max(200, this.resizing.sourcesWidth + delta));
            }
          } else {
            this.studioWidth = Math.min(500, Math.max(240, this.resizing.studioWidth - delta));
          }
        },
        stopResize() {
          this.resizing = null;
          document.removeEventListener('mousemove', this.onResizeMove);
          document.removeEventListener('mouseup', this.stopResize);
        },
      },
      mounted() {
        this.initFromUrl();
        this.$nextTick(() => this.updateResourceDrawerHeights());
        /** 工作台「上传资料」在 ProjectCenter 弹窗提交后回调，此处打开文件抽屉 */
        this._onMaterialsUploadedBridge = (projectId) => {
          const pid = String(projectId || '');
          if (!pid || String(this.workbenchProjectId || '') !== pid) return;
          this.ensureResourceDrawerOpen('file');
        };
        const b = typeof window !== 'undefined' ? window.__demoQuoteSkillBridge : null;
        if (b && typeof b === 'object') b.onMaterialsUploaded = this._onMaterialsUploadedBridge;
        const onHash = () => this.initFromUrl();
        window.addEventListener('hashchange', onHash);
        this._freeauditHashCleanup = () => window.removeEventListener('hashchange', onHash);
        const onResize = () => this.updateResourceDrawerHeights();
        window.addEventListener('resize', onResize);
        this._resourceDrawerResizeCleanup = () => window.removeEventListener('resize', onResize);
        this.$el.addEventListener('click', e => {
          const el = e.target.closest('.nlm-citation');
          if (!el) return;
          const sourceId = el.dataset.sourceId;
          const excerptIndex = parseInt(el.dataset.excerptIndex, 10);
          const found = this.findMaterialBySourceId(sourceId);
          if (!found) return;
          const materialId = found.material.id;
          this.sourcesCollapsed = false;
          this.lastDetailFocus = 'left';
          this.sourcesLeftView = 'detail';
          this.selectedMaterialId = materialId;
          this.sourcesDetailWidth = 450;
          this.highlightSourceId = materialId;
          this.highlightExcerptIndex = excerptIndex;
          this.$nextTick(() => {
            const ref = this.excerptRefs[materialId] && this.excerptRefs[materialId][excerptIndex];
            if (ref) ref.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setTimeout(() => { this.highlightSourceId = null; this.highlightExcerptIndex = null; }, 2000);
          });
        });
      },
      beforeUnmount() {
        const br = typeof window !== 'undefined' ? window.__demoQuoteSkillBridge : null;
        if (br && br.onMaterialsUploaded === this._onMaterialsUploadedBridge) br.onMaterialsUploaded = null;
        this.unbindChatAtFloaterReposition();
        if (this._chatInputBlurTimer) window.clearTimeout(this._chatInputBlurTimer);
        if (this._freeauditHashCleanup) this._freeauditHashCleanup();
        if (this._resourceDrawerResizeCleanup) this._resourceDrawerResizeCleanup();
        if (this._wbProjectSkillDetailSyncTimer) {
          window.clearTimeout(this._wbProjectSkillDetailSyncTimer);
          this._wbProjectSkillDetailSyncTimer = null;
        }
        if (this._summaryTaskTimers) {
          Object.keys(this._summaryTaskTimers).forEach((id) => this._clearSummaryTaskTimers(id));
        }
      }
    });

})();
