#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const prototypeRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const target = path.join(prototypeRoot, "assets/demo-app.css");
const css = fs.readFileSync(target, "utf8");

const lines = css.split("\n");
const allowComment = /one-off decorative/i;
const hexRe = /#[0-9a-fA-F]{3,8}\b/g;
const violations = [];

for (let i = 0; i < lines.length; i += 1) {
  const line = lines[i];
  if (allowComment.test(line)) continue;
  if (hexRe.test(line)) {
    violations.push({ line: i + 1, text: line.trim() });
  }
}

if (violations.length) {
  console.error("audit-no-bare-hex failed:");
  for (const v of violations) {
    console.error(`- line ${v.line}: ${v.text}`);
  }
  process.exit(1);
}

console.log("audit-no-bare-hex passed");
