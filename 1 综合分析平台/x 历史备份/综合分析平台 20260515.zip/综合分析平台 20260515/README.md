# 综合分析平台 · 静态 Demo（SPA）· 原型 v2.0（runtime UI kit）

本目录为**高保真**原型。运行时样式已收敛到 [`ui/runtime-ui.css`](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/ui/runtime-ui.css) 与 [`ui/runtime-theme.antdv.js`](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/ui/runtime-theme.antdv.js)；UI 规范、页面配方与校验由 [`.cursor/skills/pm-ui-prototype-kit/`](../../.cursor/skills/pm-ui-prototype-kit/) 维护。可选的本地只读基线见仓库根 `audits/LOCAL_BASELINE.txt`。

本地高保真原型：Vue 3 + ant-design-vue（UMD）+ 内联模板组件，**无构建步骤**。可直接用浏览器打开 `demo.html`（建议用本地静态服务器，避免个别浏览器对 `file://` 下多脚本限制）。

**样式入口（防重复与漂移）**：当前 `demo.html` 直接加载 [`ui/runtime-ui.css`](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/ui/runtime-ui.css) 作为**自持运行时样式入口**（由 `.cursor/skills/pm-ui-prototype-kit/scripts/extract-ui-kit.mjs` 生成，不包含 `@import` 与运行时 DS 依赖）；**最后**加载 [`assets/demo-app.css`](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/assets/demo-app.css) 作为 **仅本原型** 的增量（`#app` 补丁、业务壳、未下沉到 runtime kit 的局部样式）。

**协作 / 防文档漂移**：改 `js` 加载顺序或拆文件时，务必同步本 README 的文件地图与加载顺序说明。在本目录执行 `**node scripts/check-manifest.js`** 可校验 `demo.html` 中的 `js` 引用是否均已写入下方文件地图。

**改造验收（UI Kit 闸门）**：在仓库根运行：

`node .cursor/skills/pm-ui-prototype-kit/scripts/run-all-ui-kit.mjs --target "综合分析平台/40_原型设计/综合分析平台v2.0" --runtime "综合分析平台/40_原型设计/综合分析平台v2.0/ui/runtime-ui.css"`

结构变更后在本目录运行 `node scripts/check-manifest.js`。

**Cursor 规则（Agent）**：工作区协作总则见 [`.cursor/rules/pm-workspace.mdc`](../../.cursor/rules/pm-workspace.mdc)；原型 UI 细则见 [`.cursor/skills/pm-ui-prototype-kit/SKILL.md`](../../.cursor/skills/pm-ui-prototype-kit/SKILL.md)。

## 版本复制流程（用于后续 v2.1+ 或日期快照分支）

1. 在 `40_原型设计/` 下整目录复制当前快照，例如：  
   `cp -R '综合分析平台v2.0' '综合分析平台v2.1（0507）'`（目录名可按你的日期/分支习惯命名）。
2. 仅在新目录内进行需求与页面迭代，不回写旧快照。
3. 验证入口：`demo.html` 可正常打开与导航。
4. 验证失败则删除新目录并从基线快照重新复制。
5. 将 `40_原型设计/README.md` 与产品根 `README.md`、`综合分析平台.md` 中的「当前路径」改指向新目录（`run-all-ui-kit` 的 `--target` / `--runtime` 同理）。

## 外链与离线

- `demo.html` 使用 **Google Fonts**（**Inter**、**JetBrains Mono**）。**方案 A**：正文与界面数字统一 **Inter + 系统无衬线 + 简中黑体回退**（`--ds-font-family`）；需要列对齐的数字用 `**font-variant-numeric: tabular-nums`**（如 `.tabular-nums`、`.ds-font-display-num`）；**JetBrains Mono** 仅用于代码/编辑区等（`--ds-font-mono` / `.ds-font-mono`）。断网时回退系统字体。
- 主 SPA 依赖的脚本/CSS 均在 `assets/lib/`（除上项字体 CDN）。
- **Figma 网页捕获**：已从 `demo.html` 移除（不再请求 `mcp.figma.com`、无 `#figmacapture` 相关逻辑）。需要时可在 Git 历史中找回旧版脚本块单独使用。

## 设计系统与 Token

**v2 执行口径（2026-05）**：

- 颜色命名按层级冻结：`--ds-c-*`（Primitive）→ `--ds-bg/text/border/fx-*`（Semantic）→ `--ds-tone-*`（通用情绪色）→ `--ds-ctx-*`（场景）。
- 历史 `--ds-color-*`、`--ds-status-*`、`--ds-file-type-*` 已下线；新增与存量改造统一使用 v2 前缀（`--ds-c-*`、`--ds-bg-*`、`--ds-text-*`、`--ds-border-*`、`--ds-fx-*`、`--ds-tone-*`、`--ds-ctx-*`）。
- 状态与文件类型统一消费 `--ds-tone-*`，不再扩展专用色板。
- 业务 CSS 禁止裸 `#hex`，仅允许标注 `one-off decorative` 的一次性装饰色。
- 主色保持 `#0075de`；`success/warning/error` 已同步为 `#169c34/#b96b00/#d83a3a`，并由 `scripts/check-color-parity.mjs`、`scripts/check-color-oklch.mjs` 审核。

**文档与代码分工：** **规范入口**以 [`.cursor/skills/pm-ui-prototype-kit/`](../../.cursor/skills/pm-ui-prototype-kit/) 为准。本 Demo 的 **`ui/runtime-ui.css` + `ui/runtime-theme.antdv.js` + `assets/demo-app.css`** 应在主色、背景、正文/次级字、默认边框、圆角上保持一致；下表为**本目录维护用**双轨对照清单。

### 职责划分


| 来源                         | 文件                                                       | 作用                                       |
| -------------------------- | -------------------------------------------------------- | ---------------------------------------- |
| **规范 + 可复用样式快照**   | [`.cursor/skills/pm-ui-prototype-kit/`](../../.cursor/skills/pm-ui-prototype-kit/) | 组件规范、页面配方、CSS reference 与校验脚本 |
| **CSS 变量 `--ds-*`（本 Demo）** | [assets/demo-app.css](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/assets/demo-app.css) `:root`     | 与 foundation 对齐 + 原型扩展（页面/组件类） |
| **Ant Design Vue `token`** | [`ui/runtime-theme.antdv.js`](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/ui/runtime-theme.antdv.js)（保留 `DS_FOUNDATION` / `UI_FOUNDATION` 兼容导出） | ConfigProvider；须先于 `demo-runtime.js` 加载 |
| **审计助手 `--nlm-*`**         | 同上 `demo-app.css` 内与 `.nlm-*` 相邻的映射块                     | 默认 **alias 到 `--ds-*`**，仅在为助手单独调色时局部覆盖   |


**同步约定**：改主色、背景、正文/次级字、默认边框时，优先更新 `pm-ui-prototype-kit/css-reference/foundation.css` 与 [`ui/runtime-theme.antdv.js`](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/ui/runtime-theme.antdv.js)，再通过 `extract-ui-kit.mjs` 同步 [`ui/runtime-ui.css`](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/ui/runtime-ui.css)；`demo-runtime.js` 仅消费 `DS_FOUNDATION`，勿再手写一份色表。主色 **Primary = `#0075de`**，`--ds-color-primary` 应与之一致。

### APP_THEME 与 :root 对照（须保持一致）


| 语义      | `APP_THEME.token`                      | `:root` / `--ds-*`                                          |
| ------- | -------------------------------------- | ----------------------------------------------------------- |
| 主色      | `colorPrimary` / `colorLink`           | `--ds-color-primary`                                        |
| 焦点 / 徽章字 / 模式点缀 | — | `--ds-color-focus-ring`（`#097fe8`，DESIGN Focus Blue；历史 badge / 模式点缀同色，已统一到本 token） |
| 背景（布局）  | `colorBgLayout`                        | `--ds-color-bg-layout`                                      |
| 背景（容器）  | `colorBgContainer`                     | `--ds-color-bg-container`                                   |
| 正文/次级字色 | `colorTextBase` / `colorTextSecondary` / `colorTextTertiary` | `--ds-color-text-primary` / `--ds-color-text-secondary` / `--ds-color-text-tertiary` |
| 边框      | `colorBorder` / `colorBorderSecondary` | `--ds-color-border`（通用分割与表单控件外框；`DS_THEME_COLORS.border` 与 Ant `colorBorder` 对齐 whisper；**原评审编号 21 的灰实线边框已并入本 token**） |
| 成功/警告   | `colorSuccess` / `colorWarning`        | `--ds-color-success` / `--ds-color-warning`                 |
| 错误色     | `colorError`                           | `--ds-color-error`（DESIGN 已备案破坏性红）                      |
| 填充层级    | `colorFillSecondary` / `Tertiary` / `Quaternary` | `colorFillSecondary` / `fillTertiary` 与 `--ds-neutral-1` / `--ds-neutral-2` 对齐；`:root` 次按钮见 `--ds-color-btn-secondary-*` / `--ds-color-btn-default-bg` |
| 禁用字色    | `colorTextDisabled` / `colorTextQuaternary` | `--ds-color-text-disabled` / `--ds-color-text-tertiary` |
| 语义状态    | —（Ant Tag 等仍走 token）                  | 统一走 `--ds-tone-*`（如 `--ds-tone-neutral-*`、`--ds-tone-green-*`、`--ds-tone-red-*`、`--ds-tone-purple-*`） |
| 设计命名辅色  | —（图表/深色条可选用）                       | `--ds-color-accent-purple`、`--ds-color-accent-teal` |
| 列表/表格悬停与选中填充 | —（侧栏菜单选中为容器白底，见下） | `--ds-color-list-hover-bg` / `--ds-color-list-selected-bg` 均 → `--ds-color-bg-layout`（**`--ds-neutral-2`**，选中与悬停同阶）；`border` 仍为 **`--ds-neutral-4`** |
| 浅主色底（非列表选中） | — | `--ds-color-primary-light`（主色 12% 混入 `--ds-color-bg-container`） |
| 侧栏当前项 | `app-shell` 内 `a-menu` | 选中为 **`--ds-bg-container` 白底** + 轻阴影；未选悬停见 `demo-app.css` `.app-shell-sider-menu` |
| ECharts 文案色 | `DS_THEME_COLORS` → `__DEMO_ECHARTS_TEXT_STYLE` | 与 `textSecondary` / `textBase` 同源（canvas 不能用 CSS var） |
| 页面渐变 stop | —                                      | `--ds-gradient-shell-mesh`：`--ds-neutral-0` → `--ds-neutral-1` → `var(--ds-color-bg-layout)` |
| 输入框边框   | —                                      | `--ds-color-border`（与分割线与控件外框同源）   |
| 轻阴影 / 警告加深 | —                                | `--ds-shadow-sm`、`--ds-color-warning-strong`（用量偏高条与文案）   |
| 圆角      | `borderRadius` / `borderRadiusSM` / `borderRadiusLG` | `--ds-radius-micro`（4）/ `--ds-radius-subtle`（5，历史名 `--ds-radius-sm`）/ `--ds-radius-standard`（8）/ `--ds-radius-md`（12）/ `--ds-radius-lg`（16）/ `--ds-radius-pill`（9999） |
| 正文字体栈   | `fontFamily`                           | `--ds-font-family`（与 `html, body` 一致；勿与局部 `font-family` 分叉） |
| 等宽（代码）  | —                                      | `--ds-font-mono`（Ant 表单正文仍走 `fontFamily`）                   |
| 小号字（说明/紧凑区） | `fontSizeSM` | 与 `--ds-type-caption-fs`（14px）一致 |
| 标题档位 | `fontSizeHeading1` … `5`、`lineHeightHeading1` … `5` | 对齐 Sub-heading / Card Title / Body Large / Body / Caption |
| 全局行高 | `lineHeight`、`lineHeightLG`、`lineHeightSM` | 对齐 `--ds-type-body-lh`（1.5）、同左、`--ds-type-caption-lh`（1.43） |
| 字重 | `fontWeightStrong` | 600，同 `--ds-type-body-semibold-fw` |


### 字阶与功能角色映射（runtime foundation）

规范入口见 [`pm-ui-prototype-kit/ui-foundation.md`](../../.cursor/skills/pm-ui-prototype-kit/ui-foundation.md)，字阶与变量快照见 [`pm-ui-prototype-kit/css-reference/foundation.css`](../../.cursor/skills/pm-ui-prototype-kit/css-reference/foundation.css)。Demo 将字阶抽为 `:root` 的 **`--ds-type-*`**，并在 `demo-app.css` 提供 **`.ds-text-caption` / `.ds-text-caption-light` / `.ds-text-micro` / `.ds-text-micro-secondary` / `.ds-text-badge-label` / `.ds-text-body` / `.ds-text-info-card-title`** 供内联模板复用。

| DESIGN.md 角色 | `--ds-type-*` 前缀（`:root`） | Demo 功能角色（示例） |
|----------------|------------------------------|----------------------|
| Body | `body-fs` / `body-lh` / `body-fw` | `html, body` 默认正文；`.ds-page-subtitle`、`.page-desc` |
| Body Medium | `body-fs` + `body-medium-fw`（500） | 顶栏用户名 `.header-user-name` |
| Body Semibold | `body-fs` + `body-semibold-fw`（600） | 列表行标题 `.ds-list-row-title`；区块工具标题 `.section-title`；模板卡片内标题 `.template-card-title` |
| Nav / Button | `nav-fs` / `nav-lh` / `nav-fw`（15px / 600） | 顶栏导航、Logo 区；`.ds-segmented__item`（含 `--lg`） |
| Caption | `caption-fs` / `caption-lh` / `caption-fw`（14 / 500） | 表格单元格（tbody）、技能卡片描述 `.tc-template-card__desc`、统计标签 `.stat-card-copy-title` |
| Caption Light | `caption-fs` + `caption-light-fw`（400） | 列表行说明 `.ds-list-row-desc`；`.ds-section-desc` |
| Card Title | `card-title-*`（22 / 700 / -0.25px） | 页面主标题 `.page-title`；设置/卡片区标题 `.ds-section-title`；Modal/Drawer 标题；结果预览 Markdown **`h3`**；`.nlm-heading-reset`；概览统计大卡数字 `.project-detail-overview__stat-card-number` 等 |
| Info Card Title | `info-card-title-*`（20 / 700 / 1.27 / -0.25px） | **主体信息集中展示**的格状卡标题：`.ds-list-card-title`、`.tc-template-card__name`；工具类 **`.ds-text-info-card-title`**；工作台详情「添加技能」占位卡加号图标字号 |
| Sub-heading | `subheading-*`（26 / 700 / -0.625px） | 二级页大标题 `.ds-page-title`、`.page-heading-lg`；一级 Hero 强化 `.ds-page-hero--l1 .ds-page-hero__title`；概览 KPI 数字 `.ds-overview-value` |
| Sub-heading Large | `subheading-large-*`（40 / 700） | 预览弹窗 80×80 格式图标格内字形 |
| Body Large | `body-large-*`（20 / **600** / -0.125px） | 工具条引导 `.ds-page-toolbar__lead`；统计大卡数字 `.stat-card-copy-value`；总览顶栏标题 `.project-detail-overview__page-head-title`；审计助手横幅 `.freeaudit-banner-title`（与同字号 **Info Card Title** 区分在字重 600 vs 700） |
| Caption Light | `caption-fs` + `caption-light-fw`（14 / 400）+ `body-lh` | 工作台列表卡描述 `.project-center-card-desc` 与同卡统计数字 `.ds-space-stat-hit__num`（字阶一致；**默认**图标+数字 `--ds-text-secondary`；**整卡 hover** 或**某一统计链 `:focus-visible`** 时按资料/结果/技能分色；不用卡片 `:focus-within`，避免 `tabindex` 根节点聚焦后鼠标移开仍保持彩色） |
| Badge | `badge-*`（12 / 600 / 0.125px） | `TagLg`/`TagSm`（经 `--ds-tag-shared-*`）；表头 `.ant-table-thead`；页眉 meta 大写行 `.ds-page-hero--l1 .ds-page-hero__meta`；`.ds-page-eyebrow`（+ `text-transform: uppercase`） |
| Micro Label | `micro-*`（12 / 400 / 0.125px） | 页脚 meta、面包屑、列表 meta、树侧辅助信息、原 11px 文案（统一升到 12px 档） |

**说明**：后台信息密度下，部分原 **13px** 文案已并入 **Caption 14px**；原 **11px** 并入 **Micro 12px**。图标与装饰字形统一走 **`--ds-type-icon-*`**（见下），不再使用裸 `9px` / `10px`。

#### 行高 token（`--ds-type-*-lh`）

除 `line-height: inherit` 外，`demo-app.css` 中文本行高均引用 `:root` 变量：`body-lh`、`caption-lh`、`nav-lh`、`badge-lh`、`micro-lh`、扩展项 **`body-lh-reading`（1.6）**、**`body-lh-roomy`（1.65）**、**`prose-heading-lh`（1.4）**、**`ui-row-lh`（1.35）**、**`ui-tight-lh`（1.3）**、**`ui-compact-lh`（1.2）**、**`chat-meta-lh`（1.55）**、**`control-lh`（1.5715）**、**`caption-lh-box` / `bar` 等 px 档**、**`line-solid`（1）**、**`line-normal`**、**`layout-zero-lh`（0）**。改行高时只改 `:root` 一处。

#### 图标字阶（`--ds-type-icon-*`）

| 变量 | 对应字阶 | 用途 |
|------|-----------|------|
| `--ds-type-icon-chevron-fs` | Micro 12 | 下拉箭头、树折叠、chip 关闭 |
| `--ds-type-icon-inline-fs` | Micro 12 | 菜单内勾选等行内 FA |
| `--ds-type-icon-row-fs` | Nav 15 | 树行 24px 格内图标 |
| `--ds-type-icon-toolbar-fs` | Caption 14 | 预览工具条 `.fas` |
| `--ds-type-icon-hero-fs` | Sub-heading Large 40 | 上传区大图标 |
| `--ds-type-icon-symbol-lh` | `line-solid` | 单行图标盒 |

#### Ant Design 全组件字阶

- **`APP_THEME.token`**：已补全 `fontSizeHeading*`、`lineHeight*`、`fontWeightStrong` 等（与 DESIGN 档位一致）。
- **`demo-app.css`**：在表格样式块后增加 **Ant 组件覆盖**（Modal/Drawer/Form/Input/Button/Tabs/Pagination/Card/Menu/Steps/Statistic/List/Transfer 等）；**Modal、Dropdown、Select 下拉、Tooltip、Popover** 选择器**不带 `#app`**，避免 Portal 挂到 `body` 时不生效。

#### ECharts

当前业务 `js` **未初始化图表**；`demo-runtime.js` 暴露 **`window.__DEMO_ECHARTS_TEXT_STYLE`**（`axisLabel` / `title` / `legend` / `tooltip` 等，字号与 Badge～Caption 档一致）。新增图表时在 `option` 里展开合并该对象即可与字阶同步。

#### Markdown 预览（`.analysis-result-preview-modal__md`）

- 正文：**Body**（16 / 1.5）。
- **`h2`**：**Sub-heading**（26 / 700）；**`h3`**：**Card Title**（22 / 700；长文内小节标题，非格状信息卡）。
- **`code`**：**Caption** 字号 + **JetBrains Mono**，行高 **`body-lh-roomy`**。

### B 端与 DESIGN §4 组件样式：已固化决策

以下为静态 Demo 在 `pm-ui-prototype-kit` 与 runtime UI kit 约束下的**产品侧结论**（后台信息密度优先；**以本 README 为执行记录**）。

| 议题 | 结论 | 说明 |
| ---- | ---- | ---- |
| 次按钮（default）底色与 hover scale | **已对齐 §4** | 底色 **`--ds-color-btn-secondary-bg`（`rgba(0,0,0,0.05)`）**、悬停 **`--ds-color-btn-secondary-hover-bg`**、hover **`scale(1.05)`**、字重 **500**（与主按钮 600 区分）；`APP_THEME.fillSecondary` 近似同系浅灰。 |
| §5 **Standard 8px**（小卡/内联容器） | **已用 `--ds-radius-standard` 落地** | 含 `.ds-page-header`、`.pie-chart-container`、`.project-table-card`、模式说明气泡、资料树浮层、审计助手内多块面板/浮层、`.nlm-original-doc-page` 等；**标准/功能大卡**仍为 **12px（`--ds-radius-md`）**；聊天气泡用 **16px（`--ds-radius-lg`）**。 |
| 功能卡标题 **22px** vs 信息卡 **20px** | **长期双轨** | **Card Title（22）**：页面/设置区/Modal 标题等；**Info Card Title（20）**：列表格、模板格等主体信息卡标题。见上文字阶表。 |
| Ghost/Link 下划线 | **`ant-btn-link`：hover / focus-visible 下划线** | **`ant-btn-text` 不加**（避免工具条纯图标/弱操作误像超链接）。局部若需「看起来像数字不是链」：用更高优先级覆盖（例：`.proj-skill-mat-count-link` 已 `text-decoration: none !important`）。 |
| 大浮层阴影 | **Modal 内容区已为 `--ds-shadow-deep`**；**Drawer 内容包装器同步 deep** | 小 Popover/Dropdown 仍可用较轻 shadow，不按 Deep Card 一刀切。 |
| 文档 | **本小节 + 下表即为 §4 映射** | 无需另开独立 Markdown，除非后续组件暴增再拆页。 |

#### DESIGN §4 ↔ Demo 实现（简表）

| DESIGN §4（摘要） | Demo 主要承载 |
| ----------------- | ------------- |
| Primary / Secondary / Ghost 按钮 | `.ant-btn-primary` / `default` / `link` / `text`；`ds-btn-page-cta`；`demo-app.css` 按钮覆盖块 |
| Pill Badge / 标签 | `<TagLg>` / `<TagSm>` → **`ds-tag` + `--lg` / `--sm`**（见 `pm-ui-prototype-kit/components/tag.md` 与 `ui/runtime-ui.css`） |
| Cards & Containers | `.ant-card`、`.template-card`、`.ds-page-card`、`.ds-list-card`、`--ds-shadow-card` / `deep` |
| Inputs & Forms | `:is(#app,.ant-modal-wrap)` 下 Input/Select/DatePicker；`--ds-color-border`、占位 `--ds-color-text-secondary` |
| Navigation（摘要） | `.header-nav`、`--ds-type-nav-*`；侧栏 `.ant-layout-sider .ant-menu-item*` |
| Image Treatment（截图框） | 资料/预览相关 modal 内区域；按需 whisper 边 + 圆角 |
| Metric / 功能卡（大数字、说明） | `.ds-overview-value`、`.stat-card-copy-value`、`project-detail-overview__stat-card-number` 等（字阶见上表，未必一律 40px） |
| §6 深度 · Deep Card | `.ant-modal-content`、`--ds-shadow-deep`；`.ant-drawer .ant-drawer-content-wrapper` |
| §8 焦点 | 主按钮 `focus-visible` 轮廓色 `--ds-color-focus-ring`；`prefers-reduced-motion` 见 `demo-app.css` 顶部 |


### 间距与 z-index

- **间距刻度**：`--ds-space-xxs` … `--ds-space-xl`、`--ds-space-2xl`（32px）、`--ds-space-section-y`（大区块纵向 48–120px clamp）及 `--ds-layout-content-max-width`（1200px）、`--ds-layout-hero-pad-top`（一级列表 Hero 顶留白）、页面级 `--ds-layout-content-pad-*`、`--ds-page-stack-gap`、无侧栏一级页 **`--ds-l1-section-gap`（仅 Hero → 工具条）**、**`--ds-l1-toolbar-to-rail-gap`（工具条 → 信息控制轨，同一块内收紧）**、`--ds-l1-rail-to-grid-gap`（控制轨 → 卡片区）等，见 `demo-app.css` `:root`。
- **层级（`--ds-z-*`）**：勿随意写裸数字；常用变量如下（完整定义见 `demo-app.css` `:root`）。


| 变量                                                 | 典型用途                       |
| -------------------------------------------------- | -------------------------- |
| `--ds-z-base` / `--ds-z-panel` / `--ds-z-lift`     | 组件内叠放（底/文/角标按钮）            |
| `--ds-z-strip` / `--ds-z-workbench-embed`          | 工作台内局部条、嵌入预览               |
| `--ds-z-workbench-aside`                           | 审计助手侧栏叠放                   |
| `--ds-z-popover-local`                             | 卡片下挂资料树等局部浮层               |
| `--ds-z-dropdown`                                  | 与 Ant 对齐的固定浮层（约 1050； citation / 树节点 popover 等） |
| `--ds-z-fullscreen` / `--ds-z-fullscreen-control`  | 审计助手全屏与关闭钮                 |
| `--ds-z-modal-nested`                              | 叠在大预览上的二级 Modal            |


### 按钮（Ant `a-button`）


| 角色                                         | `size`     | class                | 说明                                                                                                    |
| ------------------------------------------ | ---------- | -------------------- | ----------------------------------------------------------------------------------------------------- |
| **一级页面主 CTA**（工作台「创建工作台」、技能库「技能」、系统管理「新建」） | `large`    | `ds-btn-page-cta`    | **Notion Primary Blue**（`#0075de`，hover `#005bab`）与全局实心 primary 一致；由 `[demo-app.css](./assets/demo-app.css)` 提供；**每路由视图至多 1 颗** |
| **工作台、Modal/Drawer 主操作**（上传资料、保存、确认等） | 默认（middle） | 勿加 `ds-btn-page-cta` | **纯色 primary**（`--ds-color-primary` / `APP_THEME`）                                                    |
| **L2 工具条 / 总览列头 CTA / 侧栏紧凑主色**                  | `large` 或默认 | `ds-btn-compact`（叠 `a-btn-primary`）或 `ds-icon-btn--compact` | **30px** · 与 `--ds-control-height-compact` 对齐；**勿**再用独立 `nlm-*` 高度皮肤 |
| **modal picker 等极矮主操作**                         | `small`    | `ds-btn-micro` + primary | **24px** |
| **表格工具条、筛选条、行内操作**                         | `small`    | 按需                   | `default` / `link` / `text` / `danger` 按语义；行内以 link 为主                                                |
| **文字链**（行内主色/危险、无填充） | 默认或 `small` | `a-button` **`type="link"`** 或 **`<button class="ds-link-btn">`** | 字色、悬停/聚焦/按下**均不下划线**（仅靠色变化），与 `pm-ui-prototype-kit/components/button.md` / `ui/runtime-ui.css` 中 `.ds-link-btn` / `.ds-link-btn--danger` 一致；本 Demo 在 [`assets/demo-app.css`](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/assets/demo-app.css) 为 `.ant-btn-link` 做对齐覆盖 |


**一级工具条**：与 `**size="large"**` 的 `ds-btn-page-cta` 同框时，侧旁搜索也应 `**size="large"**`；**即时筛选**场景用 `**a-input` + `#prefix` 搜索图标**（类 `**ds-input-inline-search**`），避免 `a-input-search` 右侧独立搜索触发区；宽度用 `**ds-page-heading-search**` / `**ds-page-toolbar__search**`。仍需要「按回车/点按钮才搜」的页面可继续用 `**a-input-search**`。

**禁止**把全局 `.ant-btn-primary` 改成多色渐变（与 Notion「单一饱和强调色」不一致）。`ds-btn-page-cta` 与默认 primary 同为 **Notion Blue**；主色与 hover 仅用 `--ds-color-primary` / `--ds-color-primary-hover`（R6 已删除历史 `gradient-brand*` 别名）。

**无侧栏一级页（工作台列表 / 技能库）结构约定**（自上而下）：① `**ds-page-hero--l1**`：仅 **标题 + 副标题**（引导语），统计不下沉到 hero；② `**ds-page-toolbar--l1**`：**Tab 或信息标题** + **搜索** + **页面主 CTA**；③ **信息操作区**：优先 `**InfoControlRail**`（根节点 `**ds-info-control-rail` + `ds-l1-control-rail**`）。**左** `**#total**`（共 n）→ `**#selection**`（已选、全选按需、批量）；**右** `**#query**`（列表搜索）→ `**#filter**`（标签/状态等）→ `**#sort**` → `**#toggle**`；缺省不占位。特殊布局可用 `**#left` / `#right**` 整侧替换。④ `**ds-l1-list**` 卡片或列表。

**布局工具类**（同在 `demo-app.css`）：`ds-page-hero`（一级页语境；与工具条间无分隔线）、`ds-page-hero--l1`（更强标题与副标题；**统计在信息操作区 `#total**`）、`ds-page-hero-tabs`、`ds-page-toolbar` / `ds-page-toolbar--l1` / `ds-page-toolbar--skill` / `ds-page-toolbar--split`、`ds-l1-control-rail` 与 `**ds-info-control-rail**`（组件根）、`ds-l1-control-rail__stats` / `__ops` / `__display`、`ds-page-subpanel`（其它页筛选区无浅底）、`ds-l1-list` + `ds-l1-grid-card`、`ds-list-card-title`、`ds-page-empty-block--l1`、`ds-page-heading-actions` / `ds-page-toolbar__actions`、`ds-page-heading-search` + `ds-page-toolbar__search`、`ds-segmented` + `ds-segmented__item` + `is-active`（`**--lg**` / `**--compact**` / `**--dense**`）；技能库一级工具条「我的技能/共享技能」为 **`ds-segmented--lg` + `ds-segmented--skill-l1-scope`**（胶囊槽；**选中段白底** + 主色字，见 `demo-app.css`）；弹内来源切换等仍可用 **`ds-text-tablist`**（`**--toolbar-lead**` / `**--modal**`、`/` 分隔）；`ds-toolbar-split`、`ds-modal-footer-end` + `<a-space>`、`ds-btn-icon-before` / `ds-btn-caret`、`ds-page-empty-block`、`ds-list-card-clickable`。

### 编写约定

- **业务模板**（各 `demo-cmp-*.js` 内联 HTML）：优先使用 **class** + `demo-app.css`，**避免写死 hex**；动态样式仅保留确有计算必要的场景并注释原因。字阶优先用 **`--ds-type-*`**、**`--ds-type-icon-*`** 或 **`.ds-text-caption` / `.ds-text-caption-light` / `.ds-text-micro-secondary` / `.ds-text-badge-label` / `.ds-text-meta-block` / `.ds-text-body` / `.ds-text-info-card-title`**（见上表），勿再写裸的 `11px` / `13px`。
- **标签**：大/小标签统一 `<TagLg>` / `<TagSm>`，样式走 `--ds-tag-*`，按本文档的 UI 语义与样式约定执行。
- **体验自检**（对齐 ui-ux-pro-max）：主要按钮与链接有 **hover / focus**；浅色模式正文对比度充足；尊重 `**prefers-reduced-motion**`（全局已有减动效规则）。

### 兼容说明

- `#app` 使用 `**min-width: 1024px**`：本 Demo 面向**桌面端**演示，未做移动端适配；小视窗可能出现横向滚动。

### 后续图表（ECharts）

- 若接入真实图表，请在 **option 配色** 上与 `--ds-color-primary-rgb` 及灰阶 token 对齐，避免与壳层主色脱节。

## 如何运行

1. 在本目录启动静态服务，例如：`python3 -m http.server 8080`
2. 浏览器访问：`http://127.0.0.1:8080/demo.html`
3. 依赖均已放在 `assets/lib/`（dayjs、vue、antd、echarts、marked、fontawesome、reset），无需联网即可跑（Google Fonts 外链 **Inter** 与 JetBrains Mono，断网时回退系统字体）。

## 开发对照包

需要把原型单独发给开发时，在仓库根运行：

```bash
node 综合分析平台/40_原型设计/综合分析平台v2.0/scripts/export-dev-package.mjs
node 综合分析平台/40_原型设计/综合分析平台v2.0/scripts/check-dev-package.mjs
```

输出目录：`综合分析平台/40_原型设计/综合分析平台v2.0/dist/dev-package/`。该目录为可重新生成的导出物，不作为运行真源维护；导出包不包含维护文档、设计映射资产、Cursor skill 等。（若仓库内暂未包含上述导出脚本，可跳过本段。）

## 文件地图（改需求时先看这里）


| 文件                                                                     | 职责                                                                                                        | 对应界面 / 主题                 |
| ---------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------- | ------------------------- |
| [demo.html](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/demo.html)                                               | 入口：外链 CSS、按顺序加载 `js/*.js`                                                                                 | —                         |
| [assets/demo-app.css](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/assets/demo-app.css)                           | 全局与设计系统相关样式、各视图布局与组件类                                                                                     | 全站视觉                      |
| [js/demo-runtime.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-runtime.js)                             | `VIEW_IDS`、hash 路由辅助、`createApp` 之前的常量与函数；含工作台权限演示数据 `PROJECT_SHARE_DEPT_TREE_DATA` / `PROJECT_SHARE_USERS_BY_DEPT_KEY` 等 | 根路由、与父页 embed 通信、`SpaceSharePicker` |
| [js/demo-ds-modals.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-ds-modals.js)                         | `window.dsConfirm`：删除等二次确认弹窗规约收敛（依赖页面已加载的 `antd.Modal`）                                                         | 工作台列表等（逐步迁移调用点）           |
| [js/demo-app-root.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-app-root.js)                           | 根 `createApp`（顶栏、创建工作台弹窗）；**直接** `window.__DEMO_APP = createApp({...})`（无单独 `const app`，避免与后续脚本冲突）         | 应用壳                       |
| [js/demo-cmp-space-share-picker.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-cmp-space-share-picker.js) | 全局注册 `SpaceSharePicker`：工作台权限「指定用户可见」左栏按部门/按用户选择与右栏已选（创建/编辑工作台共用）                              | 创建工作台、编辑工作台弹窗               |
| [js/demo-cmp-tags.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-cmp-tags.js)                           | 全局注册 `TagLg` / `TagSm`：输出 **`ds-tag` + `ds-tag--lg` / `ds-tag--sm`**（筛选叠 `skill-filter-chip`），真源见 DS `tag.css`                         | 全站标签展示与筛选                 |
| [js/demo-cmp-info-control-rail.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-cmp-info-control-rail.js) | 全局注册 `InfoControlRail`：左 `total`→`selection`；右 `query`→`filter`→`sort`→`toggle`；或整侧 `left` / `right` | 工作台列表、技能库、详情资料/结果/技能等       |
| [js/demo-skill-file-tree.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-skill-file-tree.js)             | `window.DemoSkillFileTree`：技能 `skillFiles` 树（文件夹/文件）、路径重名校验、`extractionRules` 派生同步（供资料匹配等）              | 技能库 / 工作台技能配置             |
| [js/demo-mock-data.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-mock-data.js)                         | 演示用 `Vue.reactive` 数据、资料/结果/技能种子、`demoSubmitProjectTemplateAnalysisJobs`、引用映射等                            | 数据层演示                     |
| [js/demo-project-skill-match.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-project-skill-match.js)     | `window.DemoProjectSkillMatch`：技能配置校验、按文档特征子串建议关联 `materialIds`（同步，无异步「匹配」流程）；供工作台与审计助手共用                | 数据层演示                     |
| [js/demo-cmp-shell.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-cmp-shell.js)                         | `AppShellSiderMenu`                                                                                       | 侧栏菜单                      |
| [js/demo-cmp-settings.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-cmp-settings.js)                   | `SettingsView`                                                                                            | 系统管理                      |
| [js/demo-cmp-project-list.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-cmp-project-list.js)           | `ProjectCenterListPanel`：工作台卡片列表（由 `ProjectCenterView` 引用）                                               | 工作台 · 列表                 |
| [js/demo-cmp-project.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-cmp-project.js)                     | `ProjectCenterView`：工作台列表渲染、历史链接跳转到审计助手、共享桥接（引用技能/上传资料/编辑工作台）                                                              | 工作台主入口与桥接          |
| [scripts/check-manifest.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/scripts/check-manifest.js)               | 校验 `demo.html` 引用的 `js` 是否列入本表（可选）                                                                        | 维护辅助                      |
| [js/template/demo-template-utils.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/template/demo-template-utils.js) | template 分拆首层：技能库默认排序等公共常量（辅助层；主体仍在 `demo-cmp-template.js`）                                                     | 技能库拆分准备                   |
| [js/template/demo-cmp-template-list.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/template/demo-cmp-template-list.js) | `TemplateListPanel`：技能库一级列表、工具条与筛选轨首轮拆分（父级仍协调弹窗与状态） | 技能库 · 列表 |
| [js/demo-cmp-template.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-cmp-template.js)                   | `TemplateCenterView`                                                                                      | 技能库                       |
| [js/freeaudit/demo-freeaudit-utils.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/freeaudit/demo-freeaudit-utils.js) | freeaudit 分拆首层：query、diff、模板映射；**资料文件区目录树** `buildWorkbenchMaterialAntTreeData` / `applyWorkbenchMaterialTreeDrop` / 路径前缀等（主体交互在 `demo-cmp-freeaudit.js`） | 审计助手拆分准备                  |
| [js/freeaudit/demo-cmp-freeaudit-chat-panel.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/freeaudit/demo-cmp-freeaudit-chat-panel.js) | `FreeAuditChatPanel`：审计助手中间会话展示区首轮拆分（输入区与左右栏仍在父级） | 审计助手 · 对话 |
| [js/demo-cmp-freeaudit.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-cmp-freeaudit.js)                 | `FreeAuditView` 及专属辅助常量/函数                                                                                | 审计助手（hash: `freeaudit`） |
| [js/demo-boot.js](1%20综合分析平台/1%20需求设计/综合分析平台2.0基线版本（20260514）/html原型/js/demo-boot.js)                                   | `message.config`、`__DEMO_APP.use(antd).mount('#app')`                                                     | 启动                        |
| [scripts/export-dev-package.mjs](./scripts/export-dev-package.mjs)     | 导出可独立交付给开发的静态原型包到 `dist/dev-package/`，导出时可按需剥离外链                                  | 交付辅助                     |
| [scripts/check-dev-package.mjs](./scripts/check-dev-package.mjs)       | 校验开发对照包本地引用完整性与禁止内容                                                                                | 交付辅助                     |
| [scripts/audit-demo-css.mjs](./scripts/audit-demo-css.mjs)             | 只读输出 `demo-app.css` 重复 selector 候选、高风险 Ant 覆盖计数与必要锚点状态                                  | 维护辅助                     |


## 脚本加载顺序

**不可随意调整**（除非你知道依赖关系）：`ui/runtime-theme.antdv.js`（`DS_FOUNDATION` 兼容桥）→ `demo-runtime` → `demo-ds-modals` → `demo-app-root` → `**demo-cmp-space-share-picker**` → `**demo-cmp-tags`** → `**demo-cmp-info-control-rail**` → `ui/components/ui-tags` → `ui/components/ui-info-control-rail` → `ui/components/ui-page-shell` → `ui/components/ui-table-shell` → `ui/components/ui-modal-footer` → `ui/components/ui-status-pill` → `**demo-skill-file-tree**` → `demo-mock-data` → `**demo-project-skill-match**` → shell → settings → `**demo-cmp-project-list**` → `project/demo-project-utils` → `**demo-cmp-project**` → `template/demo-template-utils` → `template/demo-cmp-template-list` → template → `freeaudit/demo-freeaudit-utils` → `freeaudit/demo-cmp-freeaudit-chat-panel` → freeaudit → `demo-boot`。

- `demo-ds-modals.js` 须在 **`demo-runtime` 之后、`demo-app-root` 之前**：封装 `Modal.confirm` 等（依赖 head 中已加载的 `antd` UMD）。
- `demo-cmp-space-share-picker.js` 须在 `**demo-app-root` 之后**、`**demo-cmp-tags` 之前**：向 `window.__DEMO_APP` 注册 `SpaceSharePicker`（依赖 `demo-runtime` 中 `PROJECT_SHARE_DEPT_TREE_DATA` 等常量）。
- `demo-cmp-tags.js` 须在 `**demo-app-root` 之后、各 `demo-cmp-*.js` 之前**：向 `window.__DEMO_APP` 注册 `TagLg` / `TagSm`。
- `demo-cmp-info-control-rail.js` 须在 `**demo-cmp-tags` 之后**、`**demo-cmp-project-list` / `demo-cmp-project` / `demo-cmp-template` 之前**：注册 `InfoControlRail`（依赖全局 `TagSm`/`TagLg` 的页面需保证 tags 已加载）。
- `demo-skill-file-tree.js` 必须在 **`demo-mock-data.js` 之前**：技能 `skillFiles` 树与 `extractionRules` 同步工具。
- `demo-mock-data.js` 必须在 **project / template** 之前：内含 `SKILL_SEED`_*、`demoSharedPrivateAnalysisTemplatePool` 等。
- `demo-project-skill-match.js` 须在 **project / freeaudit** 之前加载（依赖 mock 中的 reactive 对象名约定，本身不引用 Vue）。
- `js/template/demo-template-utils.js` 必须在 `demo-cmp-template.js` 之前。
- `js/template/demo-cmp-template-list.js` 必须在 `demo-cmp-template.js` 之前。
- `js/freeaudit/demo-freeaudit-utils.js` 必须在 `demo-cmp-freeaudit.js` 之前。
- `js/freeaudit/demo-cmp-freeaudit-chat-panel.js` 必须在 `demo-cmp-freeaudit.js` 之前。
- `demo-cmp-project-list.js` 须在 `**demo-cmp-project.js` 之前**：先注册子组件，再由 `ProjectCenterView` 引用。
- 各 `demo-cmp-*.js` **整段包在 IIFE** 内：`const app = window.__DEMO_APP`，再调用 `app.component(...)`。这样在全局作用域不会重复声明 `app`（经典脚本标签共享同一全局对象）。

## 常见需求 → 改哪个文件

- 工作台 **卡片列表**（搜索、创建入口、卡片菜单）→ `demo-cmp-project-list.js` + 数据在父级 `demo-cmp-project.js`
- **信息操作区**（左：共 n / 已选与批量；右：查询 / 过滤 / 排序 / 切换）→ `demo-cmp-info-control-rail.js`（`InfoControlRail`）+ `demo-app.css` 中 `ds-info-control-rail`*
- 工作台入口与历史详情兼容跳转（统一进入审计助手）→ `demo-cmp-project.js`
- 技能库列表、筛选、新建/编辑技能抽屉、技能配置弹窗（左侧 **四 Tab**：基本信息 / 技能配置 / **版本** / **技能引用**）→ `demo-cmp-template.js`
- 审计助手对话、资料树、摘要任务；辅助模式侧栏与助手内 **结果预览**（顶栏或左栏 Tab 含 **历史版本**，同工作台交互）→ `demo-cmp-freeaudit.js`
- 系统管理占位页、数据源表 → `demo-cmp-settings.js`
- 顶栏、主导航 hash、创建工作台流程 → `demo-app-root.js` + `demo-runtime.js`
- 设计令牌、间距、卡片、某视图专用 class → `demo-app.css`
- 大/小标签组件封装与统一 class → `demo-cmp-tags.js`（业务模板用 `<TagLg>` / `<TagSm>`，勿再散落写 `a-tag` + 历史 `u-tag-*`；样式由 `ui/runtime-ui.css` 承载）
- 演示数据、技能种子、跨视图共享 store → `demo-mock-data.js`

## Agent 快速入口

- 改审计助手对话展示：`js/freeaudit/demo-cmp-freeaudit-chat-panel.js` + `js/demo-cmp-freeaudit.js` + `assets/demo-app.css`
- 改审计助手输入、左栏、右栏：`js/freeaudit/demo-freeaudit-utils.js` + `js/demo-cmp-freeaudit.js` + `assets/demo-app.css`
- 改工作台入口跳转与共享桥接：`js/demo-cmp-project.js`
- 改技能库列表：`js/template/demo-cmp-template-list.js` + `js/demo-cmp-template.js`
- 改 mock 数据：`js/demo-mock-data.js` + 对应使用方页面脚本
- 仅改样式：`assets/demo-app.css`（业务样式）或 `ui/runtime-ui.css`（可复用组件层）

## Hash 约定（简述）

- `project`：工作台列表；`project/{id}`：兼容旧链接，自动跳转到 `freeaudit?projectId={id}`。
- `template`：技能库；`settings`：系统管理；`freeaudit`：审计助手。

细节见 `demo-runtime.js` 中 `VIEW_IDS`、`HASH_TO_VIEW`、`getProjectIdFromHash` 等。