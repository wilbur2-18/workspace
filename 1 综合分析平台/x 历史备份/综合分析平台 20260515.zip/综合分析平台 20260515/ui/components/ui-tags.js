(function registerUiTags() {
  const app = window.__DEMO_APP;
  if (!app) return;
  if (app.component("UiTagLg")) return;

  app.component("UiTagLg", {
    inheritAttrs: false,
    props: ["tone"],
    template:
      '<TagLg v-bind="$attrs" :class="tone ? `ds-tag--tone-${tone}` : \'\'"><slot /></TagLg>',
  });

  app.component("UiTagSm", {
    inheritAttrs: false,
    props: ["variant", "active", "count", "tone"],
    template:
      '<TagSm v-bind="$attrs" :class="tone ? `ds-tag--tone-${tone}` : \'\'" :variant="variant || \'static\'" :active="!!active" :count="count"><slot /></TagSm>',
  });
})();
