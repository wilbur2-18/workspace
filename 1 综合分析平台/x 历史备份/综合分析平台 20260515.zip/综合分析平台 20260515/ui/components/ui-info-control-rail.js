(function registerUiInfoControlRail() {
  const app = window.__DEMO_APP;
  if (!app) return;
  if (app.component("UiInfoControlRail")) return;

  const { h, resolveComponent } = Vue;

  app.component("UiInfoControlRail", {
    inheritAttrs: false,
    /** 须把父级传入的具名插槽原样交给 InfoControlRail；仅用默认 <slot /> 会丢 #total/#filter 等 */
    render() {
      return h(resolveComponent("InfoControlRail"), { ...this.$attrs }, this.$slots);
    },
  });
})();
