# Runtime UI Kit (Demo v2.0)

## Purpose

This folder hosts runtime UI assets consumed directly by `demo.html`.

## Files

- `runtime-ui.css`: self-contained runtime UI style entry generated from skill snapshots / legacy DS source.
- `runtime-theme.antdv.js`: runtime theme seed exposed as `DS_FOUNDATION` and `UI_FOUNDATION`.
- `components/*.js`: lightweight runtime component wrappers.

## Source

Generated or synchronized from `.cursor/skills/pm-ui-prototype-kit/css-reference/*.css`.
`runtime-theme.antdv.js` keeps a local copy of the theme seed and exposes `DS_FOUNDATION` for compatibility.

## Rules

- Do not hand-edit generated style sections without syncing skill references.
- Keep compatibility alias `DS_FOUNDATION` until demo-runtime no longer depends on it.
- For CSS tokens, only write v2 canonical names (`--ds-c-*`, `--ds-bg-*`, `--ds-text-*`, `--ds-border-*`, `--ds-fx-*`, `--ds-tone-*`, `--ds-ctx-*`).
- Page-specific visual patching stays in `assets/demo-app.css` or page-local css files.
- `runtime-ui.css` must not contain `@import` or runtime references to `design-system-v3`.
