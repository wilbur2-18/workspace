(function () {
  const app = window.__DEMO_APP;
  const Modal = antd.Modal;

    // FreeAuditView：审计助手（hash 仍为 freeaudit，与工作台共用资料与结果 store）
    const freeauditUtils = window.__DEMO_FREEAUDIT_UTILS || {};
    const getFreeAuditQuery = freeauditUtils.getFreeAuditQuery || function () { return {}; };
    const presetSuggestions = freeauditUtils.presetSuggestions || [];
    const WORKBENCH_PROJECT_NAME_BY_ID = freeauditUtils.WORKBENCH_PROJECT_NAME_BY_ID || {};
    const SUMMARY_RESPONSE_DEMO = freeauditUtils.SUMMARY_RESPONSE_DEMO || '';
    const DEMO_RUN_SUMMARY_TEXT = freeauditUtils.DEMO_RUN_SUMMARY_TEXT || '';
    const demoToolDiffLineClass = freeauditUtils.demoToolDiffLineClass || function () { return 'nlm-tool-diff-line--ctx'; };
    const demoLinesUnifiedDiff = freeauditUtils.demoLinesUnifiedDiff || function () { return { lines: [], truncated: false }; };
    const toAnalysisTemplateShared = freeauditUtils.toAnalysisTemplateShared || function (seed) { return seed; };
    app.component('FreeAuditView', {
      emits: ['navigate'],
      template: `<a-layout class="shell-main shell-main-flex-col freeaudit-view"><a-layout-content class="content-reset-flex-col">
            <div class="nlm-main nlm-main-shell">
          <div v-if="toastMessage" class="nlm-toast">{{ toastMessage }}</div>
          <div v-if="citationPopover.show" class="nlm-extract-citation-popover" :style="{ left: citationPopover.x + 'px', top: citationPopover.y + 'px' }" @mouseenter="onCitationPopoverEnter" @mouseleave="onExtractCitationLeave">
            <div class="nlm-extract-citation-popover-title">{{ citationPopover.title || '原文' }}</div>
            <div class="nlm-extract-citation-popover-content">{{ citationPopover.excerpt }}</div>
          </div>
          <div v-if="sourcesLeftFullscreen" class="nlm-fullscreen-overlay">
            <button class="close-btn" @click="sourcesLeftFullscreen = false; fullscreenMaterialId = null; fullscreenLeftView = 'list'; fullscreenSelectedSourceId = null; fullscreenExcerptRefs = {}; fullscreenOriginalHighlight = null; fullscreenOriginalPageRefs = {}; fullscreenOriginalRowRefs = {}"><i class="fas fa-times"></i></button>
            <h2 v-if="fullscreenMaterial" class="nlm-heading-reset">{{ fullscreenMaterial.title }}</h2>
            <div v-if="fullscreenMaterial && fullscreenMaterial.type === 'raw'" class="nlm-fullscreen-raw-single nlm-fill-scroll">
              <div v-if="(fullscreenMaterial.rawSubtype || 'document') === 'document' && fullscreenMaterial.originalView && fullscreenMaterial.originalView.pages" class="nlm-original-doc-view nlm-fill-scroll">
                <div v-for="(page, pi) in fullscreenMaterial.originalView.pages" :key="pi" :class="['nlm-original-doc-page', { 'nlm-original-doc-page-highlight': fullscreenOriginalHighlight && fullscreenOriginalHighlight.pageIndex === pi }]" :ref="el => setFullscreenOriginalPageRef(pi, el)">{{ page }}</div>
              </div>
              <div v-else-if="(fullscreenMaterial.rawSubtype || 'document') === 'table' && fullscreenMaterial.originalView && fullscreenMaterial.originalView.headers" class="nlm-original-table-wrap nlm-fill-scroll">
                <table class="nlm-original-table">
                  <thead><tr><th v-for="(h, hi) in fullscreenMaterial.originalView.headers" :key="hi">{{ h }}</th></tr></thead>
                  <tbody><tr v-for="(row, ri) in (fullscreenMaterial.originalView.rows || [])" :key="ri" :class="{ 'nlm-original-row-highlight': fullscreenOriginalHighlight && fullscreenOriginalHighlight.rowIndex === ri }" :ref="el => setFullscreenOriginalRowRef(ri, el)"><td v-for="(cell, ci) in row" :key="ci">{{ cell }}</td></tr></tbody>
                </table>
              </div>
              <div v-else class="nlm-source-read nlm-fill-scroll">
                <div v-for="(ex, i) in (fullscreenMaterial.excerpts || [])" :key="i" class="excerpt">{{ ex }}</div>
              </div>
            </div>
            <div v-else-if="fullscreenMaterial && ['analysis','report'].includes(fullscreenMaterial.type)" class="nlm-dual-column nlm-dual-column-fill" ref="fullscreenAnalysisContainer">
              <div v-if="fullscreenSourceMaterials.length" class="col nlm-col-flex nlm-col-flex-wide">
                <div v-if="fullscreenLeftView === 'list'" class="nlm-fill-hidden-col">
                  <h4>依据资料</h4>
                  <div class="nlm-fill-scroll">
                    <div v-for="sm in fullscreenSourceMaterials" :key="sm.id" :class="['nlm-source-item', 'nlm-source-item-soft', { selected: fullscreenSelectedSourceId === sm.id }]" @click="fullscreenSelectedSourceId = sm.id; fullscreenLeftView = 'detail'">
                      <span class="type-icon"><i class="fas" :class="getMaterialIcon(sm)"></i></span>
                      <span class="title">{{ sm.title }}</span>
                    </div>
                  </div>
                </div>
                <div v-else class="nlm-fill-hidden-col">
                  <div class="back-row nlm-back-row-compact">
                    <button type="button" class="back-btn back-btn--icon-only" title="返回列表" aria-label="返回列表" @click="fullscreenLeftView = 'list'"><i class="fas fa-arrow-left" aria-hidden="true"></i></button>
                  </div>
                  <div v-if="fullscreenSelectedSource" class="nlm-fill-hidden-col">
                    <h4 class="nlm-source-title">{{ fullscreenSelectedSource.title }}</h4>
                    <div class="nlm-source-read nlm-fill-scroll">
                      <div v-for="(ex, i) in (fullscreenSelectedSource.excerpts || [])" :key="i" :class="['excerpt', { highlight: fullscreenHighlightSourceId === fullscreenSelectedSource.id && fullscreenHighlightExcerptIndex === i }]" :ref="el => setFullscreenExcerptRef(fullscreenSelectedSource.id, i, el)">{{ ex }}</div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col" :style="fullscreenSourceMaterials.length ? 'flex: 2;' : 'flex: 1;'">
                <h4>{{ fullscreenMaterial.type === 'analysis' ? '结果' : '报告' }}</h4>
                <div class="nlm-source-read" v-html="renderFullscreenAnalysisContent(fullscreenMaterial)" @click="handleFullscreenCitationClick($event)"></div>
              </div>
            </div>
          </div>
          <header class="workbench-top-header workbench-top-header--unified workbench-top-header--project-detail">
                  <div class="workbench-top-header__left workbench-top-header__left--with-pane-toggle">
                    <a-button type="text" class="ds-icon-btn workbench-back-text-btn" title="返回工作台" aria-label="返回工作台" @click="goBackToProjectCenterList">
                      <i class="fas fa-arrow-left workbench-back-icon" aria-hidden="true"></i>
                    </a-button>
                    <a-button
                      type="text"
                      class="ds-icon-btn workbench-left-pane-toggle-btn"
                      :title="sourcesCollapsed ? '展开左栏（资料 / 技能）' : '收起左栏（资料 / 技能）'"
                      :aria-label="sourcesCollapsed ? '展开左栏' : '收起左栏'"
                      :aria-expanded="sourcesCollapsed ? 'false' : 'true'"
                      @click="sourcesCollapsed = !sourcesCollapsed"
                    >
                      <i class="fas fa-table-columns workbench-left-pane-toggle-icon" aria-hidden="true"></i>
                    </a-button>
                  </div>
                  <div class="workbench-top-header__center-title-wrap">
                    <div class="workbench-top-header__title-with-mode">
                      <template v-if="workbenchProjectId">
                        <div class="workbench-top-header__title-cluster">
                          <span class="workbench-top-header__title-kicker" aria-label="工作台" title="工作台">
                            <span class="ds-page-hero__title-icon ds-page-hero__title-icon--audit-space" aria-hidden="true"><i class="fas fa-cube"></i></span>
                          </span>
                                    <span class="workbench-top-header__title-name" :title="'工作台 · ' + workbenchPageHeadTitle">{{ workbenchPageHeadTitle }}</span>
                        </div>
                      </template>
                      <span v-else class="workbench-top-header__title workbench-top-header__title--solo" :title="workbenchPageHeadTitle">{{ workbenchPageHeadTitle }}</span>
                      <div v-if="workbenchProjectId" class="ds-mode-switch-slider is-assisted" role="tablist" aria-label="模式切换">
                        <span class="ds-mode-switch-slider__thumb" aria-hidden="true"></span>
                        <button
                          type="button"
                          class="ds-mode-switch-slider__item"
                          role="tab"
                          aria-selected="false"
                          title="切换到自动模式（侧栏与内容区，与工作台卡片「自动模式」一致）"
                          aria-label="切换到自动模式"
                          @click="goBackToProjectDetailAnimated"
                        >
                          <i class="fas fa-bolt" aria-hidden="true"></i>
                          <span>自动</span>
                        </button>
                        <button
                          type="button"
                          class="ds-mode-switch-slider__item is-current"
                          role="tab"
                          aria-selected="true"
                          tabindex="-1"
                          title="当前为辅助模式"
                          aria-label="当前为辅助模式"
                        >
                          <i class="fas fa-comments" aria-hidden="true"></i>
                          <span>辅助</span>
                        </button>
                      </div>
                    </div>
                  </div>
                  <div class="workbench-top-header__actions">
                    <a-button
                      type="text"
                      class="ds-icon-btn workbench-right-pane-toggle-btn"
                      :title="studioCollapsed ? '展开右栏（结果）' : '收起右栏（结果）'"
                      :aria-label="studioCollapsed ? '展开右栏' : '收起右栏'"
                      :aria-expanded="studioCollapsed ? 'false' : 'true'"
                      @click="studioCollapsed = !studioCollapsed"
                    >
                      <i class="fas fa-table-columns workbench-right-pane-toggle-icon" aria-hidden="true"></i>
                    </a-button>
                    <a-dropdown :trigger="['click']" placement="bottomRight" :disabled="!workbenchProjectId">
                      <a-button
                        type="text"
                        size="small"
                        class="ds-icon-btn workbench-project-gear-btn"
                        title="工作台操作"
                        aria-label="工作台操作菜单"
                        :disabled="!workbenchProjectId"
                      >
                        <i class="fas fa-ellipsis" aria-hidden="true"></i>
                      </a-button>
                      <template #overlay>
                        <a-menu @click="onWorkbenchHeaderMenu">
                          <a-menu-item key="edit">编辑</a-menu-item>
                        </a-menu>
                      </template>
                    </a-dropdown>
                  </div>
          </header>
          <div ref="mainBody" class="workbench-body">
            <aside :style="{ flex: sourcesCollapsed ? '0 0 0px' : layoutRatios.left, minWidth: 0, display: 'flex', flexDirection: 'row', overflow: 'visible', transition: 'flex 0.2s ease, min-width 0.2s ease' }">
              <div
                v-show="!sourcesCollapsed"
                class="nlm-side-panel"
              >
                <div class="nlm-panel-header">
                  <div class="nlm-panel-title-row">
                    <a-segmented
                      v-model:value="workbenchLeftPrimaryTab"
                      class="ds-ant-segmented ds-ant-segmented--compact nlm-pool-tab-bar"
                      size="small"
                      :options="[
                        { label: '资料', value: 'material' },
                        { label: '技能', value: 'skill' },
                      ]"
                      aria-label="左侧资源页签"
                    />
                  </div>
                </div>
                <div v-if="sourcesLeftView === 'list'" class="nlm-side-panel-body">
                  <template v-if="workbenchLeftPrimaryTab === 'material'">
                  <div class="nlm-material-toolbar">
                    <div class="nlm-material-header-row">
                      <a-input
                        v-model:value="materialSearchQuery"
                        allow-clear
                        placeholder="搜索"
                        class="ds-input-inline-search ds-input-inline-search--compact"
                        style="flex:1;min-width:0"
                      >
                        <template #prefix>
                          <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                        </template>
                      </a-input>
                      <a-button type="text" size="large" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm" title="上传资料入口" aria-label="上传资料入口（次操作）" @click="openProjectCenterUpload">
                        <i class="fas fa-plus" aria-hidden="true"></i>
                      </a-button>
                    </div>
                    <div class="nlm-toolbar-meta-row nlm-material-filter-row">
                      <div class="nlm-toolbar-pool-caption-wrap">
                        <span class="nlm-toolbar-pool-caption">{{ poolTabMaterialCount }}个资料</span>
                        <a-button
                          type="text"
                          class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-toolbar-pool-refresh-btn"
                          :disabled="!workbenchProjectId"
                          title="重新加载资料列表（演示数据，未接真实接口）。不会刷新中间助手对话。"
                          aria-label="重新加载资料列表，不刷新对话"
                          @click="refreshWorkbenchDemoResources('material')"
                        >
                          <i class="fas fa-rotate-right" aria-hidden="true"></i>
                        </a-button>
                      </div>
                      <div class="nlm-material-toolbar__actions">
                      <a-popover
                        v-model:open="workbenchMaterialFilterPopoverOpen"
                        trigger="click"
                        placement="bottomLeft"
                        overlayClassName="skill-filter-popover-inner"
                      >
                        <template #content>
                          <div class="wb-material-filter-popover">
                            <div class="wb-material-filter-popover__section wb-material-filter-popover__section--scroll">
                              <div style="display:flex; align-items:center; justify-content:space-between; gap:var(--ds-space-xs); margin-bottom:var(--ds-space-sm);">
                                <span class="skill-filter-sort-label">标签匹配</span>
                                <a-radio-group v-model:value="workbenchMaterialTagMatchMode" size="small" option-type="button">
                                  <a-radio-button value="any">满足任意</a-radio-button>
                                  <a-radio-button value="all">满足全部</a-radio-button>
                                </a-radio-group>
                              </div>
                              <a-input
                                v-model:value="workbenchMaterialTagSearchQuery"
                                allow-clear
                                placeholder="搜索"
                                size="small"
                                class="ds-input-inline-search ds-input-inline-search--popover"
                                style="margin-bottom: var(--ds-space-sm);"
                              >
                                <template #prefix>
                                  <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                                </template>
                              </a-input>
                              <div class="skill-filter-tags" style="margin: 0;">
                                <template v-if="workbenchMaterialTagFilteredStats.length">
                                  <TagSm
                                    v-for="item in workbenchMaterialTagFilteredStats"
                                    :key="'workbench-material-filter-' + item.tag"
                                    variant="filter"
                                    :active="workbenchMaterialTagKeys.includes(item.tag)"
                                    :count="item.count"
                                    @click="toggleWorkbenchMaterialTag(item.tag)"
                                  >{{ item.tag }}</TagSm>
                                </template>
                                <span v-else class="skill-filter-empty">无匹配标签</span>
                              </div>
                            </div>
                            <div v-if="workbenchMaterialActiveFilterCount > 0" class="wb-material-filter-popover__footer">
                              <a-button type="link" size="small" @click="resetWorkbenchMaterialFilters">清除全部筛选</a-button>
                            </div>
                          </div>
                        </template>
                        <a-button
                          type="text"
                          class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-filter-icon-btn"
                          :title="workbenchMaterialActiveFilterCount ? ('按标签筛选（已选 ' + workbenchMaterialActiveFilterCount + ' 个）') : '按标签筛选'"
                          aria-label="按标签筛选"
                        >
                          <i class="fas fa-filter"></i>
                          <span v-if="workbenchMaterialActiveFilterCount > 0" class="nlm-filter-icon-btn__badge">{{ workbenchMaterialActiveFilterCount }}</span>
                        </a-button>
                      </a-popover>
                      <a-dropdown :trigger="['click']">
                        <a-button type="text" class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn" :title="'排序：' + currentWorkbenchSortLabel">
                          <i class="fas fa-arrow-down-short-wide"></i>
                        </a-button>
                        <template #overlay>
                          <a-menu @click="({ key }) => workbenchMaterialSortBy = key">
                            <a-menu-item v-for="opt in workbenchMaterialSortOptions" :key="opt.value">
                              <span class="nlm-sort-menu-item-label">
                                <i v-if="workbenchMaterialSortBy === opt.value" class="fas fa-check" style="font-size:var(--ds-type-icon-inline-fs);line-height:var(--ds-type-icon-symbol-lh);"></i>
                                <span v-else style="width:var(--ds-icon-chevron-placeholder-w);"></span>
                                {{ opt.label }}
                              </span>
                            </a-menu-item>
                          </a-menu>
                        </template>
                      </a-dropdown>
                      </div>
                    </div>
                  </div>
                  <div v-if="extractionResults.length" class="nlm-extraction-cards">
                    <div v-for="item in extractionResults" :key="item.id" :class="['nlm-extraction-card', item.status]">
                      <div v-if="item.status === 'loading'" class="nlm-extraction-card-loading">
                        <a-spin size="small" class="nlm-extraction-card-loading__spin" />
                        <span>正在从「{{ item.dataSourceName }}」抽取...</span>
                      </div>
                      <template v-else>
                        <div class="nlm-extraction-card-header">
                          <span class="nlm-extraction-card-title"><i class="fas fa-wand-magic-sparkles"></i> {{ item.dataSourceName }} 抽取已完成!</span>
                          <a class="nlm-extraction-card-view" @click.prevent="viewExtractionResult(item.id)">查看</a>
                        </div>
                        <div class="nlm-extraction-card-body">
                          <div v-for="(sn, si) in (item.snippets || []).slice(0, 3)" :key="si" class="nlm-extraction-snippet">
                            <span class="nlm-extraction-snippet-title">{{ sn.title }}</span>
                            <p class="nlm-extraction-snippet-desc">{{ sn.desc }}</p>
                          </div>
                          <p v-if="(item.snippets || []).length > 3" class="nlm-extraction-more">另外 {{ (item.snippets || []).length - 3 }} 个来源</p>
                        </div>
                        <div class="nlm-extraction-card-footer">
                          <a class="nlm-extraction-card-delete" @click.prevent="removeExtractionResult(item.id)">删除</a>
                          <button type="button" class="nlm-extraction-card-import" @click="importExtractionResult(item)"><i class="fas fa-plus"></i> 导入</button>
                        </div>
                      </template>
                    </div>
                  </div>
                  <div class="nlm-fill-scroll" @mouseleave="hoveredMaterialId = null" @click="onMaterialListAreaClick($event)">
                    <div class="nlm-cards-wrap nlm-tree-wrap">
                      <template v-for="section in workbenchLeftTreeSections" :key="section.key">
                        <div class="nlm-tree-children">
                          <a-dropdown v-for="node in section.children" :key="node.id" :trigger="['contextmenu']" @click.stop>
                            <div :class="['nlm-tree-leaf', { 'nlm-tree-leaf--analysis': section.key === 'analysis', 'nlm-source-item-loading': node.raw.loading, checked: isTreeNodeSelected(node, section.key) }]" draggable="true" @click="selectTreeNode(node, section.key)" @mouseenter="onTreeLeafMouseEnter(node, section.key, $event)" @mouseleave="onTreeLeafMouseLeave" @dragstart="onTreeLeafDragStart($event, node, section.key)">
                              <span class="nlm-tree-leaf-icon">
                                <a-spin
                                  v-if="section.key === 'material' && ['queued', 'parsing'].includes(workbenchMaterialStatusOf(node.raw))"
                                  size="small"
                                  class="nlm-tree-leaf-spin is-status-pending"
                                />
                                <i
                                  v-else-if="section.key === 'material' && workbenchMaterialStatusOf(node.raw) === 'failed'"
                                  class="fas fa-xmark is-status-failed"
                                ></i>
                                <a-spin
                                  v-else-if="section.key === 'analysis' && ['queued', 'parsing'].includes(workbenchAnalysisStatusOf(node.raw))"
                                  size="small"
                                  class="nlm-tree-leaf-spin is-status-pending"
                                />
                                <i
                                  v-else-if="section.key === 'analysis' && workbenchAnalysisStatusOf(node.raw) === 'failed'"
                                  class="fas fa-xmark is-status-failed"
                                ></i>
                                <a-spin v-else-if="node.raw.loading" size="small" class="nlm-tree-leaf-spin" />
                                <i v-else class="fas" :class="[getMaterialIcon(node.raw), getMaterialIconColorClass(node.raw)]"></i>
                              </span>
                              <div class="nlm-tree-leaf-title-wrap">
                                <div class="nlm-tree-leaf-col">
                                  <div class="nlm-tree-leaf-title" :class="{ 'is-muted': (section.key === 'material' && ['queued', 'parsing', 'failed'].includes(workbenchMaterialStatusOf(node.raw))) || (section.key === 'analysis' && ['queued', 'parsing', 'failed'].includes(workbenchAnalysisStatusOf(node.raw))) }" @click.stop="openDetailFromTreeTitle(node, section.key)">{{ node.raw.title }}</div>
                                </div>
                              </div>
                              <span class="nlm-tree-leaf-right">
                                <div class="nlm-tree-leaf-actions">
                                  <a-dropdown :trigger="['click']" @click.stop>
                                    <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                    <template #overlay>
                                      <a-menu @click="({ key }) => handleTreeContextMenu(key, node, section.key)">
                                        <a-menu-item key="ref">{{ node.raw.checked ? '从对话移除' : '添加到对话' }}</a-menu-item>
                                        <a-menu-item key="edit">编辑</a-menu-item>
                                        <a-menu-item v-if="section.key === 'material' || section.key === 'analysis'" key="download">下载</a-menu-item>
                                        <a-menu-item v-if="section.key === 'material'" key="rerun">重跑</a-menu-item>
                                        <a-menu-item key="delete">删除</a-menu-item>
                                      </a-menu>
                                    </template>
                                  </a-dropdown>
                                </div>
                              </span>
                            </div>
                            <template #overlay>
                              <a-menu @click="({ key }) => handleTreeContextMenu(key, node, section.key)">
                                <a-menu-item key="ref">{{ node.raw.checked ? '从对话移除' : '添加到对话' }}</a-menu-item>
                                <a-menu-item key="edit">编辑</a-menu-item>
                                <a-menu-item v-if="section.key === 'material' || section.key === 'analysis'" key="download">下载</a-menu-item>
                                <a-menu-item v-if="section.key === 'material'" key="rerun">重跑</a-menu-item>
                                <a-menu-item key="delete">删除</a-menu-item>
                              </a-menu>
                            </template>
                          </a-dropdown>
                        </div>
                      </template>
                    </div>
                  </div>
                  <div class="wb-material-status-footer ds-popover-panel__footer">
                    <a-popover
                      v-model:open="workbenchMaterialStatusPopoverOpenQueued"
                      trigger="click"
                      placement="top"
                    >
                      <template #content>
                        <div class="ds-popover-panel">
                          <div class="ds-popover-panel__title">排队中（{{ workbenchRawMaterialStatusSummary.queued }}）</div>
                          <div v-if="workbenchRawMaterialQueuedList.length" class="ds-popover-panel--scroll">
                            <div v-for="m in workbenchRawMaterialQueuedList" :key="'queued-' + m.id" class="text-secondary">{{ m.title || '未命名资料' }}</div>
                          </div>
                          <div v-else class="text-secondary">暂无资料</div>
                        </div>
                      </template>
                      <button type="button" class="ds-trigger-btn nlm-chat-result-toolbar-btn" @click.stop>
                        <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--queued">
                          <i class="fas fa-clock" aria-hidden="true"></i>
                          <span>排队中 {{ workbenchRawMaterialStatusSummary.queued }}</span>
                        </span>
                      </button>
                    </a-popover>
                    <a-popover
                      v-model:open="workbenchMaterialStatusPopoverOpenParsing"
                      trigger="click"
                      placement="top"
                    >
                      <template #content>
                        <div class="ds-popover-panel">
                          <div class="ds-popover-panel__title">解析中（{{ workbenchRawMaterialStatusSummary.parsing }}）</div>
                          <div v-if="workbenchRawMaterialParsingList.length" class="ds-popover-panel--scroll">
                            <div v-for="m in workbenchRawMaterialParsingList" :key="'parsing-' + m.id" class="text-secondary">{{ m.title || '未命名资料' }}</div>
                          </div>
                          <div v-else class="text-secondary">暂无资料</div>
                        </div>
                      </template>
                      <button type="button" class="ds-trigger-btn nlm-chat-result-toolbar-btn" @click.stop>
                        <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--parsing">
                          <a-spin size="small" class="wb-status-chip__spin" aria-hidden="true" />
                          <span>解析中 {{ workbenchRawMaterialStatusSummary.parsing }}</span>
                        </span>
                      </button>
                    </a-popover>
                    <a-popover
                      v-model:open="workbenchMaterialStatusPopoverOpenFailed"
                      trigger="click"
                      placement="top"
                    >
                      <template #content>
                        <div class="ds-popover-panel">
                          <div class="ds-popover-panel__title">失败（{{ workbenchRawMaterialStatusSummary.failed }}）</div>
                          <div v-if="workbenchRawMaterialFailedList.length" class="ds-popover-panel--scroll">
                            <div v-for="m in workbenchRawMaterialFailedList" :key="'failed-' + m.id" class="text-secondary">{{ m.title || '未命名资料' }}</div>
                          </div>
                          <div v-else class="text-secondary">暂无资料</div>
                        </div>
                      </template>
                      <button type="button" class="ds-trigger-btn nlm-chat-result-toolbar-btn" @click.stop>
                        <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--failed">
                          <i class="fas fa-circle-xmark" aria-hidden="true"></i>
                          <span>失败 {{ workbenchRawMaterialStatusSummary.failed }}</span>
                        </span>
                      </button>
                    </a-popover>
                  </div>
                  <div v-if="(sourcesLeftView === 'list' || sourcesRightView === 'list') && treeNodeHoverPopover.visible && treeNodeHoverPopover.node" class="nlm-tree-node-popover" :style="{ left: treeNodeHoverPopover.x + 'px', top: treeNodeHoverPopover.y + 'px' }" @mouseenter="onTreeLeafPopoverMouseEnter" @mouseleave="onTreeLeafPopoverMouseLeave">
                    <template v-if="getTreeNodePopoverFields(treeNodeHoverPopover.node, treeNodeHoverPopover.sectionKey)">
                      <div class="nlm-tree-node-popover-row"><span class="nlm-tree-node-popover-label">名称</span><span class="nlm-tree-node-popover-value">{{ getTreeNodePopoverFields(treeNodeHoverPopover.node, treeNodeHoverPopover.sectionKey).name }}</span></div>
                      <div v-if="getTreeNodePopoverFields(treeNodeHoverPopover.node, treeNodeHoverPopover.sectionKey).tags" class="nlm-tree-node-popover-row"><span class="nlm-tree-node-popover-label">标签</span><span class="nlm-tree-node-popover-value">{{ getTreeNodePopoverFields(treeNodeHoverPopover.node, treeNodeHoverPopover.sectionKey).tags }}</span></div>
                      <div v-if="getTreeNodePopoverFields(treeNodeHoverPopover.node, treeNodeHoverPopover.sectionKey).sizeFormat" class="nlm-tree-node-popover-row"><span class="nlm-tree-node-popover-label">大小/格式</span><span class="nlm-tree-node-popover-value">{{ getTreeNodePopoverFields(treeNodeHoverPopover.node, treeNodeHoverPopover.sectionKey).sizeFormat }}</span></div>
                      <div class="nlm-tree-node-popover-row"><span class="nlm-tree-node-popover-label">描述</span><span class="nlm-tree-node-popover-value">{{ getTreeNodePopoverFields(treeNodeHoverPopover.node, treeNodeHoverPopover.sectionKey).desc }}</span></div>
                      <div class="nlm-tree-node-popover-row"><span class="nlm-tree-node-popover-label">来源</span><span class="nlm-tree-node-popover-value">{{ getTreeNodePopoverFields(treeNodeHoverPopover.node, treeNodeHoverPopover.sectionKey).source }}</span></div>
                      <div class="nlm-tree-node-popover-row"><span class="nlm-tree-node-popover-label">创建时间</span><span class="nlm-tree-node-popover-value">{{ getTreeNodePopoverFields(treeNodeHoverPopover.node, treeNodeHoverPopover.sectionKey).createdAt }}</span></div>
                    </template>
                  </div>
                  </template>
                  <template v-else>
                    <div class="nlm-material-toolbar">
                      <div class="nlm-material-header-row">
                        <a-input
                          v-model:value="wbSkillSidebarSearchKeyword"
                          allow-clear
                          placeholder="搜索"
                          aria-label="搜索"
                          class="ds-input-inline-search ds-input-inline-search--compact"
                          style="flex:1;min-width:0"
                        >
                          <template #prefix>
                            <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                          </template>
                        </a-input>
                        <a-dropdown :trigger="['click']" placement="bottomRight">
                          <a-button type="text" size="large" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm" title="添加技能入口" aria-label="添加技能入口（次操作）">
                            <i class="fas fa-plus" aria-hidden="true"></i>
                          </a-button>
                          <template #overlay>
                            <a-menu @click="onWorkbenchTemplateAddMenu">
                              <a-menu-item key="new">创建技能</a-menu-item>
                              <a-menu-item key="library">引用技能</a-menu-item>
                            </a-menu>
                          </template>
                        </a-dropdown>
                      </div>
                      <div class="nlm-toolbar-meta-row nlm-material-filter-row">
                        <div class="nlm-toolbar-pool-caption-wrap">
                          <span class="nlm-toolbar-pool-caption">{{ workbenchTemplateTotalCount }}个技能</span>
                          <button
                            type="button"
                            class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-toolbar-pool-refresh-btn"
                            :disabled="!workbenchProjectId"
                            title="重新加载技能列表（演示数据，未接真实接口）。不会刷新中间助手对话。"
                            aria-label="重新加载技能列表，不刷新对话"
                            @click="refreshWorkbenchDemoResources('skill')"
                          >
                            <i class="fas fa-rotate-right" aria-hidden="true"></i>
                          </button>
                        </div>
                        <div class="nlm-material-toolbar__actions">
                          <a-popover
                            v-model:open="wbSkillListTagPopoverOpen"
                            trigger="click"
                            placement="bottomLeft"
                            overlayClassName="skill-filter-popover-inner"
                          >
                            <template #content>
                              <div class="skill-filter-popover-body skill-filter-popover-body--skill-l1">
                                <div class="ds-l1-popover-row ds-l1-popover-row--selected">
                                  <div class="ds-l1-popover-selected-main">
                                    <span class="ds-l1-popover-line-label">已选：</span>
                                    <span
                                      class="ds-l1-popover-selected-text"
                                      :title="wbSkillListTagKeys.length ? wbSkillListTagKeys.join('、') : ''"
                                    >{{ wbSkillListTagKeys.length ? wbSkillListTagKeys.join('、') : '暂无' }}</span>
                                  </div>
                                  <a-button
                                    v-if="wbSkillListTagKeys.length"
                                    type="link"
                                    size="small"
                                    class="ds-l1-popover-clear-link"
                                    @click="clearWbSkillListTags"
                                  >清空</a-button>
                                </div>
                                <div class="ds-l1-popover-row ds-l1-popover-row--match" role="group" aria-labelledby="wb-skill-popover-match-label">
                                  <span id="wb-skill-popover-match-label" class="ds-l1-popover-line-label">多标签匹配：</span>
                                  <a-radio-group v-model:value="wbSkillListTagMatchMode" size="small" class="ds-l1-popover-match-radios">
                                    <a-radio value="any">满足任意</a-radio>
                                    <a-radio value="all">满足全部</a-radio>
                                  </a-radio-group>
                                </div>
                                <div class="ds-l1-popover-row ds-l1-popover-row--search">
                                  <span class="ds-l1-popover-line-label">当前标签：</span>
                                  <a-input
                                    v-model:value="wbSkillListTagSearchQuery"
                                    allow-clear
                                    placeholder="搜索"
                                    size="small"
                                    class="ds-input-inline-search ds-input-inline-search--popover"
                                  >
                                    <template #prefix>
                                      <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                                    </template>
                                  </a-input>
                                </div>
                                <div class="skill-filter-tags skill-filter-tags--popover">
                                  <template v-if="wbSkillListTagFilteredStats.length">
                                    <TagSm
                                      v-for="item in wbSkillListTagFilteredStats"
                                      :key="'wb-skill-filter-' + item.tag"
                                      variant="filter"
                                      :active="wbSkillListTagKeys.includes(item.tag)"
                                      :count="item.count"
                                      @click="toggleWbSkillListTag(item.tag)"
                                    >{{ item.tag }}</TagSm>
                                  </template>
                                  <span v-else class="skill-filter-empty">无匹配标签</span>
                                </div>
                              </div>
                            </template>
                            <button
                              type="button"
                              class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-filter-icon-btn"
                              :title="wbSkillListTagKeys.length ? ('按标签筛选（已选 ' + wbSkillListTagKeys.length + ' 个）') : '按标签筛选'"
                              aria-label="按标签筛选"
                            >
                              <i class="fas fa-filter"></i>
                              <span v-if="wbSkillListTagKeys.length" class="nlm-filter-icon-btn__badge">{{ wbSkillListTagKeys.length }}</span>
                            </button>
                          </a-popover>
                          <button
                            v-if="wbSkillListTagKeys.length"
                            type="button"
                            class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn"
                            title="清空标签筛选"
                            aria-label="清空标签筛选"
                            @click="clearWbSkillListTags"
                          >
                            <i class="fas fa-times"></i>
                          </button>
                          <a-dropdown :trigger="['click']">
                            <a-button type="text" class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn" :title="'排序：' + currentWbSkillSortLabel">
                              <i class="fas fa-arrow-down-short-wide"></i>
                            </a-button>
                            <template #overlay>
                              <a-menu @click="({ key }) => wbSkillListSortBy = key">
                                <a-menu-item v-for="opt in wbSkillSidebarSortOptions" :key="opt.value">
                                  <span class="nlm-sort-menu-item-label">
                                    <i v-if="wbSkillListSortBy === opt.value" class="fas fa-check" style="font-size:var(--ds-type-icon-inline-fs);line-height:var(--ds-type-icon-symbol-lh);"></i>
                                    <span v-else style="width:var(--ds-icon-chevron-placeholder-w);"></span>
                                    {{ opt.label }}
                                  </span>
                                </a-menu-item>
                              </a-menu>
                            </template>
                          </a-dropdown>
                        </div>
                      </div>
                    </div>
                    <div class="nlm-fill-scroll" style="flex:1;min-height:0;">
                      <div class="nlm-cards-wrap nlm-tree-wrap">
                        <template v-for="section in workbenchTemplateTreeSections" :key="'tpl-' + section.key">
                          <div class="nlm-tree-children">
                            <div
                              v-for="node in section.children"
                              :key="node.key"
                              :class="['nlm-tree-leaf', 'nlm-tree-leaf--skill-stacked', { checked: wbSelectedTemplateKey === node.key }]"
                              @contextmenu.prevent="onWbSkillTreeLeafContextMenu(node)"
                            >
                              <div class="nlm-tree-leaf__main-row" role="button" tabindex="0" @click="selectWorkbenchSkillTemplate(node)" @keydown.enter.prevent="selectWorkbenchSkillTemplate(node)" @keydown.space.prevent="selectWorkbenchSkillTemplate(node)">
                                <span class="nlm-tree-leaf-icon">
                                  <a-spin v-if="isWbProjectSkillSummarizing(node.raw)" size="small" class="nlm-tree-leaf-spin is-status-pending" />
                                  <i v-else class="fas fa-diagram-project"></i>
                                </span>
                                <div class="nlm-tree-leaf-title-wrap">
                                  <div class="nlm-tree-leaf-col">
                                    <div
                                      class="nlm-tree-leaf-title nlm-tree-leaf-title--wb-skill-name"
                                      role="button"
                                      tabindex="0"
                                      title="查看并编辑技能"
                                      aria-label="打开技能详情（可编辑）"
                                      @click.stop="openWbProjectSkillDetailFromNode(node, { readOnly: false })"
                                      @keydown.enter.prevent.stop="openWbProjectSkillDetailFromNode(node, { readOnly: false })"
                                      @keydown.space.prevent.stop="openWbProjectSkillDetailFromNode(node, { readOnly: false })"
                                    >{{ node.raw.name || '未命名技能' }}</div>
                                    <div class="project-skill-resource-entry project-skill-resource-entry--wb" @click.stop>
                                      <a-popover
                                        :open="wbSkillResourcePopoverOpen && wbSkillResourcePopoverSkillId === String(node.raw.id)"
                                        trigger="click"
                                        placement="rightTop"
                                        @update:open="(v) => { if (v) openWbSkillResourcePopover(node.raw); else closeWbSkillResourcePopover(); }"
                                      >
                                        <template #content>
                                          <div class="project-skill-resource-popover">
                                            <div class="project-skill-resource-popover__head">
                                              <div class="project-skill-resource-popover__title">匹配资料（{{ getWbSkillLinkedResourceCount(node.raw) }}）</div>
                                              <a-button type="link" size="small" @click.stop="openWbSkillResourceEditor(node.raw)">调整</a-button>
                                            </div>
                                            <ul v-if="getWbSkillLinkedResources(node.raw).length" class="project-skill-resource-popover__list project-skill-resource-popover__list--simple">
                                              <li v-for="res in getWbSkillLinkedResources(node.raw).slice(0, 5)" :key="'wb-res-' + node.raw.id + '-' + res.id" class="project-skill-resource-popover__item">
                                                <span class="project-skill-resource-popover__name" :title="res.name">{{ res.name }}</span>
                                              </li>
                                            </ul>
                                            <a-empty v-else :image="false" description="暂无匹配资料" />
                                          </div>
                                        </template>
                                        <button type="button" class="project-skill-byline project-skill-byline--wb-inline" :class="'is-' + getWbSkillLinkedResourceBylineState(node.raw).kind" :aria-label="getWbSkillLinkedResourceBylineState(node.raw).ariaLabel">
                                          <i
                                            v-if="getWbSkillLinkedResourceBylineState(node.raw).kind === 'running'"
                                            class="fas fa-arrows-rotate project-skill-byline__icon project-skill-byline__icon--spin"
                                            aria-hidden="true"
                                          ></i>
                                          <i
                                            v-else-if="getWbSkillLinkedResourceBylineState(node.raw).kind === 'success'"
                                            class="fas fa-check project-skill-byline__icon"
                                            aria-hidden="true"
                                          ></i>
                                          <i
                                            v-else-if="getWbSkillLinkedResourceBylineState(node.raw).kind === 'failed'"
                                            class="fas fa-circle-exclamation project-skill-byline__icon"
                                            aria-hidden="true"
                                          ></i>
                                          <i
                                            v-else
                                            class="fas fa-minus project-skill-byline__icon"
                                            aria-hidden="true"
                                          ></i>
                                          <span class="project-skill-byline__text">{{ getWbSkillLinkedResourceBylineState(node.raw).text }}</span>
                                        </button>
                                      </a-popover>
                                    </div>
                                  </div>
                                </div>
                                <div class="nlm-tree-leaf-actions nlm-tree-leaf-actions--skill-corner">
                                  <a-dropdown
                                    :open="wbSkillTreeActionMenuKey === node.key"
                                    :trigger="['click']"
                                    placement="bottomRight"
                                    @update:open="(v) => onWbSkillTreeActionMenuOpenUpdate(v, node)"
                                    @click.stop
                                  >
                                    <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                    <template #overlay>
                                      <a-menu @click="(info) => onWbProjectSkillTreeMenu(info, node)">
                                        <a-menu-item key="cite">添加到对话</a-menu-item>
                                        <a-menu-item key="archive">入库</a-menu-item>
                                        <a-menu-item key="delete" danger>删除</a-menu-item>
                                      </a-menu>
                                    </template>
                                  </a-dropdown>
                                </div>
                              </div>
                            </div>
                          </div>
                        </template>
                        <div v-if="!workbenchTemplateTotalCount" class="nlm-empty-state" style="padding: var(--ds-space-m) var(--ds-space-sm);">
                          <p class="nlm-empty-desc">请先在工作台配置技能：创建或引用技能库中的技能，并关联资料后，即可在此执行并查看结果。</p>
                        </div>
                      </div>
                    </div>
                    <div class="wb-material-status-footer ds-popover-panel__footer">
                      <a-popover
                        v-model:open="wbSkillGeneratingPopoverOpen"
                        trigger="click"
                        placement="top"
                      >
                        <template #content>
                          <div class="ds-popover-panel">
                            <div class="ds-popover-panel__title">生成中（{{ wbSkillGeneratingCount }}）</div>
                            <div v-if="wbGeneratingSkills.length" class="ds-popover-panel--scroll">
                              <div v-for="s in wbGeneratingSkills" :key="'sg-' + s.id" class="text-secondary">{{ s.name || '未命名技能' }}</div>
                            </div>
                            <div v-else class="text-secondary">暂无技能</div>
                          </div>
                        </template>
                        <button type="button" class="ds-trigger-btn nlm-chat-result-toolbar-btn" @click.stop>
                          <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--parsing">
                            <a-spin size="small" class="wb-status-chip__spin" aria-hidden="true" />
                            <span>生成中 {{ wbSkillGeneratingCount }}</span>
                          </span>
                        </button>
                      </a-popover>
                    </div>
                  </template>
                </div>
                <div
                  v-else
                  class="nlm-side-panel-body"
                >
                  <div class="nlm-source-detail nlm-extraction-detail" v-if="selectedExtractionResult">
                    <div class="back-row">
                      <button type="button" class="back-btn back-btn--icon-only" title="返回列表" aria-label="返回列表" @click="selectedExtractionId = null; selectedTreeNode = null; sourcesLeftView = 'list'; sourcesWidth = 300"><i class="fas fa-arrow-left" aria-hidden="true"></i></button>
                    </div>
                    <h3 class="nlm-source-title">{{ selectedExtractionResult.dataSourceName }} 抽取结果</h3>
                    <div class="nlm-source-guide">
                      <div class="nlm-source-guide-header" @click="sourceGuideOpen = !sourceGuideOpen">
                        摘要 <i class="fas" :class="sourceGuideOpen ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
                      </div>
                      <div v-show="sourceGuideOpen" class="nlm-source-guide-body">
                        <p>{{ (selectedExtractionResult.snippets || []).length }} 条抽取结果，根据规则「{{ selectedExtractionResult.prompt || '（未填写）' }}」从 {{ selectedExtractionResult.dataSourceName }} 获取。</p>
                      </div>
                    </div>
                    <div class="nlm-source-read">
                      <div v-for="(sn, i) in (selectedExtractionResult.snippets || [])" :key="i" class="excerpt nlm-extraction-detail-snippet">
                        <strong>{{ sn.title }}</strong>
                        <p style="margin:var(--ds-space-xxs) 0 0 0">{{ sn.desc }}</p>
                      </div>
                    </div>
                  </div>
                  <div
                    class="nlm-source-detail nlm-source-detail--workbench-preview"
                    :class="{ 'material-preview-modal material-preview-modal--workbench-embed': selectedMaterial && selectedMaterial.type === 'raw' && selectedMaterial.projectSource }"
                    v-else-if="selectedMaterialDetail"
                  >
                    <div class="back-row" style="display:flex; align-items:center; flex-wrap:nowrap; justify-content:flex-start; gap:var(--ds-space-xxs);">
                      <button type="button" class="back-btn back-btn--icon-only" title="返回列表" aria-label="返回列表" @click="closeWorkbenchMaterialDetail"><i class="fas fa-arrow-left" aria-hidden="true"></i></button>
                      <span class="back-row__title" style="text-align:left;">{{ (workbenchSelectedProjectMaterialRow && workbenchSelectedProjectMaterialRow.name) || (selectedMaterial && selectedMaterial.title) || '资料预览' }}</span>
                      <a-dropdown v-if="selectedMaterial" :trigger="['click']" placement="bottomRight" @click.stop>
                        <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" style="margin-left:auto;" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                        <template #overlay>
                          <a-menu @click="({ key }) => handleTreeContextMenu(key, { raw: selectedMaterial }, 'material')">
                            <a-menu-item key="ref">{{ selectedMaterial.checked ? '从对话移除' : '添加到对话' }}</a-menu-item>
                            <a-menu-item key="edit">编辑</a-menu-item>
                            <a-menu-item key="download">下载</a-menu-item>
                            <a-menu-item key="rerun">重跑</a-menu-item>
                            <a-menu-item key="delete">删除</a-menu-item>
                          </a-menu>
                        </template>
                      </a-dropdown>
                    </div>
                    <div v-if="selectedMaterial && ['analysis','report'].includes(selectedMaterial.type)" class="nlm-wb-derived-line">根据 {{ sourceMaterialCount }} 个提取资料得到此{{ selectedMaterial.type === 'analysis' ? '结果' : '报告' }}</div>
                    <template v-if="selectedMaterial && selectedMaterial.type === 'raw' && selectedMaterial.projectSource && workbenchSelectedProjectMaterialRow">
                        <div class="tc-skill-modal-body tc-skill-modal-body--unified material-preview-unified-body workbench-material-preview-unified-body">
                          <a-tabs
                            v-model:activeKey="wbMaterialPreviewActiveTab"
                            class="skill-unified-modal-tabs material-preview-unified-tabs workbench-embed-top-tabs"
                            tab-position="top"
                            aria-label="资料预览：基本信息、文件预览或 OCR 结果"
                          >
                            <a-tab-pane key="basic" tab="基本信息">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息">
                                  <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions"></div>
                                </div>
                                <div class="material-preview-basic-tab">
                                  <div
                                    v-for="(row, idx) in workbenchMaterialPreviewBasicMetaRows"
                                    :key="'wbmeta-' + idx"
                                    class="material-preview-meta-dl-row"
                                  >
                                    <span class="material-preview-meta-dl-label">{{ row.label }}</span>
                                    <span class="material-preview-meta-dl-value">{{ row.value }}</span>
                                  </div>
                                </div>
                              </div>
                            </a-tab-pane>
                            <a-tab-pane key="preview" tab="文件预览">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="文件预览操作">
                                  <h3 class="ds-unified-tab-pane-chrome__title">文件预览</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions">
                                    <a-button
                                      v-if="(selectedMaterial.rawSubtype || 'document') !== 'table'"
                                      type="default"
                                      class="material-preview-download-link"
                                      :disabled="!workbenchSelectedProjectMaterialRow"
                                      title="下载"
                                      aria-label="下载"
                                      @click.stop="downloadWorkbenchMaterialPreview"
                                    >
                                      下载
                                    </a-button>
                                  </div>
                                </div>
                                <div class="preview-modal-content-frame preview-modal-content-frame--material">
                                  <div v-if="(selectedMaterial.rawSubtype || 'document') !== 'table'" class="material-preview-modal__viewer">
                                    <div class="material-preview-modal__viewer-body">
                                      <div
                                        v-for="(page, pi) in workbenchMaterialDocumentPages"
                                        :key="'wb-embed-mp-' + pi"
                                        class="nlm-original-doc-page material-preview-modal__page"
                                      >{{ page }}</div>
                                    </div>
                                  </div>
                                  <div v-else class="material-preview-modal__viewer">
                                    <div class="material-preview-modal__viewer-body">
                                      <div v-if="selectedMaterial.originalView && selectedMaterial.originalView.headers" class="nlm-original-table-wrap">
                                        <table class="nlm-original-table">
                                          <thead><tr><th v-for="(h, hi) in selectedMaterial.originalView.headers" :key="hi">{{ h }}</th></tr></thead>
                                          <tbody><tr v-for="(row, ri) in (selectedMaterial.originalView.rows || [])" :key="ri"><td v-for="(cell, ci) in row" :key="ci">{{ cell }}</td></tr></tbody>
                                        </table>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </a-tab-pane>
                            <a-tab-pane key="ocr" tab="OCR结果">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="OCR结果">
                                  <h3 class="ds-unified-tab-pane-chrome__title">OCR结果</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions material-preview-ocr-chrome-actions">
                                    <div class="ds-mode-switch-slider material-preview-ocr-mode-switch" :class="{ 'is-assisted': materialPreviewOcrShowLineNumbers, 'is-auto': !materialPreviewOcrShowLineNumbers }" role="tablist" aria-label="OCR预览模式切换">
                                      <span class="ds-mode-switch-slider__thumb" aria-hidden="true"></span>
                                      <button
                                        type="button"
                                        class="ds-mode-switch-slider__item"
                                        :class="{ 'is-current': !materialPreviewOcrShowLineNumbers }"
                                        role="tab"
                                        :aria-selected="!materialPreviewOcrShowLineNumbers"
                                        :tabindex="!materialPreviewOcrShowLineNumbers ? 0 : -1"
                                        title="普通预览"
                                        aria-label="普通预览"
                                        @click="materialPreviewOcrShowLineNumbers = false"
                                      >
                                        <i class="fas fa-eye" aria-hidden="true"></i>
                                      </button>
                                      <button
                                        type="button"
                                        class="ds-mode-switch-slider__item"
                                        :class="{ 'is-current': materialPreviewOcrShowLineNumbers }"
                                        role="tab"
                                        :aria-selected="materialPreviewOcrShowLineNumbers"
                                        :tabindex="materialPreviewOcrShowLineNumbers ? 0 : -1"
                                        title="带行号预览"
                                        aria-label="带行号预览"
                                        @click="materialPreviewOcrShowLineNumbers = true"
                                      >
                                        <i class="fas fa-code" aria-hidden="true"></i>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                                <div class="material-preview-modal__viewer material-preview-modal__viewer--ocr-tab">
                                  <div class="material-preview-modal__viewer-body">
                                    <div
                                      v-for="(page, pi) in workbenchMaterialOcrPagesDisplayed"
                                      :key="'wb-embed-ocr-' + pi"
                                      :class="['nlm-original-doc-page', 'material-preview-modal__page', { 'ds-font-mono': materialPreviewOcrShowLineNumbers }]"
                                    >{{ page }}</div>
                                  </div>
                                </div>
                              </div>
                            </a-tab-pane>
                          </a-tabs>
                        </div>
                    </template>
                    <template v-else-if="selectedMaterial && selectedMaterial.type === 'raw'">
                      <div class="wb-material-preview-shell wb-material-preview-shell--workbench-embed">
                        <div class="wb-material-preview-toolbar">
                          <span class="wb-material-preview-toolbar-meta">在线预览（PDF）</span>
                          <span class="wb-material-preview-toolbar-meta">1 / {{ workbenchMaterialDocumentPages.length || 1 }}</span>
                        </div>
                        <div class="wb-material-preview-body">
                          <div
                            v-for="(page, pi) in workbenchMaterialDocumentPages"
                            :key="'wb-embed-fb-' + pi"
                            class="nlm-original-doc-page wb-material-preview-page"
                          >{{ page }}</div>
                        </div>
                      </div>
                    </template>
                    <template v-else-if="!(selectedMaterial && selectedMaterial.type === 'analysis')">
                      <h3 class="nlm-source-title">{{ selectedMaterialDetail.title }}</h3>
                      <div class="nlm-source-guide">
                        <div class="nlm-source-guide-header" @click="sourceGuideOpen = !sourceGuideOpen">
                          资料指南 <i class="fas" :class="sourceGuideOpen ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
                        </div>
                        <div v-show="sourceGuideOpen" class="nlm-source-guide-body">
                          <p>{{ selectedMaterialDetail.overview }}</p>
                        </div>
                      </div>
                      <div class="nlm-source-read" ref="sourceRead">
                        <div v-for="(ex, i) in detailExcerpts" :key="i" :class="['excerpt', { highlight: highlightSourceId === selectedMaterialDetail.id && highlightExcerptIndex === i }]" :ref="el => setExcerptRef(selectedMaterialDetail.id, i, el)">{{ ex }}</div>
                      </div>
                    </template>
                  </div>
                </div>
              </div>
            </aside>
            <div class="nlm-resizer" :class="{ 'is-hidden': sourcesCollapsed }" @mousedown="beginResize('sources', $event)"></div>
            <section class="nlm-assistant-column" :style="{ flex: layoutMode === 'B' ? 4 : layoutRatios.middle, minWidth: 0, minHeight: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }">
              <div class="nlm-panel-header">
                <div class="nlm-panel-title-row">
                  <span class="nlm-panel-title">{{ layoutMode === 'B' ? '经验沉淀' : '对话' }}</span>
                </div>
                <div v-if="layoutMode === 'A'" class="nlm-assistant-header-actions">
                  <button type="button" class="nlm-assistant-header-btn" title="生成技能" aria-label="生成技能" @click="summarizeLatestBotMessageToTemplate">
                    <i class="fas fa-file-contract" aria-hidden="true"></i>
                    <span>生成技能</span>
                  </button>
                  <a-dropdown v-model:open="historyDropdownOpen" :trigger="['click']">
                    <button type="button" class="nlm-assistant-header-btn" title="历史会话" aria-label="历史会话">
                      <i class="fas fa-history" aria-hidden="true"></i>
                      <span>历史</span>
                    </button>
                    <template #overlay>
                      <a-menu v-if="sessionHistory.length" @click="({ key }) => { const s = sessionHistory.find(x => x.id === key); if (s) restoreSession(s); }">
                        <a-menu-item v-for="s in sessionHistory" :key="s.id">{{ s.title }}</a-menu-item>
                      </a-menu>
                      <div v-else class="nlm-history-empty">暂无历史会话</div>
                    </template>
                  </a-dropdown>
                  <button type="button" class="nlm-assistant-header-btn" title="新建会话" aria-label="新建会话" @click="newSession">
                    <i class="fas fa-plus" aria-hidden="true"></i>
                    <span>会话</span>
                  </button>
                </div>
              </div>
              <template v-if="layoutMode === 'B'">
                <div class="nlm-mode-b-canvas">
                  <div class="nlm-draft-block"><label>抽取技能草案</label><textarea v-model="experienceDrafts.extract" rows="4" placeholder="抽取技能草案" /></div>
                  <div class="nlm-draft-block"><label>分析技能草案</label><textarea v-model="experienceDrafts.analysis" rows="4" placeholder="分析技能草案" /></div>
                  <div class="nlm-draft-block"><label>报告技能草案</label><textarea v-model="experienceDrafts.report" rows="4" placeholder="报告技能草案" /></div>
                  <div class="nlm-mode-b-actions">
                    <button class="nlm-btn" @click="exitExperienceDraftMode">返回模式 A</button>
                    <a-button type="primary" @click="saveExperienceToTemplate">保存至技能库</a-button>
                  </div>
                </div>
              </template>
              <template v-else>
              <FreeAuditChatPanel :host="freeAuditChatHost" />
              <div class="nlm-chat-input-wrap" @dragover.prevent @drop="onChatAreaDrop">
                <teleport to="body">
                  <div
                    v-if="chatInputTriggerOpen && chatInputTriggerKind === 'at'"
                    ref="chatAtTriggerFloater"
                    class="nlm-chat-input-trigger-floater nlm-chat-input-trigger-floater--at-fixed nlm-chat-at-dropdown-root"
                    role="listbox"
                    aria-label="引用资料或结果"
                    :style="chatAtFloaterStyle"
                    @mousedown.prevent
                  >
                    <div class="nlm-chat-at-menu-wrap">
                      <template v-if="chatAtMenuHasAnythingToRef">
                        <template v-if="chatTriggerFilterTrimmed">
                          <div class="nlm-chat-at-cascade nlm-chat-at-cascade--solo">
                            <div class="nlm-chat-at-card nlm-chat-at-card--single nlm-chat-at-card--match-list">
                              <div class="nlm-chat-at-card__chrome">
                                <div class="nlm-chat-at-ref-head">匹配资料与结果</div>
                              </div>
                              <div class="nlm-chat-at-card__body nlm-chat-at-card__body--scroll">
                                <button
                                  v-for="row in chatAtUnifiedMatchRows"
                                  :key="'chat-at-uni-' + row.kind + '-' + row.m.id"
                                  type="button"
                                  class="nlm-chat-at-item-row nlm-chat-at-item-row--unified"
                                  @click="onChatInputTriggerPickMaterial(row.m)"
                                >
                                  <span
                                    class="nlm-chat-at-item-row__kind nlm-chat-at-item-row__kind--ic"
                                    :title="row.kind === 'raw' ? '资料' : '结果'"
                                    :aria-label="row.kind === 'raw' ? '资料' : '结果'"
                                  >
                                    <i class="fas" :class="[getMaterialIcon(row.m), getMaterialIconColorClass(row.m)]" aria-hidden="true"></i>
                                  </span>
                                  <span class="nlm-chat-at-item-row__title">{{ row.m.title || row.m.name || '未命名' }}</span>
                                </button>
                                <div v-if="!chatAtUnifiedMatchRows.length" class="nlm-chat-at-item-row nlm-chat-at-item-row--empty" aria-disabled="true">无匹配项</div>
                              </div>
                            </div>
                          </div>
                        </template>
                        <template v-else>
                          <div class="nlm-chat-at-cascade">
                            <div class="nlm-chat-at-flyout-anchor">
                              <div class="nlm-chat-at-card nlm-chat-at-card--flyout-rail">
                                <div class="nlm-chat-at-card__chrome">
                                  <div class="nlm-chat-at-ref-head">引用</div>
                                </div>
                                <div class="nlm-chat-at-card__body nlm-chat-at-card__body--rail">
                                  <button
                                    v-for="cat in chatAtMenuRailCategories"
                                    :key="'chat-trg-at-cat-' + cat.key"
                                    type="button"
                                    class="nlm-chat-at-cat-row"
                                    @click="openChatInputAtSubmenu(cat.key)"
                                  >
                                    <span class="nlm-chat-at-cat-row__label">{{ cat.label }}</span>
                                    <i class="fas fa-chevron-right nlm-chat-at-cat-row__chev" aria-hidden="true"></i>
                                  </button>
                                </div>
                              </div>
                              <div v-if="chatAtMenuPanel === 'items'" class="nlm-chat-at-card nlm-chat-at-card--flyout-sub">
                                <div class="nlm-chat-at-ref-head nlm-chat-at-ref-head--sub">
                                  <button
                                    type="button"
                                    class="nlm-chat-at-back"
                                    title="返回"
                                    aria-label="返回引用分类"
                                    @click="backChatInputAtSubmenu"
                                  >
                                    <i class="fas fa-chevron-left" aria-hidden="true"></i>
                                  </button>
                                  <span class="nlm-chat-at-ref-head__title">{{ chatAtSubmenuTitle }}</span>
                                </div>
                                <div class="nlm-chat-at-card__body nlm-chat-at-card__body--scroll">
                                  <template v-if="chatInputAtRail === 'raw'">
                                    <button
                                      v-for="m in chatAtMenuRawMaterials"
                                      :key="'chat-trg-at-mat-' + m.id"
                                      type="button"
                                      class="nlm-chat-at-item-row"
                                      @click="onChatInputTriggerPickMaterial(m)"
                                    >
                                      <span class="nlm-chat-at-item-row__title">{{ m.title || m.name || '未命名' }}</span>
                                    </button>
                                    <div v-if="!chatAtMenuRawMaterials.length" class="nlm-chat-at-item-row nlm-chat-at-item-row--empty" aria-disabled="true">暂无资料</div>
                                  </template>
                                  <template v-else-if="chatInputAtRail === 'result'">
                                    <button
                                      v-for="m in chatAtMenuResultMaterials"
                                      :key="'chat-trg-at-res-' + m.id"
                                      type="button"
                                      class="nlm-chat-at-item-row"
                                      @click="onChatInputTriggerPickMaterial(m)"
                                    >
                                      <span class="nlm-chat-at-item-row__title">{{ m.title || m.name || '未命名' }}</span>
                                    </button>
                                    <div v-if="!chatAtMenuResultMaterials.length" class="nlm-chat-at-item-row nlm-chat-at-item-row--empty" aria-disabled="true">暂无结果</div>
                                  </template>
                                </div>
                              </div>
                            </div>
                          </div>
                        </template>
                      </template>
                      <div v-else class="nlm-chat-at-cascade nlm-chat-at-cascade--solo">
                        <div class="nlm-chat-at-card nlm-chat-at-card--single">
                          <div class="nlm-chat-at-card__chrome">
                            <div class="nlm-chat-at-ref-head">引用</div>
                            <p class="nlm-chat-at-ref-hint">上传资料并产出结果后，可输入 @ 引用</p>
                          </div>
                          <div class="nlm-chat-at-card__body">
                            <div class="nlm-chat-at-item-row nlm-chat-at-item-row--empty">暂无可引用项</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </teleport>
                <div
                  v-if="chatInputTriggerOpen && chatInputTriggerKind === 'slash'"
                  class="nlm-chat-input-trigger-floater nlm-chat-insert-dropdown"
                  role="listbox"
                  aria-label="选择技能"
                  @mousedown.prevent
                >
                  <a-menu class="nlm-chat-insert-menu" @click="onChatInputTriggerSlashMenuClick">
                    <template v-if="chatSlashMenuHasAnyItem">
                      <template v-for="sec in chatSlashMenuSectionsFiltered" :key="'chat-trg-slash-sec-' + sec.key">
                        <a-menu-item-group :title="sec.label">
                          <a-menu-item v-for="node in sec.children" :key="node.key">{{ node.raw.name || '未命名' }}</a-menu-item>
                        </a-menu-item-group>
                      </template>
                    </template>
                    <a-menu-item v-else key="chat-trg-slash-empty" disabled>{{ chatTriggerFilter.trim() ? '无匹配技能' : '暂无技能' }}</a-menu-item>
                  </a-menu>
                </div>
                <div class="nlm-chat-input-box">
                  <div class="nlm-chat-input-text">
                    <textarea
                      ref="chatInputEl"
                      v-model="chatInput"
                      placeholder="输入问题；@ 引用资料或结果，/ 选择技能；Enter 发送"
                      rows="1"
                      @keydown="onChatInputKeydown"
                      @input="onChatInputInput"
                      @focus="onChatInputFocus"
                      @blur="onChatInputBlur"
                    ></textarea>
                  </div>
                  <div class="nlm-chat-input-bar">
                    <div class="nlm-chat-input-bar__right">
                      <button
                        v-if="chatReplyInProgress"
                        type="button"
                        class="ds-icon-btn ds-icon-btn--standard nlm-chat-send-btn nlm-chat-send-btn--pause"
                        title="暂停生成"
                        aria-label="暂停生成"
                        @click="pauseChatGeneration"
                      >
                        <i class="fas fa-pause nlm-chat-send-btn__icon" aria-hidden="true"></i>
                      </button>
                      <button
                        v-else
                        type="button"
                        class="ds-icon-btn ds-icon-btn--standard nlm-chat-send-btn"
                        title="发送"
                        aria-label="发送"
                        @click="sendChat"
                      >
                        <i class="fas fa-arrow-up nlm-chat-send-btn__icon" aria-hidden="true"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="nlm-disclaimer">系统生成内容需人工核查，审计结论以人工确认为准。</div>
              </template>
            </section>
            <div class="nlm-resizer" :class="{ 'is-hidden': studioCollapsed }" @mousedown="beginResize('studio', $event)"></div>
            <aside :style="{ flex: studioCollapsed ? '0 0 0px' : layoutRatios.right, minWidth: 0, display: 'flex', flexDirection: 'row', overflow: 'visible', transition: 'flex 0.2s ease, min-width 0.2s ease' }">
              <div v-show="!studioCollapsed" class="nlm-side-panel" :class="{ 'is-analysis-detail-open': sourcesRightView === 'detail' && selectedMaterial && selectedMaterial.type === 'analysis' }">
                <template v-if="sourcesRightView === 'list'">
                  <div class="nlm-panel-header">
                    <div class="nlm-panel-title-row">
                      <span class="nlm-panel-title">结果</span>
                    </div>
                  </div>
                  <div class="nlm-side-panel-body" style="display:flex;flex-direction:column;min-height:0;">
                    <div class="nlm-material-toolbar">
                      <div class="nlm-material-header-row">
                        <a-input
                          v-model:value="workbenchAnalysisSearchQuery"
                          allow-clear
                          placeholder="搜索"
                          class="ds-input-inline-search ds-input-inline-search--compact"
                          style="flex:1;min-width:0"
                        >
                          <template #prefix>
                            <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                          </template>
                        </a-input>
                      </div>
                      <div class="nlm-toolbar-meta-row nlm-material-filter-row">
                        <div class="nlm-toolbar-pool-caption-wrap">
                          <span class="nlm-toolbar-pool-caption">{{ poolTabAnalysisCount }}个结果</span>
                          <button
                            type="button"
                            class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-toolbar-pool-refresh-btn"
                            :disabled="!workbenchProjectId"
                            title="重新加载结果列表（演示数据，未接真实接口）。不会刷新中间助手对话。"
                            aria-label="重新加载结果列表，不刷新对话"
                            @click="refreshWorkbenchDemoResources('result')"
                          >
                            <i class="fas fa-rotate-right" aria-hidden="true"></i>
                          </button>
                        </div>
                        <div class="nlm-material-toolbar__actions">
                          <a-popover
                            v-model:open="workbenchAnalysisTagPopoverOpen"
                            trigger="click"
                            placement="bottomLeft"
                            overlayClassName="skill-filter-popover-inner"
                          >
                            <template #content>
                              <div class="skill-filter-popover-body skill-filter-popover-body--narrow">
                                <div style="display:flex; align-items:center; justify-content:space-between; gap:var(--ds-space-xs); margin-bottom:var(--ds-space-sm);">
                                  <span class="skill-filter-sort-label">标签匹配</span>
                                  <a-radio-group v-model:value="workbenchAnalysisTagMatchMode" size="small" option-type="button">
                                    <a-radio-button value="any">满足任意</a-radio-button>
                                    <a-radio-button value="all">满足全部</a-radio-button>
                                  </a-radio-group>
                                </div>
                                <a-input
                                  v-model:value="workbenchAnalysisTagSearchQuery"
                                  allow-clear
                                  placeholder="搜索"
                                  size="small"
                                  class="ds-input-inline-search ds-input-inline-search--popover"
                                  style="margin-bottom: var(--ds-space-sm);"
                                >
                                  <template #prefix>
                                    <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                                  </template>
                                </a-input>
                                <div class="skill-filter-tags" style="margin: 0;">
                                  <template v-if="workbenchAnalysisTagFilteredStats.length">
                                    <TagSm
                                      v-for="item in workbenchAnalysisTagFilteredStats"
                                      :key="'wb-ar-filter-' + item.tag"
                                      variant="filter"
                                      :active="workbenchAnalysisTagKeys.includes(item.tag)"
                                      :count="item.count"
                                      @click="toggleWorkbenchAnalysisTag(item.tag)"
                                    >{{ item.tag }}</TagSm>
                                  </template>
                                  <span v-else class="skill-filter-empty">无匹配标签</span>
                                </div>
                              </div>
                            </template>
                            <button
                              type="button"
                              class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-filter-icon-btn"
                              :title="workbenchAnalysisTagKeys.length ? ('按标签筛选（已选 ' + workbenchAnalysisTagKeys.length + ' 个）') : '按标签筛选'"
                              aria-label="按标签筛选"
                            >
                              <i class="fas fa-filter"></i>
                              <span v-if="workbenchAnalysisTagKeys.length > 0" class="nlm-filter-icon-btn__badge">{{ workbenchAnalysisTagKeys.length }}</span>
                            </button>
                          </a-popover>
                          <button
                            v-if="workbenchAnalysisTagKeys.length"
                            type="button"
                            class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn"
                            title="清空标签筛选"
                            aria-label="清空标签筛选"
                            @click="clearWorkbenchAnalysisTags"
                          >
                            <i class="fas fa-times"></i>
                          </button>
                          <a-dropdown :trigger="['click']">
                            <a-button type="text" class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn" :title="'排序：' + currentWorkbenchAnalysisSortLabel">
                              <i class="fas fa-arrow-down-short-wide"></i>
                            </a-button>
                            <template #overlay>
                              <a-menu @click="({ key }) => workbenchAnalysisSortBy = key">
                                <a-menu-item v-for="opt in workbenchAnalysisSortOptions" :key="opt.value">
                                  <span class="nlm-sort-menu-item-label">
                                    <i v-if="workbenchAnalysisSortBy === opt.value" class="fas fa-check" style="font-size:var(--ds-type-icon-inline-fs);line-height:var(--ds-type-icon-symbol-lh);"></i>
                                    <span v-else style="width:var(--ds-icon-chevron-placeholder-w);"></span>
                                    {{ opt.label }}
                                  </span>
                                </a-menu-item>
                              </a-menu>
                            </template>
                          </a-dropdown>
                        </div>
                      </div>
                    </div>
                    <div class="nlm-fill-scroll" style="flex:1;min-height:0;" @mouseleave="hoveredMaterialId = null" @click="onMaterialListAreaClick($event)">
                      <div class="nlm-cards-wrap nlm-tree-wrap">
                        <template v-for="section in workbenchRightTreeSections" :key="section.key">
                          <div class="nlm-tree-children">
                            <a-dropdown v-for="node in section.children" :key="node.id" :trigger="['contextmenu']" @click.stop>
                              <div :class="['nlm-tree-leaf', { 'nlm-tree-leaf--analysis': section.key === 'analysis', 'nlm-source-item-loading': node.raw.loading, checked: isTreeNodeSelected(node, section.key) }]" draggable="true" @click="selectTreeNode(node, section.key)" @mouseenter="onTreeLeafMouseEnter(node, section.key, $event)" @mouseleave="onTreeLeafMouseLeave" @dragstart="onTreeLeafDragStart($event, node, section.key)">
                                <span class="nlm-tree-leaf-icon">
                                  <a-spin
                                    v-if="section.key === 'material' && ['queued', 'parsing'].includes(workbenchMaterialStatusOf(node.raw))"
                                    size="small"
                                    class="nlm-tree-leaf-spin is-status-pending"
                                  />
                                  <i
                                    v-else-if="section.key === 'material' && workbenchMaterialStatusOf(node.raw) === 'failed'"
                                    class="fas fa-xmark is-status-failed"
                                  ></i>
                                  <a-spin
                                    v-else-if="section.key === 'analysis' && ['queued', 'parsing'].includes(workbenchAnalysisStatusOf(node.raw))"
                                    size="small"
                                    class="nlm-tree-leaf-spin is-status-pending"
                                  />
                                  <i
                                    v-else-if="section.key === 'analysis' && workbenchAnalysisStatusOf(node.raw) === 'failed'"
                                    class="fas fa-xmark is-status-failed"
                                  ></i>
                                  <a-spin v-else-if="node.raw.loading" size="small" class="nlm-tree-leaf-spin" />
                                  <i v-else class="fas" :class="[getMaterialIcon(node.raw), getMaterialIconColorClass(node.raw)]"></i>
                                </span>
                                <div class="nlm-tree-leaf-title-wrap">
                                  <div class="nlm-tree-leaf-col">
                                    <div class="nlm-tree-leaf-title" :class="{ 'is-muted': (section.key === 'material' && ['queued', 'parsing', 'failed'].includes(workbenchMaterialStatusOf(node.raw))) || (section.key === 'analysis' && ['queued', 'parsing', 'failed'].includes(workbenchAnalysisStatusOf(node.raw))) }" @click.stop="openDetailFromTreeTitle(node, section.key)">{{ node.raw.title }}</div>
                                  </div>
                                </div>
                                <span class="nlm-tree-leaf-right">
                                  <div class="nlm-tree-leaf-actions">
                                    <a-dropdown :trigger="['click']" @click.stop>
                                      <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                                      <template #overlay>
                                        <a-menu @click="({ key }) => handleTreeContextMenu(key, node, section.key)">
                                          <a-menu-item key="ref">{{ node.raw.checked ? '从对话移除' : '添加到对话' }}</a-menu-item>
                                          <a-menu-item key="edit">编辑</a-menu-item>
                                          <a-menu-item v-if="section.key === 'material' || section.key === 'analysis'" key="download">下载</a-menu-item>
                                          <a-menu-item v-if="section.key === 'material'" key="rerun">重跑</a-menu-item>
                                          <a-menu-item key="delete">删除</a-menu-item>
                                        </a-menu>
                                      </template>
                                    </a-dropdown>
                                  </div>
                                </span>
                              </div>
                              <template #overlay>
                                <a-menu @click="({ key }) => handleTreeContextMenu(key, node, section.key)">
                                  <a-menu-item key="ref">{{ node.raw.checked ? '从对话移除' : '添加到对话' }}</a-menu-item>
                                  <a-menu-item key="edit">编辑</a-menu-item>
                                  <a-menu-item v-if="section.key === 'material' || section.key === 'analysis'" key="download">下载</a-menu-item>
                                  <a-menu-item v-if="section.key === 'material'" key="rerun">重跑</a-menu-item>
                                  <a-menu-item key="delete">删除</a-menu-item>
                                </a-menu>
                              </template>
                            </a-dropdown>
                          </div>
                        </template>
                      </div>
                    </div>
                  </div>
                </template>
                <div v-else class="nlm-side-panel-body is-analysis-detail-open" style="display:flex;flex-direction:column;min-height:0;">
                  <div class="nlm-panel-header" style="flex-shrink:0;">
                    <div class="nlm-panel-title-row">
                      <span class="nlm-panel-title">结果</span>
                    </div>
                  </div>
                  <div
                    class="nlm-source-detail nlm-source-detail--workbench-preview nlm-fill-scroll analysis-result-preview-modal analysis-result-preview-modal--workbench-embed"
                    style="flex:1;min-height:0;"
                    v-if="selectedMaterial && selectedMaterial.type === 'analysis'"
                  >
                    <div class="back-row" style="display:flex; align-items:center; flex-wrap:nowrap; justify-content:flex-start; gap:var(--ds-space-xxs);">
                      <a-button type="text" size="small" class="ds-icon-btn ds-icon-btn--nlm wb-back-icon-btn" title="返回列表" aria-label="返回列表" @click="closeWorkbenchMaterialDetail">
                        <i class="fas fa-arrow-left" aria-hidden="true"></i>
                      </a-button>
                      <span class="back-row__title" style="text-align:left;">{{ (workbenchSelectedAnalysisResultRow && workbenchSelectedAnalysisResultRow.name) || (selectedMaterial && selectedMaterial.title) || '结果预览' }}</span>
                      <a-dropdown v-if="selectedMaterial" :trigger="['click']" placement="bottomRight" @click.stop>
                        <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" style="margin-left:auto;" @click.stop><i class="fas fa-ellipsis"></i></a-button>
                        <template #overlay>
                          <a-menu @click="({ key }) => handleTreeContextMenu(key, { raw: selectedMaterial }, 'analysis')">
                            <a-menu-item key="ref">{{ selectedMaterial.checked ? '从对话移除' : '添加到对话' }}</a-menu-item>
                            <a-menu-item key="edit">编辑</a-menu-item>
                            <a-menu-item key="download">下载</a-menu-item>
                            <a-menu-item key="delete">删除</a-menu-item>
                          </a-menu>
                        </template>
                      </a-dropdown>
                    </div>
                    <div class="workbench-analysis-result-embed">
                      <div class="tc-skill-modal-body tc-skill-modal-body--unified workbench-analysis-result-unified-body">
                        <a-tabs
                          :activeKey="wbAnalysisResultPreviewActiveTab"
                          class="skill-unified-modal-tabs workbench-analysis-result-embed-tabs workbench-embed-top-tabs"
                          tab-position="top"
                          aria-label="结果预览：基本信息、结果正文或版本管理"
                          @update:activeKey="onWorkbenchAnalysisResultPreviewTabUpdate"
                        >
                          <a-tab-pane key="basic" tab="基本信息">
                            <div class="workbench-result-preview-pane workbench-result-preview-pane--basic">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息">
                                  <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions"></div>
                                </div>
                                <div class="workbench-result-preview-tab-inner">
                                  <div
                                    v-for="(row, idx) in workbenchAnalysisResultBasicMetaRows"
                                    :key="'wbar-meta-' + idx"
                                    class="material-preview-meta-dl-row"
                                  >
                                    <span class="material-preview-meta-dl-label">{{ row.label }}</span>
                                    <span
                                      v-if="row.label === '状态'"
                                      class="material-preview-meta-dl-value material-preview-meta-dl-value--status-pill"
                                    >
                                      <span
                                        class="ds-status-pill"
                                        :class="analysisStatusChipClass(workbenchSelectedAnalysisResultRow && workbenchSelectedAnalysisResultRow.status)"
                                      >
                                        <span class="ds-status-pill__dot"></span>
                                        <span class="ds-status-pill__label">{{ analysisResultStatusLabel(workbenchSelectedAnalysisResultRow && workbenchSelectedAnalysisResultRow.status) }}</span>
                                      </span>
                                    </span>
                                    <span v-else class="material-preview-meta-dl-value">{{ row.value }}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </a-tab-pane>
                          <a-tab-pane key="body" tab="结果正文">
                            <div class="workbench-result-preview-pane workbench-result-preview-pane--body">
                              <div class="ds-unified-tab-pane-stack">
                                <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--result-body" role="toolbar" aria-label="结果正文操作">
                                  <h3 class="ds-unified-tab-pane-chrome__title">结果正文</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions" aria-label="正文与编辑器操作">
                                    <div class="analysis-result-preview-modal__toolbar-icons" role="toolbar" aria-label="复制、下载与编辑">
                                      <template v-if="workbenchAnalysisEmbedEditing">
                                        <a-button
                                          type="default"
                                          class="analysis-result-preview-toolbar-outline-btn"
                                          :disabled="!workbenchSelectedAnalysisResultRow"
                                          title="复制当前编辑内容"
                                          aria-label="复制当前编辑内容"
                                          @click="copyWorkbenchAnalysisEmbedPreview"
                                        >复制</a-button>
                                        <a-button
                                          type="default"
                                          class="analysis-result-preview-toolbar-outline-btn"
                                          :disabled="!workbenchSelectedAnalysisResultRow"
                                          title="下载为 Markdown 文件"
                                          aria-label="下载为 Markdown 文件"
                                          @click="downloadWorkbenchAnalysisEmbedPreview"
                                        >下载</a-button>
                                        <a-button type="primary" size="small" @click="saveWorkbenchAnalysisEmbedEdit">保存</a-button>
                                        <a-button size="small" @click="cancelWorkbenchAnalysisEmbedEdit">取消</a-button>
                                      </template>
                                      <template v-else>
                                        <a-button
                                          type="default"
                                          class="analysis-result-preview-toolbar-outline-btn"
                                          :disabled="!workbenchSelectedAnalysisResultRow"
                                          title="复制全文"
                                          aria-label="复制全文"
                                          @click="copyWorkbenchAnalysisEmbedPreview"
                                        >复制</a-button>
                                        <a-button
                                          type="default"
                                          class="analysis-result-preview-toolbar-outline-btn"
                                          :disabled="!workbenchSelectedAnalysisResultRow"
                                          title="下载为 Markdown 文件"
                                          aria-label="下载为 Markdown 文件"
                                          @click="downloadWorkbenchAnalysisEmbedPreview"
                                        >下载</a-button>
                                        <a-button
                                          type="default"
                                          class="analysis-result-preview-toolbar-outline-btn"
                                          :disabled="!workbenchSelectedAnalysisResultRow"
                                          title="编辑正文"
                                          aria-label="编辑正文"
                                          @click="startWorkbenchAnalysisEmbedEdit"
                                        >编辑</a-button>
                                      </template>
                                    </div>
                                  </div>
                                </div>
                                <div class="analysis-result-preview-modal__layout workbench-analysis-embed-wrap">
                                  <div class="preview-modal-content-frame">
                                    <div class="analysis-result-preview-modal__panel analysis-result-preview-modal__panel--editor analysis-result-preview-modal__panel--tab-chrome-only">
                                      <div class="analysis-result-preview-modal__panel-body">
                                        <div
                                          v-if="!workbenchAnalysisEmbedEditing"
                                          class="analysis-result-preview-modal__md"
                                          v-html="workbenchAnalysisPreviewHtml"
                                        ></div>
                                        <a-textarea
                                          v-else
                                          v-model:value="workbenchAnalysisEmbedDraft"
                                          class="analysis-result-preview-modal__editor-textarea"
                                          :rows="22"
                                          placeholder="支持编辑 Markdown 正文，保存后写入当前结果（演示）"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </a-tab-pane>
                          <a-tab-pane key="history" tab="历史版本">
                            <div class="workbench-result-preview-pane workbench-result-preview-pane--history">
                              <div class="skill-unified-tab-version-root">
                                <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--version-row" role="toolbar" aria-label="历史版本">
                                  <h3 class="ds-unified-tab-pane-chrome__title">历史版本</h3>
                                  <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions"></div>
                                </div>
                                <div class="skill-unified-tab-version-root__main skill-wizard-panel">
                                  <template v-if="selectedMaterial && selectedMaterial.type === 'analysis'">
                                    <div
                                      v-if="workbenchAnalysisVersionHistoryOnlyRows.length"
                                      class="skill-version-mgmt-history-section"
                                      role="region"
                                      aria-label="历史版本列表"
                                    >
                                      <h4 class="skill-version-mgmt-history__heading">历史版本 ({{ workbenchAnalysisVersionHistoryOnlyRows.length }})</h4>
                                      <div class="skill-version-mgmt-history">
                                        <div class="ds-l2-table-panel">
                                          <a-table
                                            :columns="workbenchAnalysisVersionMgmtColumns"
                                            :data-source="workbenchAnalysisVersionHistoryOnlyRows"
                                            row-key="key"
                                            size="small"
                                            :pagination="false"
                                            class="skill-library-version-mgmt-table wb-analysis-version-mgmt-table"
                                          >
                                            <template #bodyCell="{ column, record }">
                                              <template v-if="column.key === 'generationDesc'">
                                                <span class="skill-version-table__cell-desc" :title="record.generationDesc">{{ record.generationDesc }}</span>
                                              </template>
                                              <template v-else-if="column.key === 'action'">
                                                <span class="skill-version-mgmt-history__row-actions">
                                                  <a-button type="link" size="small" class="skill-version-table__version-link" @click="openWorkbenchAnalysisHistoryDiff(record, 'embed')">详情</a-button>
                                                  <a-button
                                                    type="link"
                                                    size="small"
                                                    class="skill-version-table__version-link"
                                                    @click="applyWorkbenchAnalysisMarkdownRollbackById(selectedMaterial && selectedMaterial.id, record.markdown)"
                                                  >回退</a-button>
                                                </span>
                                              </template>
                                              <template v-else>{{ record[column.dataIndex] }}</template>
                                            </template>
                                          </a-table>
                                        </div>
                                      </div>
                                    </div>
                                    <a-empty v-else description="暂无历史快照。" />
                                  </template>
                                  <a-empty v-else description="暂无历史版本。" />
                                </div>
                              </div>
                            </div>
                          </a-tab-pane>
                        </a-tabs>
                      </div>
                    </div>
                  </div>
                  <div class="wb-material-status-footer ds-popover-panel__footer">
                    <a-popover
                      v-model:open="workbenchAnalysisStatusPopoverOpenQueued"
                      trigger="click"
                      placement="top"
                    >
                      <template #content>
                        <div class="ds-popover-panel">
                          <div class="ds-popover-panel__title">排队中（{{ workbenchAnalysisStatusSummary.queued }}）</div>
                          <div v-if="workbenchAnalysisQueuedList.length" class="ds-popover-panel--scroll">
                            <div v-for="m in workbenchAnalysisQueuedList" :key="'ar-queued-' + m.id" class="text-secondary">{{ m.title || '未命名结果' }}</div>
                          </div>
                          <div v-else class="text-secondary">暂无结果</div>
                        </div>
                      </template>
                      <button type="button" class="ds-trigger-btn nlm-chat-result-toolbar-btn" @click.stop>
                        <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--queued">
                          <i class="fas fa-clock" aria-hidden="true"></i>
                          <span>排队中 {{ workbenchAnalysisStatusSummary.queued }}</span>
                        </span>
                      </button>
                    </a-popover>
                    <a-popover
                      v-model:open="workbenchAnalysisStatusPopoverOpenParsing"
                      trigger="click"
                      placement="top"
                    >
                      <template #content>
                        <div class="ds-popover-panel">
                          <div class="ds-popover-panel__title">分析中（{{ workbenchAnalysisStatusSummary.parsing }}）</div>
                          <div v-if="workbenchAnalysisParsingList.length" class="ds-popover-panel--scroll">
                            <div v-for="m in workbenchAnalysisParsingList" :key="'ar-parsing-' + m.id" class="text-secondary">{{ m.title || '未命名结果' }}</div>
                          </div>
                          <div v-else class="text-secondary">暂无结果</div>
                        </div>
                      </template>
                      <button type="button" class="ds-trigger-btn nlm-chat-result-toolbar-btn" @click.stop>
                        <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--parsing">
                          <a-spin size="small" class="wb-status-chip__spin" aria-hidden="true" />
                          <span>分析中 {{ workbenchAnalysisStatusSummary.parsing }}</span>
                        </span>
                      </button>
                    </a-popover>
                    <a-popover
                      v-model:open="workbenchAnalysisStatusPopoverOpenFailed"
                      trigger="click"
                      placement="top"
                    >
                      <template #content>
                        <div class="ds-popover-panel">
                          <div class="ds-popover-panel__title">失败（{{ workbenchAnalysisStatusSummary.failed }}）</div>
                          <div v-if="workbenchAnalysisFailedList.length" class="ds-popover-panel--scroll">
                            <div v-for="m in workbenchAnalysisFailedList" :key="'ar-failed-' + m.id" class="text-secondary">{{ m.title || '未命名结果' }}</div>
                          </div>
                          <div v-else class="text-secondary">暂无结果</div>
                        </div>
                      </template>
                      <button type="button" class="ds-trigger-btn nlm-chat-result-toolbar-btn" @click.stop>
                        <span class="ds-trigger-btn__text wb-status-chip wb-status-chip--failed">
                          <i class="fas fa-circle-xmark" aria-hidden="true"></i>
                          <span>失败 {{ workbenchAnalysisStatusSummary.failed }}</span>
                        </span>
                      </button>
                    </a-popover>
                  </div>
                </div>
              </div>
            </aside>
          </div>
          <a-modal
            v-model:open="saveResultModalVisible"
            title="保存结果"
            width="560"
            wrapClassName="modal-w-560"
            @cancel="closeSaveResultModal"
            @ok="confirmSaveResultModal"
            ok-text="保存"
            cancel-text="取消"
          >
            <div style="display:flex;flex-direction:column;gap:var(--ds-space-sm);">
              <a-form layout="vertical">
                <a-form-item label="结果名称" required>
                  <a-input
                    v-model:value="saveResultForm.name"
                    placeholder="例如：合同与发票一致性检查结果"
                    allow-clear
                    :maxlength="60"
                  />
                </a-form-item>
              </a-form>
            </div>
          </a-modal>
          <a-modal
            v-model:open="summaryTaskResultModalVisible"
            title="技能配置确认"
            width="1200"
            wrapClassName="modal-w-920"
            @cancel="closeSummaryTaskResultModal"
            @ok="confirmSummaryTaskResultModal"
            ok-text="确认保存为工作台级技能"
            cancel-text="取消"
          >
            <div class="analysis-template-config-modal-body">
              <div class="analysis-template-config-card">
                <div class="skill-object-field-group">
                  <div class="skill-object-field-label">技能名称<span class="skill-required">*</span></div>
                  <div class="ds-input-ai-polish-wrap">
                    <div
                      class="ds-input-ai-polish-input-shell ds-input-ai-polish-input-shell--with-corner ds-input-ai-polish-input-shell--affix"
                      :class="{ 'is-polishing': freeAuditAiPolishKey === 'summary:name' }"
                    >
                      <a-input v-model:value="summaryTaskResultForm.name" placeholder="请输入技能名称" allow-clear />
                      <div class="ds-input-ai-polish-corner">
                        <span v-show="freeAuditAiPolishKey === 'summary:name'" class="ds-input-ai-polish-status">润色中...</span>
                        <a-button type="text" class="ds-icon-btn ds-input-ai-polish-undo-btn" aria-label="回退" title="回退到润色前" :disabled="freeAuditPolishUndoDisabled('summary:name')" @click.stop="undoSummaryTaskName">
                          <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                        </a-button>
                        <a-button type="text" class="ds-icon-btn ds-input-ai-polish-btn" aria-label="智能润色" title="智能润色" :disabled="!!freeAuditAiPolishKey" @click.stop="demoAiPolishSummaryTaskName">
                          <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                        </a-button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="analysis-template-config-grid">
                <div class="analysis-template-config-card">
                  <div class="skill-config-section-head">
                    <div class="skill-config-section-title-cluster">
                      <h3 class="skill-config-col-title">审计资料</h3>
                    </div>
                    <a-button type="primary" size="small" ghost @click="addSummaryTemplateExtractionRule"><i class="fas fa-plus" style="margin-right: var(--ds-space-xxs);"></i>添加</a-button>
                  </div>
                  <div class="skill-object-list-wrap skill-object-list-wrap--config">
                    <div
                      v-for="(er, idx) in (summaryTaskResultForm.extractionRules || [])"
                      :key="er.id"
                      class="skill-object-row"
                      :class="{ 'is-expanded': summaryTaskResultExpandedRuleId === er.id }"
                    >
                      <div class="skill-object-row-main" @click="toggleSummaryTemplateRuleExpand(er.id)">
                        <span class="skill-object-idx">{{ idx + 1 }}</span>
                        <div class="skill-object-row-text">
                          <div class="skill-object-title-line">{{ (er.title || '').trim() || '（未填写资料说明）' }}</div>
                          <div class="skill-object-body-preview">{{ (er.body || '').trim() || '（未填写抽取或核对字段）' }}</div>
                          <div class="ds-text-micro-secondary" style="margin-top: var(--ds-space-xxs);">已匹配 {{ summaryRuleMatchedMaterialCount(er) }} 份文档</div>
                        </div>
                        <div class="skill-object-row-actions">
                          <a-button
                            type="text"
                            danger
                            size="small"
                            shape="circle"
                            class="ds-icon-btn ds-icon-btn--standard ds-icon-btn--danger skill-object-row-delete-btn"
                            aria-label="删除该分析对象"
                            title="删除"
                            @click.stop="removeSummaryTemplateExtractionRule(idx)"
                            :disabled="(summaryTaskResultForm.extractionRules || []).length <= 1"
                          >
                            <template #icon><i class="fas fa-xmark" aria-hidden="true"></i></template>
                          </a-button>
                        </div>
                      </div>
                      <div v-show="summaryTaskResultExpandedRuleId === er.id" class="skill-object-row-detail" @click.stop>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label-row">
                            <div class="skill-object-field-label skill-object-field-label--inline">请输入资料类型（可输入多个）<span class="skill-required">*</span></div>
                            <div class="skill-object-field-polish">
                              <span v-show="freeAuditAiPolishKey === 'summary-er:' + er.id + ':title'" class="ds-input-ai-polish-status">润色中...</span>
                              <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="freeAuditPolishUndoDisabled('summary-er:' + er.id + ':title')" @click.stop="undoSummaryErField(er, 'title')">
                                <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                              </button>
                              <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="!!freeAuditAiPolishKey" @click.stop="demoAiPolishSummaryErField(er, 'title')">
                                <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-btn__label">润色</span>
                              </button>
                            </div>
                          </div>
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'summary-er:' + er.id + ':title' }">
                              <a-textarea
                                v-model:value="er.title"
                                :rows="2"
                                :placeholder="skillObjectMaterialTypePlaceholder"
                              />
                            </div>
                          </div>
                        </div>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label-row">
                            <div class="skill-object-field-label skill-object-field-label--inline">请详细描述或罗列该审计资料中需要审计的具体内容<span class="skill-required">*</span></div>
                            <div class="skill-object-field-polish">
                              <span v-show="freeAuditAiPolishKey === 'summary-er:' + er.id + ':body'" class="ds-input-ai-polish-status">润色中...</span>
                              <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="freeAuditPolishUndoDisabled('summary-er:' + er.id + ':body')" @click.stop="undoSummaryErField(er, 'body')">
                                <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                              </button>
                              <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="!!freeAuditAiPolishKey" @click.stop="demoAiPolishSummaryErField(er, 'body')">
                                <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-btn__label">润色</span>
                              </button>
                            </div>
                          </div>
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'summary-er:' + er.id + ':body' }">
                              <a-textarea v-model:value="er.body" placeholder="列出后续比对、测算或下结论所依赖的字段及口径（尽量与资料表述一致）。示例：含税金额、业务日期、对方名称、单据编号；涉及明细时的维度字段（如部门、项目、费用类型等）。" :rows="4" />
                            </div>
                          </div>
                        </div>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label">匹配文档（可多选）<span class="skill-required">*</span></div>
                          <a-select
                            v-model:value="er.materialIds"
                            mode="multiple"
                            allow-clear
                            size="small"
                            :max-tag-count="3"
                            class="template-material-multi-select"
                            placeholder="请选择要参与该分析对象的资料"
                            :options="workbenchMaterialSelectOptions"
                          />
                          <div class="ds-text-micro-secondary" style="margin-top: var(--ds-space-xs);">当前已匹配 {{ summaryRuleMatchedMaterialCount(er) }} 份文档</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="analysis-template-config-card">
                  <div class="skill-config-section-head">
                    <div class="skill-config-section-title-cluster">
                      <h3 class="skill-config-col-title">审计思路</h3>
                    </div>
                    <div class="skill-object-field-polish">
                      <span v-show="freeAuditAiPolishKey === 'summary:analysisRule'" class="ds-input-ai-polish-status">润色中...</span>
                      <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="freeAuditPolishUndoDisabled('summary:analysisRule')" @click.stop="undoSummaryTaskAnalysisRule">
                        <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                        <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                      </button>
                      <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="!!freeAuditAiPolishKey" @click.stop="demoAiPolishSummaryTaskAnalysisRule">
                        <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                        <span class="ds-input-ai-polish-btn__label">润色</span>
                      </button>
                    </div>
                  </div>
                  <div class="ds-input-ai-polish-wrap">
                    <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'summary:analysisRule' }">
                      <a-textarea v-model:value="summaryTaskResultForm.analysisRule" :rows="16" :placeholder="getSkillAnalysisRulePlaceholder()" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </a-modal>
          <a-modal
            v-model:open="wbProjectSkillCreateBasicModalOpen"
            title="创建技能"
            width="560"
            centered
            :maskClosable="false"
            @cancel="closeWbProjectSkillCreateBasicModal"
          >
            <a-form layout="vertical">
              <a-form-item label="技能名称" required>
                <a-input
                  v-model:value="wbProjectSkillCreateBasicForm.name"
                  placeholder="请输入技能名称"
                  allow-clear
                  :maxlength="60"
                />
              </a-form-item>
              <a-form-item label="技能描述">
                <a-textarea
                  v-model:value="wbProjectSkillCreateBasicForm.description"
                  placeholder="选填。描述该技能的用途与适用场景"
                  :rows="3"
                  :maxlength="300"
                  show-count
                />
              </a-form-item>
              <a-form-item label="标签" style="margin-bottom: 0;">
                <a-select
                  v-model:value="wbProjectSkillCreateBasicForm.tags"
                  mode="tags"
                  placeholder="回车添加标签，如：函证、凭证核对"
                  style="width: 100%"
                />
              </a-form-item>
            </a-form>
            <template #footer>
              <a-button @click="closeWbProjectSkillCreateBasicModal">取消</a-button>
              <a-button type="primary" :loading="wbProjectSkillCreateBasicSubmitting" @click="submitWbProjectSkillCreateBasic">提交并继续配置</a-button>
            </template>
          </a-modal>
          <a-modal
                v-model:open="wbProjectSkillDetailModalOpen"
                width="1040"
                wrapClassName="modal-skill-config modal-project-skill-config"
                centered
                :footer="null"
                :maskClosable="false"
                @cancel="() => closeWbProjectSkillDetailModal(false)"
              >
                <template #title>
                  <div class="skill-modal-config-title-row">
                    <div class="skill-modal-config-title-main">
                      <span class="skill-modal-config-title-text">{{ wbProjectSkillDetailModalTitle }}</span>
                    </div>
                  </div>
                </template>
                <div v-if="wbDetailSelectedSkill" class="tc-skill-modal-body tc-skill-modal-body--unified">
                  <a-tabs :activeKey="wbProjectSkillDetailActiveTab" class="skill-unified-modal-tabs" tab-position="left" @update:activeKey="onWbProjectSkillTabUpdate">
                    <a-tab-pane key="basic" tab="基本信息">
                      <div class="ds-unified-tab-pane-stack">
                        <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息操作">
                          <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                          <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions">
                            <template v-if="!wbProjectSkillDetailReadOnly">
                              <a-button v-if="!wbProjectSkillBasicPaneEditing" type="primary" @click="startWbProjectSkillBasicPaneEdit">编辑</a-button>
                              <template v-else>
                                <a-button @click="cancelWbProjectSkillBasicPaneEdit">取消</a-button>
                                <a-button type="primary" @click="saveWbProjectSkillBasicPane">保存</a-button>
                              </template>
                            </template>
                          </div>
                        </div>
                        <a-form layout="vertical" class="skill-modal-form skill-wizard-panel skill-unified-tab-basic">
                          <a-form-item label="名称" required>
                            <a-input
                              v-model:value="wbProjectSkillForm.name"
                              placeholder="如：三公经费异常波动扫描"
                              allow-clear
                              :disabled="wbProjectSkillBasicFieldsLocked"
                            />
                          </a-form-item>
                          <a-form-item label="简介">
                            <a-textarea
                              v-model:value="wbProjectSkillForm.description"
                              placeholder="用途示例：系统自动比对合同与发票金额及时间逻辑，输出异常清单并提示优先核查项。"
                              :rows="2"
                              :disabled="wbProjectSkillBasicFieldsLocked"
                            />
                          </a-form-item>
                          <a-form-item label="标签" style="margin-bottom: 0;">
                            <a-select
                              v-model:value="wbProjectSkillForm.tags"
                              mode="tags"
                              placeholder="回车添加，如：财务、合规"
                              style="width: 100%"
                              :disabled="wbProjectSkillBasicFieldsLocked"
                            />
                          </a-form-item>
                        </a-form>
                      </div>
                    </a-tab-pane>
                    <a-tab-pane key="config" tab="技能配置">
                  <div class="ds-unified-tab-pane-stack">
                    <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="技能配置操作">
                      <h3 class="ds-unified-tab-pane-chrome__title">技能配置</h3>
                      <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions">
                        <template v-if="!wbProjectSkillDetailReadOnly">
                          <a-button v-if="!wbProjectSkillConfigPaneEditing" type="default" @click="onWbProjectSkillConfigSaveMenuClick({ key: 'publish-new' })">快照</a-button>
                          <a-button v-if="!wbProjectSkillConfigPaneEditing" type="primary" @click="startWbProjectSkillConfigPaneEdit">编辑</a-button>
                          <template v-else>
                            <a-button @click="cancelWbProjectSkillConfigPaneEdit">取消</a-button>
                            <a-button type="primary" @click="saveWbProjectSkillConfigPane">保存</a-button>
                          </template>
                        </template>
                      </div>
                    </div>
                  <div class="skill-config-master-detail">
                    <aside class="skill-config-nav-pane" aria-label="技能配置结构">
                      <div class="skill-config-nav-tree">
                        <div class="skill-config-nav-tree-head skill-config-nav-tree-head--with-actions">
                          <span>可配置文件</span>
                          <a-dropdown
                            :trigger="['hover', 'click']"
                            placement="bottomRight"
                            overlayClassName="skill-config-add-file-dropdown"
                          >
                            <a-button
                              type="text"
                              size="small"
                              class="ds-icon-btn ds-icon-btn--standard skill-config-nav-add-btn"
                              aria-label="添加文件或文件夹"
                              :disabled="wbProjectSkillConfigTabLocked"
                              @click.stop
                            >
                              <i class="fas fa-plus" aria-hidden="true"></i>
                            </a-button>
                            <template #overlay>
                              <a-menu @click="onWbProjectSkillConfigAddMenuClick">
                                <a-menu-item key="md">Markdown（.md）</a-menu-item>
                                <a-sub-menu key="sub-code" title="代码文件">
                                  <a-menu-item key="code:python">Python</a-menu-item>
                                  <a-menu-item key="code:javascript">JavaScript</a-menu-item>
                                  <a-menu-item key="code:typescript">TypeScript</a-menu-item>
                                  <a-menu-item key="code:shell">Shell</a-menu-item>
                                </a-sub-menu>
                                <a-menu-item key="folder">文件夹</a-menu-item>
                              </a-menu>
                            </template>
                          </a-dropdown>
                        </div>
                        <div class="skill-config-nav-tree-body">
                          <a-tree
                            class="skill-config-ant-tree"
                            block-node
                            show-line
                            :tree-data="wbProjectSkillConfigTreeData"
                            v-model:expanded-keys="wbProjectSkillConfigTreeExpandedKeys"
                            :selected-keys="wbProjectSkillConfigTreeSelectedKeys"
                            :draggable="wbProjectSkillConfigTreeNodeDraggable"
                            @select="onWbProjectSkillConfigTreeSelect"
                            @drop="onWbProjectSkillConfigTreeDrop"
                          >
                            <template #title="{ key, title }">
                              <span class="skill-config-tree-title-row">
                                <span
                                  class="skill-config-tree-title-row__text"
                                  :class="{ 'skill-config-tree-title-row__text--ellipsis': key !== 'rule' }"
                                >{{ title }}</span>
                                <a-button
                                  v-if="wbProjectSkillConfigTreeCanDeleteKey(key) && !wbProjectSkillConfigTabLocked"
                                  type="text"
                                  danger
                                  size="small"
                                  class="ds-icon-btn ds-icon-btn--xs skill-config-tree-title-row__del"
                                  aria-label="删除该项"
                                  @click.stop="removeWbProjectSkillConfigTreeNode(key)"
                                >
                                  <i class="fas fa-xmark" aria-hidden="true"></i>
                                </a-button>
                              </span>
                            </template>
                          </a-tree>
                        </div>
                      </div>
                    </aside>
                    <div class="skill-config-detail-pane">
                      <div v-if="wbProjectSkillConfigNavKey === 'rule'" class="skill-config-detail-inner">
                        <div class="skill-config-applicable-scenario-block">
                          <div class="skill-config-section-head">
                            <div class="skill-config-section-title-cluster">
                              <h3 class="skill-config-col-title">适用场景</h3>
                            </div>
                          </div>
                          <a-textarea
                            v-model:value="wbDetailSelectedSkill.applicableScenario"
                            :rows="3"
                            :disabled="wbProjectSkillConfigTabLocked"
                            placeholder="选填。与「基本信息」中技能描述互补：此处写执行侧触发条件，如资料类型、业务阶段、关键词、前置对象等。"
                            @blur="scheduleWbProjectSkillDetailSync"
                          />
                        </div>
                        <div class="skill-config-section-head">
                          <div class="skill-config-section-title-cluster">
                            <h3 class="skill-config-col-title">审计思路</h3>
                          </div>
                          <div v-if="!wbProjectSkillConfigTabLocked" class="skill-object-field-polish">
                            <span v-show="freeAuditAiPolishKey === 'wb-analysisRule'" class="ds-input-ai-polish-status">润色中...</span>
                            <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="wbFreeAuditPolishUndoDisabled('wb-analysisRule')" @click.stop="undoWbAnalysisRule">
                              <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                              <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                            </button>
                            <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="!!freeAuditAiPolishKey" @click.stop="demoAiPolishWbAnalysisRule">
                              <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                              <span class="ds-input-ai-polish-btn__label">润色</span>
                            </button>
                          </div>
                        </div>
                        <div class="skill-rules-editor">
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'wb-analysisRule' }">
                              <textarea
                                class="skill-rules-editor-textarea"
                                v-model="wbDetailSelectedSkill.analysisRule"
                                :disabled="wbProjectSkillConfigTabLocked"
                                :placeholder="getSkillAnalysisRulePlaceholder()"
                                @blur="scheduleWbProjectSkillDetailSync"
                              ></textarea>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div v-else-if="wbProjectSkillConfigSelectedFolder" class="skill-config-detail-inner">
                        <div class="skill-config-section-head">
                          <div class="skill-config-section-title-cluster">
                            <h3 class="skill-config-col-title">文件夹</h3>
                          </div>
                        </div>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label skill-object-field-label--inline">文件夹名称<span class="skill-required">*</span></div>
                          <a-input
                            v-model:value="wbProjectSkillConfigSelectedFolder.name"
                            placeholder="例如：抽取脚本、辅助说明"
                            :disabled="wbProjectSkillConfigTabLocked"
                            @blur="scheduleWbProjectSkillDetailSync"
                          />
                        </div>
                      </div>
                      <div v-else-if="wbProjectSkillConfigSelectedFile" class="skill-config-detail-inner">
                        <div class="skill-config-section-head">
                          <div class="skill-config-section-title-cluster">
                            <h3 class="skill-config-col-title">配置文件</h3>
                            <UiTagSm
                              v-if="wbProjectSkillConfigSelectedFile.fileKind === 'md'"
                              class="ds-tag--tone-primary"
                            >Markdown</UiTagSm>
                            <UiTagSm v-else>{{ wbProjectSkillConfigSelectedFileCodeLabel }}</UiTagSm>
                          </div>
                        </div>
                        <a-alert
                          v-if="wbProjectSkillConfigDuplicatePaths.length"
                          type="warning"
                          show-icon
                          :message="'文件名路径重复：' + wbProjectSkillConfigDuplicatePaths.join('、')"
                          style="margin-bottom: var(--ds-space-sm);"
                        />
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label-row">
                            <div class="skill-object-field-label skill-object-field-label--inline">文件名<span class="skill-required">*</span></div>
                            <div class="skill-object-field-polish">
                              <span v-show="freeAuditAiPolishKey === 'wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':fn'" class="ds-input-ai-polish-status">润色中...</span>
                              <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="wbFreeAuditPolishUndoDisabled('wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':fn')" @click.stop="undoWbSkillFileField(wbProjectSkillConfigSelectedFile, 'filename')">
                                <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                              </button>
                              <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="wbProjectSkillConfigTabLocked || !!freeAuditAiPolishKey" @click.stop="demoAiPolishWbSkillFileField(wbProjectSkillConfigSelectedFile, 'filename')">
                                <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-btn__label">润色</span>
                              </button>
                            </div>
                          </div>
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':fn' }">
                              <a-input v-model:value="wbProjectSkillConfigSelectedFile.filename" :disabled="wbProjectSkillConfigTabLocked" placeholder="例如：notes.md、extract.py" @blur="scheduleWbProjectSkillDetailSync" />
                            </div>
                          </div>
                        </div>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label-row">
                            <div class="skill-object-field-label skill-object-field-label--inline">具体内容<span class="skill-required">*</span></div>
                            <div class="skill-object-field-polish">
                              <span v-show="freeAuditAiPolishKey === 'wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':ct'" class="ds-input-ai-polish-status">润色中...</span>
                              <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="wbFreeAuditPolishUndoDisabled('wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':ct')" @click.stop="undoWbSkillFileField(wbProjectSkillConfigSelectedFile, 'content')">
                                <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                              </button>
                              <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="wbProjectSkillConfigTabLocked || !!freeAuditAiPolishKey" @click.stop="demoAiPolishWbSkillFileField(wbProjectSkillConfigSelectedFile, 'content')">
                                <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-btn__label">润色</span>
                              </button>
                            </div>
                          </div>
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': freeAuditAiPolishKey === 'wb-sf:' + wbProjectSkillConfigSelectedFile.id + ':ct' }">
                              <textarea
                                v-if="wbProjectSkillConfigSelectedFile.fileKind === 'md'"
                                class="skill-rules-editor-textarea"
                                v-model="wbProjectSkillConfigSelectedFile.content"
                                :disabled="wbProjectSkillConfigTabLocked"
                                placeholder="写入该文件的说明、抽取口径或提示词片段等。"
                                rows="14"
                                @blur="scheduleWbProjectSkillDetailSync"
                              ></textarea>
                              <textarea
                                v-else
                                class="skill-rules-editor-textarea ds-font-mono"
                                v-model="wbProjectSkillConfigSelectedFile.content"
                                :disabled="wbProjectSkillConfigTabLocked"
                                placeholder="代码或脚本内容（演示为纯文本编辑区）。"
                                rows="14"
                                @blur="scheduleWbProjectSkillDetailSync"
                              ></textarea>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  </div>
                    </a-tab-pane>
                    <a-tab-pane key="resource" tab="关联资源">
                      <div class="ds-unified-tab-pane-stack">
                        <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="关联资源操作">
                          <h3 class="ds-unified-tab-pane-chrome__title">关联资源</h3>
                          <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions">
                            <template v-if="!wbProjectSkillDetailReadOnly">
                              <a-button v-if="!wbProjectSkillResourcePaneEditing" type="primary" @click="startWbProjectSkillResourcePaneEdit">调整</a-button>
                              <template v-else>
                                <a-button @click="cancelWbProjectSkillResourcePaneEdit">取消</a-button>
                                <a-button type="primary" @click="saveWbProjectSkillResourcePane">保存</a-button>
                              </template>
                            </template>
                          </div>
                        </div>
                        <div class="project-skill-resource-pane">
                          <a-form layout="vertical">
                            <a-form-item :label="'已匹配资料（' + getWbSkillLinkedResourceIds(wbDetailSelectedSkill).length + '）'">
                              <a-select
                                :value="getWbSkillLinkedResourceIds(wbDetailSelectedSkill)"
                                mode="multiple"
                                :options="wbProjectSkillLinkedResourceSelectOptions"
                                placeholder="请选择关联资源"
                                style="width: 100%;"
                                :disabled="wbProjectSkillResourceTabLocked"
                                @update:value="(vals) => { wbDetailSelectedSkill.linkedResourceIds = (vals || []).map((id) => String(id)); scheduleWbProjectSkillDetailSync(); }"
                              />
                            </a-form-item>
                          </a-form>
                        </div>
                      </div>
                    </a-tab-pane>
                  </a-tabs>
                </div>
                <div v-else style="padding: var(--ds-space-m) 0;">
                  <a-empty description="未找到技能，请关闭后重试。" />
                </div>
              </a-modal>
          <a-modal
            v-model:open="wbMaterialMetaEditVisible"
            title="编辑资料"
            width="520"
            wrapClassName="modal-w-560"
            :maskClosable="false"
            @cancel="closeWorkbenchProjectMaterialMetaEdit"
          >
            <a-form layout="vertical">
              <a-form-item label="资料名称">
                <a-input v-model:value="wbMaterialMetaEditForm.name" placeholder="请输入资料名称" allow-clear />
              </a-form-item>
              <a-form-item label="标签" style="margin-bottom: 0;">
                <a-select v-model:value="wbMaterialMetaEditForm.tags" mode="tags" placeholder="回车添加标签" style="width: 100%;" />
              </a-form-item>
            </a-form>
            <template #footer>
              <a-button @click="closeWorkbenchProjectMaterialMetaEdit">取消</a-button>
              <a-button type="primary" @click="confirmWorkbenchProjectMaterialMetaEdit">保存</a-button>
            </template>
          </a-modal>
          <a-modal
            v-model:open="wbAnalysisResultMetaEditVisible"
            title="编辑分析结果"
            width="520"
            wrapClassName="modal-w-560"
            :maskClosable="false"
            @cancel="closeWorkbenchAnalysisResultMetaEdit"
          >
            <a-form layout="vertical">
              <a-form-item label="结果名称">
                <a-input v-model:value="wbAnalysisResultMetaEditForm.name" placeholder="请输入结果名称" allow-clear />
              </a-form-item>
              <a-form-item label="标签" style="margin-bottom: 0;">
                <a-select v-model:value="wbAnalysisResultMetaEditForm.tags" mode="tags" placeholder="回车添加标签" style="width: 100%;" />
              </a-form-item>
            </a-form>
            <template #footer>
              <a-button @click="closeWorkbenchAnalysisResultMetaEdit">取消</a-button>
              <a-button type="primary" @click="confirmWorkbenchAnalysisResultMetaEdit">保存</a-button>
            </template>
          </a-modal>
          <a-modal
            v-model:open="wbAnalysisModalOpen"
            width="760"
            wrapClassName="modal-w-760 analysis-result-preview-modal analysis-result-preview-modal--unified-tabs"
            centered
            :footer="null"
            @cancel="closeWbAnalysisModal"
          >
            <template #title>
              <div class="preview-modal-title-row">
                <span class="preview-modal-title-row__text">{{ (wbAnalysisModalRecord && wbAnalysisModalRecord.name) || '结果预览' }}</span>
              </div>
            </template>
            <div class="preview-modal-body-scroll">
              <div v-if="wbAnalysisModalRecord" class="tc-skill-modal-body tc-skill-modal-body--unified analysis-result-unified-body">
                <a-tabs
                  :activeKey="wbAnalysisModalActiveTab"
                  class="skill-unified-modal-tabs analysis-result-unified-tabs"
                  tab-position="left"
                  aria-label="结果预览：结果正文或版本管理"
                  @update:activeKey="onWbAnalysisModalTabUpdate"
                >
                  <a-tab-pane key="body" tab="结果正文">
                    <div class="ds-unified-tab-pane-stack">
                      <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--result-body" role="toolbar" aria-label="结果正文操作">
                        <h3 class="ds-unified-tab-pane-chrome__title">结果正文</h3>
                        <div class="ds-unified-tab-pane-chrome__mid">
                          <span class="text-secondary">{{ wbAnalysisModalEmbedEditing ? '内容编辑' : '内容预览' }}</span>
                        </div>
                        <div class="ds-unified-tab-pane-chrome__actions" aria-label="正文与编辑器操作">
                          <div class="analysis-result-preview-modal__toolbar-icons" role="toolbar" aria-label="复制、下载与编辑">
                            <template v-if="wbAnalysisModalEmbedEditing">
                              <a-button
                                type="default"
                                class="analysis-result-preview-toolbar-outline-btn"
                                :disabled="!wbAnalysisModalRecord"
                                title="复制当前编辑内容"
                                aria-label="复制当前编辑内容"
                                @click="copyWbAnalysisModalEmbedPreview"
                              >复制</a-button>
                              <a-button
                                type="default"
                                class="analysis-result-preview-toolbar-outline-btn"
                                :disabled="!wbAnalysisModalRecord"
                                title="下载为 Markdown 文件"
                                aria-label="下载为 Markdown 文件"
                                @click="downloadWbAnalysisModalEmbedPreview"
                              >下载</a-button>
                              <a-button type="primary" size="small" @click="saveWbAnalysisModalEmbedEdit">保存</a-button>
                              <a-button size="small" @click="cancelWbAnalysisModalEmbedEdit">取消</a-button>
                            </template>
                            <template v-else>
                              <a-button
                                type="default"
                                class="analysis-result-preview-toolbar-outline-btn"
                                :disabled="!wbAnalysisModalRecord"
                                title="复制全文"
                                aria-label="复制全文"
                                @click="copyWbAnalysisModalEmbedPreview"
                              >复制</a-button>
                              <a-button
                                type="default"
                                class="analysis-result-preview-toolbar-outline-btn"
                                :disabled="!wbAnalysisModalRecord"
                                title="下载为 Markdown 文件"
                                aria-label="下载为 Markdown 文件"
                                @click="downloadWbAnalysisModalEmbedPreview"
                              >下载</a-button>
                              <a-button
                                type="default"
                                class="analysis-result-preview-toolbar-outline-btn"
                                :disabled="!wbAnalysisModalRecord"
                                title="编辑正文"
                                aria-label="编辑正文"
                                @click="startWbAnalysisModalEmbedEdit"
                              >编辑</a-button>
                            </template>
                          </div>
                        </div>
                      </div>
                      <div class="analysis-result-preview-modal__layout workbench-analysis-embed-wrap">
                        <div class="preview-modal-content-frame">
                          <div class="analysis-result-preview-modal__panel analysis-result-preview-modal__panel--editor analysis-result-preview-modal__panel--tab-chrome-only">
                            <div class="analysis-result-preview-modal__panel-body">
                              <div
                                v-if="!wbAnalysisModalEmbedEditing"
                                class="analysis-result-preview-modal__md"
                                v-html="wbAnalysisModalPreviewHtml"
                              ></div>
                              <a-textarea
                                v-else
                                v-model:value="wbAnalysisModalEmbedDraft"
                                class="analysis-result-preview-modal__editor-textarea"
                                :rows="22"
                                placeholder="支持编辑 Markdown 正文，保存后写入当前结果（演示）"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </a-tab-pane>
                  <a-tab-pane key="history" tab="历史版本">
                    <div class="skill-unified-tab-version-root">
                      <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--version-row" role="toolbar" aria-label="历史版本">
                        <h3 class="ds-unified-tab-pane-chrome__title">历史版本</h3>
                        <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions"></div>
                      </div>
                      <div class="skill-unified-tab-version-root__main skill-wizard-panel">
                        <template v-if="wbAnalysisModalRecord">
                          <div
                            v-if="wbAnalysisModalVersionHistoryOnlyRows.length"
                            class="skill-version-mgmt-history-section"
                            role="region"
                            aria-label="历史版本列表"
                          >
                            <h4 class="skill-version-mgmt-history__heading">历史版本 ({{ wbAnalysisModalVersionHistoryOnlyRows.length }})</h4>
                            <div class="skill-version-mgmt-history">
                              <div class="ds-l2-table-panel">
                                <a-table
                                  :columns="workbenchAnalysisVersionMgmtColumns"
                                  :data-source="wbAnalysisModalVersionHistoryOnlyRows"
                                  row-key="key"
                                  size="small"
                                  :pagination="false"
                                  class="skill-library-version-mgmt-table wb-analysis-version-mgmt-table"
                                >
                                  <template #bodyCell="{ column, record }">
                                    <template v-if="column.key === 'generationDesc'">
                                      <span class="skill-version-table__cell-desc" :title="record.generationDesc">{{ record.generationDesc }}</span>
                                    </template>
                                    <template v-else-if="column.key === 'action'">
                                      <span class="skill-version-mgmt-history__row-actions">
                                        <a-button type="link" size="small" class="skill-version-table__version-link" @click="openWorkbenchAnalysisHistoryDiff(record, 'modal')">详情</a-button>
                                        <a-button
                                          type="link"
                                          size="small"
                                          class="skill-version-table__version-link"
                                          @click="applyWorkbenchAnalysisMarkdownRollbackById(wbAnalysisModalRecord && wbAnalysisModalRecord.id, record.markdown)"
                                        >回退</a-button>
                                      </span>
                                    </template>
                                    <template v-else>{{ record[column.dataIndex] }}</template>
                                  </template>
                                </a-table>
                              </div>
                            </div>
                          </div>
                          <a-empty v-else description="暂无历史快照。" />
                        </template>
                        <a-empty v-else description="暂无历史版本。" />
                      </div>
                    </div>
                  </a-tab-pane>
                </a-tabs>
              </div>
            </div>
          </a-modal>
          <a-modal
            v-model:open="wbAnalysisHistoryDiffOpen"
            width="800"
            wrapClassName="modal-w-800"
            title="与当前版本对比"
            :footer="null"
            destroy-on-close
            @cancel="closeWorkbenchAnalysisHistoryDiff"
          >
            <div class="nlm-tool-diff-md" role="region" aria-label="Markdown 行级差异">
              <div v-if="!wbAnalysisHistoryDiffLines.length" class="text-secondary">无差异或内容为空。</div>
              <div
                v-for="(ln, di) in wbAnalysisHistoryDiffLines"
                :key="'wb-ar-diff-' + di"
                class="nlm-tool-diff-line"
                :class="toolDiffLineClass(ln)"
              ><span class="nlm-tool-diff-line__gutter">{{ di + 1 }}</span><span class="nlm-tool-diff-line__code">{{ ln }}</span></div>
              <div v-if="wbAnalysisHistoryDiffTruncated" class="text-secondary" style="margin-top:8px;">以下差异已省略展示（演示上限）。</div>
            </div>
          </a-modal>
          <a-modal
            v-model:open="wbAnalysisVersionDetailVisible"
            title="版本详情"
            width="720"
            wrapClassName="modal-w-720 analysis-result-preview-modal"
            centered
            :footer="null"
            destroy-on-close
            @cancel="closeWbAnalysisVersionDetail"
          >
            <div class="analysis-result-preview-modal__md" v-html="wbAnalysisVersionDetailHtml"></div>
          </a-modal>
          <a-modal
            v-model:open="analysisToolPreviewModalOpen"
            width="760"
            wrapClassName="modal-w-720 analysis-result-preview-modal"
            centered
            :footer="null"
            @cancel="closeAnalysisToolPreviewModal"
          >
            <template #title>
              <div class="preview-modal-title-row">
                <span class="preview-modal-title-row__text">{{ (analysisToolPreviewRecord && analysisToolPreviewRecord.fileName) || '中间结果预览' }}</span>
              </div>
            </template>
            <div class="preview-modal-body-scroll">
              <div v-if="analysisToolPreviewRecord" class="analysis-result-preview-modal__layout workbench-analysis-embed-wrap">
                <div class="preview-modal-content-frame">
                  <div class="analysis-result-preview-modal__panel analysis-result-preview-modal__panel--editor">
                    <div class="analysis-result-preview-modal__panel-hd analysis-result-preview-modal__panel-hd--sub analysis-result-preview-modal__panel-hd--editor-toolbar analysis-result-preview-modal__panel-hd--sticky">
                      <span class="analysis-result-preview-modal__panel-hd-label">CSV 预览</span>
                      <div class="analysis-result-preview-modal__panel-hd-actions" aria-label="CSV预览操作">
                        <div class="analysis-result-preview-modal__toolbar-icons" role="toolbar" aria-label="复制、下载与保存">
                          <a-button
                            type="default"
                            class="analysis-result-preview-toolbar-outline-btn"
                            :disabled="!analysisToolPreviewRecord"
                            title="复制 CSV"
                            aria-label="复制 CSV"
                            @click="copyAnalysisToolPreviewJson"
                          >复制</a-button>
                          <a-button
                            type="default"
                            class="analysis-result-preview-toolbar-outline-btn"
                            :disabled="!analysisToolPreviewRecord"
                            title="下载 CSV"
                            aria-label="下载 CSV"
                            @click="downloadAnalysisToolPreviewJson"
                          >下载</a-button>
                          <a-button
                            type="default"
                            class="analysis-result-preview-toolbar-outline-btn"
                            :disabled="!analysisToolPreviewRecord"
                            title="保存"
                            aria-label="保存"
                            @click="openSaveResultModal(null, { type: 'analysisTool', record: analysisToolPreviewRecord })"
                          >保存</a-button>
                        </div>
                      </div>
                    </div>
                    <div class="analysis-result-preview-modal__panel-body">
                      <div class="nlm-tool-analysis-preview-shell">
                        <pre class="nlm-tool-analysis-json">{{ analysisToolPreviewCsv }}</pre>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </a-modal>
            </div>
          </a-layout></a-layout-content></a-layout>`,
      data() {
        return {
          freeAuditAiPolishKey: '',
          freeAuditPolishUndo: {},
          materials: [],
          materialSearchQuery: '',
          workbenchAnalysisSearchQuery: '',
          workbenchMaterialSortBy: 'uploaded_desc',
          workbenchMaterialTagKeys: [],
          workbenchMaterialTagMatchMode: 'any',
          workbenchMaterialTagSearchQuery: '',
          workbenchMaterialFilterPopoverOpen: false,
          workbenchMaterialStatusPopoverOpenQueued: false,
          workbenchMaterialStatusPopoverOpenParsing: false,
          workbenchMaterialStatusPopoverOpenFailed: false,
          workbenchAnalysisStatusPopoverOpenQueued: false,
          workbenchAnalysisStatusPopoverOpenParsing: false,
          workbenchAnalysisStatusPopoverOpenFailed: false,
          wbSkillGeneratingPopoverOpen: false,
          workbenchProjectId: null,
          /** 点击「刷新」时递增，驱动技能等从 mock 的只读计算重新求值 */
          workbenchDemoRefreshTick: 0,
          workbenchMaterialId: null,
          workbenchAnalysisResultId: null,
          workbenchReportId: null,
          workbenchAnalysisCitationPopover: { show: false, title: '', excerpt: '', x: 0, y: 0 },
          workbenchAnalysisCitationPopoverTimer: null,
          workbenchAnalysisEmbedEditing: false,
          workbenchAnalysisEmbedDraft: '',
          /** 审计助手侧栏结果正文：按结果 id 存 Markdown 历史快照（演示），用于历史版本回退 */
          workbenchAnalysisVersionHistoryById: {},
          wbAnalysisResultMetaEditVisible: false,
          wbAnalysisResultMetaEditTargetId: '',
          wbAnalysisResultMetaEditForm: { name: '', tags: [] },
          wbAnalysisModalEmbedEditing: false,
          wbAnalysisModalEmbedDraft: '',
          wbMaterialMetaEditVisible: false,
          wbMaterialMetaEditTargetId: '',
          wbMaterialMetaEditForm: { name: '', tags: [] },
          wbAnalysisModalOpen: false,
          wbAnalysisModalRecord: null,
          wbAnalysisModalActiveTab: 'body',
          wbMaterialPreviewActiveTab: 'preview',
          /** 资料预览 · OCR 页：是否在正文左侧展示行号 */
          materialPreviewOcrShowLineNumbers: false,
          wbAnalysisResultPreviewActiveTab: 'body',
          wbAnalysisModalCitationPopover: { show: false, title: '', excerpt: '', x: 0, y: 0 },
          wbAnalysisModalCitationPopoverTimer: null,
          wbAnalysisHistoryDiffOpen: false,
          wbAnalysisHistoryDiffLines: [],
          wbAnalysisHistoryDiffTruncated: false,
          wbAnalysisVersionDetailVisible: false,
          wbAnalysisVersionDetailMarkdown: '',
          saveResultModalVisible: false,
          saveResultModalSourceType: 'message',
          saveResultModalSourceMsgId: null,
          saveResultModalSourcePayload: null,
          saveResultForm: { name: '' },
          analysisToolPreviewModalOpen: false,
          analysisToolPreviewRecord: null,
          chatMessages: [],
          chatInput: '',
          /** 输入框内 @ / 触发：浮现引用或技能菜单 */
          chatInputTriggerOpen: false,
          chatInputTriggerKind: null,
          chatTriggerFilter: '',
          chatInputAtRail: 'raw',
          chatAtMenuPanel: 'categories',
          chatAtFloaterStyle: {},
          _chatInputBlurTimer: null,
          _chatAtFloaterReposBound: null,
          sessionHistory: [],
          historyDropdownOpen: false,
          presetSuggestions,
          selectedMaterialId: null,
          sourcesLeftView: 'list',
          sourcesRightView: 'list',
          workbenchLeftPrimaryTab: 'material',
          sourcesLeftFullscreen: false,
          fullscreenMaterialId: null,
          fullscreenLeftView: 'list',
          fullscreenSelectedSourceId: null,
          fullscreenHighlightSourceId: null,
          fullscreenHighlightExcerptIndex: null,
          fullscreenExcerptRefs: {},
          fullscreenOriginalHighlight: null,
          fullscreenOriginalPageRefs: {},
          fullscreenOriginalRowRefs: {},
          citationPopover: { show: false, title: '', excerpt: '', x: 0, y: 0 },
          citationPopoverTimer: null,
          sourceGuideOpen: true,
          highlightSourceId: null,
          highlightExcerptIndex: null,
          sourcesCollapsed: false,
          studioCollapsed: false,
          sourcesWidth: 300,
          sourcesDetailWidth: 450,
          studioWidth: 340,
          resizing: null,
          lastDetailFocus: null,
          excerptRefs: {},
          toastMessage: '',
          layoutMode: 'A',
          experienceDrafts: { extract: '', analysis: '', report: '' },
          hoveredMaterialId: null,
          treeNodeHoverPopover: { visible: false, node: null, sectionKey: null, x: 0, y: 0 },
          treeNodeHoverTimer: null,
          treeNodeHoverCloseTimer: null,
          treeSectionOpen: { material: true, analysis: true },
          selectedTreeNode: null,
          treeContextMenuNode: null,
          treeContextMenuVisible: false,
          treeContextMenuPosition: { x: 0, y: 0 },
          extractionResults: [],
          selectedExtractionId: null,
          summaryTemplateTasks: [],
          summarySkillTaskByTemplateId: {},
          summaryTaskResultModalVisible: false,
          summaryTaskResultTaskId: null,
          summaryTaskResultExpandedRuleId: '',
          summaryTaskResultForm: { name: '', extractionRules: [], analysisRule: '' },
          analysisTemplatePool: {
            public: SKILL_SEED_PUBLIC.map((x) => toAnalysisTemplateShared(x, 'public')),
            private: demoSharedPrivateAnalysisTemplatePool,
          },
          wbSelectedTemplateKey: '',
          wbSkillSidebarSearchKeyword: '',
          wbSkillListTagKeys: [],
          wbSkillListTagMatchMode: 'any',
          wbSkillListTagSearchQuery: '',
          wbSkillListTagPopoverOpen: false,
          wbSkillListSortBy: 'name_asc',
          /** 侧栏技能行「更多」菜单：受控 open，供右键与三点按钮共用 */
          wbSkillTreeActionMenuKey: null,
          wbProjectSkillDetailModalOpen: false,
          wbProjectSkillCreateBasicModalOpen: false,
          wbProjectSkillCreateBasicSubmitting: false,
          wbProjectSkillCreateBasicForm: { name: '', description: '', tags: [] },
          wbProjectSkillDetailActiveTab: 'basic',
          wbProjectSkillDetailModalIsCreate: false,
          wbProjectSkillDetailReadOnly: false,
          _wbProjectSkillModalSnapshot: null,
          wbSkillResourcePopoverOpen: false,
          wbSkillResourcePopoverSkillId: '',
          wbProjectSkillBasicPaneEditing: false,
          wbProjectSkillConfigPaneEditing: false,
          wbProjectSkillResourcePaneEditing: false,
          _wbProjectSkillBasicPaneSnap: null,
          _wbProjectSkillConfigPaneSnap: null,
          _wbProjectSkillResourcePaneSnap: null,
          _wbProjectSkillCreateCommitted: false,
          wbProjectSkillDetailId: '',
          wbProjectSkillConfigNavKey: 'rule',
          wbProjectSkillConfigTreeExpandedKeys: [],
          wbProjectSkillForm: { id: '', name: '', description: '', tags: [] },
          workbenchAnalysisTagKeys: [],
          workbenchAnalysisTagMatchMode: 'any',
          workbenchAnalysisTagSearchQuery: '',
          workbenchAnalysisTagPopoverOpen: false,
          workbenchAnalysisSortBy: 'meta_desc',
        };
      },
      computed: {
        freeAuditChatHost() { return this; },
        skillObjectMaterialTypePlaceholder() {
          return (typeof window !== 'undefined' && window.__DEMO_SKILL_OBJECT_MATERIAL_TYPE_PLACEHOLDER) || '请填写资料名称或类型';
        },
        selectedMaterial() { return this.materials.find(m => m.id === this.selectedMaterialId) || null; },
        /** 当前侧栏选中资料对应的工作台资料行（与工作台资料预览同源） */
        workbenchSelectedProjectMaterialRow() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'raw' || !m.projectSource) return null;
          return m.projectSource;
        },
        /** 侧栏/内嵌：当前分析结果对应的工作台内结果行（与工作台「结果预览」弹窗同源字段） */
        workbenchSelectedAnalysisResultRow() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return null;
          const ps = m.projectSource || {};
          return {
            id: ps.id || m.id,
            name: ps.name || m.title,
            tags: Array.isArray(m.tags) ? m.tags : (Array.isArray(ps.tags) ? ps.tags : []),
            sourceSkillName: ps.sourceSkillName || m.sourceSkillName,
            createdAt: ps.createdAt || m.meta,
            status: ps.status || 'done',
            analysisMarkdown: m.analysisMarkdown || ps.analysisMarkdown,
            analysisMarkdownEditedBy: ps.analysisMarkdownEditedBy,
            analysisMarkdownEditedAt: ps.analysisMarkdownEditedAt,
          };
        },
        workbenchAnalysisDialogueSourceLine() {
          return this.workbenchAnalysisDialogueSourceLineFromRecord(this.workbenchSelectedAnalysisResultRow);
        },
        selectedMaterialDetail() {
          if (!this.selectedMaterial) return null;
          return this.selectedMaterial;
        },
        sourceMaterialCount() { return this.selectedMaterial?.sourceMaterialIds?.length ?? 0; },
        detailExcerpts() {
          if (!this.selectedMaterialDetail) return [];
          const m = this.selectedMaterial;
          if (m && (m.type === 'analysis' || m.type === 'report') && m.excerptsWithCitations) return m.excerptsWithCitations.map(x => x.text);
          return this.selectedMaterialDetail.excerpts || [];
        },
        checkedMaterialCount() { return this.materials.filter(m => m.checked).length; },
        workbenchMaterialSelectOptions() {
          return (this.materials || [])
            .filter((m) => m && (m.type === 'raw' || m.type === undefined))
            .map((m) => ({ value: String(m.id), label: m.title || m.id }));
        },
        /** @ 引用菜单：资料 */
        chatAtMenuRawMaterials() {
          return (this.materials || []).filter((m) => m && (m.type === 'raw' || m.type === undefined));
        },
        /** @ 引用菜单：结果 */
        chatAtMenuResultMaterials() {
          return (this.materials || []).filter((m) => m && (m.type === 'analysis' || m.type === 'report'));
        },
        chatAtMenuHasAnythingToRef() {
          return this.chatAtMenuRawMaterials.length > 0 || this.chatAtMenuResultMaterials.length > 0;
        },
        chatAtMenuRailCategories() {
          return [
            { key: 'raw', label: '资料' },
            { key: 'result', label: '结果' },
          ];
        },
        chatAtSubmenuTitle() {
          const k = this.chatInputAtRail;
          if (k === 'raw') return '资料';
          if (k === 'result') return '结果';
          return '';
        },
        chatAtMenuRawMaterialsFiltered() {
          const q = (this.chatTriggerFilter || '').trim().toLowerCase();
          const list = this.chatAtMenuRawMaterials;
          if (!q) return list;
          return list.filter((m) => {
            const t = String(m.title != null ? m.title : m.name != null ? m.name : '').toLowerCase();
            return t.includes(q);
          });
        },
        chatAtMenuResultMaterialsFiltered() {
          const q = (this.chatTriggerFilter || '').trim().toLowerCase();
          const list = this.chatAtMenuResultMaterials;
          if (!q) return list;
          return list.filter((m) => {
            const t = String(m.title != null ? m.title : m.name != null ? m.name : '').toLowerCase();
            return t.includes(q);
          });
        },
        chatSlashMenuSectionsFiltered() {
          const q = (this.chatTriggerFilter || '').trim().toLowerCase();
          return (this.workbenchTemplateTreeSections || [])
            .map((sec) => ({
              key: sec.key,
              label: sec.label,
              children: (sec.children || []).filter((node) => {
                if (!q) return true;
                const name = String(node.raw && node.raw.name != null ? node.raw.name : '未命名').toLowerCase();
                return name.includes(q);
              }),
            }))
            .filter((sec) => sec.children.length > 0);
        },
        chatSlashMenuHasAnyItem() {
          return this.chatSlashMenuSectionsFiltered.some((s) => (s.children || []).length > 0);
        },
        chatTriggerFilterTrimmed() {
          return (this.chatTriggerFilter || '').trim();
        },
        /** @ 后有关键字时：合并展示匹配的资料 + 结果 */
        chatAtUnifiedMatchRows() {
          if (!this.chatTriggerFilterTrimmed) return [];
          const rows = [];
          this.chatAtMenuRawMaterialsFiltered.forEach((m) => {
            rows.push({ kind: 'raw', m });
          });
          this.chatAtMenuResultMaterialsFiltered.forEach((m) => {
            rows.push({ kind: 'result', m });
          });
          return rows;
        },
        materialsForList() {
          const q = (this.materialSearchQuery || '').trim().toLowerCase();
          const rank = (m) => (m.type === 'raw' || m.type === undefined ? 0 : 1);
          const list = this.materials.filter((m) => {
            if (!q) return true;
            const inTitle = (m.title || '').toLowerCase().includes(q);
            const inTags = (m.tags || []).some((t) => String(t).toLowerCase().includes(q));
            return inTitle || inTags;
          });
          const rawRows = list.filter((m) => m.type === 'raw' || m.type === undefined);
          const analysisRows = list.filter((m) => m.type === 'analysis');
          return [...this.filteredWorkbenchRawMaterials(rawRows), ...analysisRows].sort((a, b) => rank(a) - rank(b));
        },
        /** 筛选角标：已选标签数 */
        workbenchMaterialActiveFilterCount() {
          return (this.workbenchMaterialTagKeys || []).length;
        },
        workbenchMaterialSortOptions() {
          return [
            { value: 'uploaded_desc', label: '按上传时间（新->旧）' },
            { value: 'uploaded_asc', label: '按上传时间（旧->新）' },
            { value: 'status', label: '按状态' },
            { value: 'type', label: '按类型' },
            { value: 'name', label: '按名称' },
            { value: 'size_desc', label: '按大小（大->小）' },
            { value: 'size_asc', label: '按大小（小->大）' },
          ];
        },
        workbenchMaterialTagStats() {
          const map = new Map();
          (this.materials || [])
            .filter((m) => m.type === 'raw' || m.type === undefined)
            .forEach((m) => {
              const tags = Array.isArray(m.tags) ? m.tags : [];
              tags.forEach((t) => {
                const tag = String(t || '').trim();
                if (!tag) return;
                map.set(tag, (map.get(tag) || 0) + 1);
              });
            });
          return Array.from(map.entries())
            .map(([tag, count]) => ({ tag, count }))
            .sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag, 'zh-CN'));
        },
        workbenchMaterialTagFilteredStats() {
          const q = (this.workbenchMaterialTagSearchQuery || '').trim().toLowerCase();
          const rows = this.workbenchMaterialTagStats;
          if (!q) return rows;
          return rows.filter((r) => r.tag.toLowerCase().includes(q));
        },
        currentWorkbenchSortLabel() {
          const found = (this.workbenchMaterialSortOptions || []).find((x) => x.value === this.workbenchMaterialSortBy);
          return found ? found.label : '排序';
        },
        wbSkillSidebarSortOptions() {
          return [
            { value: 'name_asc', label: '按名称（A→Z）' },
            { value: 'name_desc', label: '按名称（Z→A）' },
            { value: 'tag_count_desc', label: '按标签数（多→少）' },
            { value: 'tag_count_asc', label: '按标签数（少→多）' },
            { value: 'updated_desc', label: '按更新时间（新→旧）' },
            { value: 'updated_asc', label: '按更新时间（旧→新）' },
            { value: 'created_desc', label: '按创建时间（新→旧）' },
            { value: 'created_asc', label: '按创建时间（旧→新）' },
          ];
        },
        currentWbSkillSortLabel() {
          const found = (this.wbSkillSidebarSortOptions || []).find((x) => x.value === this.wbSkillListSortBy);
          return found ? found.label : '排序';
        },
        wbSkillListTagStats() {
          const map = new Map();
          (this.workbenchProjectTemplates || []).forEach((tpl) => {
            (tpl.tags || []).forEach((t) => {
              const tag = String(t || '').trim();
              if (!tag) return;
              map.set(tag, (map.get(tag) || 0) + 1);
            });
          });
          return Array.from(map.entries())
            .map(([tag, count]) => ({ tag, count }))
            .sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag, 'zh-CN'));
        },
        wbSkillListTagFilteredStats() {
          const q = (this.wbSkillListTagSearchQuery || '').trim().toLowerCase();
          const rows = this.wbSkillListTagStats;
          if (!q) return rows;
          return rows.filter((r) => r.tag.toLowerCase().includes(q));
        },
        workbenchAnalysisListSource() {
          return (this.materialsForList || []).filter((m) => m && m.type === 'analysis');
        },
        workbenchAnalysisTagStats() {
          const map = new Map();
          (this.workbenchAnalysisListSource || []).forEach((m) => {
            (m.tags || []).forEach((t) => {
              const tag = String(t || '').trim();
              if (!tag) return;
              map.set(tag, (map.get(tag) || 0) + 1);
            });
          });
          return Array.from(map.entries())
            .map(([tag, count]) => ({ tag, count }))
            .sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag, 'zh-CN'));
        },
        workbenchAnalysisTagFilteredStats() {
          const q = (this.workbenchAnalysisTagSearchQuery || '').trim().toLowerCase();
          const rows = this.workbenchAnalysisTagStats;
          if (!q) return rows;
          return rows.filter((r) => r.tag.toLowerCase().includes(q));
        },
        workbenchAnalysisSortOptions() {
          return [
            { value: 'title_asc', label: '按名称（A→Z）' },
            { value: 'title_desc', label: '按名称（Z→A）' },
            { value: 'meta_desc', label: '按生成时间（新→旧）' },
            { value: 'meta_asc', label: '按生成时间（旧→新）' },
            { value: 'status_asc', label: '按状态（排队→完成）' },
            { value: 'status_desc', label: '按状态（完成→排队）' },
          ];
        },
        currentWorkbenchAnalysisSortLabel() {
          const found = (this.workbenchAnalysisSortOptions || []).find((x) => x.value === this.workbenchAnalysisSortBy);
          return found ? found.label : '排序';
        },
        materialTreeSections() {
          const rawMaterials = this.materialsForList.filter((m) => (m.type === 'raw' || m.type === undefined) && this.workbenchMaterialStatusOf(m) === 'done');
          const analysisMaterials = this.materialsForList.filter((m) => m.type === 'analysis');
          const materialNodes = rawMaterials.map((m) => ({ source: 'material', id: m.id, raw: m }));
          const analysisNodes = analysisMaterials.map((m) => ({ source: 'material', id: m.id, raw: m }));
          return [
            { key: 'material', label: '资料', children: materialNodes },
            { key: 'analysis', label: '结果', children: analysisNodes }
          ];
        },
        workbenchLeftTreeSections() {
          return (this.materialTreeSections || []).filter((s) => s.key === 'material');
        },
        workbenchRawMaterialQueuedList() {
          return (this.materials || []).filter((m) => (m.type === 'raw' || m.type === undefined) && this.workbenchMaterialStatusOf(m) === 'queued');
        },
        workbenchRawMaterialParsingList() {
          return (this.materials || []).filter((m) => (m.type === 'raw' || m.type === undefined) && this.workbenchMaterialStatusOf(m) === 'parsing');
        },
        workbenchRawMaterialFailedList() {
          return (this.materials || []).filter((m) => (m.type === 'raw' || m.type === undefined) && this.workbenchMaterialStatusOf(m) === 'failed');
        },
        workbenchRawMaterialStatusSummary() {
          return {
            queued: (this.workbenchRawMaterialQueuedList || []).length,
            parsing: (this.workbenchRawMaterialParsingList || []).length,
            failed: (this.workbenchRawMaterialFailedList || []).length,
          };
        },
        workbenchAnalysisQueuedList() {
          return (this.materials || []).filter((m) => m && m.type === 'analysis' && this.workbenchAnalysisStatusOf(m) === 'queued');
        },
        workbenchAnalysisParsingList() {
          return (this.materials || []).filter((m) => m && m.type === 'analysis' && this.workbenchAnalysisStatusOf(m) === 'parsing');
        },
        workbenchAnalysisFailedList() {
          return (this.materials || []).filter((m) => m && m.type === 'analysis' && this.workbenchAnalysisStatusOf(m) === 'failed');
        },
        workbenchAnalysisStatusSummary() {
          return {
            queued: (this.workbenchAnalysisQueuedList || []).length,
            parsing: (this.workbenchAnalysisParsingList || []).length,
            failed: (this.workbenchAnalysisFailedList || []).length,
          };
        },
        workbenchRightTreeSections() {
          let list = [...(this.workbenchAnalysisListSource || [])];
          const q = String(this.workbenchAnalysisSearchQuery || '').trim().toLowerCase();
          if (q) {
            list = list.filter((m) => {
              const title = String(m.title || '').toLowerCase();
              const inTags = (m.tags || []).some((t) => String(t).toLowerCase().includes(q));
              return title.includes(q) || inTags;
            });
          }
          const tagKeys = this.workbenchAnalysisTagKeys || [];
          const modeAll = this.workbenchAnalysisTagMatchMode === 'all';
          if (tagKeys.length) {
            list = list.filter((m) => {
              const stags = m.tags || [];
              return modeAll ? tagKeys.every((t) => stags.includes(t)) : tagKeys.some((t) => stags.includes(t));
            });
          }
          list = list.filter((m) => this.workbenchAnalysisStatusOf(m) === 'done');
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const timeOf = (m) => {
            const v = m.meta || (m.projectSource && m.projectSource.createdAt) || '';
            const t = Date.parse(String(v || '').trim().replace(' ', 'T'));
            return Number.isNaN(t) ? 0 : t;
          };
          const statusOrder = { queued: 0, parsing: 1, done: 2, failed: 3 };
          const statusRank = (m) => {
            const st = (m.projectSource && m.projectSource.status) || 'done';
            return st in statusOrder ? statusOrder[st] : 99;
          };
          const sortKey = this.workbenchAnalysisSortBy || 'meta_desc';
          list.sort((a, b) => {
            if (sortKey === 'title_asc') return collator.compare(String(a.title || ''), String(b.title || ''));
            if (sortKey === 'title_desc') return collator.compare(String(b.title || ''), String(a.title || ''));
            if (sortKey === 'meta_asc') return timeOf(a) - timeOf(b) || collator.compare(String(a.title || ''), String(b.title || ''));
            if (sortKey === 'meta_desc') return timeOf(b) - timeOf(a) || collator.compare(String(a.title || ''), String(b.title || ''));
            if (sortKey === 'status_asc') return statusRank(a) - statusRank(b) || collator.compare(String(a.title || ''), String(b.title || ''));
            if (sortKey === 'status_desc') return statusRank(b) - statusRank(a) || collator.compare(String(a.title || ''), String(b.title || ''));
            return timeOf(b) - timeOf(a) || collator.compare(String(a.title || ''), String(b.title || ''));
          });
          const analysisNodes = list.map((m) => ({ source: 'material', id: m.id, raw: m }));
          return [{ key: 'analysis', label: '结果', children: analysisNodes }];
        },
        poolTabMaterialCount() {
          const sec = (this.materialTreeSections || []).find((s) => s.key === 'material');
          return sec ? sec.children.length : 0;
        },
        poolTabAnalysisCount() {
          const sec = (this.workbenchRightTreeSections || []).find((s) => s.key === 'analysis');
          return sec ? sec.children.length : 0;
        },
        allMaterialsChecked() { return this.materials.length > 0 && this.materials.every(m => m.checked); },
        selectedExtractionResult() {
          if (!this.selectedExtractionId) return null;
          return this.extractionResults.find(r => r.id === this.selectedExtractionId) || null;
        },
        effectiveSourcesWidth() {
          if (this.sourcesLeftView === 'detail') return this.sourcesDetailWidth;
          return this.sourcesWidth;
        },
        layoutRatios() {
          const leftDetail = this.sourcesLeftView === 'detail' && !this.sourcesCollapsed;
          const rightDetail = this.sourcesRightView === 'detail' && !this.studioCollapsed;

          if (!leftDetail && !rightDetail) return { left: 2.5, middle: 5, right: 2.5 };
          if (leftDetail && !rightDetail) return { left: 4, middle: 4, right: 2 };
          if (!leftDetail && rightDetail) return { left: 2, middle: 4, right: 4 };

          if (this.lastDetailFocus === 'right') return { left: 2, middle: 4, right: 4 };
          return { left: 4, middle: 4, right: 2 };
        },
        fullscreenMaterial() { return this.materials.find(m => m.id === this.fullscreenMaterialId) || null; },
        fullscreenSourceMaterials() {
          if (!this.fullscreenMaterial || !this.fullscreenMaterial.sourceMaterialIds) return [];
          return this.fullscreenMaterial.sourceMaterialIds.map(id => this.materials.find(m => m.id === id)).filter(Boolean);
        },
        fullscreenSelectedSource() {
          if (!this.fullscreenSelectedSourceId) return null;
          return this.materials.find(m => m.id === this.fullscreenSelectedSourceId) || null;
        },
        workbenchPageHeadTitle() {
          if (!this.workbenchProjectId) return '审计助手';
          const named = WORKBENCH_PROJECT_NAME_BY_ID[this.workbenchProjectId];
          if (named) return named;
          try {
            const raw = sessionStorage.getItem('pendingNewProject');
            if (raw) {
              const parsed = JSON.parse(raw);
              if (parsed && parsed.id === this.workbenchProjectId && parsed.name) return String(parsed.name);
            }
          } catch (_) {}
          return '工作台 ' + this.workbenchProjectId;
        },
        workbenchProjectTemplates() {
          void this.workbenchDemoRefreshTick;
          const pid = this.workbenchProjectId;
          if (!pid) return [];
          return demoProjectAnalysisTemplatesById[pid] || [];
        },
        workbenchProjectTemplateCount() {
          return (this.workbenchProjectTemplates || []).length;
        },
        workbenchTemplateTreeSections() {
          const q = String(this.wbSkillSidebarSearchKeyword || '').trim().toLowerCase();
          const tagKeys = this.wbSkillListTagKeys || [];
          const modeAll = this.wbSkillListTagMatchMode === 'all';
          let project = (this.workbenchProjectTemplates || []).filter((tpl) => {
            if (this.isWbProjectSkillSummarizing(tpl)) return false;
            if (q) {
              const name = String(tpl.name || '').toLowerCase();
              const tags = Array.isArray(tpl.tags) ? tpl.tags.map((t) => String(t || '').toLowerCase()) : [];
              if (!name.includes(q) && !tags.some((t) => t.includes(q))) return false;
            }
            if (tagKeys.length) {
              const stags = tpl.tags || [];
              const ok = modeAll ? tagKeys.every((t) => stags.includes(t)) : tagKeys.some((t) => stags.includes(t));
              if (!ok) return false;
            }
            return true;
          });
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const time = (v) => {
            const t = Date.parse(String(v || '').trim());
            return Number.isNaN(t) ? 0 : t;
          };
          const tagCount = (t) => (Array.isArray(t.tags) ? t.tags.length : 0);
          const byName = (a, b) => collator.compare(String(a.name || ''), String(b.name || ''));
          const sortKey = this.wbSkillListSortBy || 'name_asc';
          project = [...project].sort((a, b) => {
            if (sortKey === 'name_desc') return byName(b, a);
            if (sortKey === 'tag_count_desc') return tagCount(b) - tagCount(a) || byName(a, b);
            if (sortKey === 'tag_count_asc') return tagCount(a) - tagCount(b) || byName(a, b);
            if (sortKey === 'updated_desc') return time(b.updatedAt) - time(a.updatedAt) || byName(a, b);
            if (sortKey === 'updated_asc') return time(a.updatedAt) - time(b.updatedAt) || byName(a, b);
            if (sortKey === 'created_desc') return time(b.createdAt) - time(a.createdAt) || byName(a, b);
            if (sortKey === 'created_asc') return time(a.createdAt) - time(b.createdAt) || byName(a, b);
            return byName(a, b);
          });
          const mapNode = (tpl, scope) => ({
            source: 'template',
            id: tpl.id,
            key: `${scope}:${tpl.id}`,
            scope,
            raw: tpl,
          });
          return [
            { key: 'project', label: '技能', children: project.map((tpl) => mapNode(tpl, 'project')) },
          ];
        },
        workbenchTemplateTotalCount() {
          return (this.workbenchTemplateTreeSections || []).reduce((sum, sec) => sum + ((sec.children || []).length), 0);
        },
        wbGeneratingSkills() {
          return (this.workbenchProjectTemplates || []).filter((tpl) => this.isWbProjectSkillSummarizing(tpl));
        },
        wbSkillGeneratingCount() {
          return (this.wbGeneratingSkills || []).length;
        },
        workbenchAnalysisPreviewMarkdown() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return '';
          if (m.analysisMarkdown) return m.analysisMarkdown;
          const ps = m.projectSource || {};
          return buildAnalysisResultPreviewMarkdown({ name: m.title || ps.name, tags: m.tags || ps.tags, createdAt: m.meta || ps.createdAt });
        },
        workbenchAnalysisCitationMap() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return DEMO_ANALYSIS_CITATION_MAP;
          return m.citationMap || DEMO_ANALYSIS_CITATION_MAP;
        },
        workbenchAnalysisPreviewHtml() {
          const md = this.workbenchAnalysisPreviewMarkdown || '';
          const html = (window.marked && typeof window.marked.parse === 'function')
            ? window.marked.parse(md)
            : md.replace(/\n/g, '<br>');
          return html.replace(/\[(E\d+)\]/g, (_, k) => `<span class="analysis-inline-citation" aria-label="引用 ${this.analysisCitationDisplayIndex(k)}">（${this.analysisCitationDisplayIndex(k)}）</span>`);
        },
        workbenchAnalysisVersionMenuList() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return [];
          const list = (this.workbenchAnalysisVersionHistoryById || {})[m.id];
          return Array.isArray(list) ? list : [];
        },
        workbenchAnalysisVersionMgmtColumns() {
          return [
            { title: '生成时间', dataIndex: 'generatedAt', key: 'generatedAt', width: 156 },
            {
              title: '生成说明',
              dataIndex: 'generationDesc',
              key: 'generationDesc',
              ellipsis: true,
              className: 'skill-version-mgmt-col-desc',
            },
            { title: '操作', key: 'action', width: 128, align: 'left', className: 'skill-version-mgmt-col-action' },
          ];
        },
        workbenchAnalysisVersionCurrentRow() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return null;
          const ps = m.projectSource || {};
          const base = this.workbenchSelectedAnalysisResultRow || {};
          const rec = {
            ...ps,
            ...base,
            sourceSkillName: base.sourceSkillName || ps.sourceSkillName,
            sourceMaterialIds: Array.isArray(ps.sourceMaterialIds)
              ? ps.sourceMaterialIds
              : (Array.isArray(m.sourceMaterialIds) ? m.sourceMaterialIds : []),
          };
          const generatedAt = String(ps.analysisMarkdownEditedAt || m.meta || ps.createdAt || '').trim() || '—';
          const resolver = (mid) => this.workbenchAnalysisResolveMaterialNameById(mid);
          const generationDesc =
            typeof buildAnalysisResultGenerationDesc === 'function'
              ? buildAnalysisResultGenerationDesc(rec, resolver)
              : `使用技能「${String(rec.sourceSkillName || '关联技能')}」生成的结果（演示）。`;
          return {
            key: '_current',
            generatedAt,
            generationDesc,
            markdown: this.workbenchAnalysisPreviewMarkdown || '',
          };
        },
        workbenchAnalysisVersionHistoryOnlyRows() {
          const list = this.workbenchAnalysisVersionMenuList || [];
          return list.map((v) => {
            const raw = String(v.markdown || '');
            const gd = String(v.generationDesc || '').trim();
            const savedAt = String(v.savedAt || '').trim();
            const generationDesc = gd || (savedAt ? `历史快照 · ${savedAt}` : '历史快照');
            const generatedAt = savedAt || String(v.label || '').trim() || '—';
            return {
              key: v.key,
              generatedAt,
              generationDesc,
              markdown: raw,
            };
          });
        },
        workbenchAnalysisStatusLabel() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return '—';
          const st = (m.projectSource && m.projectSource.status) || 'done';
          const map = { queued: '排队中', parsing: '分析中', done: '完成', failed: '失败' };
          return map[st] || '完成';
        },
        workbenchAnalysisStatusChipClass() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return 'is-neutral';
          const st = (m.projectSource && m.projectSource.status) || 'done';
          return this.analysisStatusChipClass(st);
        },
        /** 工作台侧栏「原始文件」与工作台资料预览同源：文档页 / OCR 页由 demo-mock-data 拆分函数提供 */
        workbenchMaterialDocumentPages() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'raw' || !m.projectSource) return ['暂无内容'];
          return materialPreviewDocumentPagesFromRecord(m.projectSource);
        },
        workbenchMaterialOcrPagesList() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'raw' || !m.projectSource) return ['暂无 OCR 内容'];
          return materialPreviewOcrPagesFromRecord(m.projectSource);
        },
        workbenchMaterialOcrPagesDisplayed() {
          const pages = this.workbenchMaterialOcrPagesList;
          if (!this.materialPreviewOcrShowLineNumbers) return pages;
          return pages.map((p) => materialPreviewOcrPageWithLineNumbers(p, true));
        },
        workbenchMaterialPreviewBasicMetaRows() {
          const r = this.workbenchSelectedProjectMaterialRow;
          if (!r) return [];
          const tags = Array.isArray(r.tags) ? r.tags.map((t) => String(t || '').trim()).filter(Boolean) : [];
          const tagText = tags.length ? tags.join('、') : '—';
          const statusMap = { queued: '排队中', parsing: '解析中', done: '完成', failed: '失败' };
          const st = statusMap[r.status] || '排队中';
          const size = r.size == null || r.size === '' ? '—' : `${Number(r.size).toFixed(1)} MB`;
          return [
            { label: '名称', value: String(r.name || '').trim() || '—' },
            { label: '标签', value: tagText },
            { label: '大小', value: size },
            { label: '格式', value: String(r.format || '').trim() || '—' },
            { label: '状态', value: st },
            { label: '上传人', value: String(r.uploader || r.uploadedBy || '').trim() || '—' },
            { label: '上传时间', value: String(r.uploadedAt || '').trim() || '—' },
          ];
        },
        /** 与工作台结果预览 Modal 的 buildOverviewResultMeta 字段一致 */
        workbenchAnalysisResultBasicMetaRows() {
          const r = this.workbenchSelectedAnalysisResultRow;
          if (!r) return [];
          const tags = Array.isArray(r.tags) ? r.tags.map((t) => String(t || '').trim()).filter(Boolean) : [];
          const tagText = tags.length ? tags.join('、') : '—';
          const statusMap = { queued: '排队中', parsing: '分析中', done: '完成', failed: '失败' };
          const st = statusMap[r.status] || '完成';
          return [
            { label: '名称', value: String(r.name || '').trim() || '—' },
            { label: '标签', value: tagText },
            { label: '来源技能', value: String(r.sourceSkillName || '').trim() || '—' },
            { label: '状态', value: st },
            { label: '生成时间', value: String(r.createdAt || '').trim() || '—' },
          ];
        },
        wbAnalysisModalPreviewMarkdown() {
          if (!this.wbAnalysisModalOpen) return '';
          const r = this.wbAnalysisModalRecord || {};
          if (r.analysisMarkdown) return r.analysisMarkdown;
          return buildAnalysisResultPreviewMarkdown(r);
        },
        wbAnalysisModalVersionMenuList() {
          const r = this.wbAnalysisModalRecord;
          if (!r || !r.id) return [];
          const list = (this.workbenchAnalysisVersionHistoryById || {})[r.id];
          return Array.isArray(list) ? list : [];
        },
        wbAnalysisModalVersionCurrentRow() {
          const r = this.wbAnalysisModalRecord;
          if (!r || !r.id) return null;
          const generatedAt = String(r.analysisMarkdownEditedAt || r.createdAt || '').trim() || '—';
          const resolver = (mid) => this.workbenchAnalysisResolveMaterialNameById(mid);
          const generationDesc =
            typeof buildAnalysisResultGenerationDesc === 'function'
              ? buildAnalysisResultGenerationDesc(r, resolver)
              : `使用技能「${String(r.sourceSkillName || '关联技能')}」生成的结果（演示）。`;
          return {
            key: '_current',
            generatedAt,
            generationDesc,
            markdown: this.wbAnalysisModalPreviewMarkdown || '',
          };
        },
        wbAnalysisModalVersionHistoryOnlyRows() {
          const list = this.wbAnalysisModalVersionMenuList || [];
          return list.map((v) => {
            const raw = String(v.markdown || '');
            const gd = String(v.generationDesc || '').trim();
            const savedAt = String(v.savedAt || '').trim();
            const generationDesc = gd || (savedAt ? `历史快照 · ${savedAt}` : '历史快照');
            const generatedAt = savedAt || String(v.label || '').trim() || '—';
            return {
              key: v.key,
              generatedAt,
              generationDesc,
              markdown: raw,
            };
          });
        },
        wbAnalysisVersionDetailHtml() {
          const md = this.wbAnalysisVersionDetailMarkdown || '';
          const html = (window.marked && typeof window.marked.parse === 'function')
            ? window.marked.parse(md)
            : md.replace(/\n/g, '<br>');
          return html.replace(/\[(E\d+)\]/g, (_, k) => `<span class="analysis-inline-citation" aria-label="引用 ${this.analysisCitationDisplayIndex(k)}">（${this.analysisCitationDisplayIndex(k)}）</span>`);
        },
        wbAnalysisModalCitationMap() {
          const r = this.wbAnalysisModalRecord;
          if (!r) return DEMO_ANALYSIS_CITATION_MAP;
          return r.citationMap || DEMO_ANALYSIS_CITATION_MAP;
        },
        wbAnalysisModalDialogueSourceLine() {
          return this.workbenchAnalysisDialogueSourceLineFromRecord(this.wbAnalysisModalRecord);
        },
        wbAnalysisModalPreviewHtml() {
          const md = this.wbAnalysisModalPreviewMarkdown || '';
          const html = (window.marked && typeof window.marked.parse === 'function')
            ? window.marked.parse(md)
            : md.replace(/\n/g, '<br>');
          return html.replace(/\[(E\d+)\]/g, (_, k) => `<span class="analysis-inline-citation" aria-label="引用 ${this.analysisCitationDisplayIndex(k)}">（${this.analysisCitationDisplayIndex(k)}）</span>`);
        },
        analysisToolPreviewJson() {
          const rec = this.analysisToolPreviewRecord;
          if (!rec || rec.jsonData == null) return '{}';
          try {
            return JSON.stringify(rec.jsonData, null, 2);
          } catch (err) {
            return '{}';
          }
        },
        analysisToolPreviewCsv() {
          const rec = this.analysisToolPreviewRecord;
          if (rec && typeof rec.csvData === 'string' && rec.csvData.trim()) return rec.csvData;
          return '';
        },
        wbAnalysisModalStatusLabel() {
          const r = this.wbAnalysisModalRecord || {};
          const st = r.status || 'done';
          const map = { queued: '排队中', parsing: '分析中', done: '完成', failed: '失败' };
          return map[st] || '完成';
        },
        wbAnalysisModalStatusChipClass() {
          const r = this.wbAnalysisModalRecord || {};
          const st = r.status || 'done';
          return this.analysisStatusChipClass(st);
        },
        wbDetailSelectedSkill() {
          const pid = this.workbenchProjectId;
          if (!this.wbProjectSkillDetailId || !pid) return null;
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          return list.find((x) => x.id === this.wbProjectSkillDetailId) || null;
        },
        wbProjectSkillDetailModalTitle() {
          if (this.wbProjectSkillDetailModalIsCreate) return '新建技能';
          const s = this.wbDetailSelectedSkill;
          if (!s) return '技能详情';
          const n = String(s.name || '').trim();
          return n || '未命名技能';
        },
        wbProjectSkillDetailModalHeadVersionLabel() {
          if (this.wbProjectSkillDetailModalIsCreate || !this.wbDetailSelectedSkill) return '';
          const s = this.wbDetailSelectedSkill;
          const list = Array.isArray(s.publishedVersions) ? s.publishedVersions : [];
          if (!list.length) return '';
          const sorted = [...list].sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
          const v = sorted[0] && sorted[0].versionLabel;
          return v ? String(v).trim() : '';
        },
        wbProjectSkillConfigSelectedFile() {
          const k = this.wbProjectSkillConfigNavKey;
          if (!k || String(k).indexOf('file:') !== 0 || !this.wbDetailSelectedSkill) return null;
          const id = String(k).slice('file:'.length);
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || typeof T.findFileNodeById !== 'function') return null;
          const hit = T.findFileNodeById(this.wbDetailSelectedSkill.skillFiles || [], id);
          return hit ? hit.node : null;
        },
        wbProjectSkillConfigSelectedFolder() {
          const k = this.wbProjectSkillConfigNavKey;
          if (!k || String(k).indexOf('folder:') !== 0 || !this.wbDetailSelectedSkill) return null;
          const id = String(k).slice('folder:'.length);
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || typeof T.findFolderNodeById !== 'function') return null;
          const hit = T.findFolderNodeById(this.wbDetailSelectedSkill.skillFiles || [], id);
          return hit ? hit.node : null;
        },
        wbProjectSkillConfigDuplicatePaths() {
          const s = this.wbDetailSelectedSkill;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!s || !T || typeof T.findDuplicatePaths !== 'function') return [];
          return T.findDuplicatePaths(s.skillFiles || []);
        },
        wbProjectSkillConfigSelectedFileCodeLabel() {
          const f = this.wbProjectSkillConfigSelectedFile;
          if (!f || f.fileKind !== 'code') return '代码';
          const m = { python: 'Python', javascript: 'JavaScript', typescript: 'TypeScript', shell: 'Shell' };
          return m[f.codeLang] || f.codeLang || '代码';
        },
        wbProjectSkillConfigTreeData() {
          if (!this.wbDetailSelectedSkill) return [];
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (T && typeof T.buildAntTreeData === 'function') return T.buildAntTreeData(this.wbDetailSelectedSkill.skillFiles || []);
          return [{ key: 'rule', title: '审计思路', isLeaf: true }];
        },
        wbProjectSkillConfigTreeSelectedKeys() {
          const k = this.wbProjectSkillConfigNavKey;
          if (!k || k === 'rule') return ['rule'];
          return [String(k)];
        },
        wbProjectSkillBasicFieldsLocked() {
          return this.wbProjectSkillDetailReadOnly || !this.wbProjectSkillBasicPaneEditing;
        },
        wbProjectSkillConfigTabLocked() {
          return this.wbProjectSkillDetailReadOnly || !this.wbProjectSkillConfigPaneEditing;
        },
        wbProjectSkillResourceTabLocked() {
          return this.wbProjectSkillDetailReadOnly || !this.wbProjectSkillResourcePaneEditing;
        },
        wbProjectSkillLinkedResourceSelectOptions() {
          const pid = this.workbenchProjectId;
          const mats = pid ? demoProjectMaterialsById[pid] || [] : [];
          return mats.map((m) => ({ value: String(m.id), label: String(m.name || m.id || '') }));
        },
        wbProjectSkillSaveConfigButtonLabel() {
          return '保存配置';
        },
        /** 思考轨未结束或引导语/收尾总结仍在打字时视为「生成中」（此时输入区显示暂停而非发送） */
        chatReplyInProgress() {
          const list = this.chatMessages || [];
          for (let i = 0; i < list.length; i++) {
            const m = list[i];
            if (m.role === 'thinking' && m._finalized === false) return true;
            if (m.role === 'bot') {
              const introLen = (m.chatIntro || '').length;
              if (introLen) {
                const ip = m.chatIntroProgress;
                if (ip != null && ip < introLen) return true;
              }
              const rs = m.chatRunSummary || '';
              if (rs.length) {
                const rp = m.chatRunSummaryProgress ?? 0;
                if (rp < rs.length) return true;
              }
            }
          }
          return false;
        },
      },
      methods: {
        /** 与 ProjectCenter 同映射：列表 `.ds-status-pill` 与预览「基本信息·状态」共用 */
        analysisResultStatusLabel(status) {
          const map = { queued: '排队中', parsing: '分析中', done: '完成', failed: '失败' };
          return map[status] || map.done;
        },
        analysisStatusChipClass(status) {
          const s = (status && String(status)) || 'done';
          const map = { queued: 'is-neutral', parsing: 'is-primary', done: 'is-success', failed: 'is-error' };
          return map[s] || map.done;
        },
        getSkillAnalysisRulePlaceholder() {
          if (typeof window !== 'undefined' && typeof window.__demoGetSkillAnalysisRulePlaceholder === 'function') {
            return window.__demoGetSkillAnalysisRulePlaceholder();
          }
          return (typeof window !== 'undefined' && window.__DEMO_SKILL_ANALYSIS_RULE_PLACEHOLDER) || '';
        },
        analysisCitationDisplayIndex(key) {
          const raw = String(key || '').trim();
          const matched = raw.match(/(\d+)$/);
          return matched ? matched[1] : raw;
        },
        buildAnalysisCitationEntries(markdown, citationMap) {
          const text = String(markdown || '');
          const map = citationMap || {};
          const seen = new Set();
          const keys = [];
          text.replace(/\[(E\d+)\]/g, (_, key) => {
            if (!seen.has(key)) {
              seen.add(key);
              keys.push(key);
            }
            return _;
          });
          return keys.map((key) => {
            const data = map[key] || {};
            return {
              key,
              indexLabel: this.analysisCitationDisplayIndex(key),
              sourceLabel: String(data.sourceLabel || '引用来源').trim() || '引用来源',
              excerpt: String(data.sourceExcerpt || data.sourceFullText || '').trim() || '暂无可展示的引用内容',
            };
          });
        },
        normalizeResultInlineCitationText(text) {
          return String(text || '')
            .replace(/【(\d+)】/g, '（$1）')
            .replace(/\[(\d+)\]/g, '（$1）')
            .replace(/\[(E\d+)\]/g, (_, key) => `（${this.analysisCitationDisplayIndex(key)}）`);
        },
        buildMessageResultCitationEntries(msg) {
          const list = Array.isArray(msg && msg.citations) ? msg.citations : [];
          const seen = new Set();
          return list.reduce((acc, item, index) => {
            const sourceId = String(item && item.sourceId || '').trim();
            const excerptIndex = Number(item && item.excerptIndex);
            const dedupeKey = `${sourceId}::${Number.isFinite(excerptIndex) ? excerptIndex : 0}`;
            if (!sourceId || seen.has(dedupeKey)) return acc;
            seen.add(dedupeKey);
            const sourceLabel = this.getCitationSourceLabel(sourceId);
            const excerpt = this.buildCitationPopoverExcerpt(this.getExcerptTextForCitation(sourceId, Number.isFinite(excerptIndex) ? excerptIndex : 0));
            acc.push({
              indexLabel: index + 1,
              sourceLabel: sourceLabel || '引用来源',
              excerpt: excerpt || '暂无可展示的引用内容',
            });
            return acc;
          }, []);
        },
        buildPlainTextCitationSection(entries) {
          if (!entries || !entries.length) return '';
          const lines = ['### 引用信息', ''];
          entries.forEach((item) => {
            lines.push(`**（${item.indexLabel}）${item.sourceLabel}**`);
            String(item.excerpt || '').split('\n').forEach((line) => {
              lines.push(`> ${line}`);
            });
            lines.push('');
          });
          return lines.join('\n').trim();
        },
        formatSavedResultBodyFromMessage(msg) {
          const text = this.normalizeResultInlineCitationText(this.getMessageResultPlainText(msg));
          const appendix = this.buildPlainTextCitationSection(this.buildMessageResultCitationEntries(msg));
          return [text, appendix].filter(Boolean).join('\n\n');
        },
        freeAuditPolishUndoDisabled(key) {
          return (
            !!this.freeAuditAiPolishKey || !Object.prototype.hasOwnProperty.call(this.freeAuditPolishUndo, key)
          );
        },
        wbFreeAuditPolishUndoDisabled(key) {
          return this.wbProjectSkillConfigTabLocked || this.freeAuditPolishUndoDisabled(key);
        },
        beginFreeAuditAiPolish(key, getText, setText, onDone) {
          if (this.freeAuditAiPolishKey) return;
          this.freeAuditPolishUndo[key] = String(getText() == null ? '' : getText());
          this.freeAuditAiPolishKey = key;
          window.setTimeout(() => {
            const sample =
              typeof window.__demoPolishSampleForKey === 'function' ? window.__demoPolishSampleForKey(key) : '';
            setText(sample);
            this.freeAuditAiPolishKey = '';
            if (typeof onDone === 'function') onDone();
          }, 1300);
        },
        undoFreeAuditPolish(key, setText, onDone) {
          if (this.freeAuditAiPolishKey) return;
          if (key.startsWith('wb-') && this.wbProjectSkillConfigTabLocked) return;
          if (!Object.prototype.hasOwnProperty.call(this.freeAuditPolishUndo, key)) return;
          const prev = this.freeAuditPolishUndo[key];
          delete this.freeAuditPolishUndo[key];
          setText(prev);
          if (typeof onDone === 'function') onDone();
        },
        demoAiPolishSummaryTaskName() {
          this.beginFreeAuditAiPolish(
            'summary:name',
            () => this.summaryTaskResultForm.name,
            (t) => {
              this.summaryTaskResultForm.name = t;
            }
          );
        },
        undoSummaryTaskName() {
          this.undoFreeAuditPolish('summary:name', (t) => {
            this.summaryTaskResultForm.name = t;
          });
        },
        demoAiPolishSummaryTaskAnalysisRule() {
          this.beginFreeAuditAiPolish(
            'summary:analysisRule',
            () => this.summaryTaskResultForm.analysisRule,
            (t) => {
              this.summaryTaskResultForm.analysisRule = t;
            }
          );
        },
        undoSummaryTaskAnalysisRule() {
          this.undoFreeAuditPolish('summary:analysisRule', (t) => {
            this.summaryTaskResultForm.analysisRule = t;
          });
        },
        demoAiPolishSummaryErField(er, field) {
          const key = 'summary-er:' + er.id + ':' + field;
          this.beginFreeAuditAiPolish(
            key,
            () => er[field],
            (t) => {
              er[field] = t;
            }
          );
        },
        undoSummaryErField(er, field) {
          const key = 'summary-er:' + er.id + ':' + field;
          this.undoFreeAuditPolish(key, (t) => {
            er[field] = t;
          });
        },
        demoAiPolishWbSkillFileField(file, field) {
          if (this.wbProjectSkillConfigTabLocked || !file) return;
          const short = field === 'filename' ? 'fn' : 'ct';
          const key = 'wb-sf:' + file.id + ':' + short;
          this.beginFreeAuditAiPolish(
            key,
            () => (field === 'filename' ? file.filename : file.content),
            (t) => {
              if (field === 'filename') file.filename = t;
              else file.content = t;
            },
            () => this.scheduleWbProjectSkillDetailSync()
          );
        },
        undoWbSkillFileField(file, field) {
          if (this.wbProjectSkillConfigTabLocked || !file) return;
          const short = field === 'filename' ? 'fn' : 'ct';
          const key = 'wb-sf:' + file.id + ':' + short;
          this.undoFreeAuditPolish(
            key,
            (t) => {
              if (field === 'filename') file.filename = t;
              else file.content = t;
            },
            () => this.scheduleWbProjectSkillDetailSync()
          );
        },
        demoAiPolishWbAnalysisRule() {
          if (this.wbProjectSkillConfigTabLocked) return;
          const s = this.wbDetailSelectedSkill;
          if (!s) return;
          this.beginFreeAuditAiPolish(
            'wb-analysisRule',
            () => s.analysisRule,
            (t) => {
              s.analysisRule = t;
            },
            () => this.scheduleWbProjectSkillDetailSync()
          );
        },
        undoWbAnalysisRule() {
          if (this.wbProjectSkillConfigTabLocked) return;
          const s = this.wbDetailSelectedSkill;
          if (!s) return;
          this.undoFreeAuditPolish(
            'wb-analysisRule',
            (t) => {
              s.analysisRule = t;
            },
            () => this.scheduleWbProjectSkillDetailSync()
          );
        },
        initFromUrl() {
          const rawRoute = (window.location.hash || '').replace(/^#/, '');
          /* hash 已切到 project/ 等其它路由时仍会触发本组件的 hashchange，勿按「无 projectId」误跳工作台 */
          if (!rawRoute.startsWith('freeaudit')) return;
          const q = getFreeAuditQuery();
          if (!q.projectId) {
            message.warning('请先选择或创建工作台后再打开审计助手');
            window.location.hash = 'project';
            return;
          }
          let auxiliaryEnterStaged = false;
          try {
            if (sessionStorage.getItem('demoAuxiliaryEnterAnim') === '1') {
              sessionStorage.removeItem('demoAuxiliaryEnterAnim');
              auxiliaryEnterStaged = true;
            }
          } catch (_) { /* ignore */ }
          if (auxiliaryEnterStaged) {
            this.sourcesCollapsed = true;
            this.studioCollapsed = true;
          }
          this.workbenchProjectId = q.projectId;
          this.workbenchMaterialId = q.materialId || null;
          this.workbenchAnalysisResultId = q.analysisResultId || null;
          this.workbenchReportId = q.reportId || null;
          const pid = this.workbenchProjectId;
          const pRows = demoProjectMaterialsById[pid] || [];
          const aRows = demoProjectAnalysisResultsById[pid] || [];
          const mappedRaw = pRows.map((r) => mapProjectRowToWorkbenchMaterial(r, pid));
          const mappedAnalysis = aRows.map((r) => mapAnalysisResultRowToWorkbench(r, pid));
          this.materials = [...mappedRaw, ...mappedAnalysis];
          this.workbenchMaterialFilterPopoverOpen = false;
          this.wbSkillSidebarSearchKeyword = '';
          this.wbSkillListTagKeys = [];
          this.wbSkillListTagMatchMode = 'any';
          this.wbSkillListTagSearchQuery = '';
          this.wbSkillListTagPopoverOpen = false;
          this.wbSkillListSortBy = 'name_asc';
          this.workbenchAnalysisSearchQuery = '';
          this.workbenchAnalysisTagKeys = [];
          this.workbenchAnalysisTagMatchMode = 'any';
          this.workbenchAnalysisTagSearchQuery = '';
          this.workbenchAnalysisTagPopoverOpen = false;
          this.workbenchAnalysisSortBy = 'meta_desc';
          if (this.workbenchMaterialId && this.materials.some((x) => x.id === this.workbenchMaterialId)) this.selectedMaterialId = this.workbenchMaterialId;
          else if (this.workbenchAnalysisResultId && this.materials.some((x) => x.id === this.workbenchAnalysisResultId)) this.selectedMaterialId = this.workbenchAnalysisResultId;
          else if (this.workbenchReportId) this.selectedMaterialId = this.materials.find((x) => x.type === 'analysis')?.id || this.materials[0]?.id;
          else if (this.materials.length) this.selectedMaterialId = this.materials[0].id;
          else this.selectedMaterialId = null;
          const sel = this.selectedMaterialId ? this.materials.find((m) => m.id === this.selectedMaterialId) : null;
          this.sourcesRightView = 'list';
          if (sel) sel.checked = true;
          if (q.openTemplate) {
            this.$nextTick(() => this.openTemplateLibrary());
            const raw2 = (window.location.hash || '').replace(/^#/, '');
            if (raw2.startsWith('freeaudit?')) {
              const [base2, query2 = ''] = raw2.split('?');
              const params2 = new URLSearchParams(query2);
              params2.delete('openTemplate');
              const next2 = params2.toString() ? `${base2}?${params2.toString()}` : base2;
              window.history.replaceState(null, '', '#' + next2);
            }
          }
          if (auxiliaryEnterStaged) {
            this.$nextTick(() => {
              window.setTimeout(() => {
                this.sourcesCollapsed = false;
                this.studioCollapsed = false;
              }, 70);
            });
          }
          this.$nextTick(() => this.ensureDefaultDemoConversation());
        },
        refreshWorkbenchDemoResources(listScope) {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先进入工作台');
            return;
          }
          const pRows = demoProjectMaterialsById[pid] || [];
          const aRows = demoProjectAnalysisResultsById[pid] || [];
          const mappedRaw = pRows.map((r) => mapProjectRowToWorkbenchMaterial(r, pid));
          const mappedAnalysis = aRows.map((r) => mapAnalysisResultRowToWorkbench(r, pid));
          this.materials = [...mappedRaw, ...mappedAnalysis];
          const prevSel = this.selectedMaterialId;
          if (prevSel && this.materials.some((x) => x.id === prevSel)) {
            this.selectedMaterialId = prevSel;
          } else if (this.workbenchMaterialId && this.materials.some((x) => x.id === this.workbenchMaterialId)) {
            this.selectedMaterialId = this.workbenchMaterialId;
          } else if (this.workbenchAnalysisResultId && this.materials.some((x) => x.id === this.workbenchAnalysisResultId)) {
            this.selectedMaterialId = this.workbenchAnalysisResultId;
          } else if (this.workbenchReportId) {
            this.selectedMaterialId = this.materials.find((x) => x.type === 'analysis')?.id || this.materials[0]?.id || null;
          } else if (this.materials.length) {
            this.selectedMaterialId = this.materials[0].id;
          } else {
            this.selectedMaterialId = null;
          }
          const sel = this.selectedMaterialId ? this.materials.find((m) => m.id === this.selectedMaterialId) : null;
          if (sel) sel.checked = true;
          this.workbenchMaterialStatusPopoverOpenQueued = false;
          this.workbenchMaterialStatusPopoverOpenParsing = false;
          this.workbenchMaterialStatusPopoverOpenFailed = false;
          this.workbenchAnalysisStatusPopoverOpenQueued = false;
          this.workbenchAnalysisStatusPopoverOpenParsing = false;
          this.workbenchAnalysisStatusPopoverOpenFailed = false;
          this.wbSkillGeneratingPopoverOpen = false;
          this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          const scope = listScope === 'skill' ? 'skill' : listScope === 'result' ? 'result' : 'material';
          const hint =
            scope === 'result'
              ? '结果列表已与演示数据同步；助手对话未刷新。'
              : scope === 'skill'
                ? '技能列表已与演示数据同步；助手对话未刷新。'
                : '资料列表已与演示数据同步；助手对话未刷新。';
          message.success(hint);
        },
        openProjectCenterUpload() {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先进入工作台并打开审计助手后再上传资料');
            return;
          }
          window.location.hash = 'project/' + encodeURIComponent(pid) + '?openUpload=1';
        },
        onWorkbenchTemplateAddMenu(info) {
          const key = info && info.key;
          if (key === 'library') {
            this.openTemplateLibrary();
            return;
          }
          if (key === 'new') {
            const pid = this.workbenchProjectId;
            if (!pid) {
              message.warning('请先通过工作台进入本工作台的审计助手后再创建技能');
              return;
            }
            this.openWbProjectSkillCreateBasicModal();
          }
        },
        openTemplateLibrary() {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先通过工作台进入本工作台的审计助手后再引用技能');
            return;
          }
          const bridge = window.__demoQuoteSkillBridge;
          if (bridge && typeof bridge.openForWorkbenchProject === 'function') {
            bridge.openForWorkbenchProject(pid);
            return;
          }
          message.warning('引用技能面板暂不可用，请先从「工作台」进入一次后再试');
        },
        selectWorkbenchSkillTemplate(node) {
          if (!node || !node.key) return;
          if (this.isWbProjectSkillSummarizing(node.raw)) {
            message.info('该工作台技能正在总结中，暂不可引用');
            return;
          }
          this.wbSelectedTemplateKey = this.wbSelectedTemplateKey === node.key ? '' : node.key;
        },
        onWbSkillTreeLeafContextMenu(node) {
          if (!node || !node.key) return;
          this.wbSkillTreeActionMenuKey = node.key;
        },
        onWbSkillTreeActionMenuOpenUpdate(open, node) {
          if (open) {
            this.wbSkillTreeActionMenuKey = node && node.key ? node.key : null;
          } else if (node && node.key && this.wbSkillTreeActionMenuKey === node.key) {
            this.wbSkillTreeActionMenuKey = null;
          }
        },
        onWbProjectSkillTreeMenu(info, node) {
          const key = info && info.key;
          const tpl = node && node.raw;
          if (!tpl) return;
          if (this.isWbProjectSkillSummarizing(tpl) && key !== 'delete') {
            message.info('该工作台技能正在总结中，完成后可查看与操作');
            return;
          }
          if (key === 'cite') {
            const name = String(tpl.name != null ? tpl.name : '未命名').trim() || '未命名';
            this.appendChatInputToken('/' + name);
          } else if (key === 'archive') {
            this.wbArchiveProjectTemplatesToMyLibrary([tpl]);
          } else if (key === 'delete') {
            this.wbDeleteProjectAnalysisTemplate(tpl, node.key);
          }
        },
        wbArchiveProjectTemplatesToMyLibrary(templates) {
          const pid = this.workbenchProjectId;
          if (!pid) return;
          const selected = (templates || []).filter(Boolean);
          if (!selected.length) {
            message.warning('没有可入库的技能');
            return;
          }
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const privatePool = this.analysisTemplatePool.private || [];
          const usedIds = new Set(privatePool.map((x) => x.id));
          const inserted = [];
          selected.forEach((tpl) => {
            let newId = typeof newSkillId === 'function' ? newSkillId('priv-arch') : 'priv-arch-' + Date.now();
            while (usedIds.has(newId)) {
              newId = typeof newSkillId === 'function' ? newSkillId('priv-arch') : newId + 'x';
            }
            usedIds.add(newId);
            let skillFiles = [];
            if (typeof window.DemoSkillFileTree !== 'undefined' && window.DemoSkillFileTree.remapSkillFilesTree) {
              skillFiles = window.DemoSkillFileTree.remapSkillFilesTree(tpl.skillFiles || []);
            } else if (Array.isArray(tpl.extractionRules) && tpl.extractionRules.length) {
              skillFiles = tpl.extractionRules.map((r, ri) => ({
                id: newId + '-sf' + (ri + 1),
                kind: 'file',
                fileKind: 'md',
                codeLang: '',
                filename: (String(r.title || '').trim() || '条目' + (ri + 1)) + '.md',
                content: String(r.body || ''),
              }));
            }
            const row = {
              id: newId,
              name: tpl.name,
              description: (tpl.description != null ? tpl.description : '') || '',
              tags: Array.isArray(tpl.tags) ? tpl.tags.slice() : [],
              skillFiles,
              extractionRules: [],
              analysisRule: tpl.analysisRule || '',
              applicableScenario: tpl.applicableScenario != null ? String(tpl.applicableScenario) : '',
              createdAt: now,
              updatedAt: now,
              library: 'private',
              publishedVersions: [],
              sourceSkillId: tpl.id,
              sourceLibrary: 'project',
              sourceSkillName: tpl.name || tpl.id,
              sourceVersionLabel: '工作台实例',
            };
            if (typeof window.DemoSkillFileTree !== 'undefined' && window.DemoSkillFileTree.syncExtractionRulesFromSkillFiles) {
              window.DemoSkillFileTree.syncExtractionRulesFromSkillFiles(row);
            }
            inserted.push(row);
          });
          const priv = this.analysisTemplatePool.private || [];
          inserted.forEach((row) => priv.push(row));
          message.success(`已将 ${inserted.length} 个技能入库到「我的技能」`);
        },
        wbDeleteProjectAnalysisTemplate(template, nodeKey) {
          if (!template || !this.workbenchProjectId) return;
          const id = String(template.id || '');
          const pid = this.workbenchProjectId;
          Modal.confirm({
            centered: true,
            title: '确定删除该技能？',
            content: '删除后将从当前工作台移除该技能。',
            okText: '删除',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              const taskId = this.summarySkillTaskByTemplateId && this.summarySkillTaskByTemplateId[id];
              if (taskId) {
                this._clearSummaryTaskTimers(taskId);
                this.summaryTemplateTasks = (this.summaryTemplateTasks || []).filter((x) => x.id !== taskId);
                const map = { ...(this.summarySkillTaskByTemplateId || {}) };
                delete map[id];
                this.summarySkillTaskByTemplateId = map;
              }
              const list = demoProjectAnalysisTemplatesById[pid] || [];
              demoProjectAnalysisTemplatesById[pid] = list.filter((x) => String(x.id) !== id);
              if (nodeKey && this.wbSelectedTemplateKey === nodeKey) this.wbSelectedTemplateKey = '';
              if (String(this.wbProjectSkillDetailId) === id) {
                this._wbProjectSkillModalSnapshot = null;
                this.closeWbProjectSkillDetailModal(false);
              }
              message.success('技能已删除');
            },
          });
        },
        openWbProjectSkillDetailFromNode(node, options) {
          if (!node || !node.raw) return;
          if (this.isWbProjectSkillSummarizing(node.raw)) {
            message.info('该工作台技能正在总结中，完成后可查看');
            return;
          }
          const readOnly = !!(options && options.readOnly);
          this.openWbProjectSkillDetail(node.raw, { readOnly });
        },
        isWbProjectSkillSummarizing(template) {
          const id = template && template.id ? String(template.id) : '';
          if (!id) return false;
          return !!(this.summarySkillTaskByTemplateId && this.summarySkillTaskByTemplateId[id]);
        },
        syncWbProjectSkillFormFromSkill(s) {
          if (!s) return;
          this.wbProjectSkillForm = {
            id: s.id,
            name: s.name || '',
            description: s.description != null ? String(s.description) : '',
            tags: Array.isArray(s.tags) ? [...s.tags] : [],
          };
        },
        syncWbProjectSkillFormToSelected() {
          const s = this.wbDetailSelectedSkill;
          if (!s || this.wbProjectSkillDetailReadOnly) return;
          const name = String(this.wbProjectSkillForm.name || '').trim();
          const desc = String(this.wbProjectSkillForm.description || '').trim();
          const tagList = [...(this.wbProjectSkillForm.tags || [])].map((t) => String(t).trim()).filter(Boolean);
          const tags = tagList.length ? Array.from(new Set(tagList)) : ['技能'];
          s.name = name;
          s.description = desc;
          s.tags = tags;
        },
        validateWbProjectSkillFilesForSave() {
          const s = this.wbDetailSelectedSkill;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!s || !T) return false;
          const dups = T.findDuplicatePaths(s.skillFiles || []);
          if (dups.length) {
            message.warning('文件名路径重复：' + dups.join('、'));
            return false;
          }
          if (!String(s.analysisRule || '').trim()) {
            message.warning('请填写审计思路');
            return false;
          }
          let bad = false;
          const walk = (nodes) => {
            (nodes || []).forEach((n) => {
              if (!n) return;
              if (n.kind === 'folder') {
                if (!String(n.name || '').trim()) bad = true;
                walk(n.children);
              } else if (n.kind === 'file') {
                if (!String(n.filename || '').trim() || !String(n.content || '').trim()) bad = true;
              }
            });
          };
          walk(s.skillFiles || []);
          if (bad) {
            message.warning('每个文件夹须有名称；每个文件须填写文件名与具体内容');
            return false;
          }
          return true;
        },
        hydrateWbProjectSkillForModal(target) {
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!target || !T) return target;
          if (T.ensureSkillFiles) T.ensureSkillFiles(target);
          if (T.syncExtractionRulesFromSkillFiles) T.syncExtractionRulesFromSkillFiles(target);
          if (Array.isArray(target.extractionRules)) {
            target.extractionRules = target.extractionRules.map((x) =>
              window.DemoProjectSkillMatch ? window.DemoProjectSkillMatch.dedupeRuleMaterialIds(x) : x
            );
          }
          return target;
        },
        refreshWbProjectSkillModalSnapshotAfterPaneSave() {
          const s = this.wbDetailSelectedSkill;
          const pid = this.workbenchProjectId;
          if (!s || !pid) return;
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          const f = list.find((x) => String(x.id) === String(s.id));
          if (f) this._wbProjectSkillModalSnapshot = JSON.parse(JSON.stringify(f));
        },
        startWbProjectSkillBasicPaneEdit() {
          if (this.wbProjectSkillDetailReadOnly) return;
          this._wbProjectSkillBasicPaneSnap = {
            name: this.wbProjectSkillForm.name,
            description: this.wbProjectSkillForm.description,
            tags: Array.isArray(this.wbProjectSkillForm.tags) ? [...this.wbProjectSkillForm.tags] : [],
          };
          this.wbProjectSkillBasicPaneEditing = true;
        },
        cancelWbProjectSkillBasicPaneEdit() {
          const snap = this._wbProjectSkillBasicPaneSnap;
          if (snap) {
            this.wbProjectSkillForm.name = snap.name;
            this.wbProjectSkillForm.description = snap.description;
            this.wbProjectSkillForm.tags = snap.tags ? [...snap.tags] : [];
          }
          this._wbProjectSkillBasicPaneSnap = null;
          this.wbProjectSkillBasicPaneEditing = false;
        },
        saveWbProjectSkillBasicPane() {
          if (this.wbProjectSkillDetailReadOnly) return;
          const name = String(this.wbProjectSkillForm.name || '').trim();
          if (!name) {
            message.warning('请填写名称');
            return;
          }
          if (this._wbProjectSkillDetailSyncTimer) {
            window.clearTimeout(this._wbProjectSkillDetailSyncTimer);
            this._wbProjectSkillDetailSyncTimer = null;
          }
          this.syncWbProjectSkillFormToSelected();
          this.syncWbProjectSkillDetailNow();
          this._wbProjectSkillCreateCommitted = true;
          this.refreshWbProjectSkillModalSnapshotAfterPaneSave();
          this.wbProjectSkillBasicPaneEditing = false;
          this._wbProjectSkillBasicPaneSnap = null;
          if (this.wbProjectSkillDetailModalIsCreate) this.wbProjectSkillDetailModalIsCreate = false;
          message.success('基本信息已保存');
        },
        startWbProjectSkillConfigPaneEdit() {
          if (this.wbProjectSkillDetailReadOnly) return;
          const s = this.wbDetailSelectedSkill;
          if (!s) return;
          this._wbProjectSkillConfigPaneSnap = JSON.parse(JSON.stringify(s));
          this.wbProjectSkillConfigPaneEditing = true;
        },
        cancelWbProjectSkillConfigPaneEdit() {
          const snap = this._wbProjectSkillConfigPaneSnap;
          const pid = this.workbenchProjectId;
          if (snap && pid) {
            const list = demoProjectAnalysisTemplatesById[pid] || [];
            const idx = list.findIndex((x) => String(x.id) === String(snap.id));
            if (idx >= 0) {
              list.splice(idx, 1, JSON.parse(JSON.stringify(snap)));
              demoProjectAnalysisTemplatesById[pid] = [...list];
            }
          }
          this._wbProjectSkillConfigPaneSnap = null;
          this.wbProjectSkillConfigPaneEditing = false;
          this.$nextTick(() => this.ensureWbProjectSkillFirstObjectExpanded());
        },
        saveWbProjectSkillConfigPane() {
          if (this.wbProjectSkillDetailReadOnly) return;
          if (!this.validateWbProjectSkillFilesForSave()) return;
          if (this._wbProjectSkillDetailSyncTimer) {
            window.clearTimeout(this._wbProjectSkillDetailSyncTimer);
            this._wbProjectSkillDetailSyncTimer = null;
          }
          this.syncWbProjectSkillFormToSelected();
          this.syncWbProjectSkillDetailNow();
          this._wbProjectSkillCreateCommitted = true;
          this.refreshWbProjectSkillModalSnapshotAfterPaneSave();
          this.wbProjectSkillConfigPaneEditing = false;
          this._wbProjectSkillConfigPaneSnap = null;
          if (this.wbProjectSkillDetailModalIsCreate) this.wbProjectSkillDetailModalIsCreate = false;
          message.success('技能配置已保存');
        },
        startWbProjectSkillResourcePaneEdit() {
          if (this.wbProjectSkillDetailReadOnly) return;
          const s = this.wbDetailSelectedSkill;
          if (!s) return;
          this._wbProjectSkillResourcePaneSnap = this.getWbSkillLinkedResourceIds(s);
          this.wbProjectSkillResourcePaneEditing = true;
        },
        cancelWbProjectSkillResourcePaneEdit() {
          const s = this.wbDetailSelectedSkill;
          if (s && Array.isArray(this._wbProjectSkillResourcePaneSnap)) {
            s.linkedResourceIds = this._wbProjectSkillResourcePaneSnap.slice();
          }
          this._wbProjectSkillResourcePaneSnap = null;
          this.wbProjectSkillResourcePaneEditing = false;
        },
        saveWbProjectSkillResourcePane() {
          if (this.wbProjectSkillDetailReadOnly) return;
          const s = this.wbDetailSelectedSkill;
          if (!s) return;
          s.linkedResourceIds = this.getWbSkillLinkedResourceIds(s);
          this.syncWbProjectSkillDetailNow();
          this._wbProjectSkillCreateCommitted = true;
          this.refreshWbProjectSkillModalSnapshotAfterPaneSave();
          this.wbProjectSkillResourcePaneEditing = false;
          this._wbProjectSkillResourcePaneSnap = null;
          message.success('关联资源已保存');
        },
        onWbProjectSkillTabUpdate(key) {
          const next = String(key || 'basic');
          if (next === String(this.wbProjectSkillDetailActiveTab)) return;
          const leaving = String(this.wbProjectSkillDetailActiveTab);
          if (
            (leaving === 'basic' && this.wbProjectSkillBasicPaneEditing)
            || (leaving === 'config' && this.wbProjectSkillConfigPaneEditing)
            || (leaving === 'resource' && this.wbProjectSkillResourcePaneEditing)
          ) {
            Modal.confirm({
              centered: true,
              title: '有未保存的编辑',
              content: '切换页签将放弃当前页签的未保存修改，是否继续？',
              okText: '放弃并切换',
              cancelText: '留在本页',
              onOk: () => {
                if (leaving === 'basic') this.cancelWbProjectSkillBasicPaneEdit();
                if (leaving === 'config') this.cancelWbProjectSkillConfigPaneEdit();
                if (leaving === 'resource') this.cancelWbProjectSkillResourcePaneEdit();
                this.wbProjectSkillDetailActiveTab = next;
              },
            });
            return;
          }
          this.wbProjectSkillDetailActiveTab = next;
        },
        openWbProjectSkillDetail(template, options) {
          const pid = this.workbenchProjectId;
          if (!template || !template.id || !pid) return;
          const readOnly = !!(options && options.readOnly);
          this.wbProjectSkillBasicPaneEditing = false;
          this.wbProjectSkillConfigPaneEditing = false;
          this.wbProjectSkillResourcePaneEditing = false;
          this._wbProjectSkillBasicPaneSnap = null;
          this._wbProjectSkillConfigPaneSnap = null;
          this._wbProjectSkillResourcePaneSnap = null;
          this._wbProjectSkillCreateCommitted = false;
          this.wbProjectSkillDetailReadOnly = readOnly;
          this.wbProjectSkillDetailModalIsCreate = false;
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          const idx = list.findIndex((x) => x.id === template.id);
          if (idx < 0) return;
          const target = list[idx];
          this.hydrateWbProjectSkillForModal(target);
          demoProjectAnalysisTemplatesById[pid] = [...list];
          const fresh = (demoProjectAnalysisTemplatesById[pid] || []).find((x) => x.id === target.id) || target;
          if (!readOnly) {
            this._wbProjectSkillModalSnapshot = JSON.parse(JSON.stringify(fresh));
          } else {
            this._wbProjectSkillModalSnapshot = null;
          }
          this.wbProjectSkillDetailId = fresh.id;
          this.wbProjectSkillDetailActiveTab = readOnly ? 'config' : 'basic';
          this.syncWbProjectSkillFormFromSkill(fresh);
          this.wbProjectSkillConfigNavKey = 'rule';
          this.wbProjectSkillDetailModalOpen = true;
          this.$nextTick(() => this.ensureWbProjectSkillFirstObjectExpanded());
        },
        openWbProjectSkillCreateBasicModal() {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先通过工作台进入本工作台的审计助手后再创建技能');
            return;
          }
          this.wbProjectSkillCreateBasicSubmitting = false;
          this.wbProjectSkillCreateBasicForm = { name: '', description: '', tags: [] };
          this.wbProjectSkillCreateBasicModalOpen = true;
        },
        closeWbProjectSkillCreateBasicModal() {
          this.wbProjectSkillCreateBasicSubmitting = false;
          this.wbProjectSkillCreateBasicModalOpen = false;
        },
        submitWbProjectSkillCreateBasic() {
          if (this.wbProjectSkillCreateBasicSubmitting) return;
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先通过工作台进入本工作台的审计助手后再创建技能');
            return;
          }
          const name = String(this.wbProjectSkillCreateBasicForm.name || '').trim();
          if (!name) {
            message.warning('请填写技能名称');
            return;
          }
          this.wbProjectSkillCreateBasicSubmitting = true;
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const newId = 'sk-prj-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
          const row = {
            id: newId,
            library: 'project',
            name,
            description: String(this.wbProjectSkillCreateBasicForm.description || '').trim(),
            tags: Array.from(new Set((this.wbProjectSkillCreateBasicForm.tags || []).map((t) => String(t).trim()).filter(Boolean))),
            autoMatchOnSave: true,
            skillFiles: [],
            extractionRules: [],
            analysisRule: '',
            applicableScenario: '',
            createdAt: now,
            updatedAt: now,
            createdBy: '我',
            matchStatus: 'pending_config',
            matchPhase: '待配置',
            matchProgress: 0,
          };
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          list.unshift(row);
          demoProjectAnalysisTemplatesById[pid] = [...list];
          this.wbProjectSkillDetailModalIsCreate = true;
          this.wbProjectSkillDetailReadOnly = false;
          this._wbProjectSkillModalSnapshot = null;
          this.wbProjectSkillBasicPaneEditing = false;
          this.wbProjectSkillConfigPaneEditing = true;
          this.wbProjectSkillResourcePaneEditing = false;
          this._wbProjectSkillBasicPaneSnap = null;
          this._wbProjectSkillConfigPaneSnap = null;
          this._wbProjectSkillResourcePaneSnap = null;
          this._wbProjectSkillCreateCommitted = false;
          this.wbProjectSkillDetailId = row.id;
          this.wbProjectSkillDetailActiveTab = 'config';
          this.syncWbProjectSkillFormFromSkill(row);
          this.wbProjectSkillConfigNavKey = 'rule';
          this.wbProjectSkillCreateBasicSubmitting = false;
          this.wbProjectSkillCreateBasicModalOpen = false;
          this.wbProjectSkillDetailModalOpen = true;
          this.$nextTick(() => this.ensureWbProjectSkillFirstObjectExpanded());
        },
        openWbProjectSkillCreateUnified() {
          this.openWbProjectSkillCreateBasicModal();
        },
        ensureWbProjectSkillFirstObjectExpanded() {
          const s = this.wbDetailSelectedSkill;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (s && T && T.ensureSkillFiles) T.ensureSkillFiles(s);
          this.wbProjectSkillConfigNavKey = 'rule';
          this.wbProjectSkillConfigTreeExpandedKeys = s && T && T.defaultExpandedKeys ? T.defaultExpandedKeys(s.skillFiles || []) : [];
        },
        closeWbProjectSkillDetailModal(fromSave) {
          const saved = fromSave === true;
          const createCommitted = this._wbProjectSkillCreateCommitted;
          if (this._wbProjectSkillDetailSyncTimer) {
            window.clearTimeout(this._wbProjectSkillDetailSyncTimer);
            this._wbProjectSkillDetailSyncTimer = null;
          }
          const templateId = this.wbProjectSkillDetailId;
          const pid = this.workbenchProjectId;
          const wasCreate = this.wbProjectSkillDetailModalIsCreate;
          const wasReadOnly = this.wbProjectSkillDetailReadOnly;
          if (!saved && pid) {
            if (wasCreate && templateId && !createCommitted) {
              const list = demoProjectAnalysisTemplatesById[pid] || [];
              demoProjectAnalysisTemplatesById[pid] = list.filter((x) => String(x.id) !== String(templateId));
            } else if (!wasReadOnly && this._wbProjectSkillModalSnapshot && templateId) {
              const list = demoProjectAnalysisTemplatesById[pid] || [];
              const idx = list.findIndex((x) => String(x.id) === String(templateId));
              if (idx >= 0) {
                list.splice(idx, 1, JSON.parse(JSON.stringify(this._wbProjectSkillModalSnapshot)));
                demoProjectAnalysisTemplatesById[pid] = [...list];
              }
            }
          }
          this._wbProjectSkillModalSnapshot = null;
          this.wbProjectSkillDetailModalIsCreate = false;
          this.wbProjectSkillDetailModalOpen = false;
          this.wbProjectSkillDetailReadOnly = false;
          this.wbProjectSkillDetailId = '';
          this.wbProjectSkillConfigNavKey = 'rule';
          this.wbProjectSkillConfigTreeExpandedKeys = [];
          this.wbProjectSkillDetailActiveTab = 'basic';
          this.wbProjectSkillBasicPaneEditing = false;
          this.wbProjectSkillConfigPaneEditing = false;
          this.wbProjectSkillResourcePaneEditing = false;
          this._wbProjectSkillBasicPaneSnap = null;
          this._wbProjectSkillConfigPaneSnap = null;
          this._wbProjectSkillResourcePaneSnap = null;
          this._wbProjectSkillCreateCommitted = false;
        },
        scheduleWbProjectSkillDetailSync() {
          if (this.wbProjectSkillDetailReadOnly) return;
          if (this._wbProjectSkillDetailSyncTimer) window.clearTimeout(this._wbProjectSkillDetailSyncTimer);
          this._wbProjectSkillDetailSyncTimer = window.setTimeout(() => {
            this.syncWbProjectSkillDetailNow();
            this._wbProjectSkillDetailSyncTimer = null;
          }, 250);
        },
        syncWbProjectSkillDetailNow() {
          const s = this.wbDetailSelectedSkill;
          const pid = this.workbenchProjectId;
          if (!s || !pid) return;
          if (this.wbProjectSkillDetailReadOnly) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (T && T.ensureSkillFiles) T.ensureSkillFiles(s);
          if (T && T.syncExtractionRulesFromSkillFiles) T.syncExtractionRulesFromSkillFiles(s);
          if (!Array.isArray(s.extractionRules)) s.extractionRules = [];
          s.extractionRules = s.extractionRules.map((x) => ({
            id: x.id || newSkillId('er'),
            title: String(x.title || ''),
            body: String(x.body || ''),
            materialIds: Array.isArray(x.materialIds) ? Array.from(new Set(x.materialIds.map((mid) => String(mid)))) : [],
          }));
          s.analysisRule = String(s.analysisRule || '');
          s.applicableScenario = String(s.applicableScenario || '');
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          s.updatedAt = now;
          if (!s.createdAt) {
            s.createdAt = now;
            if (!s.createdBy) s.createdBy = '我';
          }
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          const idx = list.findIndex((x) => x.id === s.id);
          if (idx >= 0) {
            list.splice(idx, 1, { ...s });
            demoProjectAnalysisTemplatesById[pid] = [...list];
          }
        },
        onWbProjectSkillConfigSaveMenuClick(info) {
          const k = info && info.key;
          if (k !== 'publish-new') return;
          message.info('保存为新版本仅在「我的技能」资产库中支持，请在工作台将技能入库后再于技能库发布版本。');
        },
        onWbProjectSkillConfigAddMenuClick(info) {
          if (this.wbProjectSkillConfigTabLocked || !this.wbDetailSelectedSkill) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T) return;
          const root = T.ensureSkillFiles(this.wbDetailSelectedSkill);
          const key = info && info.key;
          let node;
          if (key === 'md') node = T.newFileNode('md', '');
          else if (key === 'folder') node = T.newFolderNode();
          else if (String(key || '').startsWith('code:')) node = T.newFileNode('code', String(key).slice(5));
          else return;
          const parentRef = T.findAddParentRef(root, this.wbProjectSkillConfigNavKey);
          T.insertChild(root, parentRef, node);
          if (node.kind === 'file') {
            this.wbProjectSkillConfigNavKey = 'file:' + node.id;
          } else {
            this.wbProjectSkillConfigNavKey = 'folder:' + node.id;
            const ek = new Set(this.wbProjectSkillConfigTreeExpandedKeys || []);
            ek.add('folder:' + node.id);
            this.wbProjectSkillConfigTreeExpandedKeys = Array.from(ek);
          }
          this.scheduleWbProjectSkillDetailSync();
        },
        wbProjectSkillConfigTreeCanDeleteKey(treeKey) {
          if (!treeKey || treeKey === 'rule') return false;
          return String(treeKey).startsWith('file:') || String(treeKey).startsWith('folder:');
        },
        removeWbProjectSkillConfigTreeNode(treeKey) {
          if (this.wbProjectSkillConfigTabLocked || !this.wbDetailSelectedSkill) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || !treeKey || treeKey === 'rule') return;
          const id = String(treeKey).startsWith('file:')
            ? String(treeKey).slice('file:'.length)
            : String(treeKey).startsWith('folder:')
              ? String(treeKey).slice('folder:'.length)
              : '';
          if (!id) return;
          const root = T.ensureSkillFiles(this.wbDetailSelectedSkill);
          const wasNav = String(this.wbProjectSkillConfigNavKey) === String(treeKey);
          T.removeNodeById(root, id);
          if (wasNav) this.wbProjectSkillConfigNavKey = 'rule';
          this.scheduleWbProjectSkillDetailSync();
        },
        onWbProjectSkillConfigTreeSelect(selectedKeys) {
          if (!selectedKeys || !selectedKeys.length) return;
          const key = selectedKeys[0];
          this.wbProjectSkillConfigNavKey = key === 'rule' ? 'rule' : String(key);
        },
        wbProjectSkillConfigTreeNodeDraggable(node) {
          if (this.wbProjectSkillConfigTabLocked) return false;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          return !!(T && T.treeNodeIsDraggable && T.treeNodeIsDraggable(node));
        },
        onWbProjectSkillConfigTreeDrop(info) {
          if (this.wbProjectSkillConfigTabLocked || !this.wbDetailSelectedSkill) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || !T.applyTreeDropFromAntEvent) return;
          const res = T.applyTreeDropFromAntEvent(this.wbDetailSelectedSkill, info);
          if (!res.ok) {
            message.warning(res.message || '无法放置到此处');
            return;
          }
          this.scheduleWbProjectSkillDetailSync();
        },
        wbNormalizeRuleForProjectTemplate(rule) {
          const pid = this.workbenchProjectId;
          const mats = pid ? demoProjectMaterialsById[pid] || [] : [];
          return window.DemoProjectSkillMatch
            ? window.DemoProjectSkillMatch.normalizeRuleForProjectTemplate(rule, (r) =>
                window.DemoProjectSkillMatch.autoMatchMaterialIdsForRule(r, mats))
            : { ...(rule || {}), materialIds: [] };
        },
        getWbSkillLinkedResourceIds(template) {
          const t = template || {};
          const direct = Array.isArray(t.linkedResourceIds) ? t.linkedResourceIds.map((id) => String(id)).filter(Boolean) : [];
          if (direct.length) return Array.from(new Set(direct));
          const ids = new Set();
          if (Array.isArray(t.manualMaterialIds)) t.manualMaterialIds.forEach((id) => ids.add(String(id)));
          (Array.isArray(t.extractionRules) ? t.extractionRules : []).forEach((rule) => {
            (Array.isArray(rule && rule.materialIds) ? rule.materialIds : []).forEach((id) => ids.add(String(id)));
          });
          return Array.from(ids);
        },
        getWbSkillLinkedResourceCount(template) {
          return this.getWbSkillLinkedResourceIds(template).length;
        },
        getWbSkillLinkedResourceBylineState(template) {
          const ids = this.getWbSkillLinkedResourceIds(template);
          const total = ids.length;
          if (!total) {
            return {
              kind: 'idle',
              text: '未匹配到资料',
              ariaLabel: '查看匹配资料，当前未匹配',
            };
          }
          const pid = this.workbenchProjectId;
          const mats = pid ? demoProjectMaterialsById[pid] || [] : [];
          const byId = new Map(mats.map((m) => [String(m.id), m]));
          let done = 0;
          let pending = 0;
          let failed = 0;
          for (let i = 0; i < ids.length; i += 1) {
            const row = byId.get(String(ids[i]));
            const status = row && row.status ? String(row.status) : '';
            if (status === 'done') {
              done += 1;
            } else if (status === 'queued' || status === 'parsing') {
              pending += 1;
            } else if (status === 'failed') {
              failed += 1;
            } else {
              done += 1;
            }
          }
          if (pending > 0) {
            return {
              kind: 'running',
              text: '匹配中…',
              ariaLabel: '查看匹配资料，匹配中，当前完成 ' + done + ' 条，共 ' + total + ' 条',
            };
          }
          if (failed > 0) {
            return {
              kind: 'failed',
              text: '未匹配到资料',
              ariaLabel: '查看匹配资料，未匹配到资料',
            };
          }
          return {
            kind: 'success',
            text: '已匹配到 ' + total + ' 份资料',
            ariaLabel: '查看匹配资料，已匹配到 ' + total + ' 份资料',
          };
        },
        getWbSkillLinkedResources(template) {
          const pid = this.workbenchProjectId;
          const mats = pid ? demoProjectMaterialsById[pid] || [] : [];
          const byId = new Map(mats.map((m) => [String(m.id), m]));
          const ids = this.getWbSkillLinkedResourceIds(template);
          const metaMap = template && template.linkedResourceMeta && typeof template.linkedResourceMeta === 'object'
            ? template.linkedResourceMeta
            : {};
          return ids.map((id) => {
            const row = byId.get(String(id));
            return {
              id: String(id),
              name: row && row.name ? String(row.name) : String(id),
              format: row && row.format ? String(row.format) : '—',
              updatedAt: row && row.uploadedAt ? String(row.uploadedAt) : '—',
              matchSource: String(metaMap[id] || '命中配置规则'),
            };
          });
        },
        openWbSkillResourcePopover(template) {
          if (!template || !template.id) return;
          this.wbSkillResourcePopoverSkillId = String(template.id);
          this.wbSkillResourcePopoverOpen = true;
        },
        closeWbSkillResourcePopover() {
          this.wbSkillResourcePopoverOpen = false;
          this.wbSkillResourcePopoverSkillId = '';
        },
        openWbSkillResourceEditor(template) {
          if (!template) return;
          this.closeWbSkillResourcePopover();
          this.openWbProjectSkillDetail(template, { readOnly: false });
          this.wbProjectSkillDetailActiveTab = 'resource';
        },
        saveWbProjectSkillConfig() {
          const pid = this.workbenchProjectId;
          if (!pid || !this.wbDetailSelectedSkill || !window.DemoProjectSkillMatch) return;
          this.syncWbProjectSkillDetailNow();
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          const fresh = list.find((x) => x.id === this.wbDetailSelectedSkill.id);
          if (!fresh || !window.DemoProjectSkillMatch.validateProjectSkillConfigForMatch(fresh, message)) return;
          const idx = list.findIndex((x) => x.id === fresh.id);
          if (idx < 0) return;
          const row = { ...list[idx] };
          row.extractionRules = (row.extractionRules || [])
            .map((x) => ({
              id: x.id || newSkillId('er'),
              title: String(x.title || '').trim(),
              body: String(x.body || '').trim(),
              materialIds: Array.isArray(x.materialIds) ? Array.from(new Set(x.materialIds.map((mid) => String(mid)))) : [],
            }))
            .filter((x) => String(x.title || '').trim() && String(x.body || '').trim());
          row.analysisRule = String(row.analysisRule || '').trim();
          row.applicableScenario = String(row.applicableScenario || '').trim();
          const normRules = row.extractionRules.map((r) => this.wbNormalizeRuleForProjectTemplate(r));
          row.extractionRules = normRules;
          row.manualMaterialIds = Array.from(
            new Set(normRules.flatMap((r) => (Array.isArray(r.materialIds) ? r.materialIds : []).map((x) => String(x)))),
          );
          list.splice(idx, 1, row);
          demoProjectAnalysisTemplatesById[pid] = [...list];
          this.closeWbProjectSkillDetailModal(true);
          message.success('配置已保存');
        },
        wbProjectSkillModalCreator(sk) {
          if (!sk) return '—';
          return sk.createdBy || '我';
        },
        wbProjectSkillModalCreatedDateYmd(sk) {
          if (!sk || sk.createdAt == null || sk.createdAt === '') return '—';
          const t = String(sk.createdAt).trim();
          const m = t.match(/^(\d{4}-\d{2}-\d{2})/);
          if (m) return m[1];
          return t.slice(0, 10) || '—';
        },
        wbProjectSkillModalUpdatedCompact(sk) {
          if (!sk) return '—';
          const raw = sk.updatedAt != null && sk.updatedAt !== '' ? sk.updatedAt : sk.createdAt;
          if (raw == null || raw === '') return '—';
          const t = String(raw).trim();
          const m = t.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/);
          if (m) return `${m[2]}-${m[3]} ${m[4]}:${m[5]}`;
          const m2 = t.match(/^(\d{4})-(\d{2})-(\d{2})/);
          if (m2) return `${m2[2]}-${m2[3]}`;
          return t.slice(0, 16) || '—';
        },
        buildDemoAnalysisBotMessage(userText) {
          const atTitles = this.parseChatInputAtReferences(userText);
          let mat = null;
          for (let i = 0; i < atTitles.length; i++) {
            const title = atTitles[i];
            mat = this.materials.find((m) => String(m.title != null ? m.title : '未命名').trim() === title);
            if (mat) break;
          }
          if (!mat) mat = this.materials.find((m) => m.checked) || this.materials[0];
          const materials = this.materials || [];
          const rawList = materials.filter((m) => m && (m.type === 'raw' || m.type === undefined));
          const analysisTarget = (this.selectedMaterial && this.selectedMaterial.type === 'analysis')
            ? this.selectedMaterial
            : materials.find((m) => m.type === 'analysis');
          const baseRaw = mat && (mat.type === 'raw' || mat.type === undefined) ? mat : (rawList[0] || mat || materials[0]);
          const secondRaw = rawList.find((m) => m.id !== baseRaw?.id) || baseRaw;
          const thirdRaw = rawList.find((m) => m.id !== baseRaw?.id && m.id !== secondRaw?.id) || secondRaw;
          /** 与 SUMMARY 正文 [1][2][3][4] 一一对应，保证均可点击溯源 */
          const citationSlots = [
            baseRaw,
            analysisTarget && analysisTarget.id ? analysisTarget : baseRaw,
            secondRaw,
            thirdRaw || analysisTarget || baseRaw,
          ];
          let citations = citationSlots
            .filter((m) => m && m.id)
            .map((m) => ({ sourceId: m.id, excerptIndex: 0 }));
          while (citations.length < 4 && baseRaw && baseRaw.id) {
            citations.push({ sourceId: baseRaw.id, excerptIndex: 0 });
          }
          if (!citations.length && materials.length) {
            const fb = materials[0];
            citations = [{ sourceId: fb.id, excerptIndex: 0 }];
            while (citations.length < 4) citations.push({ sourceId: fb.id, excerptIndex: 0 });
          }
          const fullText = SUMMARY_RESPONSE_DEMO.replace('总结当前工作台中的主要疑点', userText ? `「${userText}」` : '所选资料');
          const splitIdx = fullText.indexOf('\n\n');
          let chatIntro = null;
          let bodyText = fullText;
          if (splitIdx > 0) {
            const intro = fullText.slice(0, splitIdx).trimEnd();
            const body = fullText.slice(splitIdx + 2).trimStart();
            if (intro) {
              chatIntro = intro;
              bodyText = body;
            }
          }
          return {
            id: 'm' + Date.now() + 2,
            role: 'bot',
            text: bodyText,
            ...(chatIntro ? { chatIntro, chatIntroProgress: 0 } : {}),
            chatRunSummary: DEMO_RUN_SUMMARY_TEXT,
            chatRunSummaryProgress: 0,
            citations,
            saved: false,
          };
        },
        /** 演示用：旁白（text）、深度思考（deep_think）、工具步；技能调用后进入「规划中」清单（仅计划+勾选），执行过程在卡片下方以对话行追加（与真实模型无关） */
        buildDemoToolCalls(refTitles, userText) {
          const rawTitle = (Array.isArray(refTitles) && refTitles[0]) || (this.materials[0] && this.materials[0].title) || '工作台已加载资料';
          const fileLabel = String(rawTitle != null ? rawTitle : '资料').trim() || '资料';
          const q = String(userText || '').trim();
          const queryText = q.length >= 2 ? q.slice(0, 48) + (q.length > 48 ? '…' : '') : '合同金额 · 发票 · 审批流水';
          const lead = q.length >= 2
            ? `针对「${q.length > 20 ? q.slice(0, 18) + '…' : q}」，先对齐本次要用的资料范围与期望产出（疑点描述、证据指向、后续核查建议）。`
            : '先对齐本次问题的范围：结合工作台内已选资料与既有分析结果，输出可追溯的疑点与证据链。';
          return [
            { type: 'text', body: lead },
            {
              type: 'deep_think',
              body:
                '从「尾款 50%」与发票价税合计两条线索出发，优先验证时间先后：若发票早于合同约定的里程碑节点，需区分是预开票、暂估还是流程倒置；若晚于付款审批，则重点核对银行回单摘要与会计科目归集。\n\n'
                + '另需交叉核对：合同含税总额与采购订单、验收单是否闭环；若存在拆分开票或负数调整行，是否在备注与附件索引中可追溯；同时将「尾款」触发条件与保函/质保金释放条款对照，避免把制度性尾款与商务尾款混为一谈。',
            },
            { type: 'read', fileLabel, lineStart: 10, lineEnd: 30 },
            {
              type: 'text',
              body: '这一段同时出现付款节点、比例与「尾款」表述，和发票开具金额、审批流水里的实际支付时点可能对不上。下面在资料与结果里分多轮关键词检索，缩小需要人工核对的片段。',
            },
            { type: 'query', text: queryText },
            { type: 'query', text: '尾款 · 付款节点 · 合同 50%' },
            { type: 'query', text: '应付账款 · 银行流水 · 实际支付日期', demoToolStatus: 'fail' },
            { type: 'query', text: '采购审批单 · 发票号码 · 价税合计' },
            {
              type: 'text',
              body: '检索命中若干段落；从金额、日期、科目三个维度粗对齐后，把仍无法解释的差额标成待核实项。接下来调用结构化技能做归纳与引用编号，再由技能要求驱动后续落地步骤。',
            },
            { type: 'skill', name: '疑点归纳与交叉核对' },
            {
              type: 'text',
              body: '技能先给出检查框架与疑点口径（金额口径、时点先后、主体一致性）。下面按技能规则把核查动作拆成任务，先执行检索与回读，再统一产出结构化中间结果。',
            },
            {
              type: 'todo',
              contextFileLabel: fileLabel,
              items: [
                '按技能检查项核对「付款节点—发票—流水」时间链',
                '对未命中检索构造替代关键词并写入扩展备忘',
                '汇总异常并形成结构化中间结果，准备落入审计备忘录',
              ],
            },
            {
              type: 'analysis',
              id: 'analysis-' + Date.now().toString(36),
              fileName: '中间结果.csv',
              analysisArtifact: this.buildDemoAnalysisArtifact(refTitles, userText),
            },
            {
              type: 'text',
              body: '核查任务已完成并生成中间结果：疑点条目、证据引用与风险分级已结构化。现在把可读结论同步写入审计备忘录草案，便于你继续追问或直接保存到结果。',
            },
            {
              type: 'edit',
              fileName: '审计备忘录-疑点摘录.md',
              /** 演示：点击 diff 卡标题栏时在结果栏打开的分析结果标题（正式环境可由接口返回结果 ID） */
              previewResultTitle: '合同与发票一致性检查结果',
              added: 2,
              removed: 1,
              diffExpanded: false,
              diffLines: [
                '- 待核实：合同金额与已开发票差异（演示）',
                '+ 待核实：合同金额与已开发票差异 [高风险]（演示）',
                '+ 建议：补充 2024Q4 对账单及剩余发票复印件',
                '  （上下文）第四条 付款方式按进度支付，尾款 50%。',
                '- 备注：原草稿行，仅在展开后可见',
                '+ 备注：已关联采购审批单 PR-2026-014',
              ],
            },
          ];
        },
        /** 与 type===text 相同：按字符流式输出（深度思考 deep_think） */
        isToolCallTextStream(call) {
          return !!(call && (call.type === 'text' || call.type === 'deep_think'));
        },
        /** deep_think 步已结束（进入后续 toolCalls）后收起为一行「思考 Ns」 */
        isDeepThinkCollapsed(msg, i) {
          if (!msg || msg.role !== 'thinking') return true;
          if (msg.thinkPhaseIndex == null) {
            return i < (msg.currentStep ?? 0);
          }
          return i < (msg.thinkPhaseIndex ?? 0);
        },
        formatDeepThinkSeconds(call) {
          const ms = call && call.deepThinkDurationMs;
          if (ms == null || Number.isNaN(ms)) return '1秒';
          const sec = Math.max(1, Math.round(ms / 1000));
          return sec + '秒';
        },
        toggleDeepThinkUserExpand(call) {
          if (!call || call.type !== 'deep_think') return;
          call.deepThinkUserExpanded = !call.deepThinkUserExpanded;
        },
        todoItemIsDone(call, ti) {
          return !!(call && call.todoDoneFlags && call.todoDoneFlags[ti]);
        },
        /** 规划中 | 执行中 | 执行完成（已翻篇的步骤固定为执行完成） */
        todoCardHeaderLabel(msg, i, call) {
          if (!call || call.type !== 'todo') return '规划中';
          const phase = msg.thinkPhaseIndex ?? 0;
          const past =
            msg.thinkPhaseIndex == null ? i < (msg.currentStep ?? 0) : i < phase;
          if (past) return '执行完成';
          if (call._todoUiPhase === 'planning') return '规划中';
          if (call._todoUiPhase === 'executing') return '执行中';
          if (call._todoUiPhase === 'complete') return '执行完成';
          return '执行完成';
        },
        /** 仅执行中及之后展示任务清单与下方动作流 */
        todoTaskListVisible(msg, i, call) {
          if (!call || call.type !== 'todo') return false;
          const phase = msg.thinkPhaseIndex ?? 0;
          const past =
            msg.thinkPhaseIndex == null ? i < (msg.currentStep ?? 0) : i < phase;
          if (past) return true;
          return call._todoUiPhase === 'executing' || call._todoUiPhase === 'complete';
        },
        /** 技能调用后「规划中」模拟步骤：思考 + 查询/编辑/阅读 + 勾选（渲染在规划卡下方的 todoExecutionLog） */
        buildTodoSimPlan(contextFileLabel) {
          const fl = String(contextFileLabel || '资料').trim() || '资料';
          return [
            { kind: 'think', text: '任务 1（技能检查项）：把合同付款节点、发票开具日与银行回单摘要映射到同一时间轴，标出「先票后款」「先款后票」类异常。', delayMs: 580 },
            { kind: 'query', text: '里程碑 · 开票日期 · 银行摘要 · 尾款 50%', delayMs: 760 },
            { kind: 'markDone', itemIndex: 0, delayMs: 440 },
            { kind: 'think', text: '任务 2（检索扩展）：对上一轮未命中段落做同义词与科目别名扩展，覆盖暂估、预开票、价税拆分等常见表述。', delayMs: 560 },
            { kind: 'query', text: '暂估 · 预开票 · 科目重分类 · 价税合计', delayMs: 720 },
            { kind: 'edit', fileName: '检索扩展备忘.md', detail: '追加候选关键词组', delayMs: 980 },
            { kind: 'markDone', itemIndex: 1, delayMs: 420 },
            { kind: 'think', text: '任务 3（汇总成型）：把已核对片段映射到疑点条目与引用编号字段，并回读资料头部摘要避免漏引。', delayMs: 540 },
            { kind: 'read', fileLabel: fl, lineStart: 1, lineEnd: 12, delayMs: 840 },
            { kind: 'markDone', itemIndex: 2, delayMs: 440 },
          ];
        },
        appendTodoExecutionLogEntry(call, step) {
          if (!call || !step || step.kind === 'markDone') return;
          if (!Array.isArray(call.todoExecutionLog)) call.todoExecutionLog = [];
          const id = 'tlog-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
          if (step.kind === 'think') {
            call.todoExecutionLog.push({ id, kind: 'think', text: step.text });
          } else if (step.kind === 'query') {
            call.todoExecutionLog.push({ id, kind: 'query', text: step.text, running: true });
          } else if (step.kind === 'read') {
            call.todoExecutionLog.push({
              id,
              kind: 'read',
              fileLabel: step.fileLabel,
              lineStart: step.lineStart,
              lineEnd: step.lineEnd,
              running: true,
            });
          } else if (step.kind === 'edit') {
            call.todoExecutionLog.push({
              id,
              kind: 'edit',
              fileName: step.fileName,
              detail: step.detail,
              running: true,
            });
          }
        },
        finalizeTodoExecutionLogEntryForStep(call, step) {
          if (!step || step.kind === 'markDone' || step.kind === 'think') return;
          const log = call.todoExecutionLog;
          if (!log || !log.length) return;
          const last = log[log.length - 1];
          if (last && last.running) last.running = false;
        },
        applyTodoMarkDoneStep(call, step) {
          if (step && step.kind === 'markDone' && call.todoDoneFlags && step.itemIndex != null) {
            const ix = step.itemIndex;
            if (ix >= 0 && ix < call.todoDoneFlags.length) {
              call.todoDoneFlags[ix] = true;
            }
          }
        },
        /** 三态：规划中（仅标题）→ 执行中（清单 1/2/3 + 下方动作）→ 执行完成；清单不在规划中展示 */
        advanceTodoPlanningDemo(thinking, idx) {
          const calls = thinking.toolCalls || [];
          const call = calls[idx];
          if (!call || call.type !== 'todo') return;
          const items = call.items || [];
          const planningHoldMs = 560;
          if (!call._todoPlanBuilt) {
            call._todoPlanBuilt = true;
            call._todoPlan = this.buildTodoSimPlan(call.contextFileLabel);
            call.todoDoneFlags = items.map(() => false);
            call._todoPlanIdx = 0;
            call.todoExecutionLog = [];
            call._todoUiPhase = 'planning';
            call._todoPlanningUntil = Date.now() + planningHoldMs;
            thinking.thinkToolStartedAt = null;
            return;
          }
          if (call._todoUiPhase === 'planning') {
            if (Date.now() < (call._todoPlanningUntil || 0)) return;
            call._todoUiPhase = 'executing';
            return;
          }
          const plan = call._todoPlan || [];
          const pi = call._todoPlanIdx ?? 0;
          if (pi >= plan.length) {
            call._todoUiPhase = 'complete';
            thinking.thinkPhaseIndex = idx + 1;
            thinking.thinkToolStartedAt = null;
            thinking.thinkTextChars = 0;
            if (thinking.thinkPhaseIndex >= calls.length) this.finalizeThinkingDemo(thinking);
            return;
          }
          const step = plan[pi];
          if (thinking.thinkToolStartedAt == null) {
            this.appendTodoExecutionLogEntry(call, step);
            thinking.thinkToolStartedAt = Date.now();
            return;
          }
          const need = step.delayMs != null ? step.delayMs : 650;
          if (Date.now() - thinking.thinkToolStartedAt < need) return;
          this.finalizeTodoExecutionLogEntryForStep(call, step);
          this.applyTodoMarkDoneStep(call, step);
          call._todoPlanIdx = pi + 1;
          thinking.thinkToolStartedAt = null;
        },
        /** 旧版 currentStep 演示兼容；新版用 thinkPhaseIndex + thinkTextChars */
        toolCallIsDone(msg, i) {
          if (msg.thinkPhaseIndex == null) {
            return i < (msg.currentStep ?? 0);
          }
          return i < (msg.thinkPhaseIndex ?? 0);
        },
        thinkingTextSlice(msg, call, i) {
          if (!this.isToolCallTextStream(call)) return '';
          const body = call.body || '';
          if (msg.thinkPhaseIndex == null) {
            const cur = msg.currentStep ?? 0;
            return i <= cur ? body : '';
          }
          const phase = msg.thinkPhaseIndex ?? 0;
          if (i < phase) return body;
          if (i > phase) return '';
          return body.slice(0, Math.min(body.length, msg.thinkTextChars ?? 0));
        },
        toolCallStepPending(msg, i) {
          const calls = msg.toolCalls || [];
          if (!calls.length) return false;
          if (msg.thinkPhaseIndex == null) {
            const cur = msg.currentStep ?? 0;
            if (cur >= calls.length) return false;
            return i === cur;
          }
          const phase = msg.thinkPhaseIndex ?? 0;
          if (phase >= calls.length || i !== phase) return false;
          const c = calls[i];
          return !!(c && !this.isToolCallTextStream(c));
        },
        /** read / query / skill / edit / todo 行首状态：进行中 | 成功 | 失败（演示） */
        toolCallActionStatus(msg, i, call) {
          if (!call || this.isToolCallTextStream(call)) return null;
          if (call.type === 'todo') {
            const plan = call._todoPlan || [];
            const pi = call._todoPlanIdx ?? 0;
            const planRunning = pi < plan.length;
            if (msg.thinkPhaseIndex == null) {
              const cur = msg.currentStep ?? 0;
              if (i < cur) return 'ok';
              if (i !== cur) return null;
              if (call._todoUiPhase === 'planning') return 'running';
              if (call._todoUiPhase === 'executing') return planRunning ? 'running' : 'ok';
              return 'ok';
            }
            const phase = msg.thinkPhaseIndex ?? 0;
            if (i < phase) return 'ok';
            if (i > phase) return null;
            if (call._todoUiPhase === 'planning') return 'running';
            if (call._todoUiPhase === 'executing') return planRunning ? 'running' : 'ok';
            return 'ok';
          }
          const calls = msg.toolCalls || [];
          if (msg.thinkPhaseIndex == null) {
            const cur = msg.currentStep ?? 0;
            if (i < cur) return call.demoToolStatus === 'fail' ? 'fail' : 'ok';
            if (i === cur && cur < calls.length) {
              const c = calls[i];
              if (c && !this.isToolCallTextStream(c)) return 'running';
            }
            return null;
          }
          const phase = msg.thinkPhaseIndex ?? 0;
          if (i < phase) return call.demoToolStatus === 'fail' ? 'fail' : 'ok';
          if (i > phase) return null;
          if (this.toolCallStepPending(msg, i)) return 'running';
          return 'ok';
        },
        advanceThinkingDemo(thinking) {
          if (!thinking || thinking._finalized) return;
          const calls = thinking.toolCalls || [];
          if (!calls.length) {
            this.finalizeThinkingDemo(thinking);
            return;
          }
          let idx = thinking.thinkPhaseIndex ?? 0;
          if (idx >= calls.length) {
            this.finalizeThinkingDemo(thinking);
            return;
          }
          const c = calls[idx];
          if (this.isToolCallTextStream(c)) {
            const body = c.body || '';
            if (!body.length) {
              if (c.type === 'deep_think') {
                c.deepThinkDurationMs = 0;
                delete c._deepThinkStart;
              }
              thinking.thinkPhaseIndex = idx + 1;
              thinking.thinkTextChars = 0;
              thinking.thinkToolStartedAt = null;
              if (thinking.thinkPhaseIndex >= calls.length) this.finalizeThinkingDemo(thinking);
              return;
            }
            let chars = thinking.thinkTextChars ?? 0;
            if (chars < body.length) {
              if (c.type === 'deep_think' && c._deepThinkStart == null) {
                c._deepThinkStart = Date.now();
              }
              const n = body.length;
              const perTick = n > 140 ? 3 : n > 55 ? 2 : 1;
              thinking.thinkTextChars = Math.min(body.length, chars + perTick);
              return;
            }
            if (c.type === 'deep_think') {
              if (c._deepThinkStart != null) {
                c.deepThinkDurationMs = Date.now() - c._deepThinkStart;
                delete c._deepThinkStart;
              } else {
                c.deepThinkDurationMs = c.deepThinkDurationMs ?? 0;
              }
            }
            thinking.thinkPhaseIndex = idx + 1;
            thinking.thinkTextChars = 0;
            thinking.thinkToolStartedAt = null;
            if (thinking.thinkPhaseIndex >= calls.length) this.finalizeThinkingDemo(thinking);
            return;
          }
          if (c.type === 'todo') {
            this.advanceTodoPlanningDemo(thinking, idx);
            return;
          }
          if (thinking.thinkToolStartedAt == null) {
            thinking.thinkToolStartedAt = Date.now();
            return;
          }
          const delays = { read: 920, query: 780, skill: 1200, analysis: 1350, edit: 1400 };
          const need = delays[c.type] || 850;
          if (Date.now() - thinking.thinkToolStartedAt < need) return;
          thinking.thinkPhaseIndex = idx + 1;
          thinking.thinkToolStartedAt = null;
          thinking.thinkTextChars = 0;
          if (thinking.thinkPhaseIndex >= calls.length) this.finalizeThinkingDemo(thinking);
        },
        /** 有 chatIntro 时先逐字显示引导句，结束后再露出 Markdown 并启动收尾总结打字 */
        displayChatIntroSlice(msg) {
          if (!msg || !msg.chatIntro) return '';
          const full = msg.chatIntro;
          const p = msg.chatIntroProgress;
          if (p == null) return full;
          return full.slice(0, Math.min(full.length, p));
        },
        chatIntroRevealMarkdown(msg) {
          if (!msg || !msg.chatIntro) return true;
          const len = (msg.chatIntro || '').length;
          const p = msg.chatIntroProgress;
          if (p == null) return true;
          return p >= len;
        },
        scheduleChatIntroTypewriter(botMsg) {
          if (!botMsg || !botMsg.chatIntro) {
            this.scheduleBotRunSummary(botMsg);
            return;
          }
          const msgId = botMsg.id;
          botMsg.chatIntroProgress = 0;
          if (botMsg._chatIntroIv) {
            clearInterval(botMsg._chatIntroIv);
            botMsg._chatIntroIv = null;
          }
          const iv = setInterval(() => {
            const cur = this.chatMessages.find((x) => x.id === msgId);
            if (!cur || !cur.chatIntro) {
              clearInterval(iv);
              return;
            }
            const len = cur.chatIntro.length;
            const step = len > 80 ? 2 : 1;
            const next = Math.min(len, (cur.chatIntroProgress || 0) + step);
            cur.chatIntroProgress = next;
            if (next >= len) {
              clearInterval(iv);
              cur._chatIntroIv = null;
              this.scheduleBotRunSummary(cur);
            }
            this.$nextTick(() => {
              const w = this.$refs.chatMessages;
              if (w) w.scrollTop = w.scrollHeight;
            });
          }, 42);
          const m = this.chatMessages.find((x) => x.id === msgId);
          if (m) m._chatIntroIv = iv;
        },
        scheduleBotRunSummary(botMsg) {
          if (!botMsg || !botMsg.chatRunSummary) return;
          const msgId = botMsg.id;
          botMsg.chatRunSummaryProgress = 0;
          if (botMsg._runSummaryIv) {
            clearInterval(botMsg._runSummaryIv);
            botMsg._runSummaryIv = null;
          }
          if (botMsg._runSummaryStartTid) {
            clearTimeout(botMsg._runSummaryStartTid);
            botMsg._runSummaryStartTid = null;
          }
          const tid = setTimeout(() => {
            const m = this.chatMessages.find((x) => x.id === msgId);
            if (m) m._runSummaryStartTid = null;
            if (!m || !m.chatRunSummary) return;
            const iv = setInterval(() => {
              const cur = this.chatMessages.find((x) => x.id === msgId);
              if (!cur || !cur.chatRunSummary) {
                clearInterval(iv);
                return;
              }
              const len = cur.chatRunSummary.length;
              const step = len > 100 ? 2 : 1;
              const next = Math.min(len, (cur.chatRunSummaryProgress || 0) + step);
              cur.chatRunSummaryProgress = next;
              if (next >= len) {
                clearInterval(iv);
                cur._runSummaryIv = null;
              }
              this.$nextTick(() => {
                const w = this.$refs.chatMessages;
                if (w) w.scrollTop = w.scrollHeight;
              });
            }, 46);
            m._runSummaryIv = iv;
          }, 520);
          botMsg._runSummaryStartTid = tid;
        },
        finalizeThinkingDemo(thinking) {
          if (!thinking || thinking._finalized) return;
          thinking._finalized = true;
          if (thinking._intervalId) {
            clearInterval(thinking._intervalId);
            thinking._intervalId = null;
          }
          const thinkId = thinking.id;
          const userText = thinking._demoSendText || '';
          const botMsg = this.buildDemoAnalysisBotMessage(userText);
          const ins = this.chatMessages.findIndex((m) => m.id === thinkId);
          if (ins >= 0) this.chatMessages.splice(ins + 1, 0, botMsg);
          else this.chatMessages.push(botMsg);
          this.$nextTick(() => {
            const w = this.$refs.chatMessages;
            if (w) w.scrollTop = w.scrollHeight;
            this.scheduleChatIntroTypewriter(botMsg);
          });
        },
        toolDiffLineClass(line) {
          return demoToolDiffLineClass(line);
        },
        visibleToolDiffLines(call, expanded) {
          const lines = call.diffLines || [];
          if (expanded) return lines;
          return lines.slice(0, 4);
        },
        toggleToolDiffExpand(toolCall) {
          if (!toolCall || toolCall.type !== 'edit') return;
          toolCall.diffExpanded = !toolCall.diffExpanded;
        },
        buildDemoAnalysisArtifact(refTitles, userText) {
          const selected = (Array.isArray(refTitles) ? refTitles : []).filter(Boolean);
          const fallbackTitles = (this.materials || [])
            .filter((m) => m && m.type === 'raw')
            .slice(0, 3)
            .map((m) => m.title || m.name || '未命名资料');
          const sourceLabels = (selected.length ? selected : fallbackTitles).slice(0, 3);
          const displayPrompt = String(userText || '').trim() || '当前工作台资料一致性分析';
          const generatedAt = new Date().toISOString().slice(0, 19).replace('T', ' ');
          return {
            fileName: '中间结果.csv',
            toolName: '分析工具',
            generatedAt,
            tags: ['分析工具', '中间结果'],
            sourceLabels,
            hitCount: 6,
            objectCount: 3,
            summaryItems: [
              { label: '命中对象', value: '3 个对象' },
              { label: '异常条目', value: '3 条高风险疑点' },
              { label: '来源资料', value: `${sourceLabels.length} 份资料` },
              { label: '处理状态', value: '已生成' },
            ],
            jsonData: {
              task: 'analysis_tool',
              prompt: displayPrompt,
              sourceMaterials: sourceLabels.map((label, index) => ({ id: `src-${index + 1}`, label })),
              summary: { objectCount: 3, hitCount: 6, riskLevel: 'high' },
              findings: [
                { id: 'finding-1', title: '合同金额与累计开票金额不一致', severity: 'high', evidenceRefs: ['E1'], suggestion: '补充补充协议与红冲记录核对口径' },
                { id: 'finding-2', title: '付款日期早于验收节点', severity: 'high', evidenceRefs: ['E2'], suggestion: '核查是否存在先付后验的审批豁免' },
                { id: 'finding-3', title: '供应商主体名称存在近似差异', severity: 'medium', evidenceRefs: ['E3'], suggestion: '补充主体授权与开户证明资料' },
              ],
            },
            csvData: [
              '疑点ID,疑点标题,风险等级,证据引用,建议动作',
              '"finding-1","合同金额与累计开票金额不一致","高","E1","补充补充协议与红冲记录核对口径"',
              '"finding-2","付款日期早于验收节点","高","E2","核查是否存在先付后验的审批豁免"',
              '"finding-3","供应商主体名称存在近似差异","中","E3","补充主体授权与开户证明资料"',
            ].join('\n'),
            resultMarkdown: [
              '## 一、分析结论',
              `围绕“${displayPrompt}”，分析工具对 ${sourceLabels.join('、')} 进行了结构化对齐，识别出金额口径差异、付款时点异常与主体名称近似不一致三类问题。`,
              '',
              '## 二、关键发现',
              '- 合同金额与累计开票金额存在差异，需补充核验变更与红冲记录。（1）',
              '- 付款发生在验收完成前，存在流程倒置风险。（2）',
              '- 供应商主体名称在合同与开户信息中表述不一致，需确认是否为同一主体。（3）',
              '',
              '## 三、建议动作',
              '- 先核对金额差异的变更依据与对账口径。',
              '- 再复核付款、验收、审批三者的时间链。',
              '- 最后补齐主体授权、开户与工商登记资料。',
              '',
              '---',
              '',
              '### 引用信息',
              '',
              `**（1）${DEMO_ANALYSIS_CITATION_MAP.E1.sourceLabel}**`,
              ...String(DEMO_ANALYSIS_CITATION_MAP.E1.sourceExcerpt || '').split('\n').map((line) => `> ${line}`),
              '',
              `**（2）${DEMO_ANALYSIS_CITATION_MAP.E2.sourceLabel}**`,
              ...String(DEMO_ANALYSIS_CITATION_MAP.E2.sourceExcerpt || '').split('\n').map((line) => `> ${line}`),
              '',
              `**（3）${DEMO_ANALYSIS_CITATION_MAP.E3.sourceLabel}**`,
              ...String(DEMO_ANALYSIS_CITATION_MAP.E3.sourceExcerpt || '').split('\n').map((line) => `> ${line}`),
            ].join('\n'),
          };
        },
        analysisToolCallLabel(call) {
          const labels = Array.isArray(call && call.analysisArtifact && call.analysisArtifact.sourceLabels)
            ? call.analysisArtifact.sourceLabels.filter(Boolean)
            : [];
          if (!labels.length) return '分析已选资料并生成结构化中间结果';
          return `分析 ${labels.join('、')}`;
        },
        /** 思考轨内「编辑」diff 卡标题栏：在右侧结果区打开对应分析结果（演示用 previewResultTitle / 文件名启发式） */
        openChatToolEditPreview(call) {
          if (!call || call.type !== 'edit') return;
          const materials = this.materials || [];
          const analyses = materials.filter((m) => m && m.type === 'analysis');
          let target = null;
          const hint = String(call.previewResultTitle || '').trim();
          if (hint) {
            target =
              analyses.find((m) => String(m.title || '').trim() === hint) ||
              analyses.find((m) => String(m.title || '').includes(hint));
          }
          if (!target) {
            const stem = String(call.fileName || '')
              .replace(/\.(md|markdown)$/i, '')
              .trim();
            if (stem) {
              target = analyses.find((m) => {
                const t = String(m.title || '');
                return t.includes(stem) || stem.includes(t);
              });
            }
          }
          if (!target) {
            target = analyses.find((m) => this.canOpenAnalysisPreview(m)) || analyses[0];
          }
          if (!target) {
            message.info('当前工作台暂无可预览的分析结果');
            return;
          }
          if (!this.canOpenAnalysisPreview(target)) {
            message.info('该结果尚未完成，暂不可预览');
            return;
          }
          this.sourcesCollapsed = false;
          this.studioCollapsed = false;
          this.clearWorkbenchAnalysisCitationFloats();
          this.openMaterialDetail(target);
        },
        openChatToolAnalysisPreview(call) {
          if (!call || call.type !== 'analysis') return;
          if (!call.analysisArtifact) {
            if (call.demoToolStatus === 'fail') message.info('该中间结果生成失败，暂不可预览');
            return;
          }
          this.analysisToolPreviewRecord = { ...call.analysisArtifact, sourceCallId: call.id || call.fileName || 'analysis-tool' };
          this.analysisToolPreviewModalOpen = true;
        },
        closeAnalysisToolPreviewModal() {
          this.analysisToolPreviewModalOpen = false;
          this.analysisToolPreviewRecord = null;
        },
        copyAnalysisToolPreviewJson() {
          if (!this.analysisToolPreviewRecord) return;
          navigator.clipboard?.writeText(this.analysisToolPreviewCsv);
          this.toastMessage = '已复制 CSV';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        downloadAnalysisToolPreviewJson() {
          const rec = this.analysisToolPreviewRecord;
          if (!rec) return;
          const blob = new Blob([this.analysisToolPreviewCsv], { type: 'text/csv;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${String(rec.fileName || '中间结果').replace(/\.csv$/i, '')}.csv`;
          a.click();
          URL.revokeObjectURL(url);
          message.success('已开始下载');
        },
        createWorkbenchResultRowFromMarkdown(payload) {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('缺少工作台上下文');
            return null;
          }
          const title = String(payload && payload.name || '').trim();
          const markdown = String(payload && payload.markdown || '').trim();
          if (!title || !markdown) return null;
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const id = 'ar-msg-' + Date.now();
          const row = {
            id,
            name: title,
            tags: Array.isArray(payload && payload.tags) ? payload.tags.slice() : ['AI生成'],
            createdAt: now,
            status: 'done',
            analysisMarkdown: markdown,
          };
          if (!demoProjectAnalysisResultsById[pid]) demoProjectAnalysisResultsById[pid] = [];
          demoProjectAnalysisResultsById[pid].unshift(row);
          const material = mapAnalysisResultRowToWorkbench(row, pid);
          material.analysisMarkdown = row.analysisMarkdown;
          material.excerpts = [row.analysisMarkdown];
          material.excerptsWithCitations = [{ text: row.analysisMarkdown, citations: [] }];
          material.overview = String(payload && payload.overview || markdown).slice(0, 150) + (markdown.length > 150 ? '...' : '');
          this.materials.push(material);
          this.selectedMaterialId = material.id;
          this.sourcesCollapsed = false;
          this.studioCollapsed = false;
          this.clearWorkbenchAnalysisCitationFloats();
          this.sourcesRightView = 'detail';
          this.sourcesLeftView = 'list';
          this.sourcesDetailWidth = 450;
          material.checked = true;
          return { row, material };
        },
        clearChatThinkingIntervals() {
          (this.chatMessages || []).forEach((m) => {
            if (m._intervalId) {
              clearInterval(m._intervalId);
              m._intervalId = null;
            }
            if (m._runSummaryStartTid) {
              clearTimeout(m._runSummaryStartTid);
              m._runSummaryStartTid = null;
            }
            if (m._runSummaryIv) {
              clearInterval(m._runSummaryIv);
              m._runSummaryIv = null;
            }
            if (m._chatIntroIv) {
              clearInterval(m._chatIntroIv);
              m._chatIntroIv = null;
            }
          });
        },
        /** 停止当前轮演示定时器：思考轨中途停止不再插入 bot；已出现的 bot 则瞬间补全引导语与收尾总结 */
        pauseChatGeneration() {
          const list = this.chatMessages || [];
          for (let i = list.length - 1; i >= 0; i--) {
            const m = list[i];
            if (m.role !== 'bot') continue;
            const introLen = (m.chatIntro || '').length;
            const introGoing = !!(m.chatIntro && introLen && m.chatIntroProgress != null && m.chatIntroProgress < introLen);
            const rs = m.chatRunSummary || '';
            const runGoing = !!(rs.length && (m.chatRunSummaryProgress ?? 0) < rs.length);
            if (!introGoing && !runGoing) continue;
            if (m._chatIntroIv) {
              clearInterval(m._chatIntroIv);
              m._chatIntroIv = null;
            }
            if (introLen) m.chatIntroProgress = introLen;
            if (m._runSummaryStartTid) {
              clearTimeout(m._runSummaryStartTid);
              m._runSummaryStartTid = null;
            }
            if (m._runSummaryIv) {
              clearInterval(m._runSummaryIv);
              m._runSummaryIv = null;
            }
            if (rs.length) m.chatRunSummaryProgress = rs.length;
            this.toastMessage = '已暂停生成';
            setTimeout(() => {
              this.toastMessage = '';
            }, 1500);
            return;
          }
          for (let i = list.length - 1; i >= 0; i--) {
            const m = list[i];
            if (m.role !== 'thinking' || m._finalized) continue;
            if (m._intervalId) {
              clearInterval(m._intervalId);
              m._intervalId = null;
            }
            m._finalized = true;
            m._generationPaused = true;
            this.toastMessage = '已暂停生成';
            setTimeout(() => {
              this.toastMessage = '';
            }, 1500);
            return;
          }
        },
        viewExtractionResult(id) {
          this.clearWorkbenchAnalysisCitationFloats();
          this.selectedExtractionId = id;
          this.sourcesLeftView = 'detail';
          this.sourcesRightView = 'list';
          this.sourcesDetailWidth = 450;
        },
        removeExtractionResult(id) {
          this.extractionResults = this.extractionResults.filter(r => r.id !== id);
          if (this.selectedExtractionId === id) {
            this.selectedExtractionId = null;
            this.selectedTreeNode = null;
            this.sourcesLeftView = 'list';
            this.sourcesWidth = 300;
          }
        },
        importExtractionResult(item) {
          if (item.status !== 'done' || !item.snippets) return;
          const pid = this.workbenchProjectId;
          if (!pid) return;
          const id = 'ar-ext-' + Date.now();
          const title = item.dataSourceName + ' 抽取结果';
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const row = { id, name: title, tags: ['结构化抽取'], createdAt: now };
          if (!demoProjectAnalysisResultsById[pid]) demoProjectAnalysisResultsById[pid] = [];
          demoProjectAnalysisResultsById[pid].unshift(row);
          const material = mapAnalysisResultRowToWorkbench(row, pid);
          material.excerpts = item.snippets.map((s) => s.title + '\n' + s.desc);
          material.excerptsWithCitations = item.snippets.map((s) => ({ text: s.title + '：' + s.desc, citations: [] }));
          material.overview = '从 ' + item.dataSourceName + ' 抽取的 ' + item.snippets.length + ' 条结果';
          this.materials.push(material);
          this.selectedMaterialId = material.id;
          this.extractionResults = this.extractionResults.filter((r) => r.id !== item.id);
          if (this.selectedExtractionId === item.id) {
            this.selectedExtractionId = null;
            this.selectedTreeNode = null;
            this.sourcesLeftView = 'list';
          }
          this.toastMessage = '已导入到结果';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        goBackToProjectCenter() {
          window.location.hash = 'project' + (this.workbenchProjectId ? '/' + this.workbenchProjectId : '');
          window.dispatchEvent(new HashChangeEvent('hashchange'));
        },
        goBackToProjectDetail() {
          if (!this.workbenchProjectId) return;
          window.location.hash = 'project/' + encodeURIComponent(this.workbenchProjectId);
          window.dispatchEvent(new HashChangeEvent('hashchange'));
          this.$emit('navigate', VIEW_IDS.PROJECT);
        },
        goBackToProjectDetailAnimated() {
          if (!this.workbenchProjectId) return;
          const pid = this.workbenchProjectId;
          this.sourcesCollapsed = true;
          this.studioCollapsed = true;
          window.setTimeout(() => {
            try { sessionStorage.setItem('demoAutoEnterAnim', '1'); } catch (_) { /* ignore */ }
            window.location.hash = 'project/' + encodeURIComponent(pid);
            window.dispatchEvent(new HashChangeEvent('hashchange'));
            this.$emit('navigate', VIEW_IDS.PROJECT);
          }, 300);
        },
        goBackToProjectCenterList() {
          window.location.hash = 'project';
          window.dispatchEvent(new HashChangeEvent('hashchange'));
        },
        openWorkbenchProjectEdit() {
          const pid = this.workbenchProjectId;
          if (!pid) return;
          window.location.hash = 'project/' + encodeURIComponent(pid) + '?openEdit=1';
          window.dispatchEvent(new HashChangeEvent('hashchange'));
          this.$emit('navigate', VIEW_IDS.PROJECT);
        },
        onWorkbenchHeaderMenu(info) {
          if (info && info.key === 'edit') this.openWorkbenchProjectEdit();
        },
        enterExperienceDraftMode() {
          this.layoutMode = 'B';
          this.experienceDrafts = { extract: '（抽取技能草案占位）', analysis: '（分析技能草案占位）', report: '（报告技能草案占位）' };
        },
        exitExperienceDraftMode() { this.layoutMode = 'A'; },
        saveExperienceToTemplate() {
          this.layoutMode = 'A';
          this.toastMessage = '已保存至技能库';
          window.location.hash = 'template';
          setTimeout(() => { this.toastMessage = ''; window.dispatchEvent(new HashChangeEvent('hashchange')); }, 1500);
        },
        setExcerptRef(sourceId, index, el) {
          if (!el) return;
          if (!this.excerptRefs[sourceId]) this.excerptRefs[sourceId] = {};
          this.excerptRefs[sourceId][index] = el;
        },
        getMaterialIcon(m) {
          if (m.type === 'raw') {
            if (m.rawSubtype === 'table') return 'fa-file-excel';
            return 'fa-file-pdf';
          }
          if (m.type === 'analysis') return 'fa-file-signature';
          return 'fa-file-lines';
        },
        getMaterialIconColorClass(m) {
          if (!this.isWorkbenchMaterialDone(m)) return '';
          const fmt = String((m && (m.format || (m.projectSource && m.projectSource.format))) || '').toUpperCase();
          if (fmt === 'PDF') return 'is-pdf';
          if (fmt === 'XLSX' || fmt === 'XLS' || fmt === 'CSV') return 'is-sheet';
          if (fmt === 'DOCX') return 'is-doc';
          if (fmt === 'JSON') return 'is-data';
          return '';
        },
        workbenchMaterialStatusOf(m) {
          const status = (m && m.projectSource && m.projectSource.status) || (m && m.status) || 'queued';
          if (status === 'queued' || status === 'parsing' || status === 'done' || status === 'failed') return status;
          return 'queued';
        },
        workbenchAnalysisStatusOf(m) {
          const status = (m && m.projectSource && m.projectSource.status) || (m && m.status) || 'done';
          if (status === 'queued' || status === 'parsing' || status === 'done' || status === 'failed') return status;
          return 'done';
        },
        canOpenAnalysisPreview(m) {
          if (!m || m.type !== 'analysis') return true;
          return this.workbenchAnalysisStatusOf(m) === 'done';
        },
        canOpenMaterialPreview(m) {
          if (!m || m.type !== 'raw') return true;
          return this.workbenchMaterialStatusOf(m) === 'done';
        },
        workbenchMaterialProgressOf(m) {
          const p = Number((m && m.projectSource && m.projectSource.progress) ?? (m && m.progress) ?? 0);
          if (Number.isNaN(p)) return 0;
          return Math.max(0, Math.min(100, p));
        },
        workbenchMaterialStatusLabel(status) {
          const map = { queued: '排队中', parsing: '解析中', done: '完成', failed: '失败' };
          return map[status] || '排队中';
        },
        workbenchMaterialProgressStatus(m) {
          const status = this.workbenchMaterialStatusOf(m);
          if (status === 'failed') return 'exception';
          if (status === 'done') return 'success';
          return 'active';
        },
        isWorkbenchMaterialDone(m) {
          return this.workbenchMaterialStatusOf(m) === 'done';
        },
        filteredWorkbenchRawMaterials(rawRows) {
          const rows = Array.isArray(rawRows) ? rawRows : [];
          const tagKeys = this.workbenchMaterialTagKeys || [];
          const modeAll = this.workbenchMaterialTagMatchMode === 'all';
          const statusRank = (s) => ({ parsing: 0, queued: 1, failed: 2, done: 3 }[s] ?? 9);
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const timeOf = (v) => {
            const t = Date.parse(String(v || '').trim());
            return Number.isNaN(t) ? 0 : t;
          };
          const sizeOf = (v) => Number(v || 0);
          const filtered = rows.filter((m) => {
            const rowTags = Array.isArray(m.tags) ? m.tags : [];
            const hitTag = !tagKeys.length || (modeAll ? tagKeys.every((t) => rowTags.includes(t)) : tagKeys.some((t) => rowTags.includes(t)));
            return hitTag;
          });
          return [...filtered].sort((a, b) => {
            const aSource = a.projectSource || {};
            const bSource = b.projectSource || {};
            const byName = () => collator.compare(String(a.title || ''), String(b.title || ''));
            if (this.workbenchMaterialSortBy === 'uploaded_desc') return timeOf(bSource.uploadedAt || b.meta) - timeOf(aSource.uploadedAt || a.meta) || byName();
            if (this.workbenchMaterialSortBy === 'uploaded_asc') return timeOf(aSource.uploadedAt || a.meta) - timeOf(bSource.uploadedAt || b.meta) || byName();
            if (this.workbenchMaterialSortBy === 'status') return statusRank(this.workbenchMaterialStatusOf(a)) - statusRank(this.workbenchMaterialStatusOf(b)) || byName();
            if (this.workbenchMaterialSortBy === 'type') return collator.compare(String(aSource.format || ''), String(bSource.format || '')) || byName();
            if (this.workbenchMaterialSortBy === 'name') return byName();
            if (this.workbenchMaterialSortBy === 'size_desc') return sizeOf(bSource.size) - sizeOf(aSource.size) || byName();
            if (this.workbenchMaterialSortBy === 'size_asc') return sizeOf(aSource.size) - sizeOf(bSource.size) || byName();
            return byName();
          });
        },
        toggleWorkbenchMaterialTag(tag) {
          if (!tag) return;
          const keys = this.workbenchMaterialTagKeys || [];
          const idx = keys.indexOf(tag);
          if (idx >= 0) this.workbenchMaterialTagKeys = keys.filter((t) => t !== tag);
          else this.workbenchMaterialTagKeys = [...keys, tag];
        },
        clearWorkbenchMaterialTags() {
          this.workbenchMaterialTagKeys = [];
        },
        resetWorkbenchMaterialFilters() {
          this.clearWorkbenchMaterialTags();
        },
        toggleWbSkillListTag(tag) {
          if (!tag) return;
          const keys = this.wbSkillListTagKeys || [];
          const idx = keys.indexOf(tag);
          if (idx >= 0) this.wbSkillListTagKeys = keys.filter((t) => t !== tag);
          else this.wbSkillListTagKeys = [...keys, tag];
        },
        clearWbSkillListTags() {
          this.wbSkillListTagKeys = [];
        },
        toggleWorkbenchAnalysisTag(tag) {
          if (!tag) return;
          const keys = this.workbenchAnalysisTagKeys || [];
          const idx = keys.indexOf(tag);
          if (idx >= 0) this.workbenchAnalysisTagKeys = keys.filter((t) => t !== tag);
          else this.workbenchAnalysisTagKeys = [...keys, tag];
        },
        clearWorkbenchAnalysisTags() {
          this.workbenchAnalysisTagKeys = [];
        },
        rerunWorkbenchMaterial(m) {
          if (!m || (m.type && m.type !== 'raw') || !this.workbenchProjectId) return;
          const arr = demoProjectMaterialsById[this.workbenchProjectId] || [];
          const idx = arr.findIndex((x) => x.id === m.id);
          if (idx < 0) return;
          arr.splice(idx, 1, { ...arr[idx], status: 'parsing', progress: 12 });
          if (m.projectSource) {
            m.projectSource.status = 'parsing';
            m.projectSource.progress = 12;
          }
          this.toastMessage = '已加入重跑队列';
          setTimeout(() => { this.toastMessage = ''; }, 1200);
        },
        materialMeta(m) {
          if (!m) return '—';
          if (m.meta) return m.meta;
          if (m.createdAt) return typeof m.createdAt === 'string' ? m.createdAt : '—';
          return '—';
        },
        noop() {},
        toggleAllMaterials() {
          const checked = !this.allMaterialsChecked;
          this.materials.forEach(m => { m.checked = checked; });
        },
        handleMaterialMenuClick(key, m) {
          if (!m) return;
          if (key === 'rerun') {
            if (m.type && m.type !== 'raw') return;
            this.rerunWorkbenchMaterial(m);
            return;
          }
          if (key === 'delete') this.deleteMaterial(m);
        },
        deleteMaterial(m) {
          const pid = this.workbenchProjectId;
          if (m && m.projectSource && pid) {
            if (m.type === 'analysis') {
              const arr = demoProjectAnalysisResultsById[pid];
              if (arr) {
                const j = arr.findIndex((x) => x.id === m.id);
                if (j >= 0) arr.splice(j, 1);
              }
            } else {
              const arr = demoProjectMaterialsById[pid];
              if (arr) {
                const j = arr.findIndex((x) => x.id === m.id);
                if (j >= 0) arr.splice(j, 1);
              }
            }
          }
          const i = this.materials.findIndex((x) => x.id === m.id);
          if (i < 0) return;
          this.materials.splice(i, 1);
          if (this.selectedMaterialId === m.id) {
            const next = this.materials[i] || this.materials[i - 1];
            this.selectedMaterialId = next ? next.id : null;
            if (!next) {
              this.selectedTreeNode = null;
              this.sourcesLeftView = 'list';
            }
          }
          this.toastMessage = '已删除资料';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        openWorkbenchTreeItemMetaEdit(m, sectionKey) {
          if (!m) return;
          const ps = m.projectSource;
          if (!ps || !ps.id) {
            message.info('该条目暂不支持在此编辑');
            return;
          }
          if (sectionKey === 'material' && m.type === 'raw') {
            this.openWorkbenchProjectMaterialMetaEdit(ps);
            return;
          }
          if (sectionKey === 'analysis' && m.type === 'analysis') {
            this.openWorkbenchAnalysisResultMetaEdit(ps);
            return;
          }
          message.info('该条目暂不支持在此编辑');
        },
        openMaterialDetail(m) {
          if (m && m.loading) return;
          if (!this.canOpenMaterialPreview(m)) {
            message.info('该资料尚未完成解析，暂不可预览');
            return;
          }
          if (!this.canOpenAnalysisPreview(m)) {
            message.info('该结果尚未完成，暂不可预览');
            return;
          }
          this.clearWorkbenchAnalysisCitationFloats();
          this.workbenchAnalysisEmbedEditing = false;
          this.workbenchAnalysisEmbedDraft = '';
          if (m.type === 'analysis') {
            this.wbMaterialPreviewActiveTab = 'basic';
            this.wbAnalysisResultPreviewActiveTab = 'body';
          } else {
            this.wbMaterialPreviewActiveTab = 'preview';
            this.wbAnalysisResultPreviewActiveTab = 'basic';
          }
          this.selectedMaterialId = m.id;
          this.studioCollapsed = false;
          if (m.type === 'analysis') {
            this.lastDetailFocus = 'right';
            this.sourcesRightView = 'detail';
            this.sourcesLeftView = 'list';
          } else {
            this.lastDetailFocus = 'left';
            this.sourcesLeftView = 'detail';
            this.sourcesRightView = 'list';
            this.sourcesDetailWidth = 450;
          }
        },
        closeWorkbenchMaterialDetail() {
          this.clearWorkbenchAnalysisCitationFloats();
          this.workbenchAnalysisEmbedEditing = false;
          this.workbenchAnalysisEmbedDraft = '';
          if (this.sourcesRightView === 'detail' && this.selectedMaterial && this.selectedMaterial.type === 'analysis') {
            this.sourcesRightView = 'list';
          } else {
            this.sourcesLeftView = 'list';
          }
          this.selectedTreeNode = null;
          this.sourcesWidth = 300;
        },
        clearWorkbenchAnalysisCitationFloats() {
          this.workbenchAnalysisCitationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
          if (this.workbenchAnalysisCitationPopoverTimer) {
            window.clearTimeout(this.workbenchAnalysisCitationPopoverTimer);
            this.workbenchAnalysisCitationPopoverTimer = null;
          }
        },
        showWorkbenchAnalysisCitationPopoverByKey(key, rect) {
          const map = this.workbenchAnalysisCitationMap || {};
          const data = map[key];
          if (!data) return;
          if (this.workbenchAnalysisCitationPopoverTimer) {
            window.clearTimeout(this.workbenchAnalysisCitationPopoverTimer);
            this.workbenchAnalysisCitationPopoverTimer = null;
          }
          let x = rect.left;
          let y = rect.bottom + 4;
          const maxW = 320;
          const maxH = 220;
          if (x + maxW > window.innerWidth) x = window.innerWidth - maxW - 8;
          if (x < 8) x = 8;
          if (y + maxH > window.innerHeight) y = rect.top - maxH - 4;
          if (y < 8) y = 8;
          const title = `${key} · ${data.sourceLabel || '溯源信息'}`;
          const excerpt = String(data.sourceExcerpt || data.sourceFullText || '').trim() || '暂无溯源内容';
          this.workbenchAnalysisCitationPopover = { show: true, title, excerpt, x, y };
        },
        onWorkbenchAnalysisPreviewCitationHover(event) {
          const el = event && event.target ? event.target.closest('.analysis-inline-citation') : null;
          if (!el) return;
          const key = String(el.getAttribute('data-cite') || '').trim();
          if (!key) return;
          this.showWorkbenchAnalysisCitationPopoverByKey(key, el.getBoundingClientRect());
        },
        onWorkbenchAnalysisPreviewCitationLeave() {
          this.workbenchAnalysisCitationPopoverTimer = window.setTimeout(() => {
            this.workbenchAnalysisCitationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
            this.workbenchAnalysisCitationPopoverTimer = null;
          }, 120);
        },
        onWorkbenchAnalysisCitationPopoverEnter() {
          if (this.workbenchAnalysisCitationPopoverTimer) {
            window.clearTimeout(this.workbenchAnalysisCitationPopoverTimer);
            this.workbenchAnalysisCitationPopoverTimer = null;
          }
        },
        onWorkbenchAnalysisCitationPopoverLeave() {
          this.onWorkbenchAnalysisPreviewCitationLeave();
        },
        workbenchAnalysisDialogueSourceLineFromRecord(r) {
          if (!r) return '';
          const base = '初始结果通过对话生成';
          const who = String(r.analysisMarkdownEditedBy || '').trim();
          const when = String(r.analysisMarkdownEditedAt || '').trim();
          if (who && when) return `${base}（${who} 于 ${when} 编辑）`;
          return base;
        },
        workbenchAnalysisResultBasicMetaLine(record) {
          const r = record || {};
          const when = this.wbToOverviewMetaValue(r.createdAt, '—');
          return `${when} 生成`;
        },
        workbenchAnalysisMarkdownFromMaterial(m) {
          if (!m || m.type !== 'analysis') return '';
          if (m.analysisMarkdown) return m.analysisMarkdown;
          const ps = m.projectSource || {};
          return buildAnalysisResultPreviewMarkdown({ name: m.title || ps.name, tags: m.tags || ps.tags, createdAt: m.meta || ps.createdAt });
        },
        pushWorkbenchAnalysisVersionEntry(resultId, label, markdown, savedAt, sourceSummary) {
          if (!resultId || markdown == null) return;
          const key = `v-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
          const at =
            savedAt != null && String(savedAt).trim()
              ? String(savedAt).trim()
              : new Date().toISOString().slice(0, 19).replace('T', ' ');
          const sum = String(sourceSummary || '').trim();
          const prev = (this.workbenchAnalysisVersionHistoryById || {})[resultId] || [];
          const next = [
            {
              key,
              label: String(label || '快照').trim() || '快照',
              markdown: String(markdown),
              savedAt: at,
              ...(sum ? { sourceSummary: sum } : {}),
            },
            ...prev,
          ].slice(0, 30);
          this.workbenchAnalysisVersionHistoryById = { ...(this.workbenchAnalysisVersionHistoryById || {}), [resultId]: next };
        },
        /** 当前版本行由 computed 合成；此处仅保留钩子供切换 Tab 时触发（可扩展预拉取） */
        ensureWorkbenchAnalysisVersionHistoryForSelected() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return;
        },
        ensureWorkbenchAnalysisVersionHistoryForRecord(record) {
          const r = record || this.wbAnalysisModalRecord;
          if (!r || !r.id) return;
        },
        closeWorkbenchAnalysisHistoryDiff() {
          this.wbAnalysisHistoryDiffOpen = false;
          this.wbAnalysisHistoryDiffLines = [];
          this.wbAnalysisHistoryDiffTruncated = false;
        },
        workbenchAnalysisResolveMaterialNameById(materialId) {
          const id = String(materialId || '').trim();
          if (!id) return '';
          const rows = this.materials || [];
          const r = rows.find((x) => x && String(x.id) === id);
          return (r && r.title) ? String(r.title).trim() : id;
        },
        openWbAnalysisVersionDetail(record) {
          if (!record) return;
          this.wbAnalysisVersionDetailMarkdown = String(record.markdown || '');
          this.wbAnalysisVersionDetailVisible = true;
        },
        closeWbAnalysisVersionDetail() {
          this.wbAnalysisVersionDetailVisible = false;
          this.wbAnalysisVersionDetailMarkdown = '';
        },
        openWorkbenchAnalysisHistoryDiff(record, scope) {
          if (!record || record.key === '_current') {
            message.info('已为当前版本');
            return;
          }
          const hist = String(record.markdown ?? '');
          const cur =
            scope === 'modal'
              ? String(this.wbAnalysisModalPreviewMarkdown || '')
              : String(this.workbenchAnalysisPreviewMarkdown || '');
          const { lines, truncated } = demoLinesUnifiedDiff(hist, cur, { maxOut: 500 });
          this.wbAnalysisHistoryDiffLines = lines;
          this.wbAnalysisHistoryDiffTruncated = truncated;
          this.wbAnalysisHistoryDiffOpen = true;
        },
        onWbAnalysisModalTabUpdate(key) {
          const next = String(key || 'body');
          if (next === String(this.wbAnalysisModalActiveTab)) return;
          if (String(this.wbAnalysisModalActiveTab) === 'body' && this.wbAnalysisModalEmbedEditing && next !== 'body') {
            Modal.confirm({
              centered: true,
              title: '有未保存的编辑',
              content: '切换页签将放弃对正文的未保存修改，是否继续？',
              okText: '放弃并切换',
              cancelText: '留在本页',
              onOk: () => {
                this.cancelWbAnalysisModalEmbedEdit();
                if (next === 'history') this.ensureWorkbenchAnalysisVersionHistoryForRecord(this.wbAnalysisModalRecord);
                this.wbAnalysisModalActiveTab = next;
              },
            });
            return;
          }
          if (next === 'history') this.ensureWorkbenchAnalysisVersionHistoryForRecord(this.wbAnalysisModalRecord);
          this.wbAnalysisModalActiveTab = next;
        },
        applyWorkbenchAnalysisMarkdownRollbackById(resultId, md) {
          const pid = this.workbenchProjectId;
          const id = String(resultId || '');
          if (!id || !pid) return;
          const m = (this.materials || []).find((x) => x && x.type === 'analysis' && String(x.id) === id);
          const text = String(md ?? '');
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const patch = {
            analysisMarkdown: text,
            analysisMarkdownEditedBy: '我',
            analysisMarkdownEditedAt: now,
          };
          const rows = demoProjectAnalysisResultsById[pid];
          if (Array.isArray(rows)) {
            const idx = rows.findIndex((r) => r && r.id === id);
            if (idx >= 0) rows.splice(idx, 1, { ...rows[idx], ...patch });
          }
          if (m) {
            m.analysisMarkdown = text;
            if (m.projectSource) Object.assign(m.projectSource, patch);
          }
          if (this.wbAnalysisModalOpen && this.wbAnalysisModalRecord && this.wbAnalysisModalRecord.id === id) {
            this.wbAnalysisModalRecord = { ...this.wbAnalysisModalRecord, ...patch };
          }
          this.workbenchAnalysisEmbedEditing = false;
          this.workbenchAnalysisEmbedDraft = '';
          this.wbAnalysisModalEmbedEditing = false;
          this.wbAnalysisModalEmbedDraft = '';
          message.success('已回退到所选版本');
        },
        onWorkbenchAnalysisResultPreviewTabUpdate(key) {
          const next = String(key || 'basic');
          if (next === String(this.wbAnalysisResultPreviewActiveTab)) return;
          if (String(this.wbAnalysisResultPreviewActiveTab) === 'body' && this.workbenchAnalysisEmbedEditing && next !== 'body') {
            Modal.confirm({
              centered: true,
              title: '有未保存的编辑',
              content: '切换页签将放弃对正文的未保存修改，是否继续？',
              okText: '放弃并切换',
              cancelText: '留在本页',
              onOk: () => {
                this.cancelWorkbenchAnalysisEmbedEdit();
                if (next === 'history') this.ensureWorkbenchAnalysisVersionHistoryForSelected();
                this.wbAnalysisResultPreviewActiveTab = next;
                // #region agent log
                if (next === 'history') this._debugLogWorkbenchEmbedHistoryLayout('modal_ok');
                // #endregion
              },
            });
            return;
          }
          if (next === 'history') this.ensureWorkbenchAnalysisVersionHistoryForSelected();
          this.wbAnalysisResultPreviewActiveTab = next;
          // #region agent log
          if (next === 'history') this._debugLogWorkbenchEmbedHistoryLayout('direct');
          // #endregion
        },
        // #region agent log
        _debugLogWorkbenchEmbedHistoryLayout(tag) {
          this.$nextTick(() => {
            requestAnimationFrame(() => {
              try {
                const root = this.$el;
                const embed = root && root.querySelector
                  ? root.querySelector('.analysis-result-preview-modal.analysis-result-preview-modal--workbench-embed')
                  : null;
                const panel = embed ? embed.querySelector('.ds-l2-table-panel') : null;
                const tableWrap = embed ? embed.querySelector('.wb-analysis-version-mgmt-table') : null;
                const cols = this.workbenchAnalysisVersionMgmtColumns || [];
                const rows = this.workbenchAnalysisVersionHistoryOnlyRows || [];
                const colWidths = cols.map((c) => ({ key: c.key, w: c.width }));
                const sumW = colWidths.reduce((s, x) => s + (Number(x.w) || 0), 0);
                const panelRect = panel ? { cw: panel.clientWidth, sw: panel.scrollWidth } : null;
                const twRect = tableWrap ? { cw: tableWrap.clientWidth, sw: tableWrap.scrollWidth } : null;
                const innerTable = tableWrap
                  ? tableWrap.querySelector('.ant-table-content table') || tableWrap.querySelector('table')
                  : null;
                const innerTableLayout = innerTable && typeof window.getComputedStyle === 'function'
                  ? window.getComputedStyle(innerTable).tableLayout
                  : '';
                let thInfo = [];
                if (tableWrap) {
                  const headerTable = tableWrap.querySelector('.ant-table-header table');
                  const ths = headerTable ? headerTable.querySelectorAll('thead th') : [];
                  thInfo = Array.from(ths).map((th) => ({
                    w: th.offsetWidth,
                    t: String(th.textContent || '').trim().slice(0, 12),
                  }));
                }
                let td0 = [];
                if (tableWrap) {
                  const bodyTable =
                    tableWrap.querySelector('.ant-table-body table') ||
                    tableWrap.querySelector('.ant-table-content table');
                  const tr = bodyTable && bodyTable.querySelector('tbody tr:not(.ant-table-measure-row)');
                  if (tr) td0 = Array.from(tr.querySelectorAll('td')).map((td) => td.offsetWidth);
                }
                fetch('http://127.0.0.1:7513/ingest/4f092e80-cdeb-409f-b8b0-4a397bd0359b', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', 'X-Debug-Session-Id': 'be30db' },
                  body: JSON.stringify({
                    sessionId: 'be30db',
                    hypothesisId: 'H1_H3_H5',
                    location: 'demo-cmp-freeaudit.js:_debugLogWorkbenchEmbedHistoryLayout',
                    message: 'embed_history_layout',
                    data: {
                      tag,
                      activeTab: this.wbAnalysisResultPreviewActiveTab,
                      colWidths,
                      sumW,
                      rowCount: rows.length,
                      panelRect,
                      twRect,
                      innerTableLayout,
                      thCount: thInfo.length,
                      thInfo,
                      td0,
                    },
                    timestamp: Date.now(),
                    runId: 'post-fix-v2',
                  }),
                }).catch(() => {});
              } catch (e) {
                fetch('http://127.0.0.1:7513/ingest/4f092e80-cdeb-409f-b8b0-4a397bd0359b', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json', 'X-Debug-Session-Id': 'be30db' },
                  body: JSON.stringify({
                    sessionId: 'be30db',
                    hypothesisId: 'H4',
                    location: 'demo-cmp-freeaudit.js:_debugLogWorkbenchEmbedHistoryLayout',
                    message: 'embed_history_layout_error',
                    data: { tag, err: String(e && e.message) },
                    timestamp: Date.now(),
                    runId: 'post-fix-v2',
                  }),
                }).catch(() => {});
              }
            });
          });
        },
        // #endregion
        startWorkbenchAnalysisEmbedEdit() {
          this.wbAnalysisResultPreviewActiveTab = 'body';
          this.workbenchAnalysisEmbedDraft = this.workbenchAnalysisPreviewMarkdown || '';
          this.workbenchAnalysisEmbedEditing = true;
        },
        cancelWorkbenchAnalysisEmbedEdit() {
          this.workbenchAnalysisEmbedEditing = false;
          this.workbenchAnalysisEmbedDraft = '';
        },
        saveWorkbenchAnalysisEmbedEdit() {
          const m = this.selectedMaterial;
          const pid = this.workbenchProjectId;
          if (!m || m.type !== 'analysis' || !pid) return;
          const oldMd = this.workbenchAnalysisMarkdownFromMaterial(m);
          const md = String(this.workbenchAnalysisEmbedDraft ?? '');
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          if (oldMd !== md) {
            this.pushWorkbenchAnalysisVersionEntry(m.id, `${now} · 保存前`, oldMd, now, '编辑前版本');
          }
          const patch = {
            analysisMarkdown: md,
            analysisMarkdownEditedBy: '我',
            analysisMarkdownEditedAt: now,
          };
          const id = m.id;
          const list = demoProjectAnalysisResultsById[pid];
          if (Array.isArray(list)) {
            const idx = list.findIndex((r) => r && r.id === id);
            if (idx >= 0) {
              list.splice(idx, 1, { ...list[idx], ...patch });
            }
          }
          m.analysisMarkdown = md;
          if (m.projectSource) Object.assign(m.projectSource, patch);
          if (this.wbAnalysisModalOpen && this.wbAnalysisModalRecord && this.wbAnalysisModalRecord.id === id) {
            this.wbAnalysisModalRecord = { ...this.wbAnalysisModalRecord, ...patch };
          }
          this.workbenchAnalysisEmbedEditing = false;
          this.workbenchAnalysisEmbedDraft = '';
          message.success('内容已保存');
        },
        copyWorkbenchAnalysisEmbedPreview() {
          if (!this.workbenchSelectedAnalysisResultRow) return;
          const text = this.workbenchAnalysisEmbedEditing
            ? String(this.workbenchAnalysisEmbedDraft ?? '')
            : this.workbenchAnalysisPreviewMarkdown || '';
          const ok = () => message.success('已复制到剪贴板');
          const fail = () => message.warning('复制失败');
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(ok).catch(fail);
          } else {
            try {
              const ta = document.createElement('textarea');
              ta.value = text;
              ta.style.cssText = 'position:fixed;left:-9999px;top:0';
              document.body.appendChild(ta);
              ta.select();
              document.execCommand('copy');
              document.body.removeChild(ta);
              ok();
            } catch (_) {
              fail();
            }
          }
        },
        downloadWorkbenchAnalysisEmbedPreview() {
          if (!this.workbenchSelectedAnalysisResultRow) return;
          const text = this.workbenchAnalysisEmbedEditing
            ? String(this.workbenchAnalysisEmbedDraft ?? '')
            : this.workbenchAnalysisPreviewMarkdown || '';
          const name = String((this.workbenchSelectedAnalysisResultRow && this.workbenchSelectedAnalysisResultRow.name) || '结果');
          const safe = name.replace(/[/\\?%*:|"<>]/g, '_');
          const blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${safe}.md`;
          a.click();
          URL.revokeObjectURL(url);
          message.success('已开始下载');
        },
        openWorkbenchAnalysisResultMetaEdit(record) {
          if (!record || !record.id) return;
          this.wbAnalysisResultMetaEditForm = {
            name: String(record.name || '').trim(),
            tags: Array.isArray(record.tags) ? [...record.tags] : [],
          };
          this.wbAnalysisResultMetaEditTargetId = record.id;
          this.wbAnalysisResultMetaEditVisible = true;
        },
        closeWorkbenchAnalysisResultMetaEdit() {
          this.wbAnalysisResultMetaEditVisible = false;
          this.wbAnalysisResultMetaEditTargetId = '';
        },
        confirmWorkbenchAnalysisResultMetaEdit() {
          const id = this.wbAnalysisResultMetaEditTargetId;
          const pid = this.workbenchProjectId;
          const name = String((this.wbAnalysisResultMetaEditForm && this.wbAnalysisResultMetaEditForm.name) || '').trim();
          const tagSrc = this.wbAnalysisResultMetaEditForm && Array.isArray(this.wbAnalysisResultMetaEditForm.tags) ? this.wbAnalysisResultMetaEditForm.tags : [];
          const tags = Array.from(new Set(tagSrc.map((t) => String(t || '').trim()).filter(Boolean)));
          if (!pid || !id) return;
          if (!name) {
            message.warning('请填写结果名称');
            return;
          }
          const rows = demoProjectAnalysisResultsById[pid] || [];
          const idx = rows.findIndex((x) => x.id === id);
          if (idx < 0) return;
          rows.splice(idx, 1, { ...rows[idx], name, tags });
          const m = (this.materials || []).find((x) => x.id === id && x.type === 'analysis');
          if (m) {
            m.title = name;
            m.tags = [...tags];
            if (m.projectSource) {
              m.projectSource = { ...m.projectSource, name, tags };
            }
          }
          if (this.wbAnalysisModalRecord && this.wbAnalysisModalRecord.id === id) {
            this.wbAnalysisModalRecord = { ...this.wbAnalysisModalRecord, name, tags };
          }
          this.closeWorkbenchAnalysisResultMetaEdit();
          message.success('已保存');
        },
        wbToOverviewMetaValue(v, fallback = '—') {
          const s = String(v == null ? '' : v).trim();
          return s || fallback;
        },
        wbMaterialPreviewSizeFormatLine(record) {
          const r = record || {};
          const sizePart =
            r.size == null || r.size === ''
              ? '—'
              : `${Number(r.size).toFixed(1)} MB`;
          const fmt = String(r.format || '').trim() || '—';
          return `大小 ${sizePart} · 格式 ${fmt}`;
        },
        wbMaterialPreviewBasicMetaLine(record) {
          const r = record || {};
          const who = String(r.uploader || r.uploadedBy || '').trim() || '—';
          const when = this.wbToOverviewMetaValue(r.uploadedAt, '—');
          return `${who} 于 ${when} 上传`;
        },
        wbMaterialTypeIcon(record) {
          const fmt = String((record && record.format) || '').toUpperCase();
          if (fmt === 'PDF') return 'fas fa-file-pdf';
          if (fmt === 'XLSX' || fmt === 'CSV') return 'fas fa-file-excel';
          if (fmt === 'DOCX') return 'fas fa-file-word';
          if (fmt === 'JSON') return 'fas fa-file-code';
          return 'fas fa-file-lines';
        },
        wbMaterialTypeIconClass(record) {
          if (!record || record.status !== 'done') return '';
          const fmt = String((record && record.format) || '').toUpperCase();
          if (fmt === 'PDF') return 'is-pdf';
          if (fmt === 'XLSX' || fmt === 'CSV') return 'is-sheet';
          if (fmt === 'DOCX') return 'is-doc';
          if (fmt === 'JSON') return 'is-data';
          return '';
        },
        openWorkbenchProjectMaterialMetaEdit(record) {
          if (!record || !record.id) return;
          this.wbMaterialMetaEditForm = {
            name: String(record.name || '').trim(),
            tags: Array.isArray(record.tags) ? [...record.tags] : [],
          };
          this.wbMaterialMetaEditTargetId = record.id;
          this.wbMaterialMetaEditVisible = true;
        },
        closeWorkbenchProjectMaterialMetaEdit() {
          this.wbMaterialMetaEditVisible = false;
          this.wbMaterialMetaEditTargetId = '';
        },
        confirmWorkbenchProjectMaterialMetaEdit() {
          const id = this.wbMaterialMetaEditTargetId;
          const pid = this.workbenchProjectId;
          const name = String((this.wbMaterialMetaEditForm && this.wbMaterialMetaEditForm.name) || '').trim();
          const tagSrc = this.wbMaterialMetaEditForm && Array.isArray(this.wbMaterialMetaEditForm.tags) ? this.wbMaterialMetaEditForm.tags : [];
          const tags = Array.from(new Set(tagSrc.map((t) => String(t || '').trim()).filter(Boolean)));
          if (!pid || !id) return;
          if (!name) {
            message.warning('请填写资料名称');
            return;
          }
          const rows = demoProjectMaterialsById[pid] || [];
          const idx = rows.findIndex((x) => x.id === id);
          if (idx < 0) return;
          rows.splice(idx, 1, { ...rows[idx], name, tags });
          const m = (this.materials || []).find((x) => x.projectSource && x.projectSource.id === id);
          if (m) {
            m.title = name;
            m.tags = [...tags];
            m.projectSource = { ...m.projectSource, name, tags };
            if (m.paired) {
              m.paired.title = `${name} - 提取结果（演示）`;
              if (tags.length) m.paired.summary = `标签：${tags.join('、')}`;
            }
          }
          this.closeWorkbenchProjectMaterialMetaEdit();
          message.success('已保存');
        },
        downloadWorkbenchMaterialPreview() {
          const rec = this.workbenchSelectedProjectMaterialRow;
          if (!rec) return;
          const pages = this.workbenchMaterialDocumentPages || [];
          const body = pages.join('\n\n---\n\n');
          const base = String(rec.name || '资料').replace(/\.[^.]+$/, '');
          const safe = base.replace(/[/\\?%*:|"<>]/g, '_');
          const blob = new Blob([body], { type: 'text/plain;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${safe}-预览.txt`;
          a.click();
          URL.revokeObjectURL(url);
          message.success('已开始下载');
        },
        startWbAnalysisModalEmbedEdit() {
          this.wbAnalysisModalActiveTab = 'body';
          this.wbAnalysisModalEmbedDraft = this.wbAnalysisModalPreviewMarkdown || '';
          this.wbAnalysisModalEmbedEditing = true;
        },
        cancelWbAnalysisModalEmbedEdit() {
          this.wbAnalysisModalEmbedEditing = false;
          this.wbAnalysisModalEmbedDraft = '';
        },
        saveWbAnalysisModalEmbedEdit() {
          const rec = this.wbAnalysisModalRecord;
          const pid = this.workbenchProjectId;
          if (!rec || !rec.id || !pid) return;
          const oldMd = String(this.wbAnalysisModalPreviewMarkdown || '');
          const md = String(this.wbAnalysisModalEmbedDraft ?? '');
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          if (oldMd !== md) {
            this.pushWorkbenchAnalysisVersionEntry(rec.id, `${now} · 保存前`, oldMd, now, '编辑前版本');
          }
          const patch = {
            analysisMarkdown: md,
            analysisMarkdownEditedBy: '我',
            analysisMarkdownEditedAt: now,
          };
          const id = rec.id;
          const list = demoProjectAnalysisResultsById[pid];
          if (Array.isArray(list)) {
            const idx = list.findIndex((r) => r && r.id === id);
            if (idx >= 0) list.splice(idx, 1, { ...list[idx], ...patch });
          }
          const m = (this.materials || []).find((x) => x.id === id && x.type === 'analysis');
          if (m) {
            m.analysisMarkdown = md;
            if (m.projectSource) Object.assign(m.projectSource, patch);
          }
          this.wbAnalysisModalRecord = { ...rec, ...patch };
          this.wbAnalysisModalEmbedEditing = false;
          this.wbAnalysisModalEmbedDraft = '';
          message.success('内容已保存');
        },
        copyWbAnalysisModalEmbedPreview() {
          if (!this.wbAnalysisModalRecord) return;
          const text = this.wbAnalysisModalEmbedEditing
            ? String(this.wbAnalysisModalEmbedDraft ?? '')
            : this.wbAnalysisModalPreviewMarkdown || '';
          const ok = () => message.success('已复制到剪贴板');
          const fail = () => message.warning('复制失败');
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(ok).catch(fail);
          } else {
            try {
              const ta = document.createElement('textarea');
              ta.value = text;
              ta.style.cssText = 'position:fixed;left:-9999px;top:0';
              document.body.appendChild(ta);
              ta.select();
              document.execCommand('copy');
              document.body.removeChild(ta);
              ok();
            } catch (_) {
              fail();
            }
          }
        },
        downloadWbAnalysisModalEmbedPreview() {
          if (!this.wbAnalysisModalRecord) return;
          const text = this.wbAnalysisModalEmbedEditing
            ? String(this.wbAnalysisModalEmbedDraft ?? '')
            : this.wbAnalysisModalPreviewMarkdown || '';
          const name = String((this.wbAnalysisModalRecord && this.wbAnalysisModalRecord.name) || '结果');
          const safe = name.replace(/[/\\?%*:|"<>]/g, '_');
          const blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${safe}.md`;
          a.click();
          URL.revokeObjectURL(url);
          message.success('已开始下载');
        },
        openWorkbenchAnalysisModal() {
          const m = this.selectedMaterial;
          if (!m || m.type !== 'analysis') return;
          this.clearWbAnalysisModalCitationFloats();
          this.wbAnalysisModalEmbedEditing = false;
          this.wbAnalysisModalEmbedDraft = '';
          const ps = m.projectSource || {};
          this.wbAnalysisModalRecord = {
            id: ps.id || m.id,
            name: ps.name || m.title,
            tags: ps.tags || m.tags,
            createdAt: ps.createdAt || m.meta,
            status: ps.status || 'done',
            analysisMarkdown: m.analysisMarkdown || ps.analysisMarkdown,
            analysisMarkdownEditedBy: ps.analysisMarkdownEditedBy,
            analysisMarkdownEditedAt: ps.analysisMarkdownEditedAt,
            citationMap: m.citationMap || ps.citationMap,
          };
          this.wbAnalysisModalActiveTab = 'body';
          this.ensureWorkbenchAnalysisVersionHistoryForRecord(this.wbAnalysisModalRecord);
          this.wbAnalysisModalOpen = true;
        },
        closeWbAnalysisModal() {
          this.wbAnalysisModalOpen = false;
          this.wbAnalysisModalRecord = null;
          this.wbAnalysisModalActiveTab = 'body';
          this.wbAnalysisModalEmbedEditing = false;
          this.wbAnalysisModalEmbedDraft = '';
          this.clearWbAnalysisModalCitationFloats();
        },
        clearWbAnalysisModalCitationFloats() {
          this.wbAnalysisModalCitationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
          if (this.wbAnalysisModalCitationPopoverTimer) {
            window.clearTimeout(this.wbAnalysisModalCitationPopoverTimer);
            this.wbAnalysisModalCitationPopoverTimer = null;
          }
        },
        showWbAnalysisModalCitationPopoverByKey(key, rect) {
          const map = this.wbAnalysisModalCitationMap || {};
          const data = map[key];
          if (!data) return;
          if (this.wbAnalysisModalCitationPopoverTimer) {
            window.clearTimeout(this.wbAnalysisModalCitationPopoverTimer);
            this.wbAnalysisModalCitationPopoverTimer = null;
          }
          let x = rect.left;
          let y = rect.bottom + 4;
          const maxW = 320;
          const maxH = 220;
          if (x + maxW > window.innerWidth) x = window.innerWidth - maxW - 8;
          if (x < 8) x = 8;
          if (y + maxH > window.innerHeight) y = rect.top - maxH - 4;
          if (y < 8) y = 8;
          const title = `${key} · ${data.sourceLabel || '溯源信息'}`;
          const excerpt = String(data.sourceExcerpt || data.sourceFullText || '').trim() || '暂无溯源内容';
          this.wbAnalysisModalCitationPopover = { show: true, title, excerpt, x, y };
        },
        onWbAnalysisModalPreviewCitationHover(event) {
          const el = event && event.target ? event.target.closest('.analysis-inline-citation') : null;
          if (!el) return;
          const key = String(el.getAttribute('data-cite') || '').trim();
          if (!key) return;
          this.showWbAnalysisModalCitationPopoverByKey(key, el.getBoundingClientRect());
        },
        onWbAnalysisModalPreviewCitationLeave() {
          this.wbAnalysisModalCitationPopoverTimer = window.setTimeout(() => {
            this.wbAnalysisModalCitationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
            this.wbAnalysisModalCitationPopoverTimer = null;
          }, 120);
        },
        onWbAnalysisModalCitationPopoverEnter() {
          if (this.wbAnalysisModalCitationPopoverTimer) {
            window.clearTimeout(this.wbAnalysisModalCitationPopoverTimer);
            this.wbAnalysisModalCitationPopoverTimer = null;
          }
        },
        onWbAnalysisModalCitationPopoverLeave() {
          this.onWbAnalysisModalPreviewCitationLeave();
        },
        isTreeNodeSelected(node, sectionKey) {
          if (!this.selectedTreeNode) return false;
          return node.id === this.selectedTreeNode.id;
        },
        selectTreeNode(node, sectionKey) {
          if (node.raw.loading) return;
          this.selectedTreeNode = { source: sectionKey === 'analysis' ? 'analysis' : 'material', id: node.id };
          if (sectionKey === 'material' || sectionKey === 'analysis') {
            if (this.canOpenMaterialPreview(node.raw) && this.canOpenAnalysisPreview(node.raw)) {
              this.openMaterialDetail(node.raw);
            }
          }
        },
        openDetailFromTreeTitle(node, sectionKey) {
          this.selectedTreeNode = { source: sectionKey === 'analysis' ? 'analysis' : 'material', id: node.id };
          this.openMaterialDetail(node.raw);
        },
        handleTreeContextMenu(key, node, sectionKey) {
          if (key === 'ref') {
            const next = !node.raw.checked;
            node.raw.checked = next;
            if (next) {
              const title = String(node.raw.title != null ? node.raw.title : '未命名').trim() || '未命名';
              this.appendChatInputToken('@' + title);
            }
            this.toastMessage = next ? '已添加到对话并已插入 @' : '已从对话移除';
            setTimeout(() => { this.toastMessage = ''; }, 1500);
            return;
          }
          if (key === 'download' && sectionKey === 'material') {
            this.downloadWorkbenchMaterialPreview();
            return;
          }
          if (key === 'download' && sectionKey === 'analysis') {
            this.downloadWorkbenchAnalysisEmbedPreview();
            return;
          }
          if (key === 'edit' || key === 'rename') {
            this.openWorkbenchTreeItemMetaEdit(node.raw, sectionKey);
            return;
          }
          this.handleMaterialMenuClick(key, node.raw);
        },
        onMaterialListAreaClick() {},
        onTreeLeafMouseEnter(node, sectionKey, ev) {
          if (this.treeNodeHoverTimer) clearTimeout(this.treeNodeHoverTimer);
          this.treeNodeHoverPopover.visible = false;
          this.treeNodeHoverTimer = setTimeout(() => {
            const rect = ev.target && ev.target.getBoundingClientRect ? ev.target.getBoundingClientRect() : { right: 0, top: 0 };
            this.treeNodeHoverPopover = { visible: true, node, sectionKey, x: rect.right + 8, y: rect.top };
            this.treeNodeHoverTimer = null;
          }, 2000);
        },
        onTreeLeafMouseLeave() {
          if (this.treeNodeHoverTimer) { clearTimeout(this.treeNodeHoverTimer); this.treeNodeHoverTimer = null; }
          if (!this.treeNodeHoverPopover.visible) return;
          if (this.treeNodeHoverCloseTimer) clearTimeout(this.treeNodeHoverCloseTimer);
          this.treeNodeHoverCloseTimer = setTimeout(() => {
            this.treeNodeHoverPopover.visible = false;
            this.treeNodeHoverCloseTimer = null;
          }, 150);
        },
        onTreeLeafPopoverMouseEnter() {
          if (this.treeNodeHoverCloseTimer) { clearTimeout(this.treeNodeHoverCloseTimer); this.treeNodeHoverCloseTimer = null; }
        },
        onTreeLeafPopoverMouseLeave() {
          this.treeNodeHoverPopover.visible = false;
        },
        getTreeNodePopoverFields(node, sectionKey) {
          const sectionLabels = { material: '资料', analysis: '结果', report: '报告' };
          const raw = node.raw;
          const pm = raw.projectSource;
          const tagList = Array.isArray(raw.tags) ? raw.tags : (pm && Array.isArray(pm.tags) ? pm.tags : []);
          const tags = tagList.length ? tagList.join('、') : '';
          const desc = raw.overview || (raw.excerpts && raw.excerpts[0]) || '—';
          if (raw.type === 'analysis') {
            const createdAt = (pm && pm.createdAt) || raw.meta || '—';
            const source = sectionLabels[sectionKey] || '结果';
            return { name: raw.title || '—', tags, sizeFormat: '', desc, source, createdAt };
          }
          const source = sectionLabels[sectionKey] || '—';
          const createdAt = (pm && pm.uploadedAt) || raw.meta || raw.createdAt || '—';
          let sizeFormat = '';
          if (pm && (pm.size != null || pm.format)) {
            sizeFormat = `${pm.size != null ? pm.size + ' MB' : '—'} · ${pm.format || '—'}`;
          }
          return { name: raw.title || '—', tags, sizeFormat, desc, source, createdAt };
        },
        onTreeLeafDragStart(ev, node, sectionKey) {
          if (node.raw.loading) { ev.preventDefault(); return; }
          const payload = { source: 'material', id: node.id };
          const raw = JSON.stringify(payload);
          ev.dataTransfer.setData('application/json', raw);
          ev.dataTransfer.setData('text/plain', raw);
          ev.dataTransfer.effectAllowed = 'copy';
        },
        onChatAreaDrop(ev) {
          ev.preventDefault();
          let raw = ev.dataTransfer.getData('application/json');
          if (!raw) raw = ev.dataTransfer.getData('text/plain');
          if (!raw) return;
          try {
            const payload = JSON.parse(raw);
            this.onTreeLeafDropInChat(ev, payload);
          } catch (e) { /* ignore */ }
        },
        onTreeLeafDropInChat(ev, payload) {
          ev.preventDefault();
          if (!payload || payload.source !== 'material' || payload.id == null) return;
          const m = this.materials.find((x) => x.id === payload.id);
          if (m) {
            m.checked = true;
            const title = String(m.title != null ? m.title : '未命名').trim() || '未命名';
            this.appendChatInputToken('@' + title);
          }
          this.toastMessage = '已添加到对话';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        openFullscreenDual(m) {
          this.fullscreenMaterialId = m.id;
          this.fullscreenLeftView = 'list';
          this.fullscreenSelectedSourceId = null;
          this.fullscreenHighlightSourceId = null;
          this.fullscreenHighlightExcerptIndex = null;
          this.fullscreenOriginalHighlight = null;
          this.fullscreenOriginalPageRefs = {};
          this.fullscreenOriginalRowRefs = {};
          this.sourcesLeftFullscreen = true;
        },
        setFullscreenOriginalPageRef(pi, el) {
          if (!el) return;
          this.fullscreenOriginalPageRefs[pi] = el;
        },
        setFullscreenOriginalRowRef(ri, el) {
          if (!el) return;
          this.fullscreenOriginalRowRefs[ri] = el;
        },
        onExtractCitationEnter(ev, ref, paired) {
          if (!paired || !paired.citations) return;
          const c = paired.citations.find((x) => x.ref === ref);
          if (!c || c.excerpt == null) return;
          if (this.citationPopoverTimer) {
            clearTimeout(this.citationPopoverTimer);
            this.citationPopoverTimer = null;
          }
          const rect = ev.target.getBoundingClientRect();
          let x = rect.left;
          let y = rect.bottom + 4;
          const maxW = 320;
          const maxH = 200;
          if (x + maxW > window.innerWidth) x = window.innerWidth - maxW - 8;
          if (x < 8) x = 8;
          if (y + maxH > window.innerHeight) y = rect.top - maxH - 4;
          if (y < 8) y = 8;
          this.citationPopover = {
            show: true,
            title: '来源片段',
            excerpt: this.buildCitationPopoverExcerpt(c.excerpt),
            x,
            y,
          };
        },
        onCitationPopoverEnter() {
          if (this.citationPopoverTimer) {
            clearTimeout(this.citationPopoverTimer);
            this.citationPopoverTimer = null;
          }
        },
        onExtractCitationLeave() {
          this.citationPopoverTimer = setTimeout(() => {
            this.citationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
            this.citationPopoverTimer = null;
          }, 150);
        },
        onExtractCitationClick(ref, paired) {
          if (!this.sourcesLeftFullscreen || !paired || !paired.citations) return;
          const c = paired.citations.find((x) => x.ref === ref);
          if (!c) return;
          if (c.pageIndex != null) {
            this.fullscreenOriginalHighlight = { pageIndex: c.pageIndex };
            this.$nextTick(() => {
              const el = this.fullscreenOriginalPageRefs[c.pageIndex];
              if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              setTimeout(() => { this.fullscreenOriginalHighlight = null; }, 2000);
            });
          } else if (c.rowIndex != null) {
            this.fullscreenOriginalHighlight = { rowIndex: c.rowIndex };
            this.$nextTick(() => {
              const el = this.fullscreenOriginalRowRefs[c.rowIndex];
              if (el && el.scrollIntoView) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              setTimeout(() => { this.fullscreenOriginalHighlight = null; }, 2000);
            });
          }
        },
        setFullscreenExcerptRef(sourceId, index, el) {
          if (!el) return;
          if (!this.fullscreenExcerptRefs[sourceId]) this.fullscreenExcerptRefs[sourceId] = {};
          this.fullscreenExcerptRefs[sourceId][index] = el;
        },
        renderFullscreenAnalysisContent(material) {
          if (!material || !material.excerptsWithCitations) return (material?.excerpts || []).map(e => (e || '').replace(/</g, '&lt;').replace(/>/g, '&gt;')).join('<br><br>');
          let html = '';
          material.excerptsWithCitations.forEach((block, bi) => {
            let text = (block.text || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            (block.citations || []).forEach((c, ci) => {
              const num = String(ci + 1);
              const regex = new RegExp('\\[' + (ci + 1) + '\\]');
              text = text.replace(
                regex,
                '<span class="nlm-citation" data-source-id="' +
                  c.sourceId +
                  '" data-excerpt-index="' +
                  c.excerptIndex +
                  '" aria-label="引用 ' +
                  num +
                  '">' +
                  num +
                  '</span>'
              );
            });
            html += (bi ? '<br><br>' : '') + '<div class="excerpt">' + text + '</div>';
          });
          return html;
        },
        handleFullscreenCitationClick(e) {
          const el = e.target.closest('.nlm-citation');
          if (!el) return;
          const sourceId = el.dataset.sourceId;
          const excerptIndex = parseInt(el.dataset.excerptIndex, 10);
          this.fullscreenLeftView = 'detail';
          this.fullscreenSelectedSourceId = sourceId;
          this.fullscreenHighlightSourceId = sourceId;
          this.fullscreenHighlightExcerptIndex = excerptIndex;
          this.$nextTick(() => {
            const ref = this.fullscreenExcerptRefs[sourceId] && this.fullscreenExcerptRefs[sourceId][excerptIndex];
            if (ref) ref.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setTimeout(() => { this.fullscreenHighlightSourceId = null; this.fullscreenHighlightExcerptIndex = null; }, 2000);
          });
        },
        getMessageFullPlainText(msg) {
          if (!msg) return '';
          if (msg.role === 'user') return String(msg.text || '');
          const t = msg.text || '';
          if (msg.chatIntro) {
            let s = `${msg.chatIntro}\n\n${t}`;
            if (msg.chatRunSummary) s += `\n\n${msg.chatRunSummary}`;
            return s;
          }
          return t;
        },
        getMessageResultPlainText(msg) {
          if (!msg) return '';
          if (msg.role === 'user') return String(msg.text || '');
          const t = String(msg.text || '');
          if (msg.chatIntro) {
            return `${msg.chatIntro}\n\n${t}`;
          }
          return t;
        },
        renderMarkdownFromBotText(raw, msg) {
          let out;
          if (typeof marked !== 'undefined') {
            try {
              const parsed = marked.parse(raw, { gfm: true, breaks: true, async: false });
              out = (typeof parsed === 'string' ? parsed : String(parsed || '')).replace(/<script\b[\s\S]*?<\/script>/gi, '').replace(/\s(on\w+)=["'][^"']*["']/g, '');
            } catch (err) {
              out = raw.replace(/</g, '&lt;').replace(/>/g, '&gt;');
            }
          } else {
            out = raw.replace(/</g, '&lt;').replace(/>/g, '&gt;');
          }
          if (msg.citations && msg.citations.length) {
            msg.citations.forEach((c, i) => {
              const idx = i + 1;
              const num = String(idx);
              const squarePattern = new RegExp(`\\[${idx}\\]`, 'g');
              const fullPattern = new RegExp(`【${idx}】`, 'g');
              const span = `<span class="nlm-citation" data-source-id="${c.sourceId}" data-excerpt-index="${c.excerptIndex}" aria-label="引用 ${num}">${num}</span>`;
              out = out.replace(squarePattern, span);
              out = out.replace(fullPattern, span);
            });
          }
          out = out.replace(/\[(E\d+)\]/g, (_, k) => `<span class="analysis-inline-citation" data-cite="${k}" aria-label="引用 ${k}">${k}</span>`);
          return out;
        },
        renderMessage(msg) {
          if (msg.role === 'user') return msg.text.replace(/</g, '&lt;').replace(/>/g, '&gt;');
          return this.renderMarkdownFromBotText(msg.text || '', msg);
        },
        renderMessageBodyHtml(msg) {
          return this.renderMarkdownFromBotText(msg.text || '', msg);
        },
        onChatMarkdownBodyClick(e) {
          if (!e.target.closest('.nlm-citation')) return;
          e.preventDefault();
          this.handleCitationClick(e);
        },
        onMsgBubbleClick(msg, e) {
          if (e.target.closest('.analysis-inline-citation')) {
            e.stopPropagation();
            this.handleChatAnalysisInlineCitationClick(e);
            return;
          }
          if (e.target.closest('.nlm-citation')) {
            e.stopPropagation();
            this.handleCitationClick(e);
            return;
          }
        },
        handleChatAnalysisInlineCitationClick(e) {
          const el = e.target.closest('.analysis-inline-citation');
          if (!el) return;
          const key = String(el.getAttribute('data-cite') || '').trim();
          if (!key || !this.workbenchAnalysisCitationMap[key]) return;
          const current = this.selectedMaterial;
          let target = null;
          if (current && current.type === 'analysis') target = current;
          else target = (this.materials || []).find((m) => m.type === 'analysis') || null;
          if (!target) return;
          this.sourcesCollapsed = false;
          this.studioCollapsed = false;
          this.lastDetailFocus = 'right';
          this.sourcesRightView = 'detail';
          this.sourcesLeftView = 'list';
          this.sourcesDetailWidth = 450;
          this.selectedMaterialId = target.id;
        },
        handleCitationClick(e) {
          const el = e.target.closest('.nlm-citation');
          if (!el) return;
          const sourceId = el.dataset.sourceId;
          const excerptIndex = parseInt(el.dataset.excerptIndex, 10);
          const found = this.findMaterialBySourceId(sourceId);
          if (!found) return;
          const m = found.material;
          if (m.loading) return;
          if (!this.canOpenMaterialPreview(m)) {
            message.info('该资料尚未完成解析，暂不可预览');
            return;
          }
          if (!this.canOpenAnalysisPreview(m)) {
            message.info('该结果尚未完成，暂不可预览');
            return;
          }
          this.sourcesCollapsed = false;
          this.studioCollapsed = false;
          this.clearWorkbenchAnalysisCitationFloats();
          this.openMaterialDetail(m);
          if (m.type === 'analysis') {
            this.$nextTick(() => {
              const root = this.$el && this.$el.querySelector ? this.$el : document.body;
              const scrollEl = root.querySelector('.analysis-result-preview-modal--workbench-embed.nlm-fill-scroll');
              if (scrollEl) scrollEl.scrollTo({ top: 0, behavior: 'smooth' });
            });
            return;
          }
          this.highlightSourceId = m.id;
          this.highlightExcerptIndex = excerptIndex;
          this.$nextTick(() => {
            const ref = this.excerptRefs[m.id] && this.excerptRefs[m.id][excerptIndex];
            if (ref) ref.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setTimeout(() => {
              this.highlightSourceId = null;
              this.highlightExcerptIndex = null;
            }, 2000);
          });
        },
        findMaterialBySourceId(sourceId) {
          for (const m of this.materials) {
            if (m.id === sourceId) return { material: m };
            if (m.paired && m.paired.id === sourceId) return { material: m };
          }
          return null;
        },
        getExcerptTextForCitation(sourceId, excerptIndex) {
          const found = this.findMaterialBySourceId(sourceId);
          if (!found) return '';
          const m = found.material;
          if (m.type === 'analysis' || m.type === 'report') {
            const block = m.excerptsWithCitations && m.excerptsWithCitations[excerptIndex];
            return block && block.text != null ? block.text : '';
          }
          if (m.excerpts && m.excerpts[excerptIndex] != null) return m.excerpts[excerptIndex];
          if (m.paired && m.paired.citations && m.paired.citations[excerptIndex]) return m.paired.citations[excerptIndex].excerpt || '';
          return '';
        },
        getCitationSourceLabel(sourceId) {
          const found = this.findMaterialBySourceId(sourceId);
          if (!found || !found.material) return '引用来源';
          return String(found.material.title || '引用来源');
        },
        buildCitationPopoverExcerpt(text) {
          const raw = String(text || '').trim();
          if (!raw) return '暂无可展示的溯源内容';
          const compact = raw.replace(/\s+/g, ' ').trim();
          return compact.length > 120 ? `${compact.slice(0, 120)}...` : compact;
        },
        onChatMsgMouseEnter(ev) {
          const analysisEl = ev.target.closest('.analysis-inline-citation');
          if (analysisEl) {
            const key = String(analysisEl.getAttribute('data-cite') || '').trim();
            const data = this.workbenchAnalysisCitationMap[key];
            if (!data) return;
            if (this.citationPopoverTimer) {
              clearTimeout(this.citationPopoverTimer);
              this.citationPopoverTimer = null;
            }
            const rect = analysisEl.getBoundingClientRect();
            let x = rect.left;
            let y = rect.bottom + 4;
            const maxW = 320;
            const maxH = 200;
            if (x + maxW > window.innerWidth) x = window.innerWidth - maxW - 8;
            if (x < 8) x = 8;
            if (y + maxH > window.innerHeight) y = rect.top - maxH - 4;
            if (y < 8) y = 8;
            this.citationPopover = {
              show: true,
              title: data.sourceLabel ? `来源：${data.sourceLabel}` : '引用来源',
              excerpt: this.buildCitationPopoverExcerpt(data.sourceExcerpt || ''),
              x,
              y,
            };
            return;
          }
          const el = ev.target.closest('.nlm-citation');
          if (!el) return;
          const sourceId = el.dataset.sourceId;
          const excerptIndex = parseInt(el.dataset.excerptIndex, 10);
          if (isNaN(excerptIndex)) return;
          const excerpt = this.getExcerptTextForCitation(sourceId, excerptIndex);
          if (this.citationPopoverTimer) {
            clearTimeout(this.citationPopoverTimer);
            this.citationPopoverTimer = null;
          }
          const rect = el.getBoundingClientRect();
          let x = rect.left;
          let y = rect.bottom + 4;
          const maxW = 320;
          const maxH = 200;
          if (x + maxW > window.innerWidth) x = window.innerWidth - maxW - 8;
          if (x < 8) x = 8;
          if (y + maxH > window.innerHeight) y = rect.top - maxH - 4;
          if (y < 8) y = 8;
          this.citationPopover = {
            show: true,
            title: `来源：${this.getCitationSourceLabel(sourceId)}`,
            excerpt: this.buildCitationPopoverExcerpt(excerpt || ''),
            x,
            y,
          };
        },
        onChatMsgMouseLeave(ev) {
          if (ev.relatedTarget && ev.relatedTarget.closest('.nlm-extract-citation-popover')) return;
          this.onExtractCitationLeave();
        },
        copyMessage(msg) {
          navigator.clipboard?.writeText(this.getMessageFullPlainText(msg));
          this.toastMessage = '已复制';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        pinMessage(msg) {
          if (msg.pinned === undefined) msg.pinned = false;
          msg.pinned = !msg.pinned;
          this.toastMessage = msg.pinned ? '已钉住' : '已取消钉住';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        openSaveResultModal(msg, payload) {
          if (payload && payload.type === 'analysisTool') {
            const rec = payload.record;
            if (!rec) return;
            const seedText = String(rec.resultMarkdown || rec.fileName || '中间结果').trim();
            const seedName = (seedText.slice(0, 28) + (seedText.length > 28 ? '...' : '') || '分析结果').trim();
            this.saveResultModalSourceType = 'analysisTool';
            this.saveResultModalSourceMsgId = null;
            this.saveResultModalSourcePayload = rec;
            this.saveResultForm = { name: seedName };
            this.saveResultModalVisible = true;
            return;
          }
          if (!msg || msg.role !== 'bot') return;
          const seedText = this.getMessageFullPlainText(msg);
          const seedName = (seedText.slice(0, 28) + (seedText.length > 28 ? '...' : '') || '对话结果').trim();
          this.saveResultModalSourceType = 'message';
          this.saveResultModalSourceMsgId = msg.id;
          this.saveResultModalSourcePayload = null;
          this.saveResultForm = { name: seedName };
          this.saveResultModalVisible = true;
        },
        closeSaveResultModal() {
          this.saveResultModalVisible = false;
          this.saveResultModalSourceType = 'message';
          this.saveResultModalSourceMsgId = null;
          this.saveResultModalSourcePayload = null;
          this.saveResultForm = { name: '' };
        },
        confirmSaveResultModal() {
          const name = String((this.saveResultForm && this.saveResultForm.name) || '').trim();
          if (!name) {
            message.warning('请先输入结果名称');
            return;
          }
          if (this.saveResultModalSourceType === 'analysisTool') {
            const rec = this.saveResultModalSourcePayload;
            if (!rec || !rec.resultMarkdown) {
              message.warning('未找到对应中间结果，无法保存');
              return;
            }
            this.createWorkbenchResultRowFromMarkdown({
              name,
              markdown: rec.resultMarkdown,
              tags: ['AI生成', '分析工具'],
              overview: `由分析工具生成的结果，来源资料：${(rec.sourceLabels || []).join('、')}`,
            });
            this.closeSaveResultModal();
            this.toastMessage = '已保存到结果';
            setTimeout(() => { this.toastMessage = ''; }, 2000);
            return;
          }
          const msg = (this.chatMessages || []).find((x) => x.id === this.saveResultModalSourceMsgId);
          if (!msg) {
            message.warning('未找到对应消息，无法保存');
            return;
          }
          this.addMessageToMaterialPool(msg, name);
          this.closeSaveResultModal();
        },
        addMessageToMaterialPool(msg, customName) {
          const text = this.getMessageFullPlainText(msg);
          const title = String(customName || '').trim() || text.slice(0, 28) + (text.length > 28 ? '...' : '') || '对话结果';
          this.createWorkbenchResultRowFromMarkdown({
            name: title,
            markdown: this.formatSavedResultBodyFromMessage(msg),
            tags: ['AI生成', '对话产出'],
            overview: text,
          });
          msg.saved = true;
          this.toastMessage = '已保存到结果';
          setTimeout(() => { this.toastMessage = ''; }, 2000);
        },
        summaryTaskStatusLabel(task) {
          const map = { queued: '排队中', running: '总结中', done: '总结完成' };
          return map[String((task && task.status) || 'queued')] || '排队中';
        },
        makeSummaryTemplateDraftFromMessage(msg) {
          const text = String((msg && this.getMessageFullPlainText(msg)) || '').trim();
          const plain = text.replace(/\s+/g, ' ').trim();
          const nameSeed = plain ? plain.slice(0, 18) : '对话总结';
          const tags = ['技能', '对话总结', '审计助手'];
          return {
            name: `${nameSeed}技能`,
            description: `基于审计助手对话内容提炼，可复用于同类审计分析任务。`,
            tags,
            analysisRule: plain || '请结合当前资料与审计发现进行结构化分析，输出关键风险、证据链和复核建议。',
            extractionRules: [
              {
                id: 'sum-er-' + Date.now().toString(36),
                title: '对话上下文与已引用资料',
                body: '提炼核心事实、关键金额/日期/主体及异常线索，形成可复用分析输入。',
                materialIds: [],
              },
            ],
          };
        },
        summarizeLatestBotMessageToTemplate() {
          const list = this.chatMessages || [];
          for (let i = list.length - 1; i >= 0; i--) {
            const m = list[i];
            if (m.role === 'bot' && m.chatIntro) {
              this.openSummarizeToTemplateModal(m);
              return;
            }
          }
          for (let i = list.length - 1; i >= 0; i--) {
            const m = list[i];
            if (m.role === 'bot') {
              this.openSummarizeToTemplateModal(m);
              return;
            }
          }
          message.info('当前对话中暂无可总结的助手回复');
        },
        openSummarizeToTemplateModal(msg) {
          if (!msg || msg.role !== 'bot') return;
          if (!this.workbenchProjectId) {
            message.warning('请先进入具体工作台后再总结为技能');
            return;
          }
          const draft = this.makeSummaryTemplateDraftFromMessage(msg);
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('缺少工作台上下文，无法创建工作台级技能');
            return;
          }
          if (!demoProjectAnalysisTemplatesById[pid]) demoProjectAnalysisTemplatesById[pid] = [];
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const placeholderId = 'sk-prj-sum-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 5);
          const placeholder = {
            id: placeholderId,
            library: 'project',
            name: draft.name,
            description: draft.description || '',
            tags: Array.from(new Set([...(draft.tags || []), '总结中'])),
            extractionRules: Array.isArray(draft.extractionRules) && draft.extractionRules.length ? draft.extractionRules.map((x) => ({ ...x })) : [{ id: 'sum-er-' + Date.now().toString(36), title: '总结中', body: '正在根据对话生成技能配置，请稍候。', materialIds: [] }],
            analysisRule: String(draft.analysisRule || '').trim(),
            manualMaterialIds: [],
            createdAt: now,
            updatedAt: now,
          };
          demoProjectAnalysisTemplatesById[pid] = [placeholder, ...(demoProjectAnalysisTemplatesById[pid] || [])];
          this.enqueueSummaryTemplateTask({
            sourceMsgId: msg.id,
            name: draft.name,
            draftTemplate: draft,
            templateId: placeholderId,
            projectId: pid,
          });
          this.workbenchLeftPrimaryTab = 'skill';
          this.sourcesCollapsed = false;
          this.sourcesLeftView = 'list';
          this.studioCollapsed = false;
          this.toastMessage = '已开始总结，已在技能栏新增工作台级技能（总结中）';
          setTimeout(() => { this.toastMessage = ''; }, 1200);
        },
        enqueueSummaryTemplateTask(payload) {
          const id = 'sum-task-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
          const task = {
            id,
            taskName: payload.name || '对话总结技能任务',
            sourceMsgId: payload.sourceMsgId || null,
            status: 'queued',
            progress: 8,
            draftTemplate: payload.draftTemplate || null,
            templateId: payload.templateId || '',
            projectId: payload.projectId || '',
            savedTemplateId: null,
          };
          this.summaryTemplateTasks = [task, ...(this.summaryTemplateTasks || [])];
          if (task.templateId) {
            this.summarySkillTaskByTemplateId = {
              ...(this.summarySkillTaskByTemplateId || {}),
              [task.templateId]: id,
            };
          }
          this.runSummaryTemplateTask(id);
          return task;
        },
        _clearSummaryTaskTimers(taskId) {
          if (!this._summaryTaskTimers) return;
          const key = String(taskId || '');
          const pair = this._summaryTaskTimers[key];
          if (!pair) return;
          if (pair.startTimer) window.clearTimeout(pair.startTimer);
          if (pair.progressTimer) window.clearInterval(pair.progressTimer);
          if (pair.doneTimer) window.clearTimeout(pair.doneTimer);
          delete this._summaryTaskTimers[key];
        },
        runSummaryTemplateTask(taskId) {
          const key = String(taskId || '');
          if (!key) return;
          if (!this._summaryTaskTimers) this._summaryTaskTimers = {};
          this._clearSummaryTaskTimers(key);
          const startTimer = window.setTimeout(() => {
            const idx = (this.summaryTemplateTasks || []).findIndex((x) => x.id === key);
            if (idx < 0) return;
            const startTask = this.summaryTemplateTasks[idx];
            this.summaryTemplateTasks.splice(idx, 1, { ...startTask, status: 'running', progress: 20 });
          }, 400);
          const progressTimer = window.setInterval(() => {
            const idx = (this.summaryTemplateTasks || []).findIndex((x) => x.id === key);
            if (idx < 0) { this._clearSummaryTaskTimers(key); return; }
            const task = this.summaryTemplateTasks[idx];
            if (task.status !== 'running') return;
            const next = Math.min(92, Number(task.progress || 20) + Math.max(3, Math.round(Math.random() * 10)));
            this.summaryTemplateTasks.splice(idx, 1, { ...task, progress: next });
          }, 520);
          const doneTimer = window.setTimeout(() => {
            const idx = (this.summaryTemplateTasks || []).findIndex((x) => x.id === key);
            if (idx < 0) return;
            const task = this.summaryTemplateTasks[idx];
            const doneTask = { ...task, status: 'done', progress: 100 };
            this.summaryTemplateTasks.splice(idx, 1, doneTask);
            this._clearSummaryTaskTimers(key);
            this.finalizeSummaryProjectSkill(doneTask);
          }, 3200);
          this._summaryTaskTimers[key] = { startTimer, progressTimer, doneTimer };
        },
        finalizeSummaryProjectSkill(task) {
          const pid = String((task && task.projectId) || '');
          const templateId = String((task && task.templateId) || '');
          if (!pid || !templateId) return;
          const list = demoProjectAnalysisTemplatesById[pid] || [];
          const idx = list.findIndex((x) => String(x.id) === templateId);
          if (idx < 0) return;
          const current = list[idx];
          const draft = task.draftTemplate || {};
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          let rules = Array.isArray(draft.extractionRules) ? draft.extractionRules : [];
          if (!rules.length) {
            rules = [{ id: 'sum-er-' + Date.now().toString(36), title: '对话上下文与已引用资料', body: '提炼核心事实并组织为可复用输入。', materialIds: [] }];
          }
          const mats = demoProjectMaterialsById[pid] || [];
          if (window.DemoProjectSkillMatch) {
            rules = rules.map((r) =>
              window.DemoProjectSkillMatch.normalizeRuleForProjectTemplate(r, (rule) =>
                window.DemoProjectSkillMatch.autoMatchMaterialIdsForRule(rule, mats),
              ),
            );
          }
          const manualMaterialIds = Array.from(
            new Set(rules.flatMap((r) => (Array.isArray(r.materialIds) ? r.materialIds : []).map((x) => String(x)))),
          );
          const tags = (Array.isArray(draft.tags) ? draft.tags : []).filter((t) => String(t || '').trim() && String(t || '').trim() !== '总结中');
          const merged = {
            ...current,
            name: String(draft.name || current.name || '未命名技能').trim(),
            description: String(draft.description || current.description || '').trim(),
            tags: tags.length ? tags : (current.tags || []).filter((t) => String(t || '').trim() !== '总结中'),
            extractionRules: rules,
            analysisRule: String(draft.analysisRule || current.analysisRule || '').trim(),
            manualMaterialIds,
            updatedAt: now,
          };
          list.splice(idx, 1, merged);
          demoProjectAnalysisTemplatesById[pid] = [...list];
          const map = { ...(this.summarySkillTaskByTemplateId || {}) };
          delete map[templateId];
          this.summarySkillTaskByTemplateId = map;
          this.toastMessage = `技能「${merged.name || '未命名'}」已总结完成`;
          setTimeout(() => { this.toastMessage = ''; }, 1600);
        },
        cancelSummaryTemplateTask(task) {
          if (!task || !task.id) return;
          Modal.confirm({
            title: '确定取消该任务？',
            content: '取消后任务卡片会消失，且本次总结结果不会保存。',
            okText: '确认取消',
            okType: 'danger',
            cancelText: '继续执行',
            onOk: () => {
              const id = String(task.id);
              const templateId = String(task.templateId || '');
              this._clearSummaryTaskTimers(id);
              this.summaryTemplateTasks = (this.summaryTemplateTasks || []).filter((x) => x.id !== id);
              if (templateId) {
                const map = { ...(this.summarySkillTaskByTemplateId || {}) };
                delete map[templateId];
                this.summarySkillTaskByTemplateId = map;
              }
              this.toastMessage = '任务已取消';
              setTimeout(() => { this.toastMessage = ''; }, 1200);
            },
          });
        },
        openSummaryTaskResultModal(task) {
          if (!task || task.status !== 'done' || !task.draftTemplate) return;
          const d = task.draftTemplate;
          const rules = Array.isArray(d.extractionRules) && d.extractionRules.length
            ? d.extractionRules.map((r) => ({
              id: r.id || ('sum-er-' + Date.now().toString(36)),
              title: String(r.title || '').trim(),
              body: String(r.body || '').trim(),
              materialIds: Array.isArray(r.materialIds) ? Array.from(new Set(r.materialIds.map((id) => String(id)))) : [],
            }))
            : [{ id: 'sum-er-' + Date.now().toString(36), title: '', body: '', materialIds: [] }];
          this.summaryTaskResultTaskId = task.id;
          this.summaryTaskResultForm = {
            name: d.name || '',
            extractionRules: rules,
            analysisRule: d.analysisRule || '',
          };
          this.summaryTaskResultExpandedRuleId = (rules[0] && rules[0].id) || '';
          this.summaryTaskResultModalVisible = true;
        },
        closeSummaryTaskResultModal() {
          this.summaryTaskResultModalVisible = false;
          this.summaryTaskResultTaskId = null;
          this.summaryTaskResultExpandedRuleId = '';
          this.summaryTaskResultForm = { name: '', extractionRules: [], analysisRule: '' };
        },
        summaryRuleMatchedMaterialCount(rule) {
          const ids = Array.isArray(rule && rule.materialIds) ? rule.materialIds : [];
          return Array.from(new Set(ids.map((x) => String(x)))).length;
        },
        toggleSummaryTemplateRuleExpand(ruleId) {
          const id = String(ruleId || '');
          if (!id) return;
          this.summaryTaskResultExpandedRuleId = this.summaryTaskResultExpandedRuleId === id ? '' : id;
        },
        addSummaryTemplateExtractionRule() {
          if (!Array.isArray(this.summaryTaskResultForm.extractionRules)) this.summaryTaskResultForm.extractionRules = [];
          const newRule = {
            id: 'sum-er-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6),
            title: '',
            body: '',
            materialIds: [],
          };
          this.summaryTaskResultForm.extractionRules.push(newRule);
          this.summaryTaskResultExpandedRuleId = newRule.id;
        },
        removeSummaryTemplateExtractionRule(index) {
          const list = Array.isArray(this.summaryTaskResultForm.extractionRules) ? this.summaryTaskResultForm.extractionRules : [];
          if (list.length <= 1) return;
          const removed = list[index];
          list.splice(index, 1);
          this.summaryTaskResultForm.extractionRules = [...list];
          if (removed && this.summaryTaskResultExpandedRuleId === removed.id) {
            this.summaryTaskResultExpandedRuleId = (list[0] && list[0].id) || '';
          }
        },
        confirmSummaryTaskResultModal() {
          const taskId = this.summaryTaskResultTaskId;
          if (!taskId) return;
          const idx = (this.summaryTemplateTasks || []).findIndex((x) => x.id === taskId);
          if (idx < 0) return;
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('缺少工作台上下文，无法保存技能');
            return;
          }
          const name = String(this.summaryTaskResultForm.name || '').trim();
          if (!name) {
            message.warning('请填写技能名称');
            return;
          }
          const draft = this.summaryTemplateTasks[idx].draftTemplate || {};
          const tags = Array.isArray(draft.tags) && draft.tags.length ? draft.tags : ['技能', '对话总结'];
          const description = String(draft.description || '').trim();
          const analysisRule = String(this.summaryTaskResultForm.analysisRule || '').trim();
          if (!demoProjectAnalysisTemplatesById[pid]) demoProjectAnalysisTemplatesById[pid] = [];
          const newId = 'sk-prj-sum-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 5);
          let rules = (this.summaryTaskResultForm.extractionRules || [])
            .map((x) => ({
              id: x.id || ('sum-er-' + Date.now().toString(36)),
              title: String(x.title || '').trim(),
              body: String(x.body || '').trim(),
              materialIds: [],
            }))
            .filter((x) => x.title && x.body);
          if (!rules.length) {
            rules = [{ id: 'sum-er-' + Date.now().toString(36), title: '对话上下文与已引用资料', body: '提炼核心事实并组织为可复用输入。', materialIds: [] }];
          }
          const mats = demoProjectMaterialsById[pid] || [];
          if (window.DemoProjectSkillMatch) {
            rules = rules.map((r) =>
              window.DemoProjectSkillMatch.normalizeRuleForProjectTemplate(r, (rule) =>
                window.DemoProjectSkillMatch.autoMatchMaterialIdsForRule(rule, mats),
              ),
            );
          }
          const manualMaterialIds = Array.from(
            new Set(rules.flatMap((r) => (Array.isArray(r.materialIds) ? r.materialIds : []).map((x) => String(x)))),
          );
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          let skillFiles = [];
          if (T && rules.length) {
            skillFiles = rules.map((r, ri) => ({
              id: newId + '-sf' + (ri + 1),
              kind: 'file',
              fileKind: 'md',
              codeLang: '',
              filename: (String(r.title || '').trim() || '条目' + (ri + 1)) + '.md',
              content: String(r.body || ''),
              materialIds: Array.isArray(r.materialIds) ? r.materialIds.slice() : [],
            }));
          }
          const row = {
            id: newId,
            library: 'project',
            name,
            description,
            tags,
            skillFiles,
            extractionRules: T && skillFiles.length ? [] : rules,
            analysisRule,
            manualMaterialIds,
            createdAt: new Date().toISOString().slice(0, 19).replace('T', ' '),
            updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' '),
          };
          if (T && T.syncExtractionRulesFromSkillFiles && skillFiles.length) {
            T.syncExtractionRulesFromSkillFiles(row);
          }
          demoProjectAnalysisTemplatesById[pid] = [row, ...(demoProjectAnalysisTemplatesById[pid] || [])];
          const currentTask = this.summaryTemplateTasks[idx];
          this.summaryTemplateTasks.splice(idx, 1, { ...currentTask, savedTemplateId: newId });
          this.closeSummaryTaskResultModal();
          this.toastMessage = '已保存为工作台级技能';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        parseChatInputAtReferences(text) {
          const t = String(text || '');
          const candidates = [];
          (this.materials || []).forEach((m) => {
            const title = String(m.title != null ? m.title : '未命名').trim() || '未命名';
            candidates.push({ id: m.id, title });
          });
          candidates.sort((a, b) => b.title.length - a.title.length);
          const used = new Set();
          const titles = [];
          let pos = 0;
          while (pos < t.length) {
            const at = t.indexOf('@', pos);
            if (at < 0) break;
            const after = t.slice(at + 1);
            let matched = null;
            for (let c = 0; c < candidates.length; c++) {
              const cand = candidates[c];
              if (after.startsWith(cand.title)) {
                const nextCh = after[cand.title.length];
                if (nextCh === undefined || /\s/.test(nextCh) || '，。、；：!！?？）]}'.includes(nextCh)) {
                  matched = cand;
                  break;
                }
              }
            }
            if (matched) {
              const ukey = 'm:' + matched.id;
              if (!used.has(ukey)) {
                used.add(ukey);
                titles.push(matched.title);
              }
              pos = at + 1 + matched.title.length;
            } else {
              pos = at + 1;
            }
          }
          return titles;
        },
        appendChatInputToken(token) {
          const raw = String(token || '').trim();
          if (!raw) return;
          const cur = this.chatInput || '';
          const sep = cur.length && !/\s$/.test(cur) ? ' ' : '';
          this.chatInput = cur + sep + raw + (/\s$/.test(raw) ? '' : ' ');
          this.$nextTick(() => {
            this.adjustInputHeight();
            const el = this.$refs.chatInputEl;
            if (el && el.focus) el.focus();
          });
        },
        closeChatInputTriggerMenu() {
          this.unbindChatAtFloaterReposition();
          this.chatAtFloaterStyle = {};
          this.chatInputTriggerOpen = false;
          this.chatInputTriggerKind = null;
          this.chatTriggerFilter = '';
          this.chatAtMenuPanel = 'categories';
        },
        pickDefaultChatInputAtRail() {
          if (this.chatAtMenuRawMaterials.length) return 'raw';
          if (this.chatAtMenuResultMaterials.length) return 'result';
          return 'raw';
        },
        syncChatInputTriggerFromCaret(text, pos) {
          const t = String(text || '');
          const p = pos == null ? t.length : Math.min(Math.max(0, pos), t.length);
          const prefix = t.slice(0, p);
          const atM = prefix.match(/(?:^|[\s\n])@([^\s\n@]*)$/);
          const slashM = prefix.match(/(?:^|[\s\n])\/([^\s\n/]*)$/);
          let pick = null;
          let atFilter = '';
          let slashFilter = '';
          if (atM) {
            atFilter = atM[1] || '';
            pick = 'at';
          }
          if (slashM) {
            slashFilter = slashM[1] || '';
            if (!pick) pick = 'slash';
            else {
              const atTrig = prefix.length - atM[0].length + (atM[0][0] === '@' ? 0 : 1);
              const slashTrig = prefix.length - slashM[0].length + (slashM[0][0] === '/' ? 0 : 1);
              pick = atTrig >= slashTrig ? 'at' : 'slash';
            }
          }
          if (pick === 'at') {
            const prev = this.chatInputTriggerKind;
            this.chatInputTriggerOpen = true;
            this.chatInputTriggerKind = 'at';
            this.chatTriggerFilter = atFilter;
            if (prev !== 'at') {
              this.chatAtMenuPanel = 'categories';
              this.chatInputAtRail = this.pickDefaultChatInputAtRail();
            }
            this.$nextTick(() => {
              this.bindChatAtFloaterReposition();
              this.scheduleUpdateChatAtFloaterPosition();
            });
            return;
          }
          if (pick === 'slash') {
            this.unbindChatAtFloaterReposition();
            this.chatAtFloaterStyle = {};
            this.chatInputTriggerOpen = true;
            this.chatInputTriggerKind = 'slash';
            this.chatTriggerFilter = slashFilter;
            return;
          }
          this.closeChatInputTriggerMenu();
        },
        onChatInputInput(e) {
          this.adjustInputHeight();
          const el = e && e.target;
          if (!el) return;
          this.syncChatInputTriggerFromCaret(el.value, el.selectionStart);
          if (this.chatInputTriggerKind === 'at' && this.chatInputTriggerOpen) {
            this.$nextTick(() => this.scheduleUpdateChatAtFloaterPosition());
          }
        },
        onChatInputKeydown(e) {
          if (e.isComposing || e.keyCode === 229) return;
          if (e.key === 'Escape' && this.chatInputTriggerOpen) {
            e.preventDefault();
            this.closeChatInputTriggerMenu();
            return;
          }
          if (e.key === 'Enter' && !e.shiftKey && this.chatInputTriggerOpen) {
            e.preventDefault();
            return;
          }
          if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            this.sendChat();
          }
        },
        onChatInputFocus() {
          if (this._chatInputBlurTimer) {
            window.clearTimeout(this._chatInputBlurTimer);
            this._chatInputBlurTimer = null;
          }
        },
        onChatInputBlur() {
          if (this._chatInputBlurTimer) window.clearTimeout(this._chatInputBlurTimer);
          this._chatInputBlurTimer = window.setTimeout(() => {
            this._chatInputBlurTimer = null;
            this.closeChatInputTriggerMenu();
          }, 180);
        },
        computeChatAtTriggerCharIndex(text, caretPos) {
          const t = String(text || '');
          const p = caretPos == null ? t.length : Math.min(Math.max(0, caretPos), t.length);
          const prefix = t.slice(0, p);
          const m = prefix.match(/(?:^|[\s\n])@([^\s\n@]*)$/);
          if (!m) return -1;
          return prefix.length - m[0].length + (m[0][0] === '@' ? 0 : 1);
        },
        getTextareaCaretViewportRectAtIndex(textarea, index) {
          if (!textarea || index == null || index < 0) return null;
          const text = String(textarea.value || '');
          const pos = Math.min(Math.max(0, index), text.length);
          const computed = window.getComputedStyle(textarea);
          const mirror = document.createElement('div');
          const ms = mirror.style;
          ms.position = 'fixed';
          ms.visibility = 'hidden';
          ms.pointerEvents = 'none';
          ms.whiteSpace = 'pre-wrap';
          ms.wordBreak = 'break-word';
          ms.overflow = 'hidden';
          ms.boxSizing = computed.boxSizing;
          ms.width = `${textarea.clientWidth}px`;
          ms.maxHeight = `${textarea.clientHeight}px`;
          ms.font = computed.font;
          ms.fontSize = computed.fontSize;
          ms.fontFamily = computed.fontFamily;
          ms.fontWeight = computed.fontWeight;
          ms.fontStyle = computed.fontStyle;
          ms.letterSpacing = computed.letterSpacing;
          ms.lineHeight = computed.lineHeight;
          ms.padding = computed.padding;
          ms.border = computed.border;
          ms.textAlign = computed.textAlign;
          ms.textTransform = computed.textTransform;
          ms.textIndent = computed.textIndent;
          const taRect = textarea.getBoundingClientRect();
          const pl = parseFloat(computed.paddingLeft) || 0;
          const pt = parseFloat(computed.paddingTop) || 0;
          const bl = parseFloat(computed.borderLeftWidth) || 0;
          const bt = parseFloat(computed.borderTopWidth) || 0;
          ms.top = `${taRect.top + bt + pt}px`;
          ms.left = `${taRect.left + bl + pl}px`;
          mirror.textContent = text.slice(0, pos);
          const span = document.createElement('span');
          span.textContent = text.slice(pos, pos + 1) || '\u200b';
          mirror.appendChild(span);
          document.body.appendChild(mirror);
          mirror.scrollTop = textarea.scrollTop;
          const rect = span.getBoundingClientRect();
          document.body.removeChild(mirror);
          const lineHeight = parseFloat(computed.lineHeight) || 20;
          const h = rect.height > 0 ? rect.height : lineHeight;
          return { left: rect.left, top: rect.top, height: h };
        },
        scheduleUpdateChatAtFloaterPosition() {
          if (this.chatInputTriggerKind !== 'at' || !this.chatInputTriggerOpen) return;
          this.$nextTick(() => {
            requestAnimationFrame(() => {
              requestAnimationFrame(() => {
                const ta = this.$refs.chatInputEl;
                if (!ta || this.chatInputTriggerKind !== 'at' || !this.chatInputTriggerOpen) return;
                const idx = this.computeChatAtTriggerCharIndex(this.chatInput || '', ta.selectionStart);
                if (idx < 0) return;
                const caret = this.getTextareaCaretViewportRectAtIndex(ta, idx);
                if (!caret) return;
                const gap = 6;
                const floater = this.$refs.chatAtTriggerFloater;
                const fw = floater && floater.offsetWidth ? floater.offsetWidth : 280;
                const fh = floater && floater.offsetHeight ? floater.offsetHeight : 220;
                const vw = window.innerWidth;
                const vh = window.innerHeight;
                const pad = 8;
                let left = caret.left;
                left = Math.min(Math.max(pad, left), vw - fw - pad);
                let top = caret.top - gap;
                const minTop = pad + fh;
                if (top < minTop) top = minTop;
                if (top > vh - pad) top = vh - pad;
                this.chatAtFloaterStyle = {
                  position: 'fixed',
                  left: `${Math.round(left)}px`,
                  top: `${Math.round(top)}px`,
                  transform: 'translateY(-100%)',
                  zIndex: 1100,
                };
              });
            });
          });
        },
        bindChatAtFloaterReposition() {
          if (this._chatAtFloaterReposBound) return;
          const fn = () => {
            if (this.chatInputTriggerKind === 'at' && this.chatInputTriggerOpen) this.scheduleUpdateChatAtFloaterPosition();
          };
          this._chatAtFloaterReposBound = fn;
          window.addEventListener('scroll', fn, true);
          window.addEventListener('resize', fn);
          if (window.visualViewport) {
            window.visualViewport.addEventListener('scroll', fn);
            window.visualViewport.addEventListener('resize', fn);
          }
        },
        unbindChatAtFloaterReposition() {
          if (!this._chatAtFloaterReposBound) return;
          const fn = this._chatAtFloaterReposBound;
          window.removeEventListener('scroll', fn, true);
          window.removeEventListener('resize', fn);
          if (window.visualViewport) {
            window.visualViewport.removeEventListener('scroll', fn);
            window.visualViewport.removeEventListener('resize', fn);
          }
          this._chatAtFloaterReposBound = null;
        },
        openChatInputAtSubmenu(key) {
          if (key !== 'raw' && key !== 'result') return;
          this.chatInputAtRail = key;
          this.chatAtMenuPanel = 'items';
          this.$nextTick(() => this.scheduleUpdateChatAtFloaterPosition());
        },
        backChatInputAtSubmenu() {
          this.chatAtMenuPanel = 'categories';
          this.$nextTick(() => this.scheduleUpdateChatAtFloaterPosition());
        },
        replaceChatInputTriggerWith(insertion) {
          const el = this.$refs.chatInputEl;
          if (!el) return;
          const text = this.chatInput || '';
          const pos = el.selectionStart;
          const prefix = text.slice(0, pos);
          const kind = this.chatInputTriggerKind;
          let start = -1;
          if (kind === 'at') {
            const m = prefix.match(/(?:^|[\s\n])@([^\s\n@]*)$/);
            if (m) start = prefix.length - m[0].length + (m[0][0] === '@' ? 0 : 1);
          } else if (kind === 'slash') {
            const m = prefix.match(/(?:^|[\s\n])\/([^\s\n/]*)$/);
            if (m) start = prefix.length - m[0].length + (m[0][0] === '/' ? 0 : 1);
          }
          if (start < 0) {
            this.closeChatInputTriggerMenu();
            return;
          }
          this.chatInput = text.slice(0, start) + insertion + text.slice(pos);
          this.closeChatInputTriggerMenu();
          this.$nextTick(() => {
            this.adjustInputHeight();
            el.focus();
            const np = start + insertion.length;
            el.selectionStart = el.selectionEnd = np;
          });
        },
        onChatInputTriggerPickMaterial(m) {
          if (!m) return;
          const t = String(m.title != null ? m.title : m.name != null ? m.name : '未命名').trim() || '未命名';
          this.replaceChatInputTriggerWith('@' + t + ' ');
          this.chatAtMenuPanel = 'categories';
        },
        onChatInputTriggerSlashMenuClick(info) {
          const key = info && info.key;
          if (!key || key === 'chat-trg-slash-empty') return;
          const secs = this.workbenchTemplateTreeSections || [];
          for (let s = 0; s < secs.length; s++) {
            const node = (secs[s].children || []).find((c) => c.key === key);
            if (node && node.raw) {
              const name = String(node.raw.name != null ? node.raw.name : '未命名').trim() || '未命名';
              this.replaceChatInputTriggerWith('/' + name + ' ');
              return;
            }
          }
        },
        adjustInputHeight() {
          this.$nextTick(() => {
            const el = this.$refs.chatInputEl;
            if (!el) return;
            el.style.height = 'auto';
            const minH = 40;
            const maxH = 176;
            const h = Math.min(maxH, Math.max(minH, el.scrollHeight));
            el.style.height = h + 'px';
            if (this.chatInputTriggerKind === 'at' && this.chatInputTriggerOpen) {
              this.scheduleUpdateChatAtFloaterPosition();
            }
          });
        },
        startDemoConversation(text, refTitles) {
          const cleanText = String(text || '').trim();
          const refs = Array.isArray(refTitles) ? refTitles.slice() : [];
          const userMsg = { id: 'm' + Date.now(), role: 'user', text: cleanText, refCount: refs.length, refTitles: refs };
          this.chatMessages.push(userMsg);
          const toolCalls = this.buildDemoToolCalls(refs, cleanText);
          const thinkId = 'think-' + Date.now();
          const thinkingMsg = {
            id: thinkId,
            role: 'thinking',
            toolCalls,
            thinkPhaseIndex: 0,
            thinkTextChars: 0,
            thinkToolStartedAt: null,
            _demoSendText: cleanText,
            _finalized: false,
            _intervalId: null,
          };
          this.chatMessages.push(thinkingMsg);
          this.$nextTick(() => {
            const wrap = this.$refs.chatMessages;
            if (wrap) wrap.scrollTop = wrap.scrollHeight;
          });
          const tickMs = 48;
          const iv = setInterval(() => {
            const thinking = this.chatMessages.find((m) => m.id === thinkId && m.role === 'thinking');
            if (!thinking || thinking._finalized) {
              clearInterval(iv);
              return;
            }
            this.advanceThinkingDemo(thinking);
            this.$nextTick(() => {
              const wrap = this.$refs.chatMessages;
              if (wrap) wrap.scrollTop = wrap.scrollHeight;
            });
          }, tickMs);
          thinkingMsg._intervalId = iv;
        },
        buildSeededDemoConversation(text, refTitles) {
          const cleanText = String(text || '').trim();
          const refs = Array.isArray(refTitles) ? refTitles.slice() : [];
          const userMsg = {
            id: 'm-seed-' + Date.now(),
            role: 'user',
            text: cleanText,
            refCount: refs.length,
            refTitles: refs,
          };
          const toolCalls = this.buildDemoToolCalls(refs, cleanText).map((call) => {
            const cloned = JSON.parse(JSON.stringify(call));
            if (cloned.type === 'todo') {
              cloned.todoDoneFlags = Array.isArray(cloned.items) ? cloned.items.map(() => true) : [];
              cloned._todoUiPhase = 'complete';
              cloned.todoExecutionLog = [];
            }
            return cloned;
          });
          const thinkingMsg = {
            id: 'think-seed-' + Date.now(),
            role: 'thinking',
            toolCalls,
            thinkPhaseIndex: toolCalls.length,
            thinkTextChars: 0,
            thinkToolStartedAt: null,
            _demoSendText: cleanText,
            _finalized: true,
            _intervalId: null,
          };
          const botMsg = this.buildDemoAnalysisBotMessage(cleanText);
          if (botMsg.chatIntro) botMsg.chatIntroProgress = botMsg.chatIntro.length;
          if (botMsg.chatRunSummary) botMsg.chatRunSummaryProgress = botMsg.chatRunSummary.length;
          return [userMsg, thinkingMsg, botMsg];
        },
        ensureDefaultDemoConversation() {
          if (!this.workbenchProjectId) return;
          if ((this.chatMessages || []).length > 0) return;
          const defaultRefs = (this.materials || [])
            .filter((m) => m && m.type === 'raw')
            .slice(0, 3)
            .map((m) => m.title || m.name || '未命名资料');
          this.chatMessages = this.buildSeededDemoConversation('总结当前工作台中的主要疑点', defaultRefs);
          this.$nextTick(() => {
            const wrap = this.$refs.chatMessages;
            if (wrap) wrap.scrollTop = wrap.scrollHeight;
          });
        },
        sendChat() {
          if (this.chatReplyInProgress) return;
          let text = String(this.chatInput || '').trim();
          const refTitles = this.parseChatInputAtReferences(text);
          const hasRefs = refTitles.length > 0;
          if (!text && !hasRefs) return;
          if (!text && hasRefs) text = '请根据 @引用 内容进行分析';
          this.chatInput = '';
          this.closeChatInputTriggerMenu();
          this.adjustInputHeight();
          this.startDemoConversation(text, refTitles);
        },
        visibleToolCalls(msg) {
          const calls = msg.toolCalls || [];
          if (!calls.length) return [];
          if (msg.thinkPhaseIndex == null) {
            const current = msg.currentStep ?? 0;
            return calls.slice(0, Math.min((current ?? 0) + 1, calls.length));
          }
          const phase = msg.thinkPhaseIndex ?? 0;
          return calls.slice(0, Math.min(phase + 1, calls.length));
        },
        newSession() {
          if (this.chatMessages.length === 0) {
            this.toastMessage = '当前无对话内容';
            setTimeout(() => { this.toastMessage = ''; }, 1500);
            return;
          }
          this.clearChatThinkingIntervals();
          const now = new Date();
          const title = '会话 ' + now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0') + ' ' + String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
          this.sessionHistory.unshift({
            id: 'session-' + Date.now(),
            title,
            createdAt: title,
            messages: JSON.parse(JSON.stringify(this.chatMessages))
          });
          this.chatMessages = [];
          this.chatInput = '';
          this.historyDropdownOpen = false;
          this.toastMessage = '已保存为历史会话';
          setTimeout(() => { this.toastMessage = ''; }, 1500);
        },
        restoreSession(session) {
          this.historyDropdownOpen = false;
          const messages = JSON.parse(JSON.stringify(session.messages));
          messages.forEach((m) => {
            if (m._intervalId != null) {
              m._intervalId = undefined;
            }
            if (m._runSummaryStartTid != null) {
              m._runSummaryStartTid = undefined;
            }
            if (m._runSummaryIv != null) {
              m._runSummaryIv = undefined;
            }
            if (m._chatIntroIv != null) {
              m._chatIntroIv = undefined;
            }
            if (m.role === 'thinking' && Array.isArray(m.toolCalls)) {
              m.toolCalls.forEach((tc) => {
                delete tc._deepThinkStart;
                if (tc.type === 'todo') {
                  delete tc._todoPlanBuilt;
                  delete tc._todoPlan;
                  delete tc._todoPlanIdx;
                  delete tc.todoScratch;
                  delete tc.todoExecutionLog;
                  delete tc._todoUiPhase;
                  delete tc._todoPlanningUntil;
                }
              });
            }
          });
          this.chatMessages = messages;
          this.$nextTick(() => {
            const wrap = this.$refs.chatMessages;
            if (wrap) wrap.scrollTop = wrap.scrollHeight;
          });
        },
        beginResize(side, e) {
          e.preventDefault();
          this.resizing = { side, startX: e.clientX, sourcesWidth: this.sourcesWidth, sourcesDetailWidth: this.sourcesDetailWidth, studioWidth: this.studioWidth };
          document.addEventListener('mousemove', this.onResizeMove);
          document.addEventListener('mouseup', this.stopResize);
        },
        onResizeMove(e) {
          if (!this.resizing || !this.$refs.mainBody) return;
          const delta = e.clientX - this.resizing.startX;
          if (this.resizing.side === 'sources') {
            if (this.sourcesLeftView === 'detail') {
              this.sourcesDetailWidth = Math.min(600, Math.max(350, this.resizing.sourcesDetailWidth + delta));
            } else {
              this.sourcesWidth = Math.min(500, Math.max(200, this.resizing.sourcesWidth + delta));
            }
          } else {
            this.studioWidth = Math.min(500, Math.max(240, this.resizing.studioWidth - delta));
          }
        },
        stopResize() {
          this.resizing = null;
          document.removeEventListener('mousemove', this.onResizeMove);
          document.removeEventListener('mouseup', this.stopResize);
        },
      },
      mounted() {
        this.initFromUrl();
        const onHash = () => this.initFromUrl();
        window.addEventListener('hashchange', onHash);
        this._freeauditHashCleanup = () => window.removeEventListener('hashchange', onHash);
        this.$el.addEventListener('click', e => {
          const el = e.target.closest('.nlm-citation');
          if (!el) return;
          const sourceId = el.dataset.sourceId;
          const excerptIndex = parseInt(el.dataset.excerptIndex, 10);
          const found = this.findMaterialBySourceId(sourceId);
          if (!found) return;
          const materialId = found.material.id;
          this.sourcesCollapsed = false;
          this.lastDetailFocus = 'left';
          this.sourcesLeftView = 'detail';
          this.selectedMaterialId = materialId;
          this.sourcesDetailWidth = 450;
          this.highlightSourceId = materialId;
          this.highlightExcerptIndex = excerptIndex;
          this.$nextTick(() => {
            const ref = this.excerptRefs[materialId] && this.excerptRefs[materialId][excerptIndex];
            if (ref) ref.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setTimeout(() => { this.highlightSourceId = null; this.highlightExcerptIndex = null; }, 2000);
          });
        });
      },
      beforeUnmount() {
        this.unbindChatAtFloaterReposition();
        if (this._chatInputBlurTimer) window.clearTimeout(this._chatInputBlurTimer);
        if (this._freeauditHashCleanup) this._freeauditHashCleanup();
        if (this._wbProjectSkillDetailSyncTimer) {
          window.clearTimeout(this._wbProjectSkillDetailSyncTimer);
          this._wbProjectSkillDetailSyncTimer = null;
        }
        if (this._summaryTaskTimers) {
          Object.keys(this._summaryTaskTimers).forEach((id) => this._clearSummaryTaskTimers(id));
        }
      }
    });

})();
