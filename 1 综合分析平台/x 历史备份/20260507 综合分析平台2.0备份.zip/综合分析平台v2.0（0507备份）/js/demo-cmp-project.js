(function () {
  const app = window.__DEMO_APP;

  /** 仅保留模式切换提醒：锚定顶栏「自动模式」切换胶囊 */
  const projectUtils = window.__DEMO_PROJECT_UTILS || {};
  const PROJECT_MODE_COACH = projectUtils.PROJECT_MODE_COACH || Object.freeze({
    title: '切换工作模式',
    body: '点击「自动模式」可切换为「辅助模式」，通过 AI 对话开展审计工作。',
    target: 'mode',
  });

    /* === DEMO:project-root · ProjectCenterView 装配根 === */
    app.component('ProjectCenterView', {
      props: { openNewProjectModal: { type: Function } },
      template: `<a-layout :class="currentProjectId ? 'shell-main project-center-detail-immersive' : 'shell-main'">
          <div class="app-main" :class="{ 'app-main--project-detail-immersive': currentProjectId }">
            <!-- DEMO:project-list → demo-cmp-project-list.js · ProjectCenterListPanel -->
            <project-center-list-panel
              v-if="!currentProjectId"
              :project-list-search="projectListSearch"
              :project-list-scope="projectListScope"
              :filtered-project-list="filteredProjectList"
              :empty-description="projectListEmptyDescription"
              :project-total-count="(projectList || []).length"
              :project-sort-by="projectListSortBy"
              :project-sort-options="projectListSortOptions"
              :card-material-count="projectCardMaterialCount"
              :card-analysis-result-count="projectCardAnalysisResultCount"
              :card-template-count="projectCardTemplateCount"
              @update:project-list-search="projectListSearch = $event"
              @update:project-list-scope="projectListScope = $event"
              @update:project-sort-by="projectListSortBy = $event"
              @clear-search="projectListSearch = ''"
              @create-space="openNewProjectModal && openNewProjectModal()"
              @open-detail="goToProjectDetail"
              @open-workbench="goToWorkbenchFromListAnimated"
              @card-menu="(info, p) => onProjectCardMoreMenu(info, p)"
            />

            <template v-else>
              <div class="skill-config-page project-detail-immersive-page">
                <!-- DEMO:project-detail-header → demo-cmp-project-detail.js · 工作台详情顶栏 -->
                <project-center-detail-header
                  :project-title="currentProject ? currentProject.name : '工作台详情'"
                  :current-project-id="currentProjectId || ''"
                  :has-project="!!currentProject"
                  :overview-tour-highlight-key="projectOverviewTourHighlightKey"
                  @back="backToProjectList"
                  @workbench="() => currentProjectId && goToWorkbenchFromListAnimated(currentProjectId)"
                  @edit="openCurrentProjectEdit"
                />
                <!-- DEMO:project-detail-body · 工作台详情 · 侧栏 + workspace -->
                <div class="project-detail-body" :class="{ 'project-detail-body--mode-exit': projectDetailModeExit, 'project-detail-body--sider-boot': projectDetailSiderBoot }">
                  <AppShellSiderMenu
                    v-model:selected-key="projectDetailTab"
                    :menu-items="projectDetailMenuItems"
                    aria-label="工作台详情分区"
                  />
                  <div class="app-shell-content-workspace">
                    <div class="ds-page-card ds-card-section app-shell-content-card">
                      <div class="project-detail-pane-stack">
                      <!-- DEMO:project-tab-overview -->
                      <ProjectOverviewTab :host="overviewHost" />
                      <!-- DEMO:project-tab-materials -->
                      <div v-show="projectDetailTab === 'materials'" class="project-detail-pane">
                          <div class="project-detail-material-toolbar">
                            <div class="project-detail-material-toolbar__title">
                              <h2 class="ds-section-title title-reset">资料</h2>
                            </div>
                            <div class="project-detail-material-toolbar__actions">
                              <a-button
                                v-if="filteredProjectMaterials.length"
                                type="primary"
                                size="large"
                                class="ds-btn-compact"
                                @click="openUploadMaterialModal"
                              ><i class="fas fa-upload ds-btn-icon-before"></i>上传资料</a-button>
                            </div>
                          </div>
                          <ui-info-control-rail
                            class="project-detail-material-control-rail"
                            aria-label="资料列表统计与批量操作及展示筛选"
                          >
                            <template #total>
                              <span class="ds-l1-stat-line">
                                <span>共 {{ filteredProjectMaterials.length }} 条资料</span>
                              </span>
                            </template>
                            <template #selection>
                              <div class="project-detail-material-batch-ops" role="group" aria-label="资料批量操作">
                                <span class="ds-l1-stat-line" aria-live="polite">已选 {{ selectedMaterialCount }} 项</span>
                                <a-button @click="openBatchTagModal('material')">批量打标签</a-button>
                                <a-button @click="batchRerunSelectedMaterials">批量重跑</a-button>
                                <a-button danger @click="batchDeleteSelectedMaterials">批量删除</a-button>
                              </div>
                            </template>
                            <template #query>
                              <a-input
                                v-model:value="projectMaterialSearchKeyword"
                                placeholder="搜索"
                                size="middle"
                                allow-clear
                                class="l1-rail-inline-search ds-input-inline-search"
                                aria-label="搜索资料列表"
                              >
                                <template #prefix>
                                  <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                                </template>
                              </a-input>
                            </template>
                            <template #filter>
                              <div class="project-detail-material-filter-tools">
                                <div class="ds-l1-tag-filter-group">
                                  <a-popover
                                    v-model:open="projectMaterialStatusPopoverOpen"
                                    trigger="click"
                                    placement="bottomLeft"
                                    :arrow="false"
                                    overlayClassName="skill-filter-popover-inner skill-filter-popover-inner--l1"
                                  >
                                    <template #content>
                                      <div class="skill-filter-popover-body skill-filter-popover-body--skill-l1">
                                        <div class="ds-l1-popover-row ds-l1-popover-row--selected">
                                          <div class="ds-l1-popover-selected-main">
                                            <span class="ds-l1-popover-line-label">已选：</span>
                                            <span class="ds-l1-popover-selected-text">{{ projectMaterialStatusKey === 'all' ? '全部状态' : materialStatusLabel(projectMaterialStatusKey) }}</span>
                                          </div>
                                          <a-button
                                            v-if="projectMaterialStatusKey !== 'all'"
                                            type="link"
                                            size="small"
                                            class="ds-l1-popover-clear-link"
                                            @click="clearProjectMaterialStatus"
                                          >清空</a-button>
                                        </div>
                                        <div class="skill-filter-tags skill-filter-tags--popover">
                                          <TagSm
                                            v-for="opt in projectMaterialStatusOptions"
                                            :key="'project-material-status-' + opt.value"
                                            variant="filter"
                                            :active="projectMaterialStatusKey === opt.value"
                                            @click="setProjectMaterialStatus(opt.value)"
                                          >{{ opt.label }}</TagSm>
                                        </div>
                                      </div>
                                    </template>
                                    <button
                                      type="button"
                                      class="ds-trigger-btn ds-trigger-btn--icon-text"
                                      :class="{ 'is-active': projectMaterialStatusPopoverOpen || projectMaterialStatusKey !== 'all', 'is-open': projectMaterialStatusPopoverOpen }"
                                      aria-label="按状态筛选"
                                      :aria-expanded="projectMaterialStatusPopoverOpen ? 'true' : 'false'"
                                    >
                                      <i class="fas fa-filter ds-trigger-btn__icon ds-trigger-btn__icon--status" aria-hidden="true"></i>
                                      <span class="ds-trigger-btn__text">状态</span>
                                    </button>
                                  </a-popover>
                                  <a-popover
                                    v-model:open="projectMaterialTagPopoverOpen"
                                    trigger="click"
                                    placement="bottomLeft"
                                    :arrow="false"
                                    overlayClassName="skill-filter-popover-inner skill-filter-popover-inner--l1"
                                  >
                                    <template #content>
                                      <div class="skill-filter-popover-body skill-filter-popover-body--skill-l1">
                                        <div class="ds-l1-popover-row ds-l1-popover-row--selected">
                                          <div class="ds-l1-popover-selected-main">
                                            <span class="ds-l1-popover-line-label">已选：</span>
                                            <span
                                              class="ds-l1-popover-selected-text"
                                              :title="projectMaterialTagKeys.length ? projectMaterialTagKeys.join('、') : ''"
                                            >{{ projectMaterialTagKeys.length ? projectMaterialTagKeys.join('、') : '暂无' }}</span>
                                          </div>
                                          <a-button
                                            v-if="projectMaterialTagKeys.length"
                                            type="link"
                                            size="small"
                                            class="ds-l1-popover-clear-link"
                                            @click="clearProjectMaterialTags"
                                          >清空</a-button>
                                        </div>
                                        <div class="ds-l1-popover-row ds-l1-popover-row--match" role="group" aria-labelledby="project-material-popover-match-label">
                                          <span id="project-material-popover-match-label" class="ds-l1-popover-line-label">多标签匹配：</span>
                                          <a-radio-group v-model:value="projectMaterialTagMatchMode" size="small" class="ds-l1-popover-match-radios">
                                            <a-radio value="any">满足任意</a-radio>
                                            <a-radio value="all">满足全部</a-radio>
                                          </a-radio-group>
                                        </div>
                                        <div class="ds-l1-popover-row ds-l1-popover-row--search">
                                          <span class="ds-l1-popover-line-label">当前标签：</span>
                                          <a-input
                                            v-model:value="projectMaterialTagSearchQuery"
                                            allow-clear
                                            placeholder="搜索"
                                            size="small"
                                            class="ds-input-inline-search ds-input-inline-search--popover"
                                          />
                                        </div>
                                        <div class="skill-filter-tags skill-filter-tags--popover">
                                          <template v-if="projectMaterialTagFilteredStats.length">
                                            <TagSm
                                              v-for="item in projectMaterialTagFilteredStats"
                                              :key="'project-material-filter-' + item.tag"
                                              variant="filter"
                                              :active="projectMaterialTagKeys.includes(item.tag)"
                                              :count="item.count"
                                              @click="toggleProjectMaterialTag(item.tag)"
                                            >{{ item.tag }}</TagSm>
                                          </template>
                                          <span v-else class="skill-filter-empty">无匹配标签</span>
                                        </div>
                                      </div>
                                    </template>
                                    <button
                                      type="button"
                                      class="ds-trigger-btn ds-trigger-btn--icon-text"
                                      :class="{ 'is-active': projectMaterialTagPopoverOpen || projectMaterialTagKeys.length, 'is-open': projectMaterialTagPopoverOpen }"
                                      aria-label="按标签筛选"
                                      :aria-expanded="projectMaterialTagPopoverOpen ? 'true' : 'false'"
                                    >
                                      <i class="fas fa-filter ds-trigger-btn__icon" aria-hidden="true"></i>
                                      <span class="ds-trigger-btn__text">标签</span>
                                      <span v-if="projectMaterialTagKeys.length" class="ds-l1-tag-picker-trigger__count">{{ projectMaterialTagKeys.length }}</span>
                                    </button>
                                  </a-popover>
                                </div>
                              </div>
                            </template>
                            <template #sort>
                              <div class="ds-l1-sort-wrap">
                                <a-dropdown v-model:open="projectMaterialSortDropdownOpen" :trigger="['click']" placement="bottomRight">
                                  <button
                                    type="button"
                                    class="ds-trigger-btn ds-trigger-btn--icon-text"
                                    :class="{ 'is-active': projectMaterialSortDropdownOpen || isProjectMaterialSortSelectedByFilter, 'is-open': projectMaterialSortDropdownOpen }"
                                    :title="'排序：' + currentProjectMaterialSortLabel"
                                    aria-label="选择排序方式"
                                    :aria-expanded="projectMaterialSortDropdownOpen ? 'true' : 'false'"
                                  >
                                    <i class="fas fa-arrow-down-short-wide ds-trigger-btn__icon" aria-hidden="true"></i>
                                    <span class="ds-trigger-btn__text">排序</span>
                                  </button>
                                  <template #overlay>
                                    <a-menu @click="onProjectMaterialSortMenuClick">
                                      <a-menu-item v-for="opt in projectMaterialSortOptions" :key="opt.value">
                                        <span class="ds-trigger-menu-item-label">
                                          <i
                                            v-if="projectMaterialSortBy === opt.value"
                                            class="fas fa-check"
                                            style="font-size:var(--ds-type-icon-inline-fs);line-height:var(--ds-type-icon-symbol-lh);"
                                          ></i>
                                          <span v-else style="width:var(--ds-icon-chevron-placeholder-w);"></span>
                                          {{ opt.label }}
                                        </span>
                                      </a-menu-item>
                                    </a-menu>
                                  </template>
                                </a-dropdown>
                              </div>
                            </template>
                          </ui-info-control-rail>
                          <div class="project-detail-pane-scroll project-detail-pane-scroll--material">
                            <template v-if="pagedProjectMaterials.length">
                              <div class="ds-l2-table-panel project-material-table-wrap">
                                <a-table
                                  :columns="projectMaterialTableColumns"
                                  :data-source="pagedProjectMaterials"
                                  :pagination="false"
                                  size="small"
                                  row-key="id"
                                  :row-class-name="projectMaterialTableRowClassName"
                                  :row-selection="projectMaterialTableRowSelection"
                                  table-layout="auto"
                                >
                                  <template #bodyCell="{ column, record }">
                                    <template v-if="column.key === 'name'">
                                      <div class="project-material-table-name-cell">
                                        <div class="project-material-icon project-material-icon--table" :class="materialTypeIconClass(record)">
                                          <i :class="materialTypeIcon(record)"></i>
                                        </div>
                                        <a-tooltip placement="topLeft" :mouse-enter-delay="0.6">
                                          <template #title>
                                            <div class="ds-text-caption-light" style="max-width: var(--ds-popover-panel-max-w); line-height: var(--ds-type-body-lh-reading);">
                                              <div><span class="text-secondary">名称：</span>{{ record.name || '—' }}</div>
                                              <div><span class="text-secondary">大小：</span>{{ Number(record.size || 0).toFixed(1) }} MB</div>
                                              <div><span class="text-secondary">格式：</span>{{ record.format || '—' }}</div>
                                              <div><span class="text-secondary">上传人：</span>{{ record.uploader || '—' }}</div>
                                              <div><span class="text-secondary">上传时间：</span>{{ record.uploadedAt || '—' }}</div>
                                              <div><span class="text-secondary">标签：</span>{{ materialTagText(record) }}</div>
                                            </div>
                                          </template>
                                          <a class="project-material-name-link" @click.prevent="viewMaterial(record)">{{ record.name }}</a>
                                        </a-tooltip>
                                      </div>
                                    </template>
                                    <template v-else-if="column.key === 'tags'">
                                      <div class="project-material-table-tags-cell">
                                        <template v-if="record.status === 'done'">
                                          <a-space v-if="(record.tags || []).length" :size="4" :wrap="false">
                                            <TagLg
                                              v-for="t in (record.tags || [])"
                                              :key="record.id + '-tbl-tag-' + t"
                                            >{{ t }}</TagLg>
                                          </a-space>
                                          <span v-else class="text-secondary ds-text-micro-secondary">未打标签</span>
                                        </template>
                                      </div>
                                    </template>
                                    <template v-else-if="column.key === 'size'">
                                      <span>{{ Number(record.size || 0).toFixed(1) }} MB</span>
                                    </template>
                                    <template v-else-if="column.key === 'format'">
                                      <span>{{ record.format || '—' }}</span>
                                    </template>
                                    <template v-else-if="column.key === 'status'">
                                      <div class="project-material-table-status-cell">
                                        <template v-if="record.status !== 'done'">
                                          <span class="ds-status-pill" :class="materialStatusPillModifier(record.status || 'queued')">
                                            <span class="ds-status-pill__dot"></span>
                                            <span class="ds-status-pill__label">{{ materialStatusLabel(record.status) }}</span>
                                          </span>
                                        </template>
                                        <template v-else>
                                          <span class="ds-status-pill is-success">
                                            <span class="ds-status-pill__dot"></span>
                                            <span class="ds-status-pill__label">{{ materialStatusLabel('done') }}</span>
                                          </span>
                                        </template>
                                      </div>
                                    </template>
                                    <template v-else-if="column.key === 'progress'">
                                      <div class="project-material-table-progress-cell">
                                        <template v-if="record.status !== 'done' && record.status !== 'failed'">
                                          <div class="project-material-progress-wrap">
                                            <a-progress :percent="materialProgressPercent(record)" size="small" :status="materialProgressStatus(record)" />
                                          </div>
                                        </template>
                                        <template v-else-if="record.status === 'failed'">
                                          <div class="project-material-progress-wrap">
                                            <a-progress :percent="materialProgressPercent(record)" size="small" status="exception" />
                                          </div>
                                        </template>
                                      </div>
                                    </template>
                                    <template v-else-if="column.key === 'action'">
                                      <div v-if="isRawProjectMaterial(record)" class="project-material-table-action-cell">
                                        <a-button type="link" class="project-material-table-action-link" @click.stop="openProjectMaterialMetaEdit(record)">编辑</a-button>
                                        <a-button type="link" class="project-material-table-action-link project-material-table-action-link--rerun" @click.stop="rerunMaterial(record)">重跑</a-button>
                                        <a-button type="link" danger class="project-material-table-action-link" @click.stop="deleteMaterial(record)">删除</a-button>
                                      </div>
                                      <span v-else class="text-secondary">—</span>
                                    </template>
                                  </template>
                                </a-table>
                              </div>
                            </template>
                            <div v-else class="project-detail-pane-empty">
                              <a-empty
                                :description="projectDetailMaterialTotalCount ? '当前筛选下没有资料。可调整筛选条件，或上传新文件。' : '暂无数据，请上传资料'"
                              />
                              <a-button type="primary" size="large" class="project-detail-pane-empty__cta" @click="openUploadMaterialModal">
                                <i class="fas fa-upload ds-btn-icon-before"></i>上传资料
                              </a-button>
                            </div>
                          </div>
                          <div class="project-detail-material-table-footer">
                            <div class="project-detail-material-table-footer__pagination">
                              <span class="project-detail-material-footer-meta">共 {{ filteredProjectMaterials.length }} 条</span>
                              <a-pagination
                                v-model:current="projectMaterialPage"
                                :page-size="projectMaterialPageSize"
                                :total="filteredProjectMaterials.length"
                                size="small"
                              />
                              <a-select
                                v-model:value="projectMaterialPageSize"
                                size="small"
                                class="project-detail-material-page-size"
                                :options="projectMaterialPageSizeOptions"
                              />
                            </div>
                          </div>
                      </div>
                      <!-- DEMO:project-tab-templates -->
                      <div v-show="projectDetailTab === 'templates'" class="project-detail-pane project-detail-pane--skill-library">
                              <div class="project-detail-template-card-head">
                                <h2 class="ds-section-title title-reset">技能</h2>
                                <div class="project-detail-template-toolbar">
                                  <a-button
                                    type="default"
                                    size="middle"
                                    class="ds-trigger-btn"
                                    title="在当前工作台新建一条技能"
                                    aria-label="创建技能"
                                    @click="openProjectSkillCreateUnified"
                                  >
                                    <i class="fas fa-plus ds-trigger-btn__icon" aria-hidden="true"></i><span class="ds-trigger-btn__text">创建技能</span>
                                  </a-button>
                                  <a-button
                                    type="primary"
                                    size="middle"
                                    class="ds-trigger-btn"
                                    title="从技能库引用到本工作台"
                                    aria-label="引用技能"
                                    @click="openAnalysisTemplateModal"
                                  >
                                    <i class="fas fa-file-import ds-trigger-btn__icon" aria-hidden="true"></i><span class="ds-trigger-btn__text">引用技能</span>
                                  </a-button>
                                </div>
                              </div>
                              <ui-info-control-rail
                                class="project-detail-template-control-rail"
                                aria-label="技能列表批量操作与筛选排序"
                              >
                                <template #total>
                                  <span class="ds-l1-stat-line">
                                    <span>共 {{ filteredProjectDetailTemplates.length }} 个技能</span>
                                  </span>
                                </template>
                                <template #selection>
                                  <div class="project-detail-material-batch-ops project-detail-material-batch-ops--skill-library" role="group" aria-label="技能批量操作">
                                    <span class="ds-l1-stat-line" aria-live="polite">已选 {{ selectedProjectSkillLibraryCount }} 项</span>
                                    <a-button @click="toggleSelectAllFilteredProjectTemplates">{{ isAllFilteredProjectTemplatesSelected ? '取消全选' : '全选' }}</a-button>
                                    <a-button @click="batchRunSelectedProjectTemplates">批量执行</a-button>
                                    <a-button @click="batchExportSelectedProjectTemplates">批量导出</a-button>
                                    <a-button danger @click="batchDeleteSelectedProjectTemplates">批量删除</a-button>
                                  </div>
                                </template>
                                <template #query>
                                  <a-input
                                    v-model:value="projectDetailTemplateSearchKeyword"
                                    placeholder="搜索"
                                    size="middle"
                                    allow-clear
                                    class="l1-rail-inline-search ds-input-inline-search"
                                    aria-label="搜索技能列表"
                                  >
                                    <template #prefix>
                                      <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                                    </template>
                                  </a-input>
                                </template>
                                <template #filter>
                                  <div class="ds-l1-tag-filter-group">
                                    <a-popover
                                      v-model:open="projectDetailTemplateTagPopoverOpen"
                                      trigger="click"
                                      placement="bottomLeft"
                                      :arrow="false"
                                      overlayClassName="skill-filter-popover-inner skill-filter-popover-inner--l1"
                                    >
                                      <template #content>
                                        <div class="skill-filter-popover-body skill-filter-popover-body--skill-l1">
                                          <div class="ds-l1-popover-row ds-l1-popover-row--selected">
                                            <div class="ds-l1-popover-selected-main">
                                              <span class="ds-l1-popover-line-label">已选：</span>
                                              <span
                                                class="ds-l1-popover-selected-text"
                                                :title="projectDetailTemplateTagKeys.length ? projectDetailTemplateTagKeys.join('、') : ''"
                                              >{{ projectDetailTemplateTagKeys.length ? projectDetailTemplateTagKeys.join('、') : '暂无' }}</span>
                                            </div>
                                            <a-button
                                              v-if="projectDetailTemplateTagKeys.length"
                                              type="link"
                                              size="small"
                                              class="ds-l1-popover-clear-link"
                                              @click="clearProjectDetailTemplateTags"
                                            >清空</a-button>
                                          </div>
                                          <div class="ds-l1-popover-row ds-l1-popover-row--match" role="group" aria-labelledby="project-tpl-popover-match-label">
                                            <span id="project-tpl-popover-match-label" class="ds-l1-popover-line-label">多标签匹配：</span>
                                            <a-radio-group v-model:value="projectDetailTemplateTagMatchMode" size="small" class="ds-l1-popover-match-radios">
                                              <a-radio value="any">满足任意</a-radio>
                                              <a-radio value="all">满足全部</a-radio>
                                            </a-radio-group>
                                          </div>
                                          <div class="ds-l1-popover-row ds-l1-popover-row--search">
                                            <span class="ds-l1-popover-line-label">当前标签：</span>
                                            <a-input
                                              v-model:value="projectDetailTemplateTagSearchQuery"
                                              allow-clear
                                              placeholder="搜索"
                                              size="small"
                                              class="ds-input-inline-search ds-input-inline-search--popover"
                                            />
                                          </div>
                                          <div class="skill-filter-tags skill-filter-tags--popover">
                                            <template v-if="projectDetailTemplateTagFilteredStats.length">
                                              <TagSm
                                                v-for="item in projectDetailTemplateTagFilteredStats"
                                                :key="'project-tpl-filter-' + item.tag"
                                                variant="filter"
                                                :active="projectDetailTemplateTagKeys.includes(item.tag)"
                                                :count="item.count"
                                                @click="toggleProjectDetailTemplateTag(item.tag)"
                                              >{{ item.tag }}</TagSm>
                                            </template>
                                            <span v-else class="skill-filter-empty">无匹配标签</span>
                                          </div>
                                        </div>
                                      </template>
                                      <button
                                        type="button"
                                        class="ds-trigger-btn ds-trigger-btn--icon-text"
                                        :class="{ 'is-active': projectDetailTemplateTagPopoverOpen || projectDetailTemplateTagKeys.length, 'is-open': projectDetailTemplateTagPopoverOpen }"
                                        aria-label="按标签筛选"
                                        :aria-expanded="projectDetailTemplateTagPopoverOpen ? 'true' : 'false'"
                                      >
                                        <i class="fas fa-filter ds-trigger-btn__icon" aria-hidden="true"></i>
                                        <span class="ds-trigger-btn__text">标签</span>
                                        <span v-if="projectDetailTemplateTagKeys.length" class="ds-l1-tag-picker-trigger__count">{{ projectDetailTemplateTagKeys.length }}</span>
                                      </button>
                                    </a-popover>
                                  </div>
                                </template>
                                <template #sort>
                                  <div class="ds-l1-sort-wrap">
                                    <a-dropdown v-model:open="projectDetailTemplateSortDropdownOpen" :trigger="['click']" placement="bottomRight">
                                      <button
                                        type="button"
                                        class="ds-trigger-btn ds-trigger-btn--icon-text"
                                        :class="{ 'is-active': projectDetailTemplateSortDropdownOpen || isProjectDetailTemplateSortSelectedByFilter, 'is-open': projectDetailTemplateSortDropdownOpen }"
                                        :title="'排序：' + currentProjectDetailTemplateSortLabel"
                                        aria-label="选择排序方式"
                                        :aria-expanded="projectDetailTemplateSortDropdownOpen ? 'true' : 'false'"
                                      >
                                        <i class="fas fa-arrow-down-short-wide ds-trigger-btn__icon" aria-hidden="true"></i>
                                        <span class="ds-trigger-btn__text">排序</span>
                                      </button>
                                      <template #overlay>
                                        <a-menu @click="onProjectDetailTemplateSortMenuClick">
                                          <a-menu-item v-for="opt in projectDetailTemplateSortOptions" :key="opt.value">
                                            <span class="ds-trigger-menu-item-label">
                                              <i
                                                v-if="projectDetailTemplateSortBy === opt.value"
                                                class="fas fa-check"
                                                style="font-size:var(--ds-type-icon-inline-fs);line-height:var(--ds-type-icon-symbol-lh);"
                                              ></i>
                                              <span v-else style="width:var(--ds-icon-chevron-placeholder-w);"></span>
                                              {{ opt.label }}
                                            </span>
                                          </a-menu-item>
                                        </a-menu>
                                      </template>
                                    </a-dropdown>
                                  </div>
                                </template>
                              </ui-info-control-rail>
                              <div class="project-detail-template-scroll">
                                <a-row v-if="filteredProjectDetailTemplates.length" :gutter="16" class="recent-projects-row project-detail-proj-template-grid">
                                  <a-col v-for="tpl in filteredProjectDetailTemplates" :key="tpl.id" :span="8">
                                      <div
                                        class="tc-template-card ds-page-card ds-hover-lift ds-list-card ds-list-card--with-corner project-detail-proj-template-card project-detail-proj-template-card--selectable"
                                        :class="{ 'is-skill-library-selected': isProjectSkillLibrarySelected(tpl) }"
                                        :data-proj-skill-slot="tpl.id"
                                        role="button"
                                        tabindex="0"
                                        title="编辑技能配置"
                                        @click="openProjectSkillDetail(tpl, { readOnly: false })"
                                        @keydown.enter.prevent="openProjectSkillDetail(tpl, { readOnly: false })"
                                        @keydown.space.prevent="openProjectSkillDetail(tpl, { readOnly: false })"
                                      >
                                        <a-dropdown class="ds-list-card-corner" :trigger="['click']" placement="bottomRight" @click.stop>
                                          <a-button type="text" size="small" class="ds-icon-btn ds-icon-btn--standard ds-list-card-more-btn" @click.stop aria-label="更多操作">
                                            <i class="fas fa-ellipsis" aria-hidden="true"></i>
                                          </a-button>
                                          <template #overlay>
                                            <a-menu @click="(info) => onProjectTemplateCardMenu(info, tpl)">
                                              <a-menu-item key="copy">复制</a-menu-item>
                                              <a-menu-item key="export">导出</a-menu-item>
                                              <a-menu-item key="archive">入库</a-menu-item>
                                              <a-menu-item key="delete" danger>删除</a-menu-item>
                                            </a-menu>
                                          </template>
                                        </a-dropdown>
                                        <div class="project-detail-proj-template-card__chk" @click.stop @mousedown.stop>
                                          <a-checkbox
                                            :checked="isProjectSkillLibrarySelected(tpl)"
                                            @change="(e) => onSkillLibraryCardCheckboxChange(tpl, e)"
                                            @click.stop
                                          />
                                        </div>
                                        <div class="tc-template-card__body">
                                          <div class="tc-template-card__title-row">
                                            <h3 class="tc-template-card__name">{{ tpl.name }}</h3>
                                          </div>
                                          <p class="tc-template-card__desc" :title="projectTemplateCardDescription(tpl)">{{ projectTemplateCardDescription(tpl) }}</p>
                                          <div class="tc-template-card__tags">
                                            <TagLg v-for="t in (tpl.tags || [])" :key="tpl.id + '-ptag-' + t">{{ t }}</TagLg>
                                            <span v-if="!(tpl.tags && tpl.tags.length)" class="ds-text-micro-secondary">未打标签</span>
                                          </div>
                                          <div class="ds-card-foot" role="group" :aria-label="'技能操作：' + (tpl.name || tpl.id)" @click.stop>
                                            <a-popover
                                              class="project-skill-resource-underlay project-skill-resource-underlay--inline"
                                              :open="projectSkillResourcePopoverOpen && projectSkillResourcePopoverSkillId === String(tpl.id)"
                                              trigger="click"
                                              placement="bottomRight"
                                              @update:open="(v) => { if (v) openProjectSkillResourcePopover(tpl); else closeProjectSkillResourcePopover(); }"
                                              @click.stop
                                            >
                                              <template #content>
                                                <div class="project-skill-resource-popover">
                                                  <div class="project-skill-resource-popover__head">
                                                    <div class="project-skill-resource-popover__title">匹配资料（{{ getSkillLinkedResourceCount(tpl) }}）</div>
                                                    <a-button type="link" size="small" @click.stop="openProjectSkillResourceEditor(tpl)">调整</a-button>
                                                  </div>
                                                  <ul v-if="getSkillLinkedResources(tpl).length" class="project-skill-resource-popover__list project-skill-resource-popover__list--simple">
                                                    <li v-for="res in getSkillLinkedResources(tpl).slice(0, 5)" :key="'res-' + tpl.id + '-' + res.id" class="project-skill-resource-popover__item">
                                                      <span class="project-skill-resource-popover__name" :title="res.name">{{ res.name }}</span>
                                                    </li>
                                                    <li
                                                      v-if="getSkillLinkedResources(tpl).length > 5"
                                                      :key="'res-more-' + tpl.id"
                                                      class="project-skill-resource-popover__item"
                                                    >
                                                      <span class="project-skill-resource-popover__name project-skill-resource-popover__name--summary">等{{ getSkillLinkedResources(tpl).length - 5 }}个资料</span>
                                                    </li>
                                                  </ul>
                                                  <a-empty v-else :image="false" description="暂无匹配资料" />
                                                </div>
                                              </template>
                                              <button
                                                type="button"
                                                class="project-skill-byline"
                                                :class="'is-' + getSkillLinkedResourceBylineState(tpl).kind"
                                                :aria-label="getSkillLinkedResourceBylineState(tpl).ariaLabel"
                                              >
                                                <i
                                                  v-if="getSkillLinkedResourceBylineState(tpl).kind === 'running'"
                                                  class="fas fa-arrows-rotate project-skill-byline__icon project-skill-byline__icon--spin"
                                                  aria-hidden="true"
                                                ></i>
                                                <i
                                                  v-else-if="getSkillLinkedResourceBylineState(tpl).kind === 'success'"
                                                  class="fas fa-check project-skill-byline__icon"
                                                  aria-hidden="true"
                                                ></i>
                                                <i
                                                  v-else-if="getSkillLinkedResourceBylineState(tpl).kind === 'failed'"
                                                  class="fas fa-circle-exclamation project-skill-byline__icon"
                                                  aria-hidden="true"
                                                ></i>
                                                <i
                                                  v-else
                                                  class="fas fa-minus project-skill-byline__icon"
                                                  aria-hidden="true"
                                                ></i>
                                                <span class="project-skill-byline__text">
                                                  <template v-if="getSkillLinkedResourceBylineState(tpl).kind === 'running'">
                                                    匹配中...
                                                  </template>
                                                  <template v-else>
                                                    匹配资料 <span class="project-skill-byline__count">{{ getSkillLinkedResourceCount(tpl) }}</span>
                                                  </template>
                                                </span>
                                              </button>
                                            </a-popover>
                                            <a-button
                                              class="ds-trigger-btn ds-trigger-btn--icon-text"
                                              title="编辑技能基本信息与配置"
                                              aria-label="编辑该技能"
                                              @click.stop="openProjectSkillDetail(tpl, { readOnly: false })"
                                            >
                                              <i class="fas fa-pen-to-square ds-trigger-btn__icon" aria-hidden="true"></i><span class="ds-trigger-btn__text">编辑</span>
                                            </a-button>
                                            <a-button
                                              class="ds-trigger-btn ds-trigger-btn--icon-text"
                                              title="基于该技能执行"
                                              aria-label="执行该技能"
                                              @click.stop="runProjectTemplateCardAnalyze(tpl)"
                                            >
                                              <i class="fas fa-play ds-trigger-btn__icon" aria-hidden="true"></i><span class="ds-trigger-btn__text">执行</span>
                                            </a-button>
                                          </div>
                                        </div>
                                      </div>
                                  </a-col>
                                </a-row>
                                <div v-else class="project-detail-pane-empty">
                                  <a-empty
                                    :description="currentProjectAnalysisTemplates.length ? '没有符合当前筛选或搜索条件的技能。' : '暂无技能，可先创建技能或从技能库引用。'"
                                  />
                                  <template v-if="currentProjectAnalysisTemplates.length">
                                    <a-button type="primary" size="large" class="project-detail-pane-empty__cta" @click="clearProjectDetailTemplateListFilters">
                                      清除筛选
                                    </a-button>
                                  </template>
                                  <div v-else class="project-detail-pane-empty__actions">
                                    <a-button
                                      type="default"
                                      size="middle"
                                      class="ds-trigger-btn project-detail-pane-empty__cta"
                                      aria-label="创建技能"
                                      @click="openProjectSkillCreateUnified"
                                    >
                                      <i class="fas fa-plus ds-trigger-btn__icon" aria-hidden="true"></i><span class="ds-trigger-btn__text">创建技能</span>
                                    </a-button>
                                    <a-button
                                      type="primary"
                                      size="middle"
                                      class="ds-trigger-btn project-detail-pane-empty__cta"
                                      aria-label="引用技能"
                                      @click="openAnalysisTemplateModal"
                                    >
                                      <i class="fas fa-file-import ds-trigger-btn__icon" aria-hidden="true"></i><span class="ds-trigger-btn__text">引用技能</span>
                                    </a-button>
                                  </div>
                                </div>
                              </div>
                      </div>
                      <!-- DEMO:project-tab-results -->
                      <div v-show="projectDetailTab === 'results'" class="project-detail-pane">
                              <div class="project-detail-template-card-head">
                                <h2 class="ds-section-title title-reset">结果</h2>
                              </div>
                          <ui-info-control-rail
                            class="project-detail-results-control-rail"
                            aria-label="结果列表统计与批量操作及展示筛选"
                          >
                            <template #total>
                              <span class="ds-l1-stat-line">
                                <span>共 {{ filteredProjectAnalysisResults.length }} 条结果</span>
                              </span>
                            </template>
                            <template #selection>
                              <div class="project-detail-material-batch-ops" role="group" aria-label="结果批量操作">
                                <span class="ds-l1-stat-line" aria-live="polite">已选 {{ selectedAnalysisResultCount }} 项</span>
                                <a-button @click="openBatchTagModal('analysisResult')">批量打标签</a-button>
                                <a-button danger @click="batchDeleteAnalysisResults">批量删除</a-button>
                              </div>
                            </template>
                            <template #query>
                              <a-input
                                v-model:value="projectAnalysisResultSearchKeyword"
                                placeholder="搜索"
                                size="middle"
                                allow-clear
                                class="l1-rail-inline-search ds-input-inline-search"
                                aria-label="搜索结果列表"
                              >
                                <template #prefix>
                                  <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                                </template>
                              </a-input>
                            </template>
                            <template #filter>
                              <div class="ds-l1-tag-filter-group">
                                <a-popover
                                  v-model:open="projectAnalysisResultStatusPopoverOpen"
                                  trigger="click"
                                  placement="bottomLeft"
                                  :arrow="false"
                                  overlayClassName="skill-filter-popover-inner skill-filter-popover-inner--l1"
                                >
                                  <template #content>
                                    <div class="skill-filter-popover-body skill-filter-popover-body--skill-l1">
                                      <div class="ds-l1-popover-row ds-l1-popover-row--selected">
                                        <div class="ds-l1-popover-selected-main">
                                          <span class="ds-l1-popover-line-label">已选：</span>
                                          <span class="ds-l1-popover-selected-text">{{ projectAnalysisResultStatusKey === 'all' ? '全部状态' : analysisResultStatusLabel(projectAnalysisResultStatusKey) }}</span>
                                        </div>
                                        <a-button
                                          v-if="projectAnalysisResultStatusKey !== 'all'"
                                          type="link"
                                          size="small"
                                          class="ds-l1-popover-clear-link"
                                          @click="clearProjectAnalysisResultStatus"
                                        >清空</a-button>
                                      </div>
                                      <div class="skill-filter-tags skill-filter-tags--popover">
                                        <TagSm
                                          v-for="opt in projectMaterialStatusOptions"
                                          :key="'project-ar-status-' + opt.value"
                                          variant="filter"
                                          :active="projectAnalysisResultStatusKey === opt.value"
                                          @click="setProjectAnalysisResultStatus(opt.value)"
                                        >{{ opt.label }}</TagSm>
                                      </div>
                                    </div>
                                  </template>
                                  <button
                                    type="button"
                                    class="ds-trigger-btn ds-trigger-btn--icon-text"
                                    :class="{ 'is-active': projectAnalysisResultStatusPopoverOpen || projectAnalysisResultStatusKey !== 'all', 'is-open': projectAnalysisResultStatusPopoverOpen }"
                                    aria-label="按状态筛选"
                                    :aria-expanded="projectAnalysisResultStatusPopoverOpen ? 'true' : 'false'"
                                  >
                                    <i class="fas fa-filter ds-trigger-btn__icon ds-trigger-btn__icon--status" aria-hidden="true"></i>
                                    <span class="ds-trigger-btn__text">状态</span>
                                  </button>
                                </a-popover>
                                <a-popover
                                  v-model:open="projectAnalysisResultTagPopoverOpen"
                                  trigger="click"
                                  placement="bottomLeft"
                                  :arrow="false"
                                  overlayClassName="skill-filter-popover-inner skill-filter-popover-inner--l1"
                                >
                                  <template #content>
                                    <div class="skill-filter-popover-body skill-filter-popover-body--skill-l1">
                                      <div class="ds-l1-popover-row ds-l1-popover-row--selected">
                                        <div class="ds-l1-popover-selected-main">
                                          <span class="ds-l1-popover-line-label">已选：</span>
                                          <span
                                            class="ds-l1-popover-selected-text"
                                            :title="projectAnalysisResultTagKeys.length ? projectAnalysisResultTagKeys.join('、') : ''"
                                          >{{ projectAnalysisResultTagKeys.length ? projectAnalysisResultTagKeys.join('、') : '暂无' }}</span>
                                        </div>
                                        <a-button
                                          v-if="projectAnalysisResultTagKeys.length"
                                          type="link"
                                          size="small"
                                          class="ds-l1-popover-clear-link"
                                          @click="clearProjectAnalysisResultTags"
                                        >清空</a-button>
                                      </div>
                                      <div class="ds-l1-popover-row ds-l1-popover-row--match" role="group" aria-labelledby="project-ar-popover-match-label">
                                        <span id="project-ar-popover-match-label" class="ds-l1-popover-line-label">多标签匹配：</span>
                                        <a-radio-group v-model:value="projectAnalysisResultTagMatchMode" size="small" class="ds-l1-popover-match-radios">
                                          <a-radio value="any">满足任意</a-radio>
                                          <a-radio value="all">满足全部</a-radio>
                                        </a-radio-group>
                                      </div>
                                      <div class="ds-l1-popover-row ds-l1-popover-row--search">
                                        <span class="ds-l1-popover-line-label">当前标签：</span>
                                        <a-input
                                          v-model:value="projectAnalysisResultTagSearchQuery"
                                          allow-clear
                                          placeholder="搜索"
                                          size="small"
                                          class="ds-input-inline-search ds-input-inline-search--popover"
                                        />
                                      </div>
                                      <div class="skill-filter-tags skill-filter-tags--popover">
                                        <template v-if="projectAnalysisResultTagFilteredStats.length">
                                          <TagSm
                                            v-for="item in projectAnalysisResultTagFilteredStats"
                                            :key="'project-ar-filter-' + item.tag"
                                            variant="filter"
                                            :active="projectAnalysisResultTagKeys.includes(item.tag)"
                                            :count="item.count"
                                            @click="toggleProjectAnalysisResultTag(item.tag)"
                                          >{{ item.tag }}</TagSm>
                                        </template>
                                        <span v-else class="skill-filter-empty">无匹配标签</span>
                                      </div>
                                    </div>
                                  </template>
                                  <button
                                    type="button"
                                    class="ds-trigger-btn ds-trigger-btn--icon-text"
                                    :class="{ 'is-active': projectAnalysisResultTagPopoverOpen || projectAnalysisResultTagKeys.length, 'is-open': projectAnalysisResultTagPopoverOpen }"
                                    aria-label="按标签筛选"
                                    :aria-expanded="projectAnalysisResultTagPopoverOpen ? 'true' : 'false'"
                                  >
                                    <i class="fas fa-filter ds-trigger-btn__icon" aria-hidden="true"></i>
                                    <span class="ds-trigger-btn__text">标签</span>
                                    <span v-if="projectAnalysisResultTagKeys.length" class="ds-l1-tag-picker-trigger__count">{{ projectAnalysisResultTagKeys.length }}</span>
                                  </button>
                                </a-popover>
                              </div>
                            </template>
                            <template #sort>
                              <div class="ds-l1-sort-wrap">
                                <a-dropdown v-model:open="projectAnalysisResultSortDropdownOpen" :trigger="['click']" placement="bottomRight">
                                  <button
                                    type="button"
                                    class="ds-trigger-btn ds-trigger-btn--icon-text"
                                    :class="{ 'is-active': projectAnalysisResultSortDropdownOpen || isProjectAnalysisResultSortSelectedByFilter, 'is-open': projectAnalysisResultSortDropdownOpen }"
                                    :title="'排序：' + currentProjectAnalysisResultSortLabel"
                                    aria-label="选择排序方式"
                                    :aria-expanded="projectAnalysisResultSortDropdownOpen ? 'true' : 'false'"
                                  >
                                    <i class="fas fa-arrow-down-short-wide ds-trigger-btn__icon" aria-hidden="true"></i>
                                    <span class="ds-trigger-btn__text">排序</span>
                                  </button>
                                  <template #overlay>
                                    <a-menu @click="onProjectAnalysisResultSortMenuClick">
                                      <a-menu-item v-for="opt in projectAnalysisResultSortOptions" :key="opt.value">
                                        <span class="ds-trigger-menu-item-label">
                                          <i
                                            v-if="projectAnalysisResultSortBy === opt.value"
                                            class="fas fa-check"
                                            style="font-size:var(--ds-type-icon-inline-fs);line-height:var(--ds-type-icon-symbol-lh);"
                                          ></i>
                                          <span v-else style="width:var(--ds-icon-chevron-placeholder-w);"></span>
                                          {{ opt.label }}
                                        </span>
                                      </a-menu-item>
                                    </a-menu>
                                  </template>
                                </a-dropdown>
                              </div>
                            </template>
                          </ui-info-control-rail>
                              <div class="project-detail-pane-scroll project-detail-pane-scroll--results">
                                <template v-if="pagedProjectAnalysisResults.length">
                                  <div class="ds-l2-table-panel analysis-result-table-wrap">
                                    <a-table
                                    class="analysis-result-table"
                                    :columns="analysisResultColumns"
                                    :data-source="pagedProjectAnalysisResults"
                                    :pagination="false"
                                    :row-selection="analysisResultTableRowSelection"
                                    :row-class-name="analysisResultTableRowClassName"
                                    size="small"
                                    row-key="id"
                                    table-layout="auto"
                                  >
                                    <template #bodyCell="{ column, record }">
                                      <template v-if="column.key === 'name'">
                                        <div class="project-material-table-name-cell">
                                          <div class="project-material-icon project-material-icon--table is-markdown" aria-hidden="true">
                                            <i class="fas fa-file-signature"></i>
                                          </div>
                                          <div class="analysis-result-table-name-text">
                                            <a v-if="record.status === 'done'" class="analysis-result-table-name-link" @click.prevent="viewAnalysisResult(record)">{{ record.name }}</a>
                                            <span v-else class="analysis-result-table-name-static" :title="'仅已完成的结果支持预览（当前：' + analysisResultStatusLabel(record.status) + '）'">{{ record.name }}</span>
                                          </div>
                                        </div>
                                      </template>
                                      <template v-else-if="column.key === 'tags'">
                                        <a-space :size="4" :wrap="false">
                                          <TagLg v-for="t in (record.tags || [])" :key="record.id + '-tag-' + t">{{ t }}</TagLg>
                                          <span v-if="!record.tags || !record.tags.length" class="text-secondary">—</span>
                                        </a-space>
                                      </template>
                                      <template v-else-if="column.key === 'status'">
                                        <span class="ds-status-pill" :class="materialStatusPillModifier(record.status || 'queued')">
                                          <span class="ds-status-pill__dot"></span>
                                          <span class="ds-status-pill__label">{{ analysisResultStatusLabel(record.status) }}</span>
                                        </span>
                                      </template>
                                      <template v-else-if="column.key === 'action'">
                                        <div v-if="record && record.id" class="project-material-table-action-cell">
                                          <a-button type="link" class="project-material-table-action-link" @click.stop="openAnalysisResultMetaEdit(record)">编辑</a-button>
                                          <a-button type="link" danger class="project-material-table-action-link" @click.stop="deleteAnalysisResult(record)">删除</a-button>
                                        </div>
                                        <span v-else class="text-secondary">—</span>
                                      </template>
                                    </template>
                                  </a-table>
                                  </div>
                                </template>
                                <div v-else class="project-detail-pane-empty">
                                  <a-empty
                                    :description="currentProjectAnalysisResults.length ? '当前筛选下没有结果。可调整筛选条件或搜索关键词。' : '暂无任何分析结果。请先在「技能」页配置并执行技能。'"
                                  />
                                  <a-button
                                    v-if="currentProjectAnalysisResults.length"
                                    type="primary"
                                    size="large"
                                    class="project-detail-pane-empty__cta"
                                    @click="clearProjectAnalysisResultListFilters"
                                  >清除筛选</a-button>
                                  <a-button
                                    v-else
                                    type="primary"
                                    size="large"
                                    class="project-detail-pane-empty__cta"
                                    @click="projectDetailTab = 'templates'"
                                  ><i class="fas fa-diagram-project ds-btn-icon-before"></i>前往技能</a-button>
                                </div>
                              </div>
                              <div class="project-detail-material-table-footer">
                                <div class="project-detail-material-table-footer__pagination">
                                  <span class="project-detail-material-footer-meta">共 {{ analysisResultTotal }} 条</span>
                                  <a-pagination
                                    :current="analysisResultPageSafe"
                                    :page-size="analysisResultPageSize"
                                    :total="analysisResultTotal"
                                    size="small"
                                    @change="onAnalysisResultPageChange"
                                  />
                                  <a-select
                                    v-model:value="analysisResultPageSize"
                                    size="small"
                                    class="project-detail-material-page-size"
                                    :options="analysisResultPageSizeOptions"
                                  />
                                </div>
                              </div>
                      </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </template>

              <!-- DEMO:project-modals · 工作台/资料/结果等弹窗 -->
              <a-modal
                v-model:open="projectSkillRunConfirmOpen"
                title="请确认技能执行范围"
                width="640"
                wrapClassName="modal-project-skill-run-confirm"
                @cancel="closeProjectSkillRunConfirm"
              >
                <div class="project-skill-run-confirm">
                  <div class="project-skill-run-confirm__title">
                    当前技能：{{ (projectSkillRunConfirmTemplate && projectSkillRunConfirmTemplate.name) || '—' }}
                  </div>
                  <a-form layout="vertical">
                    <a-form-item label="匹配资料">
                      <a-select
                        v-model:value="projectSkillRunConfirmLinkedResourceIds"
                        mode="multiple"
                        :options="projectSkillLinkedResourceSelectOptions"
                        placeholder="请选择匹配资料"
                        style="width: 100%;"
                      />
                    </a-form-item>
                  </a-form>
                </div>
                <template #footer>
                  <div class="ds-modal-footer-end">
                    <a-space>
                      <a-button @click="closeProjectSkillRunConfirm">取消</a-button>
                      <a-button type="primary" @click="confirmProjectSkillRunAnalyze">确认并执行</a-button>
                    </a-space>
                  </div>
                </template>
              </a-modal>

              <a-modal v-model:open="projectEditVisible" title="编辑工作台" width="640" wrapClassName="modal-w-640">
                <a-form layout="vertical">
                  <a-form-item label="工作台名称">
                    <a-input v-model:value="projectEditForm.name" allow-clear />
                  </a-form-item>
                  <a-form-item label="工作台简介">
                    <a-textarea v-model:value="projectEditForm.description" :rows="3" />
                  </a-form-item>
                  <a-form-item label="工作台权限">
                    <a-radio-group v-model:value="projectEditForm.visibility">
                      <a-radio value="private">仅我可见</a-radio>
                      <a-radio value="shared">指定用户可见</a-radio>
                    </a-radio-group>
                    <div v-show="projectEditForm.visibility === 'shared'" style="margin-top: var(--ds-space-sm);">
                      <space-share-picker
                        v-model:user-ids="projectEditForm.sharedUserIds"
                        v-model:dept-keys="projectEditForm.sharedDeptIds"
                      />
                    </div>
                  </a-form-item>
                </a-form>
                <template #footer>
                  <div class="ds-modal-footer-end">
                    <a-space>
                      <a-button @click="projectEditVisible = false">取消</a-button>
                      <a-button type="primary" @click="saveProjectEdit">保存</a-button>
                    </a-space>
                  </div>
                </template>
              </a-modal>
              <a-modal
                v-model:open="projectItemMetaEditVisible"
                :title="projectItemMetaEditModalTitle"
                :z-index="projectItemMetaEditModalZIndex"
                width="520"
                :wrap-class-name="projectItemMetaEditWrapClass"
                @cancel="closeProjectItemMetaEdit"
              >
                <a-form layout="vertical">
                  <a-form-item :label="projectItemMetaEditKind === 'analysisResult' ? '结果名称' : '资料名称'">
                    <a-input
                      v-model:value="projectItemMetaEditForm.name"
                      allow-clear
                      :placeholder="projectItemMetaEditKind === 'analysisResult' ? '请输入结果名称' : '请输入资料名称'"
                      @keydown.enter.prevent="confirmProjectItemMetaEdit"
                    />
                  </a-form-item>
                  <a-form-item label="标签">
                    <a-select
                      v-model:value="projectItemMetaEditForm.tags"
                      mode="tags"
                      placeholder="回车添加标签，如：合同、重点核查"
                      style="width: 100%;"
                    />
                  </a-form-item>
                </a-form>
                <template #footer>
                  <div class="ds-modal-footer-end">
                    <a-space>
                      <a-button @click="closeProjectItemMetaEdit">取消</a-button>
                      <a-button type="primary" @click="confirmProjectItemMetaEdit">保存</a-button>
                    </a-space>
                  </div>
                </template>
              </a-modal>

              <a-modal
                v-model:open="uploadMaterialVisible"
                title="上传资料"
                width="560"
                wrapClassName="modal-w-640"
                @cancel="closeUploadMaterialModal"
              >
                <div class="add-material-upload-panel">
                  <div
                    class="add-material-upload-zone add-material-drop-zone add-material-upload-zone--large"
                    @click="simulateProjectUploadSelect"
                    @dragover.prevent
                    @drop.prevent="simulateProjectUploadSelect"
                  >
                    <i class="fas fa-cloud-upload-alt add-material-upload-icon" aria-hidden="true"></i>
                    <p class="add-material-drop-title">点击或拖拽文件到此处</p>
                    <p class="add-material-drop-hint">支持 PDF、Word、Excel、图片等常见格式，单文件大小建议不超过 200MB</p>
                    <div class="add-material-source-actions">
                      <span class="add-material-pill"><i class="fas fa-file-pdf"></i>PDF</span>
                      <span class="add-material-pill"><i class="fas fa-file-word"></i>Word</span>
                      <span class="add-material-pill"><i class="fas fa-file-excel"></i>Excel</span>
                      <span class="add-material-pill"><i class="fas fa-image"></i>图片</span>
                    </div>
                  </div>
                  <div v-if="uploadMaterialBatch.length" class="add-material-pending-head">
                    <span class="add-material-pending-head__title">待上传文件（{{ uploadMaterialBatch.length }}）</span>
                    <a-button type="link" size="small" class="add-material-pending-head__clear" @click="clearUploadMaterialBatch">清空</a-button>
                  </div>
                  <div v-if="uploadMaterialBatch.length" class="add-material-pending-list">
                    <div v-for="item in uploadMaterialBatch" :key="item.id" class="add-material-pending-item">
                      <span class="add-material-pending-item-icon"><i class="fas" :class="uploadBatchFormatIcon(item.format)" aria-hidden="true"></i></span>
                      <div class="add-material-pending-item-body">
                        <span class="add-material-pending-item-name">{{ item.name }}</span>
                        <span class="add-material-pending-item-meta">{{ item.format || '—' }} · {{ formatUploadBatchSize(item.size) }}</span>
                      </div>
                      <button type="button" class="add-material-pending-item-remove" title="移除" aria-label="移除文件" @click.stop="removeUploadBatchFile(item.id)">
                        <i class="fas fa-xmark" aria-hidden="true"></i>
                      </button>
                    </div>
                  </div>
                  <div v-else class="add-material-upload-empty-hint">标签将在解析完成后由系统自动生成</div>
                </div>
                <template #footer>
                  <div class="ds-modal-footer-end">
                    <a-space>
                      <a-button @click="closeUploadMaterialModal">返回</a-button>
                      <a-button type="primary" :disabled="!uploadMaterialBatch.length" @click="submitUploadMaterial">确认添加</a-button>
                    </a-space>
                  </div>
                </template>
              </a-modal>

              <a-modal
                v-model:open="materialPreviewVisible"
                width="760"
                wrapClassName="modal-w-760 material-preview-modal material-preview-modal--unified-tabs"
                centered
                :footer="null"
                :z-index="analysisResultPreviewVisible ? 3520 : 1000"
                @cancel="closeMaterialPreviewModal"
              >
                <template #title>
                  <div class="preview-modal-title-row">
                    <span class="preview-modal-title-row__text">{{ (materialPreviewRecord && materialPreviewRecord.name) || '资料预览' }}</span>
                  </div>
                </template>
                <div ref="materialPreviewScrollEl" class="preview-modal-body-scroll">
                  <div v-if="materialPreviewRecord" class="tc-skill-modal-body tc-skill-modal-body--unified material-preview-unified-body">
                    <a-tabs v-model:activeKey="materialPreviewActiveTab" class="skill-unified-modal-tabs material-preview-unified-tabs" tab-position="left">
                      <a-tab-pane key="basic" tab="基本信息">
                        <div class="ds-unified-tab-pane-stack">
                          <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息">
                            <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                            <div class="ds-unified-tab-pane-chrome__actions"></div>
                          </div>
                          <div class="material-preview-basic-tab">
                            <div
                              v-for="(row, idx) in materialPreviewBasicMetaRows"
                              :key="'mp-meta-' + idx"
                              class="material-preview-meta-dl-row"
                            >
                              <span class="material-preview-meta-dl-label">{{ row.label }}</span>
                              <span class="material-preview-meta-dl-value">{{ row.value }}</span>
                            </div>
                          </div>
                        </div>
                      </a-tab-pane>
                      <a-tab-pane key="preview" tab="文件预览">
                        <div class="ds-unified-tab-pane-stack">
                          <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="文件预览操作">
                            <h3 class="ds-unified-tab-pane-chrome__title">文件预览</h3>
                            <div class="ds-unified-tab-pane-chrome__actions">
                              <a-button
                                type="default"
                                class="material-preview-download-link"
                                :disabled="!materialPreviewRecord"
                                title="下载"
                                aria-label="下载"
                                @click.stop="downloadMaterialPreview"
                              >
                                下载
                              </a-button>
                            </div>
                          </div>
                          <div class="preview-modal-content-frame preview-modal-content-frame--material">
                            <div class="material-preview-modal__viewer">
                              <div class="material-preview-modal__viewer-body">
                                <div
                                  v-for="(page, pi) in materialPreviewDocumentPages"
                                  :key="'preview-page-' + pi"
                                  class="nlm-original-doc-page material-preview-modal__page"
                                >{{ page }}</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </a-tab-pane>
                      <a-tab-pane key="ocr" tab="OCR结果">
                        <div class="ds-unified-tab-pane-stack">
                          <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="OCR结果">
                            <h3 class="ds-unified-tab-pane-chrome__title">OCR结果</h3>
                            <div class="ds-unified-tab-pane-chrome__actions material-preview-ocr-chrome-actions">
                              <div class="ds-mode-switch-slider material-preview-ocr-mode-switch" :class="{ 'is-assisted': materialPreviewOcrShowLineNumbers, 'is-auto': !materialPreviewOcrShowLineNumbers }" role="tablist" aria-label="OCR预览模式切换">
                                <span class="ds-mode-switch-slider__thumb" aria-hidden="true"></span>
                                <button
                                  type="button"
                                  class="ds-mode-switch-slider__item"
                                  :class="{ 'is-current': !materialPreviewOcrShowLineNumbers }"
                                  role="tab"
                                  :aria-selected="!materialPreviewOcrShowLineNumbers"
                                  :tabindex="!materialPreviewOcrShowLineNumbers ? 0 : -1"
                                  title="普通预览"
                                  aria-label="普通预览"
                                  @click="materialPreviewOcrShowLineNumbers = false"
                                >
                                  <i class="fas fa-eye" aria-hidden="true"></i>
                                </button>
                                <button
                                  type="button"
                                  class="ds-mode-switch-slider__item"
                                  :class="{ 'is-current': materialPreviewOcrShowLineNumbers }"
                                  role="tab"
                                  :aria-selected="materialPreviewOcrShowLineNumbers"
                                  :tabindex="materialPreviewOcrShowLineNumbers ? 0 : -1"
                                  title="带行号预览"
                                  aria-label="带行号预览"
                                  @click="materialPreviewOcrShowLineNumbers = true"
                                >
                                  <i class="fas fa-code" aria-hidden="true"></i>
                                </button>
                              </div>
                            </div>
                          </div>
                          <div class="material-preview-modal__viewer material-preview-modal__viewer--ocr-tab">
                            <div class="material-preview-modal__viewer-body">
                              <div
                                v-for="(page, pi) in materialPreviewOcrPagesDisplayed"
                                :key="'mp-ocr-' + pi"
                                :class="['nlm-original-doc-page', 'material-preview-modal__page', { 'ds-font-mono': materialPreviewOcrShowLineNumbers }]"
                              >{{ page }}</div>
                            </div>
                          </div>
                        </div>
                      </a-tab-pane>
                    </a-tabs>
                  </div>
                </div>
              </a-modal>

              <a-modal
                v-model:open="batchTagModalVisible"
                title="批量打标签"
                width="520"
                wrapClassName="modal-w-560"
                @cancel="closeBatchTagModal"
              >
                <a-form layout="vertical">
                  <a-form-item label="标签">
                    <a-select v-model:value="batchTagForm.tags" mode="tags" placeholder="回车添加标签，如：合同、重点核查" style="width: 100%;" />
                  </a-form-item>
                </a-form>
                <template #footer>
                  <div class="ds-modal-footer-end">
                    <a-space>
                      <a-button @click="closeBatchTagModal">取消</a-button>
                      <a-button type="primary" @click="confirmBatchTag">应用</a-button>
                    </a-space>
                  </div>
                </template>
              </a-modal>

              <a-modal
                v-model:open="analysisTemplateSelectVisible"
                title="引用技能"
                width="80%"
                wrapClassName="modal-analysis-template-picker"
                :destroy-on-close="true"
                @cancel="closeAnalysisTemplateModal"
              >
                <div style="display: flex; flex-direction: column; gap: var(--ds-space-sm); flex: 1; min-height: 0;">
                  <div class="ds-page-toolbar ds-page-toolbar--skill ds-page-toolbar--l1 ds-page-toolbar--modal-picker">
                    <div class="ds-page-toolbar__tabs">
                      <a-segmented
                        v-model:value="analysisTemplateSourceTab"
                        class="ds-ant-segmented ds-ant-segmented--l1-skill-scope"
                        size="large"
                        :options="[
                          { label: '我的技能', value: 'private' },
                          { label: '共享技能', value: 'public' },
                        ]"
                        aria-label="技能来源"
                      />
                    </div>
                  </div>
                  <div class="skill-filter-row skill-filter-row--d skill-filter-row--modal-picker" style="margin-bottom: 0;">
                    <div class="ds-text-micro-secondary analysis-template-picker-row__selected-hint" aria-live="polite">已选 {{ analysisTemplateSelectedIds.length }} 个技能</div>
                    <div class="skill-filter-d-bar">
                      <div class="skill-filter-modal-tag-slot">
                      <a-input
                        v-model:value="analysisTemplateSearchKeyword"
                        placeholder="搜索"
                        size="middle"
                        allow-clear
                        class="l1-rail-inline-search ds-page-heading-search ds-page-toolbar__search ds-input-inline-search"
                        aria-label="搜索"
                      >
                        <template #prefix>
                          <i class="fas fa-search ds-input-inline-search__icon" aria-hidden="true"></i>
                        </template>
                      </a-input>
                      <a-popover
                        v-model:open="analysisTemplateFilterPopoverOpen"
                        trigger="click"
                        placement="bottomLeft"
                        :arrow="false"
                        overlayClassName="skill-filter-popover-inner skill-filter-popover-inner--l1"
                      >
                        <template #content>
                          <div class="skill-filter-popover-body skill-filter-popover-body--skill-l1">
                            <div class="ds-l1-popover-row ds-l1-popover-row--selected">
                              <div class="ds-l1-popover-selected-main">
                                <span class="ds-l1-popover-line-label">已选：</span>
                                <span
                                  class="ds-l1-popover-selected-text"
                                  :title="analysisTemplateFilterTagKeys.length ? analysisTemplateFilterTagKeys.join('、') : ''"
                                >{{ analysisTemplateFilterTagKeys.length ? analysisTemplateFilterTagKeys.join('、') : '暂无' }}</span>
                              </div>
                              <a-button
                                v-if="analysisTemplateFilterTagKeys.length"
                                type="link"
                                size="small"
                                class="ds-l1-popover-clear-link"
                                @click="clearAnalysisTemplateFilterTags"
                              >清空</a-button>
                            </div>
                            <div class="ds-l1-popover-row ds-l1-popover-row--match" role="group" aria-labelledby="atp-modal-popover-match-label">
                              <span id="atp-modal-popover-match-label" class="ds-l1-popover-line-label">多标签匹配：</span>
                              <a-radio-group v-model:value="analysisTemplateFilterTagMatchMode" size="small" class="ds-l1-popover-match-radios">
                                <a-radio value="any">满足任意</a-radio>
                                <a-radio value="all">满足全部</a-radio>
                              </a-radio-group>
                            </div>
                            <div class="ds-l1-popover-row ds-l1-popover-row--search">
                              <span class="ds-l1-popover-line-label">当前标签：</span>
                              <a-input
                                v-model:value="analysisTemplateTagSearchQuery"
                                allow-clear
                                placeholder="搜索"
                                size="small"
                                class="ds-input-inline-search ds-input-inline-search--popover"
                              />
                            </div>
                            <div class="skill-filter-tags skill-filter-tags--popover">
                              <template v-if="analysisTemplatePickerTagFilteredStats.length">
                                <TagSm
                                  v-for="item in analysisTemplatePickerTagFilteredStats"
                                  :key="'atp-filter-' + item.tag"
                                  variant="filter"
                                  :active="analysisTemplateFilterTagKeys.includes(item.tag)"
                                  :count="item.count"
                                  @click="toggleAnalysisTemplateFilterTag(item.tag)"
                                >{{ item.tag }}</TagSm>
                              </template>
                              <span v-else class="skill-filter-empty">无匹配标签</span>
                            </div>
                          </div>
                        </template>
                        <button
                          type="button"
                          class="ds-trigger-btn ds-trigger-btn--icon-text"
                          :class="{ 'is-active': analysisTemplateFilterPopoverOpen || analysisTemplateFilterTagKeys.length, 'is-open': analysisTemplateFilterPopoverOpen }"
                          :title="analysisTemplateFilterTagKeys.length ? ('筛选标签（已选 ' + analysisTemplateFilterTagKeys.length + ' 个）') : '筛选标签'"
                          aria-label="筛选标签"
                          :aria-expanded="analysisTemplateFilterPopoverOpen ? 'true' : 'false'"
                        >
                          <i class="fas fa-filter ds-trigger-btn__icon" aria-hidden="true"></i>
                          <span class="ds-trigger-btn__text">标签</span>
                          <span v-if="analysisTemplateFilterTagKeys.length" class="ds-l1-tag-picker-trigger__count">{{ analysisTemplateFilterTagKeys.length }}</span>
                        </button>
                      </a-popover>
                      </div>
                    </div>
                    <div class="skill-filter-sort-wrap">
                      <a-dropdown v-model:open="analysisTemplateSortDropdownOpen" :trigger="['click']" placement="bottomRight">
                        <button
                          type="button"
                          class="ds-trigger-btn ds-trigger-btn--icon-text"
                          :class="{ 'is-active': analysisTemplateSortDropdownOpen || !!(analysisTemplateFilterTagKeys || []).length, 'is-open': analysisTemplateSortDropdownOpen }"
                          :title="'排序：' + currentAnalysisTemplatePickerSortLabel"
                          aria-label="选择排序方式"
                          :aria-expanded="analysisTemplateSortDropdownOpen ? 'true' : 'false'"
                        >
                          <i class="fas fa-arrow-down-short-wide ds-trigger-btn__icon" aria-hidden="true"></i>
                          <span class="ds-trigger-btn__text">排序</span>
                        </button>
                        <template #overlay>
                          <a-menu @click="onAnalysisTemplatePickerSortMenuClick">
                            <a-menu-item v-for="opt in analysisTemplatePickerSortOptions" :key="opt.value">
                              <span class="ds-trigger-menu-item-label">
                                <i
                                  v-if="analysisTemplateSortBy === opt.value"
                                  class="fas fa-check"
                                  style="font-size:var(--ds-type-icon-inline-fs);line-height:var(--ds-type-icon-symbol-lh);"
                                ></i>
                                <span v-else style="width:var(--ds-icon-chevron-placeholder-w);"></span>
                                {{ opt.label }}
                              </span>
                            </a-menu-item>
                          </a-menu>
                        </template>
                      </a-dropdown>
                    </div>
                  </div>
                  <div class="analysis-template-picker-scroll">
                    <a-checkbox-group v-model:value="analysisTemplateSelectedIds" style="width: 100%; display: block;">
                      <a-row v-if="filteredSelectableAnalysisTemplates.length" :gutter="[16, 16]">
                        <a-col
                          v-for="tpl in filteredSelectableAnalysisTemplates"
                          :key="'picker-card-' + tpl.id"
                          :xs="24"
                          :sm="12"
                          :md="8"
                          :lg="8"
                          :xl="8"
                        >
                            <div
                              class="tc-template-card ds-page-card ds-hover-lift ds-list-card project-detail-proj-template-card project-detail-proj-template-card--selectable"
                              :class="{ 'is-skill-library-selected': analysisTemplateSelectedIds.includes(tpl.id) }"
                            >
                              <div class="project-detail-proj-template-card__chk" @click.stop @mousedown.stop>
                                <a-checkbox :value="tpl.id" @click.stop />
                              </div>
                              <div class="tc-template-card__body" @click="toggleAnalysisTemplatePick(tpl.id)">
                                <div class="tc-template-card__title-row">
                                  <h3 class="tc-template-card__name">{{ tpl.name }}</h3>
                                </div>
                                <p class="tc-template-card__desc" :title="projectTemplateCardDescription(tpl)">{{ projectTemplateCardDescription(tpl) }}</p>
                                <div class="tc-template-card__tags">
                                  <TagLg v-for="t in (tpl.tags || [])" :key="tpl.id + '-ptag-' + t">{{ t }}</TagLg>
                                  <span v-if="!(tpl.tags && tpl.tags.length)" class="ds-text-micro-secondary">未打标签</span>
                                </div>
                                <div class="ds-card-foot" role="group" :aria-label="'技能操作：' + (tpl.name || tpl.id)" @click.stop>
                                  <a-button
                                    class="ds-trigger-btn ds-trigger-btn--icon-text"
                                    title="查看技能详情"
                                    aria-label="查看技能详情"
                                    @click.stop="openProjectSkillDetail(tpl, { readOnly: true, fromPool: true })"
                                  >
                                    <i class="fas fa-circle-info ds-trigger-btn__icon" aria-hidden="true"></i><span class="ds-trigger-btn__text">详情</span>
                                  </a-button>
                                </div>
                              </div>
                            </div>
                        </a-col>
                      </a-row>
                      <div v-else style="padding: var(--ds-space-l) 0;">
                        <a-empty description="当前条件下无可选技能" />
                      </div>
                    </a-checkbox-group>
                  </div>
                </div>
                <template #footer>
                  <div class="ds-modal-footer-end">
                    <a-space>
                      <a-button @click="closeAnalysisTemplateModal">取消</a-button>
                      <a-button type="primary" @click="confirmAddAnalysisTemplates">添加</a-button>
                    </a-space>
                  </div>
                </template>
              </a-modal>
              <a-modal
                v-model:open="projectSkillCreateBasicModalOpen"
                title="创建技能"
                width="560"
                centered
                :maskClosable="false"
                @cancel="closeProjectSkillCreateBasicModal"
              >
                <a-form layout="vertical">
                  <a-form-item label="技能名称" required>
                    <a-input v-model:value="projectSkillCreateBasicForm.name" placeholder="请输入技能名称" allow-clear :maxlength="60" />
                  </a-form-item>
                  <a-form-item label="技能描述">
                    <a-textarea
                      v-model:value="projectSkillCreateBasicForm.description"
                      placeholder="选填。描述该技能的用途与适用场景"
                      :rows="3"
                      :maxlength="300"
                      show-count
                    />
                  </a-form-item>
                  <a-form-item label="标签" style="margin-bottom: 0;">
                    <a-select
                      v-model:value="projectSkillCreateBasicForm.tags"
                      mode="tags"
                      placeholder="回车添加标签，如：函证、凭证核对"
                      style="width: 100%"
                    />
                  </a-form-item>
                </a-form>
                <template #footer>
                  <a-button @click="closeProjectSkillCreateBasicModal">取消</a-button>
                  <a-button type="primary" :loading="projectSkillCreateBasicSubmitting" @click="submitProjectSkillCreateBasic">提交并继续配置</a-button>
                </template>
              </a-modal>
              <a-modal
                v-model:open="projectSkillDetailModalOpen"
                width="1040"
                wrapClassName="modal-skill-config modal-project-skill-config"
                :z-index="projectSkillDetailPoolPreview ? 1200 : undefined"
                centered
                :footer="null"
                :maskClosable="false"
                @cancel="() => closeProjectSkillDetailModal(false)"
              >
                <template #title>
                  <div class="skill-modal-config-title-row">
                    <div class="skill-modal-config-title-main">
                      <span class="skill-modal-config-title-text">{{ projectSkillDetailModalTitle }}</span>
                    </div>
                  </div>
                </template>
                <div v-if="selectedProjectSkill" class="tc-skill-modal-body tc-skill-modal-body--unified">
                  <a-tabs :activeKey="projectSkillDetailActiveTab" class="skill-unified-modal-tabs" tab-position="left" @update:activeKey="onProjectSkillTabUpdate">
                    <a-tab-pane key="basic" tab="基本信息">
                      <div class="ds-unified-tab-pane-stack">
                        <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息操作">
                          <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                          <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions">
                            <template v-if="!projectSkillDetailReadOnly">
                              <a-button v-if="!projectSkillBasicPaneEditing" type="primary" @click="startProjectSkillBasicPaneEdit">编辑</a-button>
                              <template v-else>
                                <a-button @click="cancelProjectSkillBasicPaneEdit">取消</a-button>
                                <a-button type="primary" @click="saveProjectSkillBasicPane">保存</a-button>
                              </template>
                            </template>
                          </div>
                        </div>
                        <a-form layout="vertical" class="skill-modal-form skill-wizard-panel skill-unified-tab-basic">
                          <a-form-item label="名称" required>
                            <a-input
                              v-model:value="projectSkillForm.name"
                              placeholder="如：三公经费异常波动扫描"
                              allow-clear
                              :disabled="projectSkillBasicFieldsLocked"
                            />
                          </a-form-item>
                          <a-form-item label="简介">
                            <a-textarea
                              v-model:value="projectSkillForm.description"
                              placeholder="用途示例：系统自动比对合同与发票金额及时间逻辑，输出异常清单并提示优先核查项。"
                              :rows="2"
                              :disabled="projectSkillBasicFieldsLocked"
                            />
                          </a-form-item>
                          <a-form-item label="标签" style="margin-bottom: 0;">
                            <a-select
                              v-model:value="projectSkillForm.tags"
                              mode="tags"
                              placeholder="回车添加，如：财务、合规"
                              style="width: 100%"
                              :disabled="projectSkillBasicFieldsLocked"
                            />
                          </a-form-item>
                        </a-form>
                      </div>
                    </a-tab-pane>
                    <a-tab-pane key="config" tab="技能配置">
                  <div class="ds-unified-tab-pane-stack">
                    <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="技能配置操作">
                      <h3 class="ds-unified-tab-pane-chrome__title">技能配置</h3>
                      <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions">
                        <template v-if="!projectSkillDetailReadOnly">
                          <a-button v-if="!projectSkillConfigPaneEditing" type="default" @click="onProjectSkillConfigSaveMenuClick({ key: 'publish-new' })">快照</a-button>
                          <a-button v-if="!projectSkillConfigPaneEditing" type="primary" @click="startProjectSkillConfigPaneEdit">编辑</a-button>
                          <template v-else>
                            <a-button @click="cancelProjectSkillConfigPaneEdit">取消</a-button>
                            <a-button type="primary" @click="saveProjectSkillConfigPane">保存</a-button>
                          </template>
                        </template>
                      </div>
                    </div>
                  <div class="skill-config-master-detail">
                    <aside class="skill-config-nav-pane" aria-label="技能配置结构">
                      <div class="skill-config-nav-tree">
                        <div class="skill-config-nav-tree-head skill-config-nav-tree-head--with-actions">
                          <span>可配置文件</span>
                          <a-dropdown
                            :trigger="['hover', 'click']"
                            placement="bottomRight"
                            overlayClassName="skill-config-add-file-dropdown"
                          >
                            <a-button
                              type="text"
                              size="small"
                              class="ds-icon-btn ds-icon-btn--standard skill-config-nav-add-btn"
                              aria-label="添加文件或文件夹"
                              :disabled="projectSkillConfigTabLocked"
                              @click.stop
                            >
                              <i class="fas fa-plus" aria-hidden="true"></i>
                            </a-button>
                            <template #overlay>
                              <a-menu @click="onProjectSkillConfigAddMenuClick">
                                <a-menu-item key="md">Markdown（.md）</a-menu-item>
                                <a-sub-menu key="sub-code" title="代码文件">
                                  <a-menu-item key="code:python">Python</a-menu-item>
                                  <a-menu-item key="code:javascript">JavaScript</a-menu-item>
                                  <a-menu-item key="code:typescript">TypeScript</a-menu-item>
                                  <a-menu-item key="code:shell">Shell</a-menu-item>
                                </a-sub-menu>
                                <a-menu-item key="folder">文件夹</a-menu-item>
                              </a-menu>
                            </template>
                          </a-dropdown>
                        </div>
                        <div class="skill-config-nav-tree-body">
                          <a-tree
                            class="skill-config-ant-tree"
                            block-node
                            show-line
                            :tree-data="projectSkillConfigTreeData"
                            v-model:expanded-keys="projectSkillConfigTreeExpandedKeys"
                            :selected-keys="projectSkillConfigTreeSelectedKeys"
                            :draggable="projectSkillConfigTreeNodeDraggable"
                            @select="onProjectSkillConfigTreeSelect"
                            @drop="onProjectSkillConfigTreeDrop"
                          >
                            <template #title="{ key, title }">
                              <span class="skill-config-tree-title-row">
                                <span
                                  class="skill-config-tree-title-row__text"
                                  :class="{ 'skill-config-tree-title-row__text--ellipsis': key !== 'rule' }"
                                >{{ title }}</span>
                                <a-button
                                  v-if="projectSkillConfigTreeCanDeleteKey(key) && !projectSkillConfigTabLocked"
                                  type="text"
                                  danger
                                  size="small"
                                  class="ds-icon-btn ds-icon-btn--xs skill-config-tree-title-row__del"
                                  aria-label="删除该项"
                                  @click.stop="removeProjectSkillConfigTreeNode(key)"
                                >
                                  <i class="fas fa-xmark" aria-hidden="true"></i>
                                </a-button>
                              </span>
                            </template>
                          </a-tree>
                        </div>
                      </div>
                    </aside>
                    <div class="skill-config-detail-pane">
                      <div v-if="projectSkillConfigNavKey === 'rule'" class="skill-config-detail-inner">
                        <div class="skill-config-applicable-scenario-block">
                          <div class="skill-config-section-head">
                            <div class="skill-config-section-title-cluster">
                              <h3 class="skill-config-col-title">适用场景</h3>
                            </div>
                          </div>
                          <a-textarea
                            v-model:value="selectedProjectSkill.applicableScenario"
                            :rows="3"
                            :disabled="projectSkillConfigTabLocked"
                            placeholder="选填。与「基本信息」中技能描述互补：此处写执行侧触发条件，如资料类型、业务阶段、关键词、前置对象等。"
                            @blur="scheduleProjectSkillDetailSync"
                          />
                        </div>
                        <div class="skill-config-section-head">
                          <div class="skill-config-section-title-cluster">
                            <h3 class="skill-config-col-title">审计思路</h3>
                          </div>
                          <div v-if="!projectSkillConfigTabLocked" class="skill-object-field-polish">
                            <span v-show="projectAiPolishKey === 'project-analysisRule'" class="ds-input-ai-polish-status">润色中...</span>
                            <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="projectPolishUndoDisabled('project-analysisRule')" @click.stop="undoProjectAnalysisRule">
                              <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                              <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                            </button>
                            <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="!!projectAiPolishKey" @click.stop="demoAiPolishProjectAnalysisRule">
                              <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                              <span class="ds-input-ai-polish-btn__label">润色</span>
                            </button>
                          </div>
                        </div>
                        <div class="skill-rules-editor">
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': projectAiPolishKey === 'project-analysisRule' }">
                              <textarea
                                class="skill-rules-editor-textarea"
                                v-model="selectedProjectSkill.analysisRule"
                                :disabled="projectSkillConfigTabLocked"
                                :placeholder="getSkillAnalysisRulePlaceholder()"
                                @blur="scheduleProjectSkillDetailSync"
                              ></textarea>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div v-else-if="projectSkillConfigSelectedFolder" class="skill-config-detail-inner">
                        <div class="skill-config-section-head">
                          <div class="skill-config-section-title-cluster">
                            <h3 class="skill-config-col-title">文件夹</h3>
                          </div>
                        </div>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label skill-object-field-label--inline">文件夹名称<span class="skill-required">*</span></div>
                          <a-input
                            v-model:value="projectSkillConfigSelectedFolder.name"
                            placeholder="例如：抽取脚本、辅助说明"
                            :disabled="projectSkillConfigTabLocked"
                            @blur="scheduleProjectSkillDetailSync"
                          />
                        </div>
                      </div>
                      <div v-else-if="projectSkillConfigSelectedFile" class="skill-config-detail-inner">
                        <div class="skill-config-section-head">
                          <div class="skill-config-section-title-cluster">
                            <h3 class="skill-config-col-title">配置文件</h3>
                            <UiTagSm
                              v-if="projectSkillConfigSelectedFile.fileKind === 'md'"
                              class="ds-tag--tone-primary"
                            >Markdown</UiTagSm>
                            <UiTagSm v-else>{{ projectSkillConfigSelectedFileCodeLabel }}</UiTagSm>
                          </div>
                        </div>
                        <a-alert
                          v-if="projectSkillConfigDuplicatePaths.length"
                          type="warning"
                          show-icon
                          :message="'文件名路径重复：' + projectSkillConfigDuplicatePaths.join('、')"
                          style="margin-bottom: var(--ds-space-sm);"
                        />
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label-row">
                            <div class="skill-object-field-label skill-object-field-label--inline">文件名<span class="skill-required">*</span></div>
                            <div v-if="!projectSkillConfigTabLocked" class="skill-object-field-polish">
                              <span v-show="projectAiPolishKey === String(projectSkillConfigSelectedFile.id) + ':fn'" class="ds-input-ai-polish-status">润色中...</span>
                              <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="projectPolishUndoDisabled(String(projectSkillConfigSelectedFile.id) + ':fn')" @click.stop="undoProjectSkillFileField(projectSkillConfigSelectedFile, 'filename')">
                                <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                              </button>
                              <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="!!projectAiPolishKey" @click.stop="demoAiPolishProjectSkillFileField(projectSkillConfigSelectedFile, 'filename')">
                                <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-btn__label">润色</span>
                              </button>
                            </div>
                          </div>
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': projectAiPolishKey === String(projectSkillConfigSelectedFile.id) + ':fn' }">
                              <a-input v-model:value="projectSkillConfigSelectedFile.filename" :disabled="projectSkillConfigTabLocked" placeholder="例如：notes.md、extract.py" @blur="scheduleProjectSkillDetailSync" />
                            </div>
                          </div>
                        </div>
                        <div class="skill-object-field-group">
                          <div class="skill-object-field-label-row">
                            <div class="skill-object-field-label skill-object-field-label--inline">具体内容<span class="skill-required">*</span></div>
                            <div v-if="!projectSkillConfigTabLocked" class="skill-object-field-polish">
                              <span v-show="projectAiPolishKey === String(projectSkillConfigSelectedFile.id) + ':ct'" class="ds-input-ai-polish-status">润色中...</span>
                              <button type="button" class="ds-input-ai-polish-undo-btn ds-input-ai-polish-undo-btn--labeled" aria-label="撤回" title="撤回至润色前" :disabled="projectPolishUndoDisabled(String(projectSkillConfigSelectedFile.id) + ':ct')" @click.stop="undoProjectSkillFileField(projectSkillConfigSelectedFile, 'content')">
                                <i class="fas fa-arrow-rotate-left" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-undo-btn__label">撤回</span>
                              </button>
                              <button type="button" class="ds-input-ai-polish-btn ds-input-ai-polish-btn--labeled" aria-label="智能润色" title="智能润色" :disabled="!!projectAiPolishKey" @click.stop="demoAiPolishProjectSkillFileField(projectSkillConfigSelectedFile, 'content')">
                                <i class="fas fa-wand-magic-sparkles" aria-hidden="true"></i>
                                <span class="ds-input-ai-polish-btn__label">润色</span>
                              </button>
                            </div>
                          </div>
                          <div class="ds-input-ai-polish-wrap">
                            <div class="ds-input-ai-polish-input-shell" :class="{ 'is-polishing': projectAiPolishKey === String(projectSkillConfigSelectedFile.id) + ':ct' }">
                              <textarea
                                v-if="projectSkillConfigSelectedFile.fileKind === 'md'"
                                class="skill-rules-editor-textarea"
                                v-model="projectSkillConfigSelectedFile.content"
                                :disabled="projectSkillConfigTabLocked"
                                placeholder="写入该文件的说明、抽取口径或提示词片段等。"
                                rows="14"
                                @blur="scheduleProjectSkillDetailSync"
                              ></textarea>
                              <textarea
                                v-else
                                class="skill-rules-editor-textarea ds-font-mono"
                                v-model="projectSkillConfigSelectedFile.content"
                                :disabled="projectSkillConfigTabLocked"
                                placeholder="代码或脚本内容（演示为纯文本编辑区）。"
                                rows="14"
                                @blur="scheduleProjectSkillDetailSync"
                              ></textarea>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  </div>
                    </a-tab-pane>
                    <a-tab-pane key="resource" tab="关联资源">
                      <div class="ds-unified-tab-pane-stack">
                        <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="关联资源操作">
                          <h3 class="ds-unified-tab-pane-chrome__title">关联资源</h3>
                          <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions">
                            <template v-if="!projectSkillDetailReadOnly">
                              <a-button v-if="!projectSkillResourcePaneEditing" type="primary" @click="startProjectSkillResourcePaneEdit">调整</a-button>
                              <template v-else>
                                <a-button @click="cancelProjectSkillResourcePaneEdit">取消</a-button>
                                <a-button type="primary" @click="saveProjectSkillResourcePane">保存</a-button>
                              </template>
                            </template>
                          </div>
                        </div>
                        <div class="project-skill-resource-pane">
                          <a-form layout="vertical">
                            <a-form-item :label="'已匹配资料（' + getSkillLinkedResourceIds(selectedProjectSkill).length + '）'">
                              <a-select
                                :value="getSkillLinkedResourceIds(selectedProjectSkill)"
                                mode="multiple"
                                :options="projectSkillLinkedResourceSelectOptions"
                                placeholder="请选择关联资源"
                                style="width: 100%;"
                                :disabled="projectSkillResourceTabLocked"
                                @update:value="(vals) => { selectedProjectSkill.linkedResourceIds = (vals || []).map((id) => String(id)); scheduleProjectSkillDetailSync(); }"
                              />
                            </a-form-item>
                          </a-form>
                        </div>
                      </div>
                    </a-tab-pane>
                  </a-tabs>
                </div>
                <div v-else style="padding: var(--ds-space-m) 0;">
                  <a-empty description="未找到技能，请关闭后重试。" />
                </div>
              </a-modal>
              <a-modal
                v-model:open="projectSkillArchiveBranchVisible"
                title="入库方式"
                width="560"
                centered
                :maskClosable="false"
                @cancel="closeProjectSkillArchiveBranchOnly"
              >
                <a-radio-group v-model:value="projectSkillArchiveMode" style="margin-bottom: var(--ds-space-sm)">
                  <a-radio value="new">另存为新技能</a-radio>
                  <a-radio value="append">追加版本到已有「我的技能」</a-radio>
                </a-radio-group>
                <div v-if="projectSkillArchiveMode === 'append'" style="margin-bottom: var(--ds-space-sm)">
                  <div class="skill-object-field-label skill-object-field-label--inline" style="margin-bottom: var(--ds-space-xs)">目标技能</div>
                  <a-select
                    v-model:value="projectSkillArchiveTargetPrivateId"
                    style="width: 100%"
                    placeholder="选择要追加的目标技能"
                    :options="projectSkillArchiveTargetOptions"
                    allow-clear
                  />
                </div>
                <template v-if="projectSkillArchiveMode === 'append'">
                  <div style="margin-bottom: var(--ds-space-sm)">
                    <div class="skill-object-field-label skill-object-field-label--inline" style="margin-bottom: var(--ds-space-xs)">
                      版本号<span class="skill-required">*</span>
                    </div>
                    <a-input
                      v-model:value="projectSkillArchiveAppendVersionLabel"
                      placeholder="如 v1.0.7"
                      allow-clear
                      :maxlength="32"
                    />
                  </div>
                  <div>
                    <div class="skill-object-field-label skill-object-field-label--inline" style="margin-bottom: var(--ds-space-xs)">
                      版本说明<span class="skill-required">*</span>
                    </div>
                    <a-textarea
                      v-model:value="projectSkillArchiveAppendVersionNote"
                      :rows="3"
                      placeholder="简要说明本版相对上一版的变更或入库原因"
                      :maxlength="500"
                      show-count
                    />
                  </div>
                </template>
                <template #footer>
                  <div class="ds-modal-footer-end">
                    <a-button @click="closeProjectSkillArchiveBranchOnly">取消</a-button>
                    <a-button type="primary" @click="submitProjectSkillArchiveBranch">确定入库</a-button>
                  </div>
                </template>
              </a-modal>
              <a-modal
                v-model:open="analysisResultPreviewVisible"
                width="760"
                wrapClassName="modal-w-760 analysis-result-preview-modal analysis-result-preview-modal--unified-tabs"
                centered
                :footer="null"
                @cancel="closeAnalysisResultPreview"
              >
                <template #title>
                  <div class="preview-modal-title-row">
                    <span class="preview-modal-title-row__text">{{ (analysisResultPreviewRecord && analysisResultPreviewRecord.name) || '结果预览' }}</span>
                  </div>
                </template>
                <div ref="analysisResultPreviewScrollEl" class="preview-modal-body-scroll">
                  <div v-if="analysisResultPreviewRecord" class="tc-skill-modal-body tc-skill-modal-body--unified analysis-result-unified-body">
                    <a-tabs :activeKey="analysisResultPreviewActiveTab" class="skill-unified-modal-tabs analysis-result-unified-tabs" tab-position="left" @update:activeKey="onAnalysisResultPreviewTabUpdate">
                      <a-tab-pane key="basic" tab="基本信息">
                        <div class="ds-unified-tab-pane-stack">
                          <div class="ds-unified-tab-pane-chrome" role="toolbar" aria-label="基本信息">
                            <h3 class="ds-unified-tab-pane-chrome__title">基本信息</h3>
                            <div class="ds-unified-tab-pane-chrome__actions"></div>
                          </div>
                          <div class="material-preview-basic-tab analysis-result-basic-tab">
                            <div
                              v-for="(row, idx) in analysisResultBasicMetaRows"
                              :key="'ar-meta-' + idx"
                              class="material-preview-meta-dl-row"
                            >
                              <span class="material-preview-meta-dl-label">{{ row.label }}</span>
                              <span
                                v-if="row.label === '状态'"
                                class="material-preview-meta-dl-value material-preview-meta-dl-value--status-pill"
                              >
                                <span
                                  class="ds-status-pill"
                                  :class="analysisStatusChipClass(analysisResultPreviewRecord && analysisResultPreviewRecord.status)"
                                >
                                  <span class="ds-status-pill__dot"></span>
                                  <span class="ds-status-pill__label">{{ analysisResultStatusLabel(analysisResultPreviewRecord && analysisResultPreviewRecord.status) }}</span>
                                </span>
                              </span>
                              <span v-else class="material-preview-meta-dl-value">{{ row.value }}</span>
                            </div>
                          </div>
                        </div>
                      </a-tab-pane>
                      <a-tab-pane key="body" tab="结果正文">
                        <div class="ds-unified-tab-pane-stack">
                          <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--result-body" role="toolbar" aria-label="结果正文操作">
                            <h3 class="ds-unified-tab-pane-chrome__title">结果正文</h3>
                            <div class="ds-unified-tab-pane-chrome__actions" aria-label="正文与编辑器操作">
                              <div class="analysis-result-preview-modal__toolbar-icons" role="toolbar" aria-label="复制、下载与编辑">
                                <template v-if="analysisResultPreviewEditing">
                                  <a-button
                                    type="default"
                                    class="analysis-result-preview-toolbar-outline-btn"
                                    :disabled="!analysisResultPreviewRecord"
                                    title="复制当前编辑内容"
                                    aria-label="复制当前编辑内容"
                                    @click="copyAnalysisResultPreview"
                                  >复制</a-button>
                                  <a-button
                                    type="default"
                                    class="analysis-result-preview-toolbar-outline-btn"
                                    :disabled="!analysisResultPreviewRecord"
                                    title="下载为 Markdown 文件"
                                    aria-label="下载为 Markdown 文件"
                                    @click="downloadAnalysisResultPreview"
                                  >下载</a-button>
                                  <a-button type="primary" size="small" @click="saveAnalysisResultPreviewEdit">保存</a-button>
                                  <a-button size="small" @click="cancelAnalysisResultPreviewEdit">取消</a-button>
                                </template>
                                <template v-else>
                                  <a-button
                                    type="default"
                                    class="analysis-result-preview-toolbar-outline-btn"
                                    :disabled="!analysisResultPreviewRecord"
                                    title="复制全文"
                                    aria-label="复制全文"
                                    @click="copyAnalysisResultPreview"
                                  >复制</a-button>
                                  <a-button
                                    type="default"
                                    class="analysis-result-preview-toolbar-outline-btn"
                                    :disabled="!analysisResultPreviewRecord"
                                    title="下载为 Markdown 文件"
                                    aria-label="下载为 Markdown 文件"
                                    @click="downloadAnalysisResultPreview"
                                  >下载</a-button>
                                  <a-button
                                    type="default"
                                    class="analysis-result-preview-toolbar-outline-btn"
                                    :disabled="!analysisResultPreviewRecord"
                                    title="编辑正文"
                                    aria-label="编辑正文"
                                    @click="startAnalysisResultPreviewEdit"
                                  >编辑</a-button>
                                </template>
                              </div>
                            </div>
                          </div>
                          <div class="analysis-result-preview-modal__layout">
                            <div class="preview-modal-content-frame">
                              <div class="analysis-result-preview-modal__panel analysis-result-preview-modal__panel--editor analysis-result-preview-modal__panel--tab-chrome-only">
                                <div class="analysis-result-preview-modal__panel-body">
                                  <div
                                    v-if="!analysisResultPreviewEditing"
                                    class="analysis-result-preview-modal__md"
                                    v-html="analysisResultPreviewHtml"
                                  ></div>
                                  <a-textarea
                                    v-else
                                    v-model:value="analysisResultPreviewDraft"
                                    class="analysis-result-preview-modal__editor-textarea"
                                    :rows="22"
                                    placeholder="支持编辑 Markdown 正文，保存后写入当前结果（演示）"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </a-tab-pane>
                      <a-tab-pane key="history" tab="版本管理">
                        <div class="skill-unified-tab-version-root">
                          <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--version-row" role="toolbar" aria-label="版本管理">
                            <h3 class="ds-unified-tab-pane-chrome__title">版本管理</h3>
                            <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions"></div>
                          </div>
                          <div class="skill-unified-tab-version-root__main skill-wizard-panel">
                            <template v-if="analysisResultPreviewRecord">
                              <div v-if="analysisResultVersionCurrentRow" class="skill-version-mgmt-latest">
                                <div class="ds-l2-table-panel">
                                  <a-table
                                    :columns="analysisResultVersionMgmtColumns"
                                    :data-source="[analysisResultVersionCurrentRow]"
                                    row-key="key"
                                    size="small"
                                    :pagination="false"
                                    class="skill-library-version-mgmt-table"
                                  >
                                    <template #bodyCell="{ column, record }">
                                      <template v-if="column.key === 'generationDesc'">
                                        <span class="skill-version-table__cell-desc" :title="record.generationDesc">{{ record.generationDesc }}</span>
                                      </template>
                                      <template v-else-if="column.key === 'action'">
                                        <a-button type="link" size="small" class="skill-version-table__version-link" @click="openAnalysisResultVersionDetail(record)">详情</a-button>
                                      </template>
                                      <template v-else>{{ record[column.dataIndex] }}</template>
                                    </template>
                                  </a-table>
                                </div>
                              </div>
                              <div
                                v-if="analysisResultVersionHistoryOnlyRows.length"
                                class="skill-version-mgmt-history-section"
                                role="region"
                                aria-label="历史版本列表"
                              >
                                <h4 class="skill-version-mgmt-history__heading">历史版本 ({{ analysisResultVersionHistoryOnlyRows.length }})</h4>
                                <div class="skill-version-mgmt-history">
                                  <div class="ds-l2-table-panel">
                                    <a-table
                                      :columns="analysisResultVersionMgmtColumns"
                                      :data-source="analysisResultVersionHistoryOnlyRows"
                                      row-key="key"
                                      size="small"
                                      :pagination="false"
                                      class="skill-library-version-mgmt-table"
                                    >
                                      <template #bodyCell="{ column, record }">
                                        <template v-if="column.key === 'generationDesc'">
                                          <span class="skill-version-table__cell-desc" :title="record.generationDesc">{{ record.generationDesc }}</span>
                                        </template>
                                        <template v-else-if="column.key === 'action'">
                                          <span class="skill-version-mgmt-history__row-actions">
                                            <a-button type="link" size="small" class="skill-version-table__version-link" @click="openAnalysisResultVersionDetail(record)">详情</a-button>
                                            <a-button
                                              type="link"
                                              size="small"
                                              class="skill-version-table__version-link"
                                              @click="applyAnalysisResultMarkdownRollbackById(analysisResultPreviewRecord && analysisResultPreviewRecord.id, record.markdown)"
                                            >回退</a-button>
                                          </span>
                                        </template>
                                        <template v-else>{{ record[column.dataIndex] }}</template>
                                      </template>
                                    </a-table>
                                  </div>
                                </div>
                              </div>
                              <p v-if="!analysisResultVersionHistoryOnlyRows.length" class="text-secondary" style="margin-top: var(--ds-space-sm);">暂无历史快照；保存正文编辑后将自动生成快照。</p>
                            </template>
                          </div>
                        </div>
                      </a-tab-pane>
                    </a-tabs>
                  </div>
                </div>
              </a-modal>
              <a-modal
                v-model:open="analysisResultVersionDetailVisible"
                title="版本详情"
                width="720"
                wrapClassName="modal-w-720 analysis-result-preview-modal"
                centered
                :footer="null"
                destroy-on-close
                @cancel="closeAnalysisResultVersionDetail"
              >
                <div class="analysis-result-preview-modal__md" v-html="analysisResultVersionDetailHtml"></div>
              </a-modal>
          </div>
        </a-layout>`,
      data() {
        const params = new URLSearchParams(window.location.search || '');
        const tab = params.get('tab');
        const initialTab = tab === 'files' || tab === 'analysis' || tab === 'report' ? tab : 'basic';
        const baseReportContent = '【审计结论草案】\n\n本工作台自动化审计已完成初步分析，系统共识别出多项金额与日期相关疑点。\n后续建议：结合原始凭证进行人工复核，对异常交易补充解释说明，并视情况调整审计结论。';
        const projectListData = [
          { id: 'PRJ-2026-001', name: 'A市城建集团年度经济责任审计', description: '围绕城建集团年度经济责任履行情况的综合审计。', templateName: '城建项目-标准技能', tags: ['经济责任', '城建'], lifecycleStatus: 'active', docCount: 20, materialCount: 20, analysisCount: 12, reportCount: 3, createdAt: '2026-03-17 10:24', updatedAt: '2026-03-24 09:10' },
          { id: 'PRJ-2026-002', name: 'B区采购专项资金异常排查', description: '对采购专项资金使用与审批流程的专项排查。', templateName: '财务审计-通用技能', tags: ['采购', '专项资金'], lifecycleStatus: 'active', docCount: 8, materialCount: 8, analysisCount: 5, reportCount: 1, createdAt: '2026-03-16 16:45', updatedAt: '2026-03-22 18:40', visibility: 'shared', sharedUserIds: ['u-1', 'u-2'], sharedDeptIds: ['d-inv'] },
          { id: 'PRJ-2026-003', name: 'C县专项债流向跟踪审计', description: '专项债资金流向与合规性跟踪审计。', templateName: '城建项目-标准技能', tags: ['专项债', '资金跟踪'], lifecycleStatus: 'active', docCount: 15, materialCount: 15, analysisCount: 8, reportCount: 2, createdAt: '2026-03-15 09:30', updatedAt: '2026-03-21 10:05' },
          { id: 'PRJ-2026-004', name: 'D市道路改扩建工程审计', description: '道路改扩建工程投资完成与变更签证审计。', templateName: '城建项目-标准技能', tags: ['工程投资', '城建'], lifecycleStatus: 'active', docCount: 22, materialCount: 22, analysisCount: 14, reportCount: 3, createdAt: '2026-03-14 11:00', updatedAt: '2026-03-20 14:12' },
          {
            id: 'PRJ-2026-005',
            name: 'E区财政收支审计',
            description: '区级财政收支与预算执行情况审计。',
            templateName: '财务审计-通用技能',
            tags: ['财政', '预算'],
            lifecycleStatus: 'ended',
            docCount: 10,
            materialCount: 10,
            analysisCount: 6,
            reportCount: 2,
            createdAt: '2026-03-13 09:20',
            updatedAt: '2026-03-19 09:55',
            isSharedToMe: true,
          },
          {
            id: 'PRJ-2026-006',
            name: 'F县乡村振兴资金审计',
            description: '乡村振兴专项资金使用与绩效审计。',
            templateName: '财务审计-通用技能',
            tags: ['乡村振兴', '绩效'],
            lifecycleStatus: 'ended',
            docCount: 12,
            materialCount: 12,
            analysisCount: 7,
            reportCount: 1,
            createdAt: '2026-03-12 14:30',
            updatedAt: '2026-03-18 16:00',
            isSharedToMe: true,
          },
        ];
        const toAnalysisTemplate = (seed, library) => {
          const row = {
            id: seed.id,
            name: seed.name,
            description: seed.description || '',
            tags: Array.isArray(seed.tags) ? seed.tags.slice() : [],
            skillFiles: Array.isArray(seed.skillFiles) ? JSON.parse(JSON.stringify(seed.skillFiles)) : [],
            extractionRules: [],
            analysisRule: seed.analysisRule || '',
            applicableScenario: seed.applicableScenario != null ? String(seed.applicableScenario) : '',
            linkedResourceIds: Array.isArray(seed.linkedResourceIds) ? seed.linkedResourceIds.map((id) => String(id)) : [],
            linkedResourceMeta: seed.linkedResourceMeta && typeof seed.linkedResourceMeta === 'object' ? { ...seed.linkedResourceMeta } : {},
            createdAt: seed.createdAt,
            updatedAt: seed.updatedAt,
            library,
          };
          if (typeof DemoSkillFileTree !== 'undefined' && DemoSkillFileTree.syncExtractionRulesFromSkillFiles) {
            DemoSkillFileTree.syncExtractionRulesFromSkillFiles(row);
          }
          return row;
        };
        return {
          projectIdFromHash: getProjectIdFromHash(),
          projectDetailModeExit: false,
          projectDetailSiderBoot: false,
          projectDetailTab: 'overview',
          projectDetailMenuItems: [
            { key: 'overview', label: '总览', icon: 'fa-house' },
            { key: 'materials', label: '资料', icon: 'fa-file-lines' },
            { key: 'templates', label: '技能', icon: 'fa-diagram-project' },
            { key: 'results', label: '结果', icon: 'fa-file-signature' },
          ],
          projectMaterialSearchKeyword: '',
          projectDetailTemplateSearchKeyword: '',
          projectDetailTemplateTagKeys: [],
          projectDetailTemplateTagMatchMode: 'any',
          projectDetailTemplateTagSearchQuery: '',
          projectDetailTemplateTagPopoverOpen: false,
          projectDetailTemplateSortBy: 'name_asc',
          projectDetailTemplateSortDropdownOpen: false,
          projectAnalysisResultSearchKeyword: '',
          projectAnalysisResultStatusKey: 'all',
          projectAnalysisResultStatusPopoverOpen: false,
          projectAnalysisResultTagKeys: [],
          projectAnalysisResultTagMatchMode: 'any',
          projectAnalysisResultTagSearchQuery: '',
          projectAnalysisResultTagPopoverOpen: false,
          projectAnalysisResultSortBy: 'created_desc',
          projectAnalysisResultSortDropdownOpen: false,
          projectMaterialSortBy: 'uploaded_desc',
          projectMaterialSortDropdownOpen: false,
          projectMaterialStatusKey: 'all',
          projectMaterialStatusPopoverOpen: false,
          projectMaterialTagKeys: [],
          projectMaterialTagMatchMode: 'any',
          projectMaterialTagSearchQuery: '',
          projectMaterialTagPopoverOpen: false,
          selectedMaterialIds: [],
          projectItemMetaEditVisible: false,
          /** 'material' | 'analysisResult' */
          projectItemMetaEditKind: 'material',
          projectItemMetaEditTargetId: '',
          projectItemMetaEditForm: { name: '', tags: [] },
          batchTagModalVisible: false,
          /** 'material' | 'analysisResult' — 与资料池共用批量打标签弹窗 */
          batchTagTarget: 'material',
          batchTagForm: { tags: [] },
          analysisTemplateSelectVisible: false,
          /** 非 null 时「引用技能」写入该工作台（审计助手打开弹窗时用，避免 hash 为 freeaudit 时 currentProjectId 为空） */
          quoteSkillTargetProjectId: null,
          analysisTemplateSourceTab: 'public',
          analysisTemplateSearchKeyword: '',
          analysisTemplateSelectedIds: [],
          analysisTemplateFilterTagKeys: [],
          analysisTemplateFilterTagMatchMode: 'any',
          analysisTemplateTagSearchQuery: '',
          analysisTemplateFilterPopoverOpen: false,
          analysisTemplateSortDropdownOpen: false,
          analysisTemplateSortBy: 'name_asc',
          /** 技能池只读预览：与 projectAnalysisTemplatesById 互斥，关闭弹窗时清空 */
          projectSkillDetailPoolPreview: null,
          selectedAnalysisTemplateIds: [],
          /** 工作台详情 · 技能库网格：批量勾选（与总览「执行」多选独立） */
          projectSkillLibrarySelectedIds: [],
          projectSkillRunConfirmOpen: false,
          projectSkillRunConfirmTemplateId: '',
          projectSkillRunConfirmLinkedResourceIds: [],
          projectSkillResourcePopoverOpen: false,
          projectSkillResourcePopoverSkillId: '',
          projectSkillOverviewResourcePopoverOpen: false,
          projectSkillOverviewResourcePopoverSkillId: '',
          projectSkillCreateBasicModalOpen: false,
          projectSkillCreateBasicSubmitting: false,
          projectSkillCreateBasicForm: { name: '', description: '', tags: [] },
          projectSkillDetailModalOpen: false,
          projectSkillDetailActiveTab: 'basic',
          projectSkillDetailModalIsCreate: false,
          _projectSkillModalSnapshot: null,
          /** true：从卡片等入口仅查看，禁用编辑与保存 */
          projectSkillDetailReadOnly: false,
          projectSkillDetailId: '',
          /** 技能配置 Tab：左侧树 — 'rule' 或分析对象 id */
          projectSkillConfigNavKey: 'rule',
          projectSkillConfigTreeExpandedKeys: [],
          projectAiPolishKey: '',
          projectPolishUndo: {},
          projectSkillForm: { id: '', name: '', description: '', tags: [] },
          /** 技能详情弹窗：各页签内编辑态（保存/取消在页签顶栏） */
          projectSkillBasicPaneEditing: false,
          projectSkillConfigPaneEditing: false,
          projectSkillResourcePaneEditing: false,
          _projectSkillBasicPaneSnap: null,
          _projectSkillConfigPaneSnap: null,
          _projectSkillResourcePaneSnap: null,
          /** 新建技能：任一页签成功保存后置 true，关闭弹窗时不再删草稿行 */
          _projectSkillCreateCommitted: false,
          projectSkillArchiveBranchVisible: false,
          projectSkillArchivePendingTpl: null,
          projectSkillArchiveMode: 'new',
          projectSkillArchiveTargetPrivateId: '',
          projectSkillArchiveAppendVersionLabel: '',
          projectSkillArchiveAppendVersionNote: '',
          selectedAnalysisResultIds: [],
          analysisFlowWaveActive: false,
          projectOverviewTourOpen: false,
          projectOverviewTourCoachStyle: {},
          projectMaterialPage: 1,
          projectMaterialPageSize: 20,
          analysisResultPage: 1,
          analysisResultPageSize: 8,
          analysisResultPreviewVisible: false,
          analysisResultPreviewRecord: null,
          analysisResultPreviewActiveTab: 'basic',
          analysisResultPreviewEditing: false,
          analysisResultPreviewDraft: '',
          analysisResultVersionHistoryById: {},
          analysisResultVersionDetailVisible: false,
          analysisResultVersionDetailMarkdown: '',
          analysisCitationPopover: { show: false, title: '', excerpt: '', x: 0, y: 0 },
          analysisCitationPopoverTimer: null,
          uploadMaterialVisible: false,
          uploadMaterialBatch: [],
          materialPreviewVisible: false,
          materialPreviewRecord: null,
          materialPreviewActiveTab: 'basic',
          /** 资料预览 · OCR 页：是否在正文左侧展示行号 */
          materialPreviewOcrShowLineNumbers: false,
          projectListSearch: '',
          /** 一级列表：我的工作台 / 共享工作台（他人开放权限给你的工作台） */
          projectListScope: 'mine',
          projectListSortBy: 'created_desc',
          projectEditVisible: false,
          projectEditForm: { id: '', name: '', description: '', visibility: 'private', sharedUserIds: [], sharedDeptIds: [] },
          projectList: projectListData,
          projectMaterialsById: demoProjectMaterialsById,
          analysisTemplatePool: {
            public: (SKILL_SEED_PUBLIC || []).map((x) => toAnalysisTemplate(x, 'public')),
            private: demoSharedPrivateAnalysisTemplatePool,
          },
          projectAnalysisTemplatesById: demoProjectAnalysisTemplatesById,
          projectAnalysisResultsById: demoProjectAnalysisResultsById,
          projectMeta: { name: 'A市城建项目', description: '', templateName: '城建项目-标准技能', docCount: 0, createdAt: '', updatedAt: '', owner: '张审计' },
        };
      },
      computed: {
        overviewHost() { return this; },
        currentProjectId() { return this.projectIdFromHash || null; },
        currentProject() {
          const id = this.currentProjectId;
          if (!id) return null;
          return (this.projectList || []).find((p) => p.id === id) || null;
        },
        currentProjectMaterials() {
          const id = this.currentProjectId;
          if (!id) return [];
          return this.projectMaterialsById[id] || [];
        },
        /**
         * 技能卡片「匹配资料」解析用：引用技能弹窗从审计助手打开时已指定 quoteSkillTargetProjectId，
         * 此时 hash 常为 freeaudit（currentProjectId 为空），须从目标工作台取资料行，否则匹配项/状态无法展示。
         */
        linkedSkillMaterialRows() {
          const pid = this.quoteSkillTargetProjectId || this.currentProjectId;
          if (!pid) return [];
          return this.projectMaterialsById[pid] || [];
        },
        projectMaterialSelectOptions() {
          return (this.currentProjectMaterials || []).map((m) => ({
            value: m.id,
            label: m.name || m.id,
          }));
        },
        selectedProjectSkill() {
          if (!this.projectSkillDetailId) return null;
          const pool = this.projectSkillDetailPoolPreview;
          if (pool && String(pool.id) === String(this.projectSkillDetailId)) return pool;
          if (!this.currentProjectId) return null;
          const list = this.projectAnalysisTemplatesById[this.currentProjectId] || [];
          return list.find((x) => x.id === this.projectSkillDetailId) || null;
        },
        projectSkillArchiveTargetOptions() {
          const pool = (this.analysisTemplatePool && this.analysisTemplatePool.private) || [];
          return pool.map((x) => ({ label: String(x.name || x.id), value: x.id }));
        },
        projectSkillDetailModalTitle() {
          if (this.projectSkillDetailModalIsCreate) return '新建技能';
          const s = this.selectedProjectSkill;
          if (!s) return '技能详情';
          const n = String(s.name || '').trim();
          return n || '未命名技能';
        },
        projectSkillDetailModalHeadVersionLabel() {
          if (this.projectSkillDetailModalIsCreate || !this.selectedProjectSkill) return '';
          const s = this.selectedProjectSkill;
          const list = Array.isArray(s.publishedVersions) ? s.publishedVersions : [];
          if (!list.length) return '';
          const sorted = [...list].sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
          const v = sorted[0] && sorted[0].versionLabel;
          return v ? String(v).trim() : '';
        },
        projectSkillConfigSelectedFile() {
          const k = this.projectSkillConfigNavKey;
          if (!k || String(k).indexOf('file:') !== 0 || !this.selectedProjectSkill) return null;
          const id = String(k).slice('file:'.length);
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || typeof T.findFileNodeById !== 'function') return null;
          const hit = T.findFileNodeById(this.selectedProjectSkill.skillFiles || [], id);
          return hit ? hit.node : null;
        },
        projectSkillConfigSelectedFolder() {
          const k = this.projectSkillConfigNavKey;
          if (!k || String(k).indexOf('folder:') !== 0 || !this.selectedProjectSkill) return null;
          const id = String(k).slice('folder:'.length);
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || typeof T.findFolderNodeById !== 'function') return null;
          const hit = T.findFolderNodeById(this.selectedProjectSkill.skillFiles || [], id);
          return hit ? hit.node : null;
        },
        projectSkillConfigDuplicatePaths() {
          const s = this.selectedProjectSkill;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!s || !T || typeof T.findDuplicatePaths !== 'function') return [];
          return T.findDuplicatePaths(s.skillFiles || []);
        },
        projectSkillConfigSelectedFileCodeLabel() {
          const f = this.projectSkillConfigSelectedFile;
          if (!f || f.fileKind !== 'code') return '代码';
          const m = { python: 'Python', javascript: 'JavaScript', typescript: 'TypeScript', shell: 'Shell' };
          return m[f.codeLang] || f.codeLang || '代码';
        },
        projectSkillConfigTreeData() {
          if (!this.selectedProjectSkill) return [];
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (T && typeof T.buildAntTreeData === 'function') return T.buildAntTreeData(this.selectedProjectSkill.skillFiles || []);
          return [{ key: 'rule', title: '审计思路', isLeaf: true }];
        },
        skillObjectMaterialTypePlaceholder() {
          return (typeof window !== 'undefined' && window.__DEMO_SKILL_OBJECT_MATERIAL_TYPE_PLACEHOLDER) || '请填写资料名称或类型';
        },
        projectSkillConfigTreeSelectedKeys() {
          const k = this.projectSkillConfigNavKey;
          if (!k || k === 'rule') return ['rule'];
          return [String(k)];
        },
        projectSkillBasicFieldsLocked() {
          return this.projectSkillDetailReadOnly || !this.projectSkillBasicPaneEditing;
        },
        projectSkillConfigTabLocked() {
          return this.projectSkillDetailReadOnly || !this.projectSkillConfigPaneEditing;
        },
        projectSkillResourceTabLocked() {
          return this.projectSkillDetailReadOnly || !this.projectSkillResourcePaneEditing;
        },
        projectSkillLinkedResourceSelectOptions() {
          return (this.currentProjectMaterials || []).map((m) => ({
            value: String(m.id),
            label: m && m.name ? String(m.name) : String(m.id || ''),
          }));
        },
        projectSkillRunConfirmTemplate() {
          const id = String(this.projectSkillRunConfirmTemplateId || '');
          if (!id) return null;
          const rows = this.currentProjectAnalysisTemplates || [];
          return rows.find((x) => x && String(x.id) === id) || null;
        },
        projectSkillSaveConfigButtonLabel() {
          return '保存配置';
        },
        hasProjectDetailFilterValues() {
          return !!(
            (this.projectMaterialTagKeys || []).length
            || (this.projectDetailTemplateTagKeys || []).length
            || (this.projectAnalysisResultTagKeys || []).length
          );
        },
        currentProjectAnalysisTemplates() {
          const id = this.currentProjectId;
          if (!id) return [];
          return this.projectAnalysisTemplatesById[id] || [];
        },
        projectDetailTemplateTagStats() {
          const map = new Map();
          (this.currentProjectAnalysisTemplates || []).forEach((row) => {
            (row.tags || []).forEach((t) => {
              const tag = String(t || '').trim();
              if (!tag) return;
              map.set(tag, (map.get(tag) || 0) + 1);
            });
          });
          return Array.from(map.entries())
            .map(([tag, count]) => ({ tag, count }))
            .sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag, 'zh-CN'));
        },
        projectDetailTemplateTagFilteredStats() {
          const q = (this.projectDetailTemplateTagSearchQuery || '').trim().toLowerCase();
          const rows = this.projectDetailTemplateTagStats;
          if (!q) return rows;
          return rows.filter((r) => r.tag.toLowerCase().includes(q));
        },
        projectDetailTemplateSortOptions() {
          return [
            { value: 'name_asc', label: '按名称（A→Z）' },
            { value: 'name_desc', label: '按名称（Z→A）' },
            { value: 'updated_desc', label: '按更新时间（新→旧）' },
            { value: 'updated_asc', label: '按更新时间（旧→新）' },
          ];
        },
        currentProjectDetailTemplateSortLabel() {
          const list = this.projectDetailTemplateSortOptions || [];
          const hit = list.find((opt) => String(opt.value) === String(this.projectDetailTemplateSortBy || ''));
          return hit ? hit.label : '排序';
        },
        isProjectDetailTemplateSortSelectedByFilter() {
          return !!((this.projectDetailTemplateTagKeys || []).length);
        },
        /** 技能页：关键词 + 标签筛选 + 排序（名称/简介/分析规则/标签 参与搜索） */
        filteredProjectDetailTemplates() {
          const rows = this.currentProjectAnalysisTemplates || [];
          const keyword = String(this.projectDetailTemplateSearchKeyword || '').trim().toLowerCase();
          const tagKeys = this.projectDetailTemplateTagKeys || [];
          const modeAll = this.projectDetailTemplateTagMatchMode === 'all';
          let list = rows.filter((row) => {
            if (keyword) {
              const name = String(row.name || '').toLowerCase();
              const desc = String(row.description || '').toLowerCase();
              const ar = String(row.analysisRule || '').toLowerCase();
              const tags = (Array.isArray(row.tags) ? row.tags : []).join(' ').toLowerCase();
              const hit = name.includes(keyword) || desc.includes(keyword) || ar.includes(keyword) || tags.includes(keyword);
              if (!hit) return false;
            }
            if (tagKeys.length) {
              const stags = row.tags || [];
              const matchTag =
                modeAll ? tagKeys.every((t) => stags.includes(t)) : tagKeys.some((t) => stags.includes(t));
              if (!matchTag) return false;
            }
            return true;
          });
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const sortBy = this.projectDetailTemplateSortBy || 'name_asc';
          const timeOf = (v) => {
            const t = Date.parse(String(v || '').trim().replace(' ', 'T'));
            return Number.isNaN(t) ? 0 : t;
          };
          list = [...list].sort((a, b) => {
            if (sortBy === 'name_desc') return collator.compare(String(b.name || ''), String(a.name || ''));
            if (sortBy === 'updated_desc') return timeOf(b.updatedAt) - timeOf(a.updatedAt);
            if (sortBy === 'updated_asc') return timeOf(a.updatedAt) - timeOf(b.updatedAt);
            return collator.compare(String(a.name || ''), String(b.name || ''));
          });
          return list;
        },
        /** 技能库批量：当前筛选下列表项数 */
        selectedProjectSkillLibraryCount() {
          return (this.projectSkillLibrarySelectedIds || []).length;
        },
        /** 技能库批量：当前筛选结果是否已全选 */
        isAllFilteredProjectTemplatesSelected() {
          const rows = this.filteredProjectDetailTemplates || [];
          if (!rows.length) return false;
          const selected = new Set((this.projectSkillLibrarySelectedIds || []).map(String));
          return rows.every((tpl) => selected.has(String(tpl.id)));
        },
        currentProjectAnalysisResults() {
          const id = this.currentProjectId;
          if (!id) return [];
          return this.projectAnalysisResultsById[id] || [];
        },
        projectAnalysisResultTagStats() {
          const map = new Map();
          (this.currentProjectAnalysisResults || []).forEach((r) => {
            (r.tags || []).forEach((t) => {
              const tag = String(t || '').trim();
              if (!tag) return;
              map.set(tag, (map.get(tag) || 0) + 1);
            });
          });
          return Array.from(map.entries())
            .map(([tag, count]) => ({ tag, count }))
            .sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag, 'zh-CN'));
        },
        projectAnalysisResultTagFilteredStats() {
          const q = (this.projectAnalysisResultTagSearchQuery || '').trim().toLowerCase();
          const rows = this.projectAnalysisResultTagStats;
          if (!q) return rows;
          return rows.filter((r) => r.tag.toLowerCase().includes(q));
        },
        projectAnalysisResultSortOptions() {
          return [
            { value: 'created_desc', label: '按生成时间（新→旧）' },
            { value: 'created_asc', label: '按生成时间（旧→新）' },
            { value: 'name_asc', label: '按名称（A→Z）' },
            { value: 'name_desc', label: '按名称（Z→A）' },
            { value: 'status_asc', label: '按状态（排队→完成）' },
            { value: 'status_desc', label: '按状态（完成→排队）' },
          ];
        },
        currentProjectAnalysisResultSortLabel() {
          const list = this.projectAnalysisResultSortOptions || [];
          const hit = list.find((opt) => String(opt.value) === String(this.projectAnalysisResultSortBy || ''));
          return hit ? hit.label : '排序';
        },
        isProjectAnalysisResultSortSelectedByFilter() {
          return !!((this.projectAnalysisResultTagKeys || []).length);
        },
        filteredProjectAnalysisResults() {
          const rows = this.currentProjectAnalysisResults || [];
          const keyword = String(this.projectAnalysisResultSearchKeyword || '').trim().toLowerCase();
          const statusKey = String(this.projectAnalysisResultStatusKey || 'all');
          const tagKeys = this.projectAnalysisResultTagKeys || [];
          const modeAll = this.projectAnalysisResultTagMatchMode === 'all';
          const filtered = rows.filter((row) => {
            if (keyword) {
              const name = String(row.name || '').toLowerCase();
              if (!name.includes(keyword)) return false;
            }
            if (statusKey !== 'all') {
              const s = String(row.status || 'queued');
              if (s !== statusKey) return false;
            }
            if (tagKeys.length) {
              const stags = row.tags || [];
              const matchTag =
                modeAll ? tagKeys.every((t) => stags.includes(t)) : tagKeys.some((t) => stags.includes(t));
              if (!matchTag) return false;
            }
            return true;
          });
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const timeOf = (v) => {
            const t = Date.parse(String(v || '').trim().replace(' ', 'T'));
            return Number.isNaN(t) ? 0 : t;
          };
          const statusRank = (s) => {
            const m = { queued: 0, parsing: 1, done: 2, failed: 3 };
            return Object.prototype.hasOwnProperty.call(m, s) ? m[s] : 99;
          };
          const sortKey = this.projectAnalysisResultSortBy || 'created_desc';
          return [...filtered].sort((a, b) => {
            if (sortKey === 'name_asc') return collator.compare(String(a.name || ''), String(b.name || ''));
            if (sortKey === 'name_desc') return collator.compare(String(b.name || ''), String(a.name || ''));
            if (sortKey === 'created_asc') return timeOf(a.createdAt) - timeOf(b.createdAt) || collator.compare(String(a.name || ''), String(b.name || ''));
            if (sortKey === 'created_desc') return timeOf(b.createdAt) - timeOf(a.createdAt) || collator.compare(String(a.name || ''), String(b.name || ''));
            if (sortKey === 'status_asc') return statusRank(a.status) - statusRank(b.status) || collator.compare(String(a.name || ''), String(b.name || ''));
            if (sortKey === 'status_desc') return statusRank(b.status) - statusRank(a.status) || collator.compare(String(a.name || ''), String(b.name || ''));
            return timeOf(b.createdAt) - timeOf(a.createdAt) || collator.compare(String(a.name || ''), String(b.name || ''));
          });
        },
        analysisResultTotal() {
          return (this.filteredProjectAnalysisResults || []).length;
        },
        /** 工作台详情页签：资料总数（全量，不受筛选分页影响） */
        projectDetailMaterialTotalCount() {
          return (this.currentProjectMaterials || []).length;
        },
        /** 总览统计：分析结果按状态计数（与资料状态口径一致） */
        overviewResultStatusSummary() {
          const rows = this.currentProjectAnalysisResults || [];
          const summary = { total: rows.length, queued: 0, parsing: 0, done: 0, failed: 0 };
          rows.forEach((r) => {
            const k = r && r.status;
            if (k === 'queued' || k === 'parsing' || k === 'done' || k === 'failed') summary[k] += 1;
          });
          return summary;
        },
        /** 总览统计：排队中 + 分析中的结果条数 */
        overviewResultProcessingCount() {
          const s = this.overviewResultStatusSummary || { queued: 0, parsing: 0 };
          return (s.queued || 0) + (s.parsing || 0);
        },
        /** 总览统计：至少关联到 1 份资料的技能个数 */
        overviewSkillLinkedTemplateCount() {
          const list = this.currentProjectAnalysisTemplates || [];
          let n = 0;
          for (let i = 0; i < list.length; i += 1) {
            if (this.matchedMaterialCount(list[i]) > 0) n += 1;
          }
          return n;
        },
        /** 模式切换提醒：localStorage 键（按工作台 id） */
        overviewTourStorageKey() {
          return `demo_project_mode_coach_v1_${this.currentProjectId || '_'}`;
        },
        /** 当前浮窗文案：仅保留模式切换提醒 */
        overviewTourActiveStep() {
          return PROJECT_MODE_COACH;
        },
        projectOverviewTourHighlightKey() {
          if (!this.projectOverviewTourOpen) return '';
          return 'mode';
        },
        analysisResultPageSafe() {
          const total = this.analysisResultTotal;
          const pageSize = Math.max(1, Number(this.analysisResultPageSize || 8));
          if (!total) return 1;
          const maxPage = Math.max(1, Math.ceil(total / pageSize));
          const page = Math.max(1, Number(this.analysisResultPage || 1));
          return Math.min(page, maxPage);
        },
        pagedProjectAnalysisResults() {
          const list = this.filteredProjectAnalysisResults || [];
          const pageSize = Math.max(1, Number(this.analysisResultPageSize || 8));
          const page = this.analysisResultPageSafe;
          const start = (page - 1) * pageSize;
          return list.slice(start, start + pageSize);
        },
        /** 工作台详情首页：最近资料（按上传时间新→旧，不受资料页筛选影响） */
        overviewRecentMaterials() {
          const rows = [...(this.currentProjectMaterials || [])];
          const timeOf = (v) => {
            const t = Date.parse(String(v || '').trim().replace(' ', 'T'));
            return Number.isNaN(t) ? 0 : t;
          };
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          rows.sort((a, b) => timeOf(b.uploadedAt) - timeOf(a.uploadedAt) || collator.compare(String(a.name || ''), String(b.name || '')));
          return rows.slice(0, 10);
        },
        /** 工作台详情首页：最近结果（按生成时间新→旧） */
        overviewRecentAnalysisResults() {
          const rows = [...(this.currentProjectAnalysisResults || [])];
          const timeOf = (v) => {
            const t = Date.parse(String(v || '').trim().replace(' ', 'T'));
            return Number.isNaN(t) ? 0 : t;
          };
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          rows.sort((a, b) => timeOf(b.createdAt) - timeOf(a.createdAt) || collator.compare(String(a.name || ''), String(b.name || '')));
          return rows.slice(0, 10);
        },
        selectedAnalysisResultCount() {
          return (this.selectedAnalysisResultIds || []).length;
        },
        analysisTemplatePickerPool() {
          const source = this.analysisTemplateSourceTab === 'private' ? 'private' : 'public';
          return this.analysisTemplatePool[source] || [];
        },
        analysisTemplatePickerTagStats() {
          const map = new Map();
          (this.analysisTemplatePickerPool || []).forEach((tpl) => {
            (tpl.tags || []).forEach((t) => {
              const tag = String(t || '').trim();
              if (!tag) return;
              map.set(tag, (map.get(tag) || 0) + 1);
            });
          });
          return Array.from(map.entries())
            .map(([tag, count]) => ({ tag, count }))
            .sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag, 'zh-CN'));
        },
        analysisTemplatePickerTagFilteredStats() {
          const q = (this.analysisTemplateTagSearchQuery || '').trim().toLowerCase();
          const rows = this.analysisTemplatePickerTagStats;
          if (!q) return rows;
          return rows.filter((r) => r.tag.toLowerCase().includes(q));
        },
        analysisTemplatePickerSortOptions() {
          return [
            { value: 'name_asc', label: '按名称（A→Z）' },
            { value: 'name_desc', label: '按名称（Z→A）' },
            { value: 'tag_count_desc', label: '按标签数（多→少）' },
            { value: 'tag_count_asc', label: '按标签数（少→多）' },
            { value: 'updated_desc', label: '按更新时间（新→旧）' },
            { value: 'updated_asc', label: '按更新时间（旧→新）' },
            { value: 'created_desc', label: '按创建时间（新→旧）' },
            { value: 'created_asc', label: '按创建时间（旧→新）' },
          ];
        },
        currentAnalysisTemplatePickerSortLabel() {
          const list = this.analysisTemplatePickerSortOptions || [];
          const hit = list.find((opt) => String(opt.value) === String(this.analysisTemplateSortBy || ''));
          return hit ? hit.label : '排序';
        },
        filteredSelectableAnalysisTemplates() {
          const list = this.analysisTemplatePickerPool || [];
          const kw = String(this.analysisTemplateSearchKeyword || '').trim().toLowerCase();
          const tagKeys = this.analysisTemplateFilterTagKeys || [];
          const modeAll = this.analysisTemplateFilterTagMatchMode === 'all';
          const filtered = list.filter((tpl) => {
            let matchKw = true;
            if (kw) {
              const name = String(tpl.name || '').toLowerCase();
              const desc = String(tpl.description || '').toLowerCase();
              const tagStr = (Array.isArray(tpl.tags) ? tpl.tags : []).join(' ').toLowerCase();
              matchKw = name.includes(kw) || desc.includes(kw) || tagStr.includes(kw);
            }
            const stags = tpl.tags || [];
            const matchTag =
              tagKeys.length === 0 ||
              (modeAll ? tagKeys.every((t) => stags.includes(t)) : tagKeys.some((t) => stags.includes(t)));
            return matchKw && matchTag;
          });
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const time = (v) => {
            const t = Date.parse(String(v || '').trim());
            return Number.isNaN(t) ? 0 : t;
          };
          const tagCount = (t) => (Array.isArray(t.tags) ? t.tags.length : 0);
          const byName = (a, b) => collator.compare(String(a.name || ''), String(b.name || ''));
          const sortKey = this.analysisTemplateSortBy || 'name_asc';
          return [...filtered].sort((a, b) => {
            if (sortKey === 'name_desc') return byName(b, a);
            if (sortKey === 'tag_count_desc') return tagCount(b) - tagCount(a) || byName(a, b);
            if (sortKey === 'tag_count_asc') return tagCount(a) - tagCount(b) || byName(a, b);
            if (sortKey === 'updated_desc') return time(b.updatedAt) - time(a.updatedAt) || byName(a, b);
            if (sortKey === 'updated_asc') return time(a.updatedAt) - time(b.updatedAt) || byName(a, b);
            if (sortKey === 'created_desc') return time(b.createdAt) - time(a.createdAt) || byName(a, b);
            if (sortKey === 'created_asc') return time(a.createdAt) - time(b.createdAt) || byName(a, b);
            return byName(a, b);
          });
        },
        analysisResultColumns() {
          return [
            { title: '结果名称', dataIndex: 'name', key: 'name', ellipsis: true },
            { title: '标签', dataIndex: 'tags', key: 'tags', ellipsis: true },
            { title: '状态', key: 'status', ellipsis: true },
            { title: '生成时间', dataIndex: 'createdAt', key: 'createdAt', ellipsis: true },
            { title: '操作', key: 'action', ellipsis: true },
          ];
        },
        analysisResultPreviewMarkdown() {
          const rec = this.analysisResultPreviewRecord || {};
          if (rec.analysisMarkdown) return rec.analysisMarkdown;
          return buildAnalysisResultPreviewMarkdown(rec);
        },
        analysisResultVersionMenuList() {
          const rec = this.analysisResultPreviewRecord;
          if (!rec || !rec.id) return [];
          const list = (this.analysisResultVersionHistoryById || {})[rec.id];
          return Array.isArray(list) ? list : [];
        },
        analysisResultVersionMgmtColumns() {
          return [
            { title: '生成时间', dataIndex: 'generatedAt', key: 'generatedAt', width: 156 },
            {
              title: '生成说明',
              dataIndex: 'generationDesc',
              key: 'generationDesc',
              ellipsis: true,
              className: 'skill-version-mgmt-col-desc',
            },
            { title: '操作', key: 'action', width: 128, align: 'left', className: 'skill-version-mgmt-col-action' },
          ];
        },
        analysisResultVersionCurrentRow() {
          const rec = this.analysisResultPreviewRecord;
          if (!rec || !rec.id) return null;
          const generatedAt = String(rec.analysisMarkdownEditedAt || rec.createdAt || '').trim() || '—';
          const resolver = (mid) => this.analysisResultMaterialNameById(mid);
          const generationDesc =
            typeof buildAnalysisResultGenerationDesc === 'function'
              ? buildAnalysisResultGenerationDesc(rec, resolver)
              : `使用技能「${String(rec.sourceSkillName || '关联技能')}」生成的结果（演示）。`;
          return {
            key: '_current',
            generatedAt,
            generationDesc,
            markdown: this.analysisResultPreviewMarkdown || '',
          };
        },
        analysisResultVersionHistoryOnlyRows() {
          const list = this.analysisResultVersionMenuList || [];
          return list.map((v) => {
            const raw = String(v.markdown || '');
            const gd = String(v.generationDesc || '').trim();
            const savedAt = String(v.savedAt || '').trim();
            const generationDesc = gd || (savedAt ? `历史快照 · ${savedAt}` : '历史快照');
            const generatedAt = savedAt || String(v.label || '').trim() || '—';
            return {
              key: v.key,
              generatedAt,
              generationDesc,
              markdown: raw,
            };
          });
        },
        /** 结果预览 · 第二行：对话生成 + 可选「人工编辑」后缀 */
        analysisResultPreviewDialogueSourceLine() {
          const r = this.analysisResultPreviewRecord;
          if (!r) return '';
          const base = '初始结果通过对话生成';
          const who = String(r.analysisMarkdownEditedBy || '').trim();
          const when = String(r.analysisMarkdownEditedAt || '').trim();
          if (who && when) return `${base}（${who} 于 ${when} 编辑）`;
          return base;
        },
        analysisResultCitationMap() {
          const r = this.analysisResultPreviewRecord;
          if (!r) return DEMO_ANALYSIS_CITATION_MAP;
          return r.citationMap || DEMO_ANALYSIS_CITATION_MAP;
        },
        analysisResultPreviewHtml() {
          const md = this.analysisResultPreviewMarkdown || '';
          const html = (window.marked && typeof window.marked.parse === 'function')
            ? window.marked.parse(md)
            : md.replace(/\n/g, '<br>');
          return html.replace(/\[(E\d+)\]/g, (_, k) => `<span class="analysis-inline-citation">（${this.analysisCitationDisplayIndex(k)}）</span>`);
        },
        analysisResultVersionDetailHtml() {
          const md = this.analysisResultVersionDetailMarkdown || '';
          const html = (window.marked && typeof window.marked.parse === 'function')
            ? window.marked.parse(md)
            : md.replace(/\n/g, '<br>');
          return html.replace(/\[(E\d+)\]/g, (_, k) => `<span class="analysis-inline-citation">（${this.analysisCitationDisplayIndex(k)}）</span>`);
        },
        projectMaterialStatusOptions() {
          return [
            { value: 'all', label: '全部状态' },
            { value: 'queued', label: '排队中' },
            { value: 'parsing', label: '解析中' },
            { value: 'done', label: '完成' },
            { value: 'failed', label: '失败' },
          ];
        },
        projectMaterialSortOptions() {
          return [
            { value: 'uploaded_desc', label: '按上传时间（新→旧）' },
            { value: 'uploaded_asc', label: '按上传时间（旧→新）' },
            { value: 'status', label: '按状态' },
            { value: 'type', label: '按类型' },
            { value: 'name', label: '按名称' },
            { value: 'size_desc', label: '按大小（大->小）' },
            { value: 'size_asc', label: '按大小（小->大）' },
          ];
        },
        currentProjectMaterialSortLabel() {
          const list = this.projectMaterialSortOptions || [];
          const hit = list.find((opt) => String(opt.value) === String(this.projectMaterialSortBy || ''));
          return hit ? hit.label : '排序';
        },
        isProjectMaterialSortSelectedByFilter() {
          return !!((this.projectMaterialTagKeys || []).length);
        },
        projectMaterialTableColumns() {
          return [
            { title: '名称', key: 'name', ellipsis: true, align: 'left' },
            { title: '标签', key: 'tags', ellipsis: true, align: 'left' },
            { title: '大小', key: 'size', align: 'left' },
            { title: '格式', key: 'format', align: 'left' },
            { title: '状态', key: 'status', align: 'left' },
            { title: '进度', key: 'progress', align: 'left' },
            { title: '操作', key: 'action', align: 'left' },
          ];
        },
        projectMaterialTableRowSelection() {
          return {
            selectedRowKeys: [...(this.selectedMaterialIds || [])],
            onChange: (keys) => {
              this.selectedMaterialIds = keys;
            },
            preserveSelectedRowKeys: true,
            columnWidth: 44,
          };
        },
        analysisResultTableRowSelection() {
          return {
            selectedRowKeys: [...(this.selectedAnalysisResultIds || [])],
            onChange: (keys) => {
              this.selectedAnalysisResultIds = Array.isArray(keys) ? keys : [];
            },
            preserveSelectedRowKeys: true,
            columnWidth: 44,
          };
        },
        projectMaterialTagStats() {
          const map = new Map();
          (this.currentProjectMaterials || []).forEach((m) => {
            (m.tags || []).forEach((t) => {
              const tag = String(t || '').trim();
              if (!tag) return;
              map.set(tag, (map.get(tag) || 0) + 1);
            });
          });
          return Array.from(map.entries())
            .map(([tag, count]) => ({ tag, count }))
            .sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag, 'zh-CN'));
        },
        projectMaterialTagFilteredStats() {
          const q = (this.projectMaterialTagSearchQuery || '').trim().toLowerCase();
          const rows = this.projectMaterialTagStats;
          if (!q) return rows;
          return rows.filter((r) => r.tag.toLowerCase().includes(q));
        },
        materialStatusSummary() {
          const rows = this.currentProjectMaterials || [];
          const summary = { total: rows.length, queued: 0, parsing: 0, done: 0, failed: 0 };
          rows.forEach((r) => {
            const k = r && r.status;
            if (k === 'queued' || k === 'parsing' || k === 'done' || k === 'failed') summary[k] += 1;
          });
          return summary;
        },
        /** 总览引导步骤 1 右侧：未就绪 / 解析中仅 x/y / 准备就绪 */
        overviewGuideMaterialStatus() {
          const s = this.materialStatusSummary || { total: 0, done: 0 };
          const total = Number(s.total) || 0;
          const done = Number(s.done) || 0;
          if (total === 0) {
            return {
              phase: 'idle',
              title: '未就绪',
              ratioText: '',
              aria: '资料汇总：未就绪，尚未上传资料',
            };
          }
          if (done === total) {
            return {
              phase: 'ready',
              title: '准备就绪',
              ratioText: '',
              aria: `资料汇总：准备就绪，${total} 份资料均已完成解析`,
            };
          }
          return {
            phase: 'parsing',
            title: `${done}/${total}`,
            ratioText: '',
            aria: `资料汇总：解析中，已完成 ${done} 份，共 ${total} 份`,
          };
        },
        /** 总览引导步骤 2 右侧：未就绪（0 技能）/ 准备就绪（已配置技能） */
        overviewGuideSkillStatus() {
          const n = (this.currentProjectAnalysisTemplates || []).length;
          if (n === 0) {
            return {
              phase: 'idle',
              title: '未就绪',
              aria: '技能汇总：未就绪，尚未配置技能',
            };
          }
          return {
            phase: 'ready',
            title: '准备就绪',
            aria: `技能汇总：准备就绪，已配置 ${n} 个技能`,
          };
        },
        /** 总览引导步骤 3 右侧：无数据 / 分析中仅 x/y（已完成/总数）/ 全部完成 */
        overviewGuideResultStatus() {
          const s = this.overviewResultStatusSummary || { total: 0, done: 0 };
          const total = Number(s.total) || 0;
          const done = Number(s.done) || 0;
          if (total === 0) {
            return {
              phase: 'empty',
              title: '无数据',
              ratioText: '',
              aria: '结果汇总：无数据，尚无分析结果',
            };
          }
          if (done === total) {
            return {
              phase: 'ready',
              title: '完成',
              ratioText: '',
              aria: `结果汇总：完成，共 ${total} 条结果均为已完成状态`,
            };
          }
          return {
            phase: 'parsing',
            title: `${done}/${total}`,
            ratioText: '',
            aria: `结果汇总：分析中，已完成 ${done} 条，共 ${total} 条`,
          };
        },
        /** 与筛选「解析中」一致：排队中 + 解析中 */
        projectMaterialProcessingTabCount() {
          const s = this.materialStatusSummary || { queued: 0, parsing: 0 };
          return (s.queued || 0) + (s.parsing || 0);
        },
        projectMaterialPageSizeOptions() {
          return [
            { value: 20, label: '20页' },
            { value: 50, label: '50页' },
            { value: 100, label: '100页' },
          ];
        },
        /** 结果列表分页：含默认 8 条/页，与资料页下拉样式类名共用 */
        analysisResultPageSizeOptions() {
          return [
            { value: 8, label: '8页' },
            { value: 20, label: '20页' },
            { value: 50, label: '50页' },
            { value: 100, label: '100页' },
          ];
        },
        uploadMaterialBatchColumns() {
          return [
            { title: '文件名称', dataIndex: 'name', key: 'name', ellipsis: true },
            { title: '大小', dataIndex: 'size', key: 'size', width: 110 },
            { title: '格式', dataIndex: 'format', key: 'format', width: 100 },
            { title: '操作', key: 'actions', width: 80 },
          ];
        },
        /** 兼容下载等：等同文档预览页 */
        materialPreviewPages() {
          return materialPreviewDocumentPagesFromRecord(this.materialPreviewRecord);
        },
        materialPreviewDocumentPages() {
          return materialPreviewDocumentPagesFromRecord(this.materialPreviewRecord);
        },
        materialPreviewOcrPages() {
          return materialPreviewOcrPagesFromRecord(this.materialPreviewRecord);
        },
        materialPreviewOcrPagesDisplayed() {
          const pages = this.materialPreviewOcrPages;
          if (!this.materialPreviewOcrShowLineNumbers) return pages;
          return pages.map((p) => materialPreviewOcrPageWithLineNumbers(p, true));
        },
        materialPreviewBasicMetaRows() {
          const r = this.materialPreviewRecord;
          if (!r) return [];
          return this.buildOverviewMaterialMeta(r);
        },
        analysisResultBasicMetaRows() {
          const r = this.analysisResultPreviewRecord;
          if (!r) return [];
          return this.buildOverviewResultMeta(r);
        },
        projectItemMetaEditModalTitle() {
          return this.projectItemMetaEditKind === 'analysisResult' ? '编辑结果' : '编辑资料';
        },
        /** 从资料/结果预览内打开编辑时，必须高于预览 Modal，否则会被遮住 */
        projectItemMetaEditModalZIndex() {
          if (this.materialPreviewVisible || this.analysisResultPreviewVisible) return 3200;
          return 1000;
        },
        projectItemMetaEditWrapClass() {
          let c = 'modal-w-560 modal-project-item-meta-edit';
          if (this.materialPreviewVisible || this.analysisResultPreviewVisible) c += ' modal-project-item-meta-edit--on-preview';
          return c;
        },
        filteredProjectMaterials() {
          const rows = this.currentProjectMaterials || [];
          const keyword = String(this.projectMaterialSearchKeyword || '').trim().toLowerCase();
          const statusKey = String(this.projectMaterialStatusKey || 'all');
          const tagKeys = this.projectMaterialTagKeys || [];
          const modeAll = this.projectMaterialTagMatchMode === 'all';
          const list = rows.filter((row) => {
            const text = `${row.name || ''}`.toLowerCase();
            const hitKeyword = !keyword || text.includes(keyword);
            const hitStatus = statusKey === 'all' || String(row.status || 'queued') === statusKey;
            const rowTags = Array.isArray(row.tags) ? row.tags : [];
            const hitTag =
              tagKeys.length === 0 ||
              (modeAll ? tagKeys.every((t) => rowTags.includes(t)) : tagKeys.some((t) => rowTags.includes(t)));
            return hitKeyword && hitStatus && hitTag;
          });
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const timeOf = (v) => {
            const t = Date.parse(String(v || '').trim());
            return Number.isNaN(t) ? 0 : t;
          };
          const sizeOf = (v) => Number(v || 0);
          const statusRank = (s) => ({ parsing: 0, queued: 1, failed: 2, done: 3 }[s] ?? 9);
          return [...list].sort((a, b) => {
            const byName = () => collator.compare(String(a.name || ''), String(b.name || ''));
            if (this.projectMaterialSortBy === 'uploaded_desc') return timeOf(b.uploadedAt) - timeOf(a.uploadedAt) || byName();
            if (this.projectMaterialSortBy === 'uploaded_asc') return timeOf(a.uploadedAt) - timeOf(b.uploadedAt) || byName();
            if (this.projectMaterialSortBy === 'status') return statusRank(a.status) - statusRank(b.status) || timeOf(b.uploadedAt) - timeOf(a.uploadedAt);
            if (this.projectMaterialSortBy === 'type') return collator.compare(String(a.format || ''), String(b.format || '')) || timeOf(b.uploadedAt) - timeOf(a.uploadedAt);
            if (this.projectMaterialSortBy === 'name') return collator.compare(String(a.name || ''), String(b.name || '')) || timeOf(b.uploadedAt) - timeOf(a.uploadedAt);
            if (this.projectMaterialSortBy === 'size_desc') return sizeOf(b.size) - sizeOf(a.size) || timeOf(b.uploadedAt) - timeOf(a.uploadedAt);
            if (this.projectMaterialSortBy === 'size_asc') return sizeOf(a.size) - sizeOf(b.size) || timeOf(b.uploadedAt) - timeOf(a.uploadedAt);
            return timeOf(b.uploadedAt) - timeOf(a.uploadedAt) || byName();
          });
        },
        pagedProjectMaterials() {
          const page = Number(this.projectMaterialPage || 1);
          const size = Number(this.projectMaterialPageSize || 8);
          const start = (page - 1) * size;
          return this.filteredProjectMaterials.slice(start, start + size);
        },
        selectedMaterialCount() {
          return (this.selectedMaterialIds || []).length;
        },
        projectListEmptyDescription() {
          const all = this.projectList || [];
          if (!all.length) return '暂无工作台，可点击「创建工作台」。';
          const k = (this.projectListSearch || '').trim();
          const scope = this.projectListScope || 'mine';
          const inScope = (p) => (scope === 'shared' ? !!p.isSharedToMe : !p.isSharedToMe);
          if (!k && !all.some(inScope)) {
            return scope === 'shared' ? '暂无他人共享给你的工作台。' : '暂无我的工作台。';
          }
          return '没有符合搜索条件的工作台，请调整关键词。';
        },
        projectListSortOptions() {
          return [
            { value: 'name_asc', label: '按名称（A→Z / 拼音）' },
            { value: 'name_desc', label: '按名称（Z→A / 拼音）' },
            { value: 'updated_desc', label: '按更新时间（新→旧）' },
            { value: 'updated_asc', label: '按更新时间（旧→新）' },
            { value: 'created_desc', label: '按创建时间（新→旧）' },
            { value: 'created_asc', label: '按创建时间（旧→新）' },
          ];
        },
        filteredProjectList() {
          const list = this.projectList || [];
          const scope = this.projectListScope || 'mine';
          const scopeList = list.filter((p) => (scope === 'shared' ? !!p.isSharedToMe : !p.isSharedToMe));
          const k = (this.projectListSearch || '').trim().toLowerCase();
          const collator = new Intl.Collator('zh-CN', { numeric: true, sensitivity: 'base' });
          const str = (v) => String(v || '').trim();
          const time = (v) => {
            const t = Date.parse(str(v));
            return Number.isNaN(t) ? 0 : t;
          };
          const filtered = scopeList.filter((p) => {
            const matchKw =
              !k ||
              str(p.name).toLowerCase().includes(k) ||
              str(p.description).toLowerCase().includes(k) ||
              str(p.templateName).toLowerCase().includes(k);
            return matchKw;
          });
          const byName = (a, b) => collator.compare(str(a.name), str(b.name));
          const key = this.projectListSortBy || 'created_desc';
          return [...filtered].sort((a, b) => {
            if (key === 'name_asc') return byName(a, b);
            if (key === 'name_desc') return byName(b, a);
            if (key === 'updated_desc') return time(b.updatedAt) - time(a.updatedAt) || byName(a, b);
            if (key === 'updated_asc') return time(a.updatedAt) - time(b.updatedAt) || byName(a, b);
            if (key === 'created_desc') return time(b.createdAt) - time(a.createdAt) || byName(a, b);
            if (key === 'created_asc') return time(a.createdAt) - time(b.createdAt) || byName(a, b);
            return time(b.createdAt) - time(a.createdAt) || byName(a, b);
          });
        },
      },
      mounted() {
        const onHashChange = () => {
          this.projectIdFromHash = getProjectIdFromHash();
          this.applyPendingNewProject();
          this.tryConsumeOpenUploadQuery();
          this.tryConsumeProjectDetailTabQuery();
          this.tryConsumeOpenCreateSkillQuery();
          this.tryConsumeOpenEditQuery();
        };
        window.addEventListener('hashchange', onHashChange);
        this._projectHashCleanup = () => window.removeEventListener('hashchange', onHashChange);
        this.projectIdFromHash = getProjectIdFromHash();
        this.applyPendingNewProject();
        this.tryConsumeOpenUploadQuery();
        this.tryConsumeProjectDetailTabQuery();
        this.tryConsumeOpenCreateSkillQuery();
        this.tryConsumeOpenEditQuery();
        this.syncRequirementsContext();
        this.$nextTick(() => this.maybeStartProjectOverviewTour());
        window.__demoQuoteSkillBridge = {
          _owner: this,
          openForWorkbenchProject: (projectId) => {
            if (!projectId) return;
            this.openAnalysisTemplateModal({ targetProjectId: String(projectId) });
          },
        };
      },
      watch: {
        projectDetailTab(v) {
          if (v !== 'overview') this.projectOverviewTourOpen = false;
          if (v !== 'templates') this.projectSkillLibrarySelectedIds = [];
          this.syncRequirementsContext();
          this.$nextTick(() => this.maybeStartProjectOverviewTour());
        },
        projectOverviewTourOpen(v) {
          if (v) {
            this.$nextTick(() => {
              this.updateProjectOverviewTourCoachPosition();
              this.bindProjectOverviewTourPositionListeners();
              this.$nextTick(() => this.updateProjectOverviewTourCoachPosition());
            });
          } else {
            this.unbindProjectOverviewTourPositionListeners();
          }
        },
        projectIdFromHash(nv) {
          this.projectOverviewTourOpen = false;
          if (!nv) {
            this.projectDetailModeExit = false;
            this.projectDetailSiderBoot = false;
          } else {
            let boot = false;
            try {
              if (sessionStorage.getItem('demoAutoEnterAnim') === '1') {
                sessionStorage.removeItem('demoAutoEnterAnim');
                boot = true;
              }
            } catch (_) { /* ignore */ }
            this.projectDetailSiderBoot = boot;
            if (boot) {
              this.$nextTick(() => {
                requestAnimationFrame(() => {
                  window.setTimeout(() => { this.projectDetailSiderBoot = false; }, 48);
                });
              });
            }
          }
          this.projectDetailTab = 'overview';
          this.projectMaterialSearchKeyword = '';
          this.projectDetailTemplateSearchKeyword = '';
          this.projectDetailTemplateTagKeys = [];
          this.projectDetailTemplateTagMatchMode = 'any';
          this.projectDetailTemplateTagSearchQuery = '';
          this.projectDetailTemplateTagPopoverOpen = false;
          this.projectDetailTemplateSortBy = 'name_asc';
          this.projectDetailTemplateSortDropdownOpen = false;
          this.projectAnalysisResultSearchKeyword = '';
          this.projectAnalysisResultTagKeys = [];
          this.projectAnalysisResultTagMatchMode = 'any';
          this.projectAnalysisResultTagSearchQuery = '';
          this.projectAnalysisResultTagPopoverOpen = false;
          this.projectAnalysisResultSortBy = 'created_desc';
          this.projectAnalysisResultSortDropdownOpen = false;
          this.projectMaterialSortBy = 'uploaded_desc';
          this.projectMaterialSortDropdownOpen = false;
          this.projectMaterialTagKeys = [];
          this.projectMaterialTagMatchMode = 'any';
          this.projectMaterialTagSearchQuery = '';
          this.projectMaterialTagPopoverOpen = false;
          this.selectedMaterialIds = [];
          this.selectedAnalysisResultIds = [];
          this.selectedAnalysisTemplateIds = [];
          this.projectSkillLibrarySelectedIds = [];
          this.projectMaterialPage = 1;
          this.analysisResultPage = 1;
          this.applyPendingNewProject();
          this.syncRequirementsContext();
          this.$nextTick(() => this.maybeStartProjectOverviewTour());
        },
        projectMaterialSearchKeyword() { this.projectMaterialPage = 1; },
        projectMaterialSortBy() { this.projectMaterialPage = 1; },
        projectMaterialStatusKey() { this.projectMaterialPage = 1; },
        projectMaterialTagKeys() { this.projectMaterialPage = 1; },
        projectMaterialTagMatchMode() { this.projectMaterialPage = 1; },
        projectMaterialPageSize() { this.projectMaterialPage = 1; },
        currentProjectAnalysisResults() { this.analysisResultPage = 1; },
        projectAnalysisResultSearchKeyword() { this.analysisResultPage = 1; },
        projectAnalysisResultStatusKey() { this.analysisResultPage = 1; },
        projectAnalysisResultTagKeys() { this.analysisResultPage = 1; },
        projectAnalysisResultTagMatchMode() { this.analysisResultPage = 1; },
        projectAnalysisResultSortBy() { this.analysisResultPage = 1; },
        analysisResultPageSize() { this.analysisResultPage = 1; },
        analysisTemplateSourceTab() {
          this.analysisTemplateFilterTagKeys = [];
          this.analysisTemplateTagSearchQuery = '';
          this.analysisTemplateFilterPopoverOpen = false;
          this.analysisTemplateSortDropdownOpen = false;
          this.analysisTemplateSelectedIds = [];
        },
        'projectEditForm.visibility'(v) {
          if (v !== 'shared' && this.projectEditForm) {
            this.projectEditForm.sharedUserIds = [];
            this.projectEditForm.sharedDeptIds = [];
          }
        },
        materialPreviewVisible(v) {
          if (v) {
            this.$nextTick(() => {
              const el = this.$refs.materialPreviewScrollEl;
              if (el) el.scrollTop = 0;
            });
          }
        },
        analysisResultPreviewVisible(v) {
          if (v) {
            this.$nextTick(() => {
              const el = this.$refs.analysisResultPreviewScrollEl;
              if (el) el.scrollTop = 0;
            });
          }
        },
      },
      beforeUnmount() {
        (this._analysisJobTimers || []).forEach((timerId) => window.clearTimeout(timerId));
        this._analysisJobTimers = [];
        if (this._projectHashCleanup) this._projectHashCleanup();
        if (window.__demoQuoteSkillBridge && window.__demoQuoteSkillBridge._owner === this) {
          window.__demoQuoteSkillBridge = null;
        }
        this.unbindProjectOverviewTourPositionListeners();
      },
      methods: {
        getSkillAnalysisRulePlaceholder() {
          if (typeof window !== 'undefined' && typeof window.__demoGetSkillAnalysisRulePlaceholder === 'function') {
            return window.__demoGetSkillAnalysisRulePlaceholder();
          }
          return (typeof window !== 'undefined' && window.__DEMO_SKILL_ANALYSIS_RULE_PLACEHOLDER) || '';
        },
        analysisCitationDisplayIndex(key) {
          const raw = String(key || '').trim();
          const matched = raw.match(/(\d+)$/);
          return matched ? matched[1] : raw;
        },
        buildAnalysisCitationEntries(markdown, citationMap) {
          const text = String(markdown || '');
          const map = citationMap || {};
          const seen = new Set();
          const keys = [];
          text.replace(/\[(E\d+)\]/g, (_, key) => {
            if (!seen.has(key)) {
              seen.add(key);
              keys.push(key);
            }
            return _;
          });
          return keys.map((key) => {
            const data = map[key] || {};
            return {
              key,
              indexLabel: this.analysisCitationDisplayIndex(key),
              sourceLabel: String(data.sourceLabel || '引用来源').trim() || '引用来源',
              excerpt: String(data.sourceExcerpt || data.sourceFullText || '').trim() || '暂无可展示的引用内容',
            };
          });
        },
        projectPolishUndoDisabled(key) {
          return (
            this.projectSkillConfigTabLocked ||
            !!this.projectAiPolishKey ||
            !Object.prototype.hasOwnProperty.call(this.projectPolishUndo, key)
          );
        },
        beginProjectAiPolish(key, getText, setText, onDone) {
          if (this.projectSkillConfigTabLocked || this.projectAiPolishKey) return;
          this.projectPolishUndo[key] = String(getText() == null ? '' : getText());
          this.projectAiPolishKey = key;
          window.setTimeout(() => {
            const sample =
              typeof window.__demoPolishSampleForKey === 'function' ? window.__demoPolishSampleForKey(key) : '';
            setText(sample);
            this.projectAiPolishKey = '';
            if (typeof onDone === 'function') onDone();
          }, 1300);
        },
        undoProjectPolish(key, setText, onDone) {
          if (this.projectSkillConfigTabLocked || this.projectAiPolishKey) return;
          if (!Object.prototype.hasOwnProperty.call(this.projectPolishUndo, key)) return;
          const prev = this.projectPolishUndo[key];
          delete this.projectPolishUndo[key];
          setText(prev);
          if (typeof onDone === 'function') onDone();
        },
        demoAiPolishProjectSkillFileField(file, field) {
          if (this.projectSkillConfigTabLocked || !file) return;
          const short = field === 'filename' ? 'fn' : 'ct';
          const key = String(file.id) + ':' + short;
          this.beginProjectAiPolish(
            key,
            () => (field === 'filename' ? file.filename : file.content),
            (t) => {
              if (field === 'filename') file.filename = t;
              else file.content = t;
            },
            () => this.scheduleProjectSkillDetailSync()
          );
        },
        undoProjectSkillFileField(file, field) {
          if (this.projectSkillConfigTabLocked || !file) return;
          const short = field === 'filename' ? 'fn' : 'ct';
          const key = String(file.id) + ':' + short;
          this.undoProjectPolish(
            key,
            (t) => {
              if (field === 'filename') file.filename = t;
              else file.content = t;
            },
            () => this.scheduleProjectSkillDetailSync()
          );
        },
        demoAiPolishProjectAnalysisRule() {
          if (this.projectSkillConfigTabLocked) return;
          const s = this.selectedProjectSkill;
          if (!s) return;
          this.beginProjectAiPolish(
            'project-analysisRule',
            () => s.analysisRule,
            (t) => {
              s.analysisRule = t;
            },
            () => this.scheduleProjectSkillDetailSync()
          );
        },
        undoProjectAnalysisRule() {
          if (this.projectSkillConfigTabLocked) return;
          const s = this.selectedProjectSkill;
          if (!s) return;
          this.undoProjectPolish(
            'project-analysisRule',
            (t) => {
              s.analysisRule = t;
            },
            () => this.scheduleProjectSkillDetailSync()
          );
        },
        syncRequirementsContext() {
          try {
            if (!window.__demoRequirementsContext) window.__demoRequirementsContext = { projectDetailTab: 'overview' };
            if (this.currentProjectId) {
              window.__demoRequirementsContext.projectDetailTab = this.projectDetailTab || 'overview';
            } else {
              window.__demoRequirementsContext.projectDetailTab = 'overview';
            }
          } catch (err) { /* ignore */ }
          notifyParentRequirementsContext();
        },
        /** 首次进入工作台总览：仅保留模式切换提醒（每工作台一次） */
        maybeStartProjectOverviewTour() {
          if (this.projectDetailTab !== 'overview') return;
          const id = this.currentProjectId;
          if (!id) return;
          try {
            if (localStorage.getItem(this.overviewTourStorageKey) === '1') return;
          } catch (_) { /* ignore */ }
          window.setTimeout(() => {
            if (this.projectDetailTab !== 'overview' || this.currentProjectId !== id) return;
            const root = this.$el;
            if (!root || !root.querySelector('[data-overview-tour="mode"]')) return;
            this.projectOverviewTourOpen = true;
          }, 520);
        },
        persistProjectOverviewTourDone() {
          try {
            if (this.currentProjectId) localStorage.setItem(this.overviewTourStorageKey, '1');
          } catch (_) { /* ignore */ }
        },
        dismissProjectOverviewTourKnow() {
          this.persistProjectOverviewTourDone();
          this.projectOverviewTourOpen = false;
        },
        updateProjectOverviewTourCoachPosition() {
          if (!this.projectOverviewTourOpen) return;
          const key = 'mode';
          const root = this.$el;
          const el = key && root && root.querySelector(`[data-overview-tour="${key}"]`);
          if (!el) return;
          const rect = el.getBoundingClientRect();
          const gap = 12;
          const coachEstH = 188;
          const coachMaxW = 320;
          const pad = 12;
          let top = rect.bottom + gap;
          top = Math.min(top, window.innerHeight - coachEstH - pad);
          top = Math.max(pad, top);
          const cx = rect.left + rect.width / 2;
          const half = Math.min(coachMaxW / 2 + 8, (window.innerWidth - pad * 2) / 2);
          const left = Math.min(Math.max(half + pad, cx), window.innerWidth - half - pad);
          this.projectOverviewTourCoachStyle = {
            position: 'fixed',
            left: `${left}px`,
            top: `${top}px`,
            transform: 'translateX(-50%)',
          };
        },
        bindProjectOverviewTourPositionListeners() {
          this.unbindProjectOverviewTourPositionListeners();
          this._overviewTourOnReposition = () => {
            if (this.projectOverviewTourOpen) this.updateProjectOverviewTourCoachPosition();
          };
          window.addEventListener('resize', this._overviewTourOnReposition);
          const scrollRoot = this.$el && this.$el.querySelector('.project-detail-overview');
          this._overviewTourScrollRoot = scrollRoot || null;
          if (this._overviewTourScrollRoot) {
            this._overviewTourScrollRoot.addEventListener('scroll', this._overviewTourOnReposition, { passive: true });
          }
        },
        unbindProjectOverviewTourPositionListeners() {
          if (!this._overviewTourOnReposition) return;
          window.removeEventListener('resize', this._overviewTourOnReposition);
          if (this._overviewTourScrollRoot) {
            this._overviewTourScrollRoot.removeEventListener('scroll', this._overviewTourOnReposition);
          }
          this._overviewTourScrollRoot = null;
          this._overviewTourOnReposition = null;
        },
        skillFormatTime(v) {
          return (v != null && String(v)) ? String(v).slice(0, 16) : '—';
        },
        onAnalysisResultPageChange(page) {
          this.analysisResultPage = Math.max(1, Number(page || 1));
        },
        /** 列表卡片统计：优先用按工作台维护的演示数据，否则回退到 projectList 汇总字段 */
        projectCardMaterialCount(projectId) {
          const pid = String(projectId || '');
          const mats = this.projectMaterialsById[pid];
          if (Array.isArray(mats) && mats.length) {
            const total = mats.length;
            const done = mats.filter((row) => String(row && row.status || '') === 'done').length;
            return done + '/' + total;
          }
          const p = (this.projectList || []).find((x) => x.id === pid);
          const total = p ? (Number(p.materialCount) || Number(p.docCount) || 0) : 0;
          return total + '/' + total;
        },
        projectCardAnalysisResultCount(projectId) {
          const pid = String(projectId || '');
          const rows = this.projectAnalysisResultsById[pid];
          if (Array.isArray(rows) && rows.length) {
            const total = rows.length;
            const done = rows.filter((row) => String(row && row.status || '') === 'done').length;
            return done + '/' + total;
          }
          const p = (this.projectList || []).find((x) => x.id === pid);
          const total = p ? (Number(p.analysisCount) || 0) : 0;
          return total + '/' + total;
        },
        projectCardTemplateCount(projectId) {
          const pid = String(projectId || '');
          const tpls = this.projectAnalysisTemplatesById[pid];
          if (Array.isArray(tpls) && tpls.length) return tpls.length;
          const p = (this.projectList || []).find((x) => x.id === pid);
          if (p && String(p.templateName || '').trim()) return 1;
          return 0;
        },
        onProjectCardMoreMenu(info, p) {
          const key = info && info.key;
          if (key === 'edit') {
            this.openProjectEdit(p);
            return;
          }
          if (key === 'delete') {
            window.dsConfirm.delete({
              subject: '该工作台',
              onOk: () => {
                this.deleteProject(p);
              },
            });
          }
        },
        deleteProject(p) {
          if (!p || !p.id) return;
          this.projectList = (this.projectList || []).filter((x) => x.id !== p.id);
          message.success('已删除');
        },
        openProjectEdit(p) {
          if (!p) return;
          let vis = 'private';
          if (p.visibility === 'shared') vis = 'shared';
          else if (p.visibility === 'public') vis = 'private';
          this.projectEditForm = {
            id: p.id,
            name: p.name || '',
            description: p.description || '',
            visibility: vis,
            sharedUserIds: vis === 'shared' && Array.isArray(p.sharedUserIds) ? p.sharedUserIds.slice() : [],
            sharedDeptIds: vis === 'shared' && Array.isArray(p.sharedDeptIds) ? p.sharedDeptIds.slice() : [],
          };
          this.projectEditVisible = true;
        },
        openCurrentProjectEdit() {
          if (!this.currentProject) return;
          this.openProjectEdit(this.currentProject);
        },
        saveProjectEdit() {
          const id = this.projectEditForm && this.projectEditForm.id;
          if (!id) return;
          const name = String(this.projectEditForm.name || '').trim();
          if (!name) {
            message.warning('请填写工作台名称');
            return;
          }
          const desc = String(this.projectEditForm.description || '').trim();
          let vis = 'private';
          let sharedIds = [];
          if (this.projectEditForm.visibility === 'shared') {
            vis = 'shared';
            sharedIds = [...(this.projectEditForm.sharedUserIds || [])].filter(Boolean);
            const sharedDeptIds = [...(this.projectEditForm.sharedDeptIds || [])].filter(Boolean);
            if (sharedIds.length === 0 && sharedDeptIds.length === 0) {
              message.warning('请至少选择一个部门或一名用户');
              return;
            }
          }
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const i = (this.projectList || []).findIndex((x) => x.id === id);
          if (i >= 0) {
            const prev = this.projectList[i];
            const sharedDeptIdsOut = vis === 'shared' ? [...(this.projectEditForm.sharedDeptIds || [])].filter(Boolean) : [];
            const next = {
              ...prev,
              name,
              description: desc,
              visibility: vis,
              sharedUserIds: vis === 'shared' ? sharedIds : [],
              sharedDeptIds: vis === 'shared' ? sharedDeptIdsOut : [],
              updatedAt: now,
            };
            this.projectList.splice(i, 1, next);
          }
          this.projectEditVisible = false;
          message.success('已保存');
        },
        backToProjectList() {
          window.location.hash = 'project';
          this.projectIdFromHash = null;
        },
        openUploadMaterialModal() {
          this.uploadMaterialBatch = [];
          this.uploadMaterialVisible = true;
        },
        tryConsumeOpenUploadQuery() {
          this.$nextTick(() => {
            const raw = (window.location.hash || '').replace(/^#/, '');
            if (!raw.startsWith('project/')) return;
            const qIdx = raw.indexOf('?');
            if (qIdx < 0) return;
            const params = new URLSearchParams(raw.slice(qIdx + 1));
            if (params.get('openUpload') !== '1') return;
            if (!this.currentProjectId) return;
            params.delete('openUpload');
            const path = raw.slice(0, qIdx);
            const nextHash = params.toString() ? `${path}?${params.toString()}` : path;
            this.openUploadMaterialModal();
            window.history.replaceState(null, '', '#' + nextHash);
          });
        },
        /** 外链入口：#project/{id}?tab=… → 打开工作台详情对应侧栏分区（analysis 兼容为技能），并去掉 tab 参数 */
        tryConsumeProjectDetailTabQuery() {
          this.$nextTick(() => {
            const raw = (window.location.hash || '').replace(/^#/, '');
            if (!raw.startsWith('project/')) return;
            const qIdx = raw.indexOf('?');
            if (qIdx < 0) return;
            const params = new URLSearchParams(raw.slice(qIdx + 1));
            const tabRaw = params.get('tab');
            if (!tabRaw) return;
            if (!this.currentProjectId) return;
            const tabMap = {
              overview: 'overview',
              home: 'overview',
              index: 'overview',
              analysis: 'templates',
              templates: 'templates',
              results: 'results',
              materials: 'materials',
            };
            const next = tabMap[String(tabRaw).trim()];
            if (!next) return;
            this.projectDetailTab = next;
            params.delete('tab');
            const path = raw.slice(0, qIdx);
            const nextHash = params.toString() ? `${path}?${params.toString()}` : path;
            window.history.replaceState(null, '', '#' + nextHash);
          });
        },
        /** 审计助手顶栏「编辑」：#project/{id}?openEdit=1 打开编辑弹窗并清理参数 */
        tryConsumeOpenEditQuery() {
          this.$nextTick(() => {
            const raw = (window.location.hash || '').replace(/^#/, '');
            if (!raw.startsWith('project/')) return;
            const qIdx = raw.indexOf('?');
            if (qIdx < 0) return;
            const params = new URLSearchParams(raw.slice(qIdx + 1));
            if (params.get('openEdit') !== '1') return;
            if (!this.currentProjectId) return;
            params.delete('openEdit');
            const path = raw.slice(0, qIdx);
            const nextHash = params.toString() ? `${path}?${params.toString()}` : path;
            window.history.replaceState(null, '', '#' + nextHash);
            this.openCurrentProjectEdit();
          });
        },
        /** 审计助手「创建技能」：#project/{id}?openCreateSkill=1 → 技能 Tab + 新建统一弹窗 */
        tryConsumeOpenCreateSkillQuery() {
          this.$nextTick(() => {
            const raw = (window.location.hash || '').replace(/^#/, '');
            if (!raw.startsWith('project/')) return;
            const qIdx = raw.indexOf('?');
            if (qIdx < 0) return;
            const params = new URLSearchParams(raw.slice(qIdx + 1));
            if (params.get('openCreateSkill') !== '1') return;
            if (!this.currentProjectId) return;
            this.projectDetailTab = 'templates';
            params.delete('openCreateSkill');
            const path = raw.slice(0, qIdx);
            const nextHash = params.toString() ? `${path}?${params.toString()}` : path;
            window.history.replaceState(null, '', '#' + nextHash);
            this.openProjectSkillCreateBasicModal();
          });
        },
        openProjectSkillCreateBasicModal() {
          if (!this.currentProjectId) {
            message.warning('请先进入工作台');
            return;
          }
          this.projectSkillCreateBasicSubmitting = false;
          this.projectSkillCreateBasicForm = { name: '', description: '', tags: [] };
          this.projectSkillCreateBasicModalOpen = true;
        },
        closeProjectSkillCreateBasicModal() {
          this.projectSkillCreateBasicSubmitting = false;
          this.projectSkillCreateBasicModalOpen = false;
        },
        submitProjectSkillCreateBasic() {
          if (this.projectSkillCreateBasicSubmitting) return;
          if (!this.currentProjectId) {
            message.warning('请先进入工作台');
            return;
          }
          const name = String(this.projectSkillCreateBasicForm.name || '').trim();
          if (!name) {
            message.warning('请填写技能名称');
            return;
          }
          this.projectSkillCreateBasicSubmitting = true;
          this.projectSkillDetailPoolPreview = null;
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const newId = 'sk-prj-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
          const tags = Array.from(new Set((this.projectSkillCreateBasicForm.tags || []).map((t) => String(t).trim()).filter(Boolean)));
          const row = {
            id: newId,
            library: 'project',
            name,
            description: String(this.projectSkillCreateBasicForm.description || '').trim(),
            tags,
            skillFiles: [],
            extractionRules: [],
            analysisRule: '',
            applicableScenario: '',
            linkedResourceIds: [],
            linkedResourceMeta: {},
            createdAt: now,
            updatedAt: now,
            createdBy: '我',
          };
          const list = this.projectAnalysisTemplatesById[this.currentProjectId] || [];
          list.unshift(row);
          this.projectAnalysisTemplatesById[this.currentProjectId] = [...list];
          this.projectSkillDetailModalIsCreate = true;
          this.projectSkillDetailReadOnly = false;
          this._projectSkillModalSnapshot = null;
          this.projectSkillBasicPaneEditing = false;
          this.projectSkillConfigPaneEditing = true;
          this.projectSkillResourcePaneEditing = false;
          this._projectSkillBasicPaneSnap = null;
          this._projectSkillConfigPaneSnap = null;
          this._projectSkillResourcePaneSnap = null;
          this._projectSkillCreateCommitted = false;
          this.projectSkillDetailId = row.id;
          this.projectSkillDetailActiveTab = 'config';
          this.syncProjectSkillFormFromSkill(row);
          this.projectSkillConfigNavKey = 'rule';
          this.projectSkillCreateBasicSubmitting = false;
          this.projectSkillCreateBasicModalOpen = false;
          this.projectSkillDetailModalOpen = true;
          this.$nextTick(() => this.ensureProjectSkillFirstObjectExpanded());
        },
        openAnalysisTemplateModal(opts) {
          const o = opts && typeof opts === 'object' ? opts : {};
          this.quoteSkillTargetProjectId = o.targetProjectId ? String(o.targetProjectId) : null;
          this.analysisTemplateSourceTab = 'public';
          this.analysisTemplateSearchKeyword = '';
          this.analysisTemplateSelectedIds = [];
          this.analysisTemplateFilterTagKeys = [];
          this.analysisTemplateFilterTagMatchMode = 'any';
          this.analysisTemplateTagSearchQuery = '';
          this.analysisTemplateFilterPopoverOpen = false;
          this.analysisTemplateSortDropdownOpen = false;
          this.analysisTemplateSortBy = 'name_asc';
          this.analysisTemplateSelectVisible = true;
        },
        closeAnalysisTemplateModal() {
          if (this.projectSkillDetailPoolPreview) {
            this.closeProjectSkillDetailModal(false);
          }
          this.analysisTemplateSelectVisible = false;
          this.analysisTemplateSortDropdownOpen = false;
          this.quoteSkillTargetProjectId = null;
        },
        toggleAnalysisTemplateFilterTag(tag) {
          const keys = this.analysisTemplateFilterTagKeys || [];
          const idx = keys.indexOf(tag);
          if (idx >= 0) this.analysisTemplateFilterTagKeys = keys.filter((t) => t !== tag);
          else this.analysisTemplateFilterTagKeys = [...keys, tag];
        },
        clearAnalysisTemplateFilterTags() {
          this.analysisTemplateFilterTagKeys = [];
        },
        onAnalysisTemplatePickerSortMenuClick(info) {
          const next = info && info.key ? String(info.key) : '';
          if (!next) return;
          this.analysisTemplateSortBy = next;
          this.analysisTemplateSortDropdownOpen = false;
        },
        toggleAnalysisTemplatePick(id) {
          if (!id) return;
          const ids = [...(this.analysisTemplateSelectedIds || [])];
          const idx = ids.indexOf(id);
          if (idx >= 0) ids.splice(idx, 1);
          else ids.push(id);
          this.analysisTemplateSelectedIds = ids;
        },
        confirmAddAnalysisTemplates() {
          const pid = this.quoteSkillTargetProjectId || this.currentProjectId;
          if (!pid) {
            message.warning('无法确定目标工作台');
            return;
          }
          const source = this.analysisTemplateSourceTab === 'private' ? 'private' : 'public';
          const sourceMap = new Map((this.analysisTemplatePool[source] || []).map((x) => [x.id, x]));
          const selected = (this.analysisTemplateSelectedIds || [])
            .map((id) => sourceMap.get(id))
            .filter(Boolean)
            .map((tpl) => ({
              id: tpl.id,
              library: source,
              name: tpl.name,
              description: tpl.description != null ? String(tpl.description) : '',
              tags: [...(tpl.tags || [])],
              skillFiles: Array.isArray(tpl.skillFiles) ? JSON.parse(JSON.stringify(tpl.skillFiles)) : [],
              extractionRules: [],
              analysisRule: tpl.analysisRule || '',
              applicableScenario: tpl.applicableScenario != null ? String(tpl.applicableScenario) : '',
              linkedResourceIds: Array.isArray(tpl.linkedResourceIds) ? tpl.linkedResourceIds.map((id) => String(id)) : [],
              linkedResourceMeta: tpl.linkedResourceMeta && typeof tpl.linkedResourceMeta === 'object' ? { ...tpl.linkedResourceMeta } : {},
            }));
          if (!selected.length) {
            message.warning('请先选择技能');
            return;
          }
          if (!Array.isArray(this.projectAnalysisTemplatesById[pid])) this.projectAnalysisTemplatesById[pid] = [];
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const insert = selected.map((tpl) => {
            const forkId = newSkillId('sk-prj');
            const row = {
              id: forkId,
              library: tpl.library === 'private' ? 'private' : 'public',
              name: tpl.name,
              description: tpl.description != null ? String(tpl.description) : '',
              tags: [...(tpl.tags || [])],
              skillFiles: Array.isArray(tpl.skillFiles) ? JSON.parse(JSON.stringify(tpl.skillFiles)) : [],
              extractionRules: [],
              analysisRule: tpl.analysisRule || '',
              applicableScenario: tpl.applicableScenario != null ? String(tpl.applicableScenario) : '',
              sourceSkillId: tpl.id,
              sourceLibrary: source,
              sourceSkillName: String(tpl.name || '').trim() || String(tpl.id),
              sourceVersionLabel: source === 'public' ? '组织快照' : '我的技能快照',
              createdAt: now,
              updatedAt: now,
              createdBy: '我',
              linkedResourceIds: Array.isArray(tpl.linkedResourceIds) ? tpl.linkedResourceIds.map((id) => String(id)) : [],
              linkedResourceMeta: tpl.linkedResourceMeta && typeof tpl.linkedResourceMeta === 'object' ? { ...tpl.linkedResourceMeta } : {},
            };
            if (typeof DemoSkillFileTree !== 'undefined' && DemoSkillFileTree.syncExtractionRulesFromSkillFiles) {
              DemoSkillFileTree.syncExtractionRulesFromSkillFiles(row);
            }
            const rules = (row.extractionRules || []).map((r) => this.normalizeRuleForProjectTemplate(r));
            row.extractionRules = rules;
            row.manualMaterialIds = Array.from(
              new Set(rules.flatMap((r) => (Array.isArray(r.materialIds) ? r.materialIds : []).map((x) => String(x)))),
            );
            return row;
          });
          this.projectAnalysisTemplatesById[pid] = [...this.projectAnalysisTemplatesById[pid], ...insert];
          this.closeAnalysisTemplateModal();
          this.analysisTemplateSelectedIds = [];
          message.info(`已加入 ${insert.length} 个技能（演示占位，可继续调整交互）`);
        },
        insertProjectWorkbenchSkillAsNewPrivate(tpl) {
          if (!tpl) return;
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const privatePool = this.analysisTemplatePool.private || [];
          const usedIds = new Set(privatePool.map((x) => x.id));
          let newId = newSkillId('priv-arch');
          while (usedIds.has(newId)) {
            newId = newSkillId('priv-arch');
          }
          let skillFiles = [];
          if (typeof DemoSkillFileTree !== 'undefined' && DemoSkillFileTree.remapSkillFilesTree) {
            skillFiles = DemoSkillFileTree.remapSkillFilesTree(tpl.skillFiles || []);
          } else if (Array.isArray(tpl.extractionRules) && tpl.extractionRules.length) {
            skillFiles = tpl.extractionRules.map((r, ri) => ({
              id: newId + '-sf' + (ri + 1),
              kind: 'file',
              fileKind: 'md',
              codeLang: '',
              filename: (String(r.title || '').trim() || '条目' + (ri + 1)) + '.md',
              content: String(r.body || ''),
            }));
          }
          const description = (tpl.description != null ? tpl.description : '') || '';
          const row = {
            id: newId,
            name: tpl.name,
            description,
            tags: Array.isArray(tpl.tags) ? tpl.tags.slice() : [],
            skillFiles,
            extractionRules: [],
            analysisRule: tpl.analysisRule || '',
            applicableScenario: tpl.applicableScenario != null ? String(tpl.applicableScenario) : '',
            createdAt: now,
            updatedAt: now,
            library: 'private',
            publishedVersions: [],
            sourceSkillId: tpl.id,
            sourceLibrary: 'project',
            sourceSkillName: tpl.name || tpl.id,
            sourceVersionLabel: '工作台实例',
          };
          if (typeof DemoSkillFileTree !== 'undefined' && DemoSkillFileTree.syncExtractionRulesFromSkillFiles) {
            DemoSkillFileTree.syncExtractionRulesFromSkillFiles(row);
          }
          demoSharedPrivateAnalysisTemplatePool.push(row);
        },
        appendProjectSkillIntoPrivateLibrary(targetId, tpl, meta) {
          const pool = typeof demoSharedPrivateAnalysisTemplatePool !== 'undefined' ? demoSharedPrivateAnalysisTemplatePool : [];
          const tgt = pool.find((x) => String(x.id) === String(targetId));
          if (!tgt) {
            message.warning('未找到目标技能');
            return false;
          }
          const m = meta || {};
          const rawLabel = String(m.versionLabel || '').trim();
          const rawNote = String(m.versionNote || '').trim();
          if (!rawLabel) {
            message.warning('请填写版本号');
            return false;
          }
          if (!rawNote) {
            message.warning('请填写版本说明');
            return false;
          }
          if (!Array.isArray(tgt.publishedVersions)) tgt.publishedVersions = [];
          const dup = tgt.publishedVersions.some((v) => String(v.versionLabel || '').trim() === rawLabel);
          if (dup) {
            message.warning('版本号与目标技能已有记录重复，请换一个');
            return false;
          }
          let skillFiles = [];
          if (typeof DemoSkillFileTree !== 'undefined' && DemoSkillFileTree.remapSkillFilesTree) {
            skillFiles = DemoSkillFileTree.remapSkillFilesTree(tpl.skillFiles || []);
          } else {
            skillFiles = JSON.parse(JSON.stringify(tpl.skillFiles || []));
          }
          const snap = {
            name: tpl.name,
            description: (tpl.description != null ? tpl.description : '') || '',
            tags: Array.isArray(tpl.tags) ? tpl.tags.slice() : [],
            analysisRule: String(tpl.analysisRule || ''),
            applicableScenario: tpl.applicableScenario != null ? String(tpl.applicableScenario) : '',
            skillFiles: JSON.parse(JSON.stringify(skillFiles)),
          };
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          tgt.publishedVersions.push({
            versionLabel: rawLabel,
            versionNote: rawNote,
            createdAt: now,
            snapshot: snap,
            publisherName: '我',
            publisherRole: '工作台入库',
            versionStatus: 'published',
          });
          tgt.updatedAt = now;
          if (typeof DemoSkillFileTree !== 'undefined' && DemoSkillFileTree.syncExtractionRulesFromSkillFiles) {
            DemoSkillFileTree.syncExtractionRulesFromSkillFiles(tgt);
          }
          return true;
        },
        beginArchiveProjectSkillToLibrary(tpl) {
          if (!tpl) return;
          this.projectSkillArchivePendingTpl = tpl;
          this.projectSkillArchiveMode = 'new';
          this.projectSkillArchiveTargetPrivateId = '';
          this.projectSkillArchiveAppendVersionLabel = '';
          this.projectSkillArchiveAppendVersionNote = '';
          this.projectSkillArchiveBranchVisible = true;
        },
        closeProjectSkillArchiveBranchOnly() {
          this.projectSkillArchiveBranchVisible = false;
          this.projectSkillArchivePendingTpl = null;
          this.projectSkillArchiveAppendVersionLabel = '';
          this.projectSkillArchiveAppendVersionNote = '';
          this.projectSkillArchiveTargetPrivateId = '';
        },
        submitProjectSkillArchiveBranch() {
          const tpl = this.projectSkillArchivePendingTpl;
          if (!tpl) {
            this.closeProjectSkillArchiveBranchOnly();
            return;
          }
          if (this.projectSkillArchiveMode === 'append') {
            if (!this.projectSkillArchiveTargetPrivateId) {
              message.warning('请选择要追加的目标技能');
              return;
            }
            const vl = String(this.projectSkillArchiveAppendVersionLabel || '').trim();
            const vn = String(this.projectSkillArchiveAppendVersionNote || '').trim();
            if (!vl) {
              message.warning('请填写版本号');
              return;
            }
            if (!vn) {
              message.warning('请填写版本说明');
              return;
            }
            const appended = this.appendProjectSkillIntoPrivateLibrary(this.projectSkillArchiveTargetPrivateId, tpl, {
              versionLabel: vl,
              versionNote: vn,
            });
            if (!appended) return;
          } else {
            this.insertProjectWorkbenchSkillAsNewPrivate(tpl);
          }
          this.projectSkillArchiveBranchVisible = false;
          this.projectSkillArchivePendingTpl = null;
          this.projectSkillArchiveAppendVersionLabel = '';
          this.projectSkillArchiveAppendVersionNote = '';
          this.projectSkillArchiveTargetPrivateId = '';
          message.success('入库完成');
        },
        archiveProjectTemplatesToMyLibrary(templates) {
          const selected = (templates || []).filter(Boolean);
          if (!selected.length) {
            message.warning('没有可入库的技能');
            return;
          }
          selected.forEach((tpl) => this.insertProjectWorkbenchSkillAsNewPrivate(tpl));
          this.selectedAnalysisTemplateIds = (this.selectedAnalysisTemplateIds || []).filter(
            (id) => !selected.some((t) => String(t.id) === String(id)),
          );
          this.projectSkillLibrarySelectedIds = (this.projectSkillLibrarySelectedIds || []).filter(
            (id) => !selected.some((t) => String(t.id) === String(id)),
          );
          message.success(`已将 ${selected.length} 个技能入库到「我的技能」`);
        },
        onProjectTemplateCardMenu(info, tpl) {
          const key = info && info.key;
          if (key === 'copy') {
            this.duplicateProjectTemplate(tpl);
          } else if (key === 'export') {
            this.exportProjectTemplate(tpl);
          } else if (key === 'archive') {
            this.beginArchiveProjectSkillToLibrary(tpl);
          } else if (key === 'delete') {
            this.deleteProjectAnalysisTemplate(tpl);
          }
        },
        duplicateProjectTemplate(tpl) {
          if (!tpl || !this.currentProjectId) return;
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const copy = JSON.parse(JSON.stringify(tpl));
          copy.id = 'sk-prj-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 6);
          copy.library = 'project';
          copy.name = (copy.name || '未命名技能') + '（副本）';
          copy.createdAt = now;
          copy.updatedAt = now;
          copy.createdBy = '我';
          if (typeof DemoSkillFileTree !== 'undefined' && DemoSkillFileTree.remapSkillFilesTree) {
            copy.skillFiles = DemoSkillFileTree.remapSkillFilesTree(copy.skillFiles || []);
          } else {
            copy.skillFiles = [];
          }
          if (typeof DemoSkillFileTree !== 'undefined' && DemoSkillFileTree.syncExtractionRulesFromSkillFiles) {
            DemoSkillFileTree.syncExtractionRulesFromSkillFiles(copy);
          }
          delete copy.sourceSkillId;
          delete copy.sourceLibrary;
          delete copy.sourceSkillName;
          delete copy.sourceVersionLabel;
          const list = this.projectAnalysisTemplatesById[this.currentProjectId] || [];
          this.projectAnalysisTemplatesById[this.currentProjectId] = [copy, ...list];
          message.success('已复制');
        },
        exportProjectTemplate(tpl) {
          if (!tpl) return;
          const blob = new Blob([JSON.stringify(tpl, null, 2)], { type: 'application/json' });
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = 'project-template-' + String(tpl.name || 'export').replace(/[/\\\\?%*:|"<>]/g, '_') + '.json';
          a.click();
          URL.revokeObjectURL(a.href);
          message.success('已导出');
        },
        isProjectSkillLibrarySelected(tpl) {
          if (!tpl || tpl.id == null) return false;
          return (this.projectSkillLibrarySelectedIds || []).some((x) => String(x) === String(tpl.id));
        },
        onSkillLibraryCardCheckboxChange(tpl, e) {
          const checked = !!(e && e.target && e.target.checked);
          if (!tpl || tpl.id == null) return;
          const id = tpl.id;
          let ids = [...(this.projectSkillLibrarySelectedIds || [])];
          const idx = ids.findIndex((x) => String(x) === String(id));
          if (checked && idx < 0) ids.push(id);
          if (!checked && idx >= 0) ids.splice(idx, 1);
          this.projectSkillLibrarySelectedIds = ids;
        },
        toggleSelectAllFilteredProjectTemplates() {
          const rows = this.filteredProjectDetailTemplates || [];
          if (!rows.length) {
            message.info('当前列表暂无可选项');
            return;
          }
          const rowIds = rows.map((tpl) => String(tpl.id));
          const rowSet = new Set(rowIds);
          const selected = new Set((this.projectSkillLibrarySelectedIds || []).map(String));
          const isAllSelected = rowIds.every((id) => selected.has(id));
          if (isAllSelected) {
            this.projectSkillLibrarySelectedIds = (this.projectSkillLibrarySelectedIds || []).filter((id) => !rowSet.has(String(id)));
            return;
          }
          const merged = [...(this.projectSkillLibrarySelectedIds || [])];
          rowIds.forEach((id) => {
            if (!selected.has(id)) merged.push(id);
          });
          this.projectSkillLibrarySelectedIds = merged;
        },
        batchRunSelectedProjectTemplates() {
          if (!this.currentProjectId) return;
          const pick = this.projectSkillLibrarySelectedIds || [];
          if (!pick.length) {
            message.info('选中任何数据即可');
            return;
          }
          const idSet = new Set(pick.map(String));
          const selected = (this.currentProjectAnalysisTemplates || []).filter((tpl) => idSet.has(String(tpl.id)));
          if (!selected.length) {
            message.info('选中任何数据即可');
            return;
          }
          this.selectedAnalysisTemplateIds = selected.map((tpl) => tpl.id);
          this.runProjectAnalysis(false, false, `已提交 ${selected.length} 条分析任务`);
        },
        batchDeleteSelectedProjectTemplates() {
          if (!this.currentProjectId) return;
          const pick = this.projectSkillLibrarySelectedIds || [];
          if (!pick.length) {
            message.info('选中任何数据即可');
            return;
          }
          const idSet = new Set(pick.map(String));
          Modal.confirm({
            centered: true,
            title: `确定删除已选 ${pick.length} 项技能？`,
            content: '删除后将从当前工作台移除这些技能。',
            okText: '删除',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              const list = this.projectAnalysisTemplatesById[this.currentProjectId] || [];
              this.projectAnalysisTemplatesById[this.currentProjectId] = list.filter((x) => !idSet.has(String(x.id)));
              this.selectedAnalysisTemplateIds = (this.selectedAnalysisTemplateIds || []).filter((x) => !idSet.has(String(x)));
              this.projectSkillLibrarySelectedIds = [];
              message.success('已批量删除');
            },
          });
        },
        batchExportSelectedProjectTemplates() {
          if (!this.currentProjectId) return;
          const pick = this.projectSkillLibrarySelectedIds || [];
          if (!pick.length) {
            message.info('选中任何数据即可');
            return;
          }
          const idSet = new Set(pick.map(String));
          const selected = (this.currentProjectAnalysisTemplates || []).filter((tpl) => idSet.has(String(tpl.id)));
          if (!selected.length) {
            message.info('选中任何数据即可');
            return;
          }
          const payload = selected.map((tpl) => JSON.parse(JSON.stringify(tpl)));
          const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = `project-templates-${this.currentProjectId || 'export'}-${Date.now()}.json`;
          a.click();
          URL.revokeObjectURL(a.href);
          message.success(`已导出 ${selected.length} 项技能`);
        },
        projectTemplateCardDescription(tpl) {
          if (!tpl) return '暂无简介，编辑技能时可补一句话说明适用场景与检查要点。';
          const d = String(tpl.description || '').trim();
          if (d) return d;
          const ar = String(tpl.analysisRule || '').trim();
          if (ar) return ar.length > 96 ? `${ar.slice(0, 96)}…` : ar;
          return '暂无简介，编辑技能时可补一句话说明适用场景与检查要点。';
        },
        deleteProjectAnalysisTemplate(template) {
          if (!template || !this.currentProjectId) return;
          const id = String(template.id || '');
          Modal.confirm({
            centered: true,
            title: '确定删除该技能？',
            content: '删除后将从当前工作台移除该技能。',
            okText: '删除',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              const list = this.projectAnalysisTemplatesById[this.currentProjectId] || [];
              this.projectAnalysisTemplatesById[this.currentProjectId] = list.filter((x) => String(x.id) !== id);
              this.selectedAnalysisTemplateIds = (this.selectedAnalysisTemplateIds || []).filter((x) => String(x) !== id);
              this.projectSkillLibrarySelectedIds = (this.projectSkillLibrarySelectedIds || []).filter((x) => String(x) !== id);
              if (String(this.projectSkillDetailId) === id) {
                this._projectSkillModalSnapshot = null;
                this.closeProjectSkillDetailModal(false);
              }
              message.success('技能已删除');
            },
          });
        },
        matchedMaterialCount(template) {
          const t = template || {};
          const ids = new Set();
          if (Array.isArray(t.manualMaterialIds)) t.manualMaterialIds.forEach((id) => ids.add(String(id)));
          (Array.isArray(t.extractionRules) ? t.extractionRules : []).forEach((rule) => {
            (Array.isArray(rule && rule.materialIds) ? rule.materialIds : []).forEach((id) => ids.add(String(id)));
          });
          return ids.size;
        },
        getSkillLinkedResourceIds(template) {
          const t = template || {};
          const direct = Array.isArray(t.linkedResourceIds)
            ? t.linkedResourceIds.map((id) => String(id)).filter(Boolean)
            : [];
          if (direct.length) return Array.from(new Set(direct));
          const ids = new Set();
          if (Array.isArray(t.manualMaterialIds)) t.manualMaterialIds.forEach((id) => ids.add(String(id)));
          (Array.isArray(t.extractionRules) ? t.extractionRules : []).forEach((rule) => {
            (Array.isArray(rule && rule.materialIds) ? rule.materialIds : []).forEach((id) => ids.add(String(id)));
          });
          return Array.from(ids);
        },
        getSkillLinkedResourceCount(template) {
          return this.getSkillLinkedResourceIds(template).length;
        },
        getSkillLinkedResourceLinkState(template) {
          const ids = this.getSkillLinkedResourceIds(template);
          const total = ids.length;
          if (!total) {
            return {
              text: '关联资源 0',
              ariaLabel: '查看关联资源，当前 0 条',
            };
          }
          const byId = new Map((this.linkedSkillMaterialRows || []).map((m) => [String(m.id), m]));
          let done = 0;
          let pending = 0;
          for (let i = 0; i < ids.length; i += 1) {
            const row = byId.get(String(ids[i]));
            const status = row && row.status ? String(row.status) : '';
            if (status === 'done') {
              done += 1;
            } else if (status === 'queued' || status === 'parsing') {
              pending += 1;
            } else {
              done += 1;
            }
          }
          if (pending > 0) {
            return {
              text: '匹配中 ' + done + '/' + total,
              ariaLabel: '查看关联资源，匹配中，当前完成 ' + done + ' 条，共 ' + total + ' 条',
            };
          }
          return {
            text: '关联资源 ' + total,
            ariaLabel: '查看关联资源，当前 ' + total + ' 条',
          };
        },
        getSkillLinkedResourceBylineState(template) {
          const ids = this.getSkillLinkedResourceIds(template);
          const total = ids.length;
          if (!total) {
            return {
              kind: 'idle',
              text: '未匹配',
              count: null,
              suffix: '',
              ariaLabel: '查看匹配资料，当前未匹配',
            };
          }
          const byId = new Map((this.linkedSkillMaterialRows || []).map((m) => [String(m.id), m]));
          let done = 0;
          let pending = 0;
          let failed = 0;
          for (let i = 0; i < ids.length; i += 1) {
            const row = byId.get(String(ids[i]));
            const status = row && row.status ? String(row.status) : '';
            if (status === 'done') {
              done += 1;
            } else if (status === 'queued' || status === 'parsing') {
              pending += 1;
            } else if (status === 'failed') {
              failed += 1;
            } else {
              done += 1;
            }
          }
          if (pending > 0) {
            return {
              kind: 'running',
              text: '匹配中…',
              count: null,
              suffix: '',
              ariaLabel: '查看匹配资料，匹配中，当前完成 ' + done + ' 条，共 ' + total + ' 条',
            };
          }
          if (failed > 0) {
            return {
              kind: 'failed',
              text: '未匹配到资料',
              count: null,
              suffix: '',
              ariaLabel: '查看匹配资料，未匹配到资料',
            };
          }
          return {
            kind: 'success',
            text: '已匹配到 ',
            count: total,
            suffix: ' 份资料',
            ariaLabel: '查看匹配资料，已匹配到 ' + total + ' 份资料',
          };
        },
        getSkillLinkedResources(template) {
          const ids = this.getSkillLinkedResourceIds(template);
          if (!ids.length) return [];
          const metaMap = template && template.linkedResourceMeta && typeof template.linkedResourceMeta === 'object'
            ? template.linkedResourceMeta
            : {};
          const byId = new Map((this.linkedSkillMaterialRows || []).map((m) => [String(m.id), m]));
          return ids.map((id) => {
            const row = byId.get(String(id));
            return {
              id: String(id),
              name: row && row.name ? String(row.name) : String(id),
              format: row && row.format ? String(row.format) : '—',
              updatedAt: row && row.uploadedAt ? String(row.uploadedAt) : '—',
              matchSource: String(metaMap[id] || '命中配置规则'),
            };
          });
        },
        openProjectSkillResourcePopover(template, context) {
          if (!template || !template.id) return;
          const id = String(template.id);
          if (context === 'overview') {
            this.projectSkillOverviewResourcePopoverSkillId = id;
            this.projectSkillOverviewResourcePopoverOpen = true;
            return;
          }
          this.projectSkillResourcePopoverSkillId = id;
          this.projectSkillResourcePopoverOpen = true;
        },
        closeProjectSkillResourcePopover(context) {
          if (context === 'overview') {
            this.projectSkillOverviewResourcePopoverOpen = false;
            this.projectSkillOverviewResourcePopoverSkillId = '';
            return;
          }
          this.projectSkillResourcePopoverOpen = false;
          this.projectSkillResourcePopoverSkillId = '';
        },
        openProjectSkillResourceEditor(template, context) {
          if (!template) return;
          this.closeProjectSkillResourcePopover(context);
          this.openProjectSkillDetail(template, { readOnly: false });
          this.projectSkillDetailActiveTab = 'resource';
        },
        normalizeRuleForProjectTemplate(rule) {
          const next = { ...(rule || {}) };
          const ids = Array.isArray(next.materialIds) ? next.materialIds : [];
          next.materialIds = Array.from(new Set(ids.map((x) => String(x)).filter(Boolean)));
          return next;
        },
        formatSelectedMaterialSummary(ids) {
          const selected = Array.isArray(ids) ? ids : [];
          if (!selected.length) return '（未选择资料）';
          const map = new Map((this.currentProjectMaterials || []).map((m) => [m.id, m.name || m.id]));
          const names = selected.map((id) => map.get(id)).filter(Boolean);
          if (!names.length) return `已选择 ${selected.length} 项资料`;
          return names.join('、');
        },
        ruleMatchedMaterialCount(rule) {
          const ids = Array.isArray(rule && rule.materialIds) ? rule.materialIds : [];
          return Array.from(new Set(ids.map((x) => String(x)))).length;
        },
        projectSkillModalCreator(s) {
          if (!s) return '—';
          return s.createdBy || '我';
        },
        projectSkillModalCreatedDateYmd(s) {
          if (!s || s.createdAt == null || s.createdAt === '') return '—';
          const t = String(s.createdAt).trim();
          const m = t.match(/^(\d{4}-\d{2}-\d{2})/);
          if (m) return m[1];
          return t.slice(0, 10) || '—';
        },
        projectSkillModalUpdatedCompact(s) {
          if (!s) return '—';
          const raw = s.updatedAt != null && s.updatedAt !== '' ? s.updatedAt : s.createdAt;
          if (raw == null || raw === '') return '—';
          const t = String(raw).trim();
          const m = t.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/);
          if (m) return `${m[2]}-${m[3]} ${m[4]}:${m[5]}`;
          const m2 = t.match(/^(\d{4})-(\d{2})-(\d{2})/);
          if (m2) return `${m2[2]}-${m2[3]}`;
          return t.slice(0, 16) || '—';
        },
        syncProjectSkillFormFromSkill(s) {
          if (!s) return;
          this.projectSkillForm = {
            id: s.id,
            name: s.name || '',
            description: s.description != null ? String(s.description) : '',
            tags: Array.isArray(s.tags) ? [...s.tags] : [],
          };
        },
        syncProjectSkillFormToSelected() {
          const s = this.selectedProjectSkill;
          if (!s || this.projectSkillDetailReadOnly) return;
          const name = String(this.projectSkillForm.name || '').trim();
          const desc = String(this.projectSkillForm.description || '').trim();
          const tagList = [...(this.projectSkillForm.tags || [])].map((t) => String(t).trim()).filter(Boolean);
          const tags = tagList.length ? Array.from(new Set(tagList)) : ['技能'];
          s.name = name;
          s.description = desc;
          s.tags = tags;
        },
        validateProjectSkillFilesForSave() {
          const s = this.selectedProjectSkill;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!s || !T) return false;
          const dups = T.findDuplicatePaths(s.skillFiles || []);
          if (dups.length) {
            message.warning('文件名路径重复：' + dups.join('、'));
            return false;
          }
          if (!String(s.analysisRule || '').trim()) {
            message.warning('请填写审计思路');
            return false;
          }
          let bad = false;
          const walk = (nodes) => {
            (nodes || []).forEach((n) => {
              if (!n) return;
              if (n.kind === 'folder') {
                if (!String(n.name || '').trim()) bad = true;
                walk(n.children);
              } else if (n.kind === 'file') {
                if (!String(n.filename || '').trim() || !String(n.content || '').trim()) bad = true;
              }
            });
          };
          walk(s.skillFiles || []);
          if (bad) {
            message.warning('每个文件夹须有名称；每个文件须填写文件名与具体内容');
            return false;
          }
          return true;
        },
        hydrateProjectSkillForModal(target) {
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!target || !T) return target;
          if (T.ensureSkillFiles) T.ensureSkillFiles(target);
          if (T.syncExtractionRulesFromSkillFiles) T.syncExtractionRulesFromSkillFiles(target);
          if (Array.isArray(target.extractionRules)) {
            target.extractionRules = target.extractionRules.map((x) =>
              window.DemoProjectSkillMatch ? window.DemoProjectSkillMatch.dedupeRuleMaterialIds(x) : x
            );
          }
          return target;
        },
        refreshProjectSkillModalSnapshotAfterPaneSave() {
          const s = this.selectedProjectSkill;
          if (!s || this.projectSkillDetailPoolPreview || !this.currentProjectId) return;
          const list = this.projectAnalysisTemplatesById[this.currentProjectId] || [];
          const f = list.find((x) => String(x.id) === String(s.id));
          if (f) this._projectSkillModalSnapshot = JSON.parse(JSON.stringify(f));
        },
        startProjectSkillBasicPaneEdit() {
          if (this.projectSkillDetailReadOnly) return;
          this._projectSkillBasicPaneSnap = {
            name: this.projectSkillForm.name,
            description: this.projectSkillForm.description,
            tags: Array.isArray(this.projectSkillForm.tags) ? [...this.projectSkillForm.tags] : [],
          };
          this.projectSkillBasicPaneEditing = true;
        },
        cancelProjectSkillBasicPaneEdit() {
          const snap = this._projectSkillBasicPaneSnap;
          if (snap) {
            this.projectSkillForm.name = snap.name;
            this.projectSkillForm.description = snap.description;
            this.projectSkillForm.tags = snap.tags ? [...snap.tags] : [];
          }
          this._projectSkillBasicPaneSnap = null;
          this.projectSkillBasicPaneEditing = false;
        },
        saveProjectSkillBasicPane() {
          if (this.projectSkillDetailReadOnly) return;
          const name = String(this.projectSkillForm.name || '').trim();
          if (!name) {
            message.warning('请填写名称');
            return;
          }
          if (this._projectSkillDetailSyncTimer) {
            window.clearTimeout(this._projectSkillDetailSyncTimer);
            this._projectSkillDetailSyncTimer = null;
          }
          this.syncProjectSkillFormToSelected();
          this.syncProjectSkillDetailNow();
          this._projectSkillCreateCommitted = true;
          this.refreshProjectSkillModalSnapshotAfterPaneSave();
          this.projectSkillBasicPaneEditing = false;
          this._projectSkillBasicPaneSnap = null;
          if (this.projectSkillDetailModalIsCreate) this.projectSkillDetailModalIsCreate = false;
          message.success('基本信息已保存');
        },
        startProjectSkillConfigPaneEdit() {
          if (this.projectSkillDetailReadOnly) return;
          const s = this.selectedProjectSkill;
          if (!s) return;
          this._projectSkillConfigPaneSnap = JSON.parse(JSON.stringify(s));
          this.projectSkillConfigPaneEditing = true;
        },
        cancelProjectSkillConfigPaneEdit() {
          const snap = this._projectSkillConfigPaneSnap;
          if (snap && this.projectSkillDetailPoolPreview && String(snap.id) === String(this.projectSkillDetailPoolPreview.id)) {
            this.projectSkillDetailPoolPreview = JSON.parse(JSON.stringify(snap));
          } else if (snap && this.currentProjectId) {
            const list = this.projectAnalysisTemplatesById[this.currentProjectId] || [];
            const idx = list.findIndex((x) => String(x.id) === String(snap.id));
            if (idx >= 0) {
              list.splice(idx, 1, JSON.parse(JSON.stringify(snap)));
              this.projectAnalysisTemplatesById[this.currentProjectId] = [...list];
            }
          }
          this._projectSkillConfigPaneSnap = null;
          this.projectSkillConfigPaneEditing = false;
          this.$nextTick(() => this.ensureProjectSkillFirstObjectExpanded());
        },
        saveProjectSkillConfigPane() {
          if (this.projectSkillDetailReadOnly) return;
          if (!this.validateProjectSkillFilesForSave()) return;
          if (this._projectSkillDetailSyncTimer) {
            window.clearTimeout(this._projectSkillDetailSyncTimer);
            this._projectSkillDetailSyncTimer = null;
          }
          this.syncProjectSkillFormToSelected();
          this.syncProjectSkillDetailNow();
          this._projectSkillCreateCommitted = true;
          this.refreshProjectSkillModalSnapshotAfterPaneSave();
          this.projectSkillConfigPaneEditing = false;
          this._projectSkillConfigPaneSnap = null;
          if (this.projectSkillDetailModalIsCreate) this.projectSkillDetailModalIsCreate = false;
          message.success('技能配置已保存');
        },
        startProjectSkillResourcePaneEdit() {
          if (this.projectSkillDetailReadOnly) return;
          const s = this.selectedProjectSkill;
          if (!s) return;
          this._projectSkillResourcePaneSnap = this.getSkillLinkedResourceIds(s);
          this.projectSkillResourcePaneEditing = true;
        },
        cancelProjectSkillResourcePaneEdit() {
          const s = this.selectedProjectSkill;
          const snap = this._projectSkillResourcePaneSnap;
          if (s && Array.isArray(snap)) s.linkedResourceIds = snap.slice();
          this._projectSkillResourcePaneSnap = null;
          this.projectSkillResourcePaneEditing = false;
        },
        saveProjectSkillResourcePane() {
          if (this.projectSkillDetailReadOnly) return;
          const s = this.selectedProjectSkill;
          if (!s) return;
          if (this._projectSkillDetailSyncTimer) {
            window.clearTimeout(this._projectSkillDetailSyncTimer);
            this._projectSkillDetailSyncTimer = null;
          }
          s.linkedResourceIds = this.getSkillLinkedResourceIds(s);
          this.syncProjectSkillDetailNow();
          this._projectSkillCreateCommitted = true;
          this.refreshProjectSkillModalSnapshotAfterPaneSave();
          this.projectSkillResourcePaneEditing = false;
          this._projectSkillResourcePaneSnap = null;
          if (this.projectSkillDetailModalIsCreate) this.projectSkillDetailModalIsCreate = false;
          message.success('关联资源已保存');
        },
        onProjectSkillTabUpdate(key) {
          const next = String(key || 'basic');
          if (next === String(this.projectSkillDetailActiveTab)) return;
          const leaving = String(this.projectSkillDetailActiveTab);
          if (
            (leaving === 'basic' && this.projectSkillBasicPaneEditing)
            || (leaving === 'config' && this.projectSkillConfigPaneEditing)
            || (leaving === 'resource' && this.projectSkillResourcePaneEditing)
          ) {
            Modal.confirm({
              centered: true,
              title: '有未保存的编辑',
              content: '切换页签将放弃当前页签的未保存修改，是否继续？',
              okText: '放弃并切换',
              cancelText: '留在本页',
              onOk: () => {
                if (leaving === 'basic') this.cancelProjectSkillBasicPaneEdit();
                if (leaving === 'config') this.cancelProjectSkillConfigPaneEdit();
                if (leaving === 'resource') this.cancelProjectSkillResourcePaneEdit();
                this.projectSkillDetailActiveTab = next;
              },
            });
            return;
          }
          this.projectSkillDetailActiveTab = next;
        },
        openProjectSkillDetail(template, options) {
          if (!template || !template.id) return;
          const readOnly = !!(options && options.readOnly);
          const fromPool = !!(options && options.fromPool);
          this.projectSkillBasicPaneEditing = false;
          this.projectSkillConfigPaneEditing = false;
          this.projectSkillResourcePaneEditing = false;
          this._projectSkillBasicPaneSnap = null;
          this._projectSkillConfigPaneSnap = null;
          this._projectSkillResourcePaneSnap = null;
          this._projectSkillCreateCommitted = false;
          if (fromPool) {
            this.projectSkillDetailPoolPreview = null;
            this.projectSkillDetailReadOnly = readOnly;
            this.projectSkillDetailModalIsCreate = false;
            const target = this.hydrateProjectSkillForModal(JSON.parse(JSON.stringify(template)));
            this.projectSkillDetailPoolPreview = target;
            this._projectSkillModalSnapshot = null;
            this.projectSkillDetailId = target.id;
            this.projectSkillDetailActiveTab = readOnly ? 'config' : 'basic';
            this.syncProjectSkillFormFromSkill(target);
            this.projectSkillConfigNavKey = 'rule';
            this.projectSkillDetailModalOpen = true;
            this.$nextTick(() => this.ensureProjectSkillFirstObjectExpanded());
            return;
          }
          if (!this.currentProjectId) return;
          this.projectSkillDetailPoolPreview = null;
          this.projectSkillDetailReadOnly = readOnly;
          this.projectSkillDetailModalIsCreate = false;
          const list = this.projectAnalysisTemplatesById[this.currentProjectId] || [];
          const idx = list.findIndex((x) => x.id === template.id);
          if (idx < 0) return;
          const target = list[idx];
          this.hydrateProjectSkillForModal(target);
          this.projectAnalysisTemplatesById[this.currentProjectId] = [...list];
          const fresh = (this.projectAnalysisTemplatesById[this.currentProjectId] || []).find((x) => x.id === target.id) || target;
          if (!readOnly) {
            this._projectSkillModalSnapshot = JSON.parse(JSON.stringify(fresh));
          } else {
            this._projectSkillModalSnapshot = null;
          }
          this.projectSkillDetailId = fresh.id;
          this.projectSkillDetailActiveTab = readOnly ? 'config' : 'basic';
          this.syncProjectSkillFormFromSkill(fresh);
          this.projectSkillConfigNavKey = 'rule';
          this.projectSkillDetailModalOpen = true;
          this.$nextTick(() => this.ensureProjectSkillFirstObjectExpanded());
        },
        openProjectSkillCreateUnified() {
          this.openProjectSkillCreateBasicModal();
        },
        ensureProjectSkillFirstObjectExpanded() {
          const s = this.selectedProjectSkill;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (s && T && T.ensureSkillFiles) T.ensureSkillFiles(s);
          this.projectSkillConfigNavKey = 'rule';
          this.projectSkillConfigTreeExpandedKeys = s && T && T.defaultExpandedKeys ? T.defaultExpandedKeys(s.skillFiles || []) : [];
        },
        closeProjectSkillDetailModal(fromSave) {
          const saved = fromSave === true;
          const createCommitted = this._projectSkillCreateCommitted;
          if (this._projectSkillDetailSyncTimer) {
            window.clearTimeout(this._projectSkillDetailSyncTimer);
            this._projectSkillDetailSyncTimer = null;
          }
          const templateId = this.projectSkillDetailId;
          const pid = this.currentProjectId;
          const wasCreate = this.projectSkillDetailModalIsCreate;
          const wasReadOnly = this.projectSkillDetailReadOnly;
          if (!saved && pid) {
            if (wasCreate && templateId && !createCommitted) {
              const list = this.projectAnalysisTemplatesById[pid] || [];
              this.projectAnalysisTemplatesById[pid] = list.filter((x) => String(x.id) !== String(templateId));
            } else if (!wasReadOnly && this._projectSkillModalSnapshot && templateId) {
              const list = this.projectAnalysisTemplatesById[pid] || [];
              const idx = list.findIndex((x) => String(x.id) === String(templateId));
              if (idx >= 0) {
                list.splice(idx, 1, JSON.parse(JSON.stringify(this._projectSkillModalSnapshot)));
                this.projectAnalysisTemplatesById[pid] = [...list];
              }
            }
          }
          this._projectSkillModalSnapshot = null;
          this.projectSkillDetailModalIsCreate = false;
          this.projectSkillDetailModalOpen = false;
          this.projectSkillDetailReadOnly = false;
          this.projectSkillDetailId = '';
          this.projectSkillConfigNavKey = 'rule';
          this.projectSkillConfigTreeExpandedKeys = [];
          this.projectSkillDetailActiveTab = 'basic';
          this.projectSkillDetailPoolPreview = null;
          this.projectSkillBasicPaneEditing = false;
          this.projectSkillConfigPaneEditing = false;
          this.projectSkillResourcePaneEditing = false;
          this._projectSkillBasicPaneSnap = null;
          this._projectSkillConfigPaneSnap = null;
          this._projectSkillResourcePaneSnap = null;
          this._projectSkillCreateCommitted = false;
        },
        scheduleProjectSkillDetailSync() {
          if (this._projectSkillDetailSyncTimer) window.clearTimeout(this._projectSkillDetailSyncTimer);
          this._projectSkillDetailSyncTimer = window.setTimeout(() => this.syncProjectSkillDetailNow(), 250);
        },
        syncProjectSkillDetailNow() {
          const s = this.selectedProjectSkill;
          if (!s) return;
          if (this.projectSkillDetailPoolPreview && String(this.projectSkillDetailPoolPreview.id) === String(s.id)) return;
          if (!this.currentProjectId) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (T && T.ensureSkillFiles) T.ensureSkillFiles(s);
          if (T && T.syncExtractionRulesFromSkillFiles) T.syncExtractionRulesFromSkillFiles(s);
          if (Array.isArray(s.extractionRules)) {
            s.extractionRules = s.extractionRules.map((x) => ({
              id: x.id || newSkillId('er'),
              title: String(x.title || ''),
              body: String(x.body || ''),
              materialIds: Array.isArray(x.materialIds) ? Array.from(new Set(x.materialIds.map((id) => String(id)))) : [],
            }));
          }
          s.analysisRule = String(s.analysisRule || '');
          s.linkedResourceIds = this.getSkillLinkedResourceIds(s);
          if (!s.linkedResourceMeta || typeof s.linkedResourceMeta !== 'object') s.linkedResourceMeta = {};
          s.applicableScenario = String(s.applicableScenario || '');
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          s.updatedAt = now;
          if (!s.createdAt) {
            s.createdAt = now;
            if (!s.createdBy) s.createdBy = '我';
          }
          const list = this.projectAnalysisTemplatesById[this.currentProjectId] || [];
          const idx = list.findIndex((x) => x.id === s.id);
          if (idx >= 0) {
            list.splice(idx, 1, { ...s });
            this.projectAnalysisTemplatesById[this.currentProjectId] = [...list];
          }
        },
        onProjectSkillConfigSaveMenuClick(info) {
          const k = info && info.key;
          if (k !== 'publish-new') return;
          message.info('保存为新版本仅在「我的技能」资产库中支持，请在工作台将技能入库后再于技能库发布版本。');
        },
        onProjectSkillConfigAddMenuClick(info) {
          if (this.projectSkillConfigTabLocked || !this.selectedProjectSkill) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T) return;
          const root = T.ensureSkillFiles(this.selectedProjectSkill);
          const key = info && info.key;
          let node;
          if (key === 'md') node = T.newFileNode('md', '');
          else if (key === 'folder') node = T.newFolderNode();
          else if (String(key || '').startsWith('code:')) node = T.newFileNode('code', String(key).slice(5));
          else return;
          const parentRef = T.findAddParentRef(root, this.projectSkillConfigNavKey);
          T.insertChild(root, parentRef, node);
          if (node.kind === 'file') {
            this.projectSkillConfigNavKey = 'file:' + node.id;
          } else {
            this.projectSkillConfigNavKey = 'folder:' + node.id;
            const ek = new Set(this.projectSkillConfigTreeExpandedKeys || []);
            ek.add('folder:' + node.id);
            this.projectSkillConfigTreeExpandedKeys = Array.from(ek);
          }
          this.scheduleProjectSkillDetailSync();
        },
        projectSkillConfigTreeCanDeleteKey(treeKey) {
          if (!treeKey || treeKey === 'rule') return false;
          return String(treeKey).startsWith('file:') || String(treeKey).startsWith('folder:');
        },
        removeProjectSkillConfigTreeNode(treeKey) {
          if (this.projectSkillConfigTabLocked || !this.selectedProjectSkill) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || !treeKey || treeKey === 'rule') return;
          const id = String(treeKey).startsWith('file:')
            ? String(treeKey).slice('file:'.length)
            : String(treeKey).startsWith('folder:')
              ? String(treeKey).slice('folder:'.length)
              : '';
          if (!id) return;
          const root = T.ensureSkillFiles(this.selectedProjectSkill);
          const wasNav = String(this.projectSkillConfigNavKey) === String(treeKey);
          T.removeNodeById(root, id);
          if (wasNav) this.projectSkillConfigNavKey = 'rule';
          this.scheduleProjectSkillDetailSync();
        },
        onProjectSkillConfigTreeSelect(selectedKeys) {
          if (!selectedKeys || !selectedKeys.length) return;
          const key = selectedKeys[0];
          this.projectSkillConfigNavKey = key === 'rule' ? 'rule' : String(key);
        },
        projectSkillConfigTreeNodeDraggable(node) {
          if (this.projectSkillConfigTabLocked) return false;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          return !!(T && T.treeNodeIsDraggable && T.treeNodeIsDraggable(node));
        },
        onProjectSkillConfigTreeDrop(info) {
          if (this.projectSkillConfigTabLocked || !this.selectedProjectSkill) return;
          const T = typeof window !== 'undefined' ? window.DemoSkillFileTree : null;
          if (!T || !T.applyTreeDropFromAntEvent) return;
          const res = T.applyTreeDropFromAntEvent(this.selectedProjectSkill, info);
          if (!res.ok) {
            message.warning(res.message || '无法放置到此处');
            return;
          }
          this.scheduleProjectSkillDetailSync();
        },
        validateProjectSkillConfigForSubmit(s) {
          return window.DemoProjectSkillMatch ? window.DemoProjectSkillMatch.validateProjectSkillConfigForMatch(s, message) : false;
        },
        saveProjectSkillConfig() {
          if (!this.currentProjectId || !this.selectedProjectSkill || !window.DemoProjectSkillMatch) return;
          this.syncProjectSkillDetailNow();
          const list = this.projectAnalysisTemplatesById[this.currentProjectId] || [];
          const fresh = list.find((x) => x.id === this.selectedProjectSkill.id);
          if (!fresh || !this.validateProjectSkillConfigForSubmit(fresh)) return;
          const idx = list.findIndex((x) => x.id === fresh.id);
          if (idx < 0) return;
          const row = { ...list[idx] };
          row.extractionRules = (row.extractionRules || [])
            .map((x) => ({
              id: x.id || newSkillId('er'),
              title: String(x.title || '').trim(),
              body: String(x.body || '').trim(),
              materialIds: Array.isArray(x.materialIds) ? Array.from(new Set(x.materialIds.map((id) => String(id)))) : [],
            }))
            .filter((x) => String(x.title || '').trim() && String(x.body || '').trim());
          row.analysisRule = String(row.analysisRule || '').trim();
          row.applicableScenario = String(row.applicableScenario || '').trim();
          const normRules = row.extractionRules.map((r) => this.normalizeRuleForProjectTemplate(r));
          row.extractionRules = normRules;
          row.manualMaterialIds = Array.from(
            new Set(normRules.flatMap((r) => (Array.isArray(r.materialIds) ? r.materialIds : []).map((x) => String(x)))),
          );
          list.splice(idx, 1, row);
          this.projectAnalysisTemplatesById[this.currentProjectId] = [...list];
          this.closeProjectSkillDetailModal(true);
          message.success('配置已保存');
        },
        onProjectTemplateAddMenu(info) {
          const key = info && info.key;
          if (key === 'new') this.openProjectSkillCreateUnified();
          else if (key === 'library') this.openAnalysisTemplateModal();
        },
        analysisResultStatusLabel(status) {
          const map = { queued: '排队中', parsing: '分析中', done: '完成', failed: '失败' };
          return map[status] || map.done;
        },
        analysisStatusChipClass(status) {
          const s = (status && String(status)) || 'done';
          const map = { queued: 'is-neutral', parsing: 'is-primary', done: 'is-success', failed: 'is-error' };
          return map[s] || map.done;
        },
        toOverviewMetaValue(v, fallback = '—') {
          const s = String(v == null ? '' : v).trim();
          return s || fallback;
        },
        /** 资料预览 · 第二行：大小 · 格式 */
        materialPreviewSizeFormatLine(record) {
          const r = record || {};
          const sizePart =
            r.size == null || r.size === ''
              ? '—'
              : `${Number(r.size).toFixed(1)} MB`;
          const fmt = String(r.format || '').trim() || '—';
          return `大小 ${sizePart} · 格式 ${fmt}`;
        },
        /** 资料预览 · 基本信息区右下角：「张三 于 xxxx 上传」 */
        materialPreviewBasicMetaLine(record) {
          const r = record || {};
          const who = String(r.uploader || r.uploadedBy || '').trim() || '—';
          const when = this.toOverviewMetaValue(r.uploadedAt, '—');
          return `${who} 于 ${when} 上传`;
        },
        /** 分析结果预览 · 基本信息区右下角：「xxxx 生成」 */
        analysisResultPreviewBasicMetaLine(record) {
          const r = record || {};
          const when = this.toOverviewMetaValue(r.createdAt, '—');
          return `${when} 生成`;
        },
        overviewMetaTagText(tags) {
          const list = Array.isArray(tags) ? tags.map((t) => String(t || '').trim()).filter(Boolean) : [];
          return list.length ? list.join('、') : '—';
        },
        formatOverviewMaterialSize(record) {
          const r = record || {};
          if (r.size == null || r.size === '') return '—';
          const n = Number(r.size);
          if (Number.isNaN(n)) return this.toOverviewMetaValue(String(r.size));
          return `${n} MB`;
        },
        runSingleTemplateAnalysis(tpl, successMessage) {
          if (!tpl || !this.currentProjectId) return;
          const prev = [...(this.selectedAnalysisTemplateIds || [])];
          this.selectedAnalysisTemplateIds = [tpl.id];
          this.runProjectAnalysis(false, false, successMessage);
          this.selectedAnalysisTemplateIds = prev;
        },
        /** 技能页卡片「执行」：单技能提交，仅成功提示、不切换页签 */
        runProjectTemplateCardAnalyze(tpl) {
          if (!tpl || !tpl.id) return;
          this.projectSkillRunConfirmTemplateId = String(tpl.id);
          this.projectSkillRunConfirmLinkedResourceIds = this.getSkillLinkedResourceIds(tpl);
          this.projectSkillRunConfirmOpen = true;
        },
        closeProjectSkillRunConfirm() {
          this.projectSkillRunConfirmOpen = false;
          this.projectSkillRunConfirmTemplateId = '';
          this.projectSkillRunConfirmLinkedResourceIds = [];
        },
        confirmProjectSkillRunAnalyze() {
          const tpl = this.projectSkillRunConfirmTemplate;
          if (!tpl) {
            this.closeProjectSkillRunConfirm();
            return;
          }
          const nextIds = Array.from(new Set((this.projectSkillRunConfirmLinkedResourceIds || []).map((id) => String(id)).filter(Boolean)));
          tpl.linkedResourceIds = nextIds;
          const oldMeta = tpl && tpl.linkedResourceMeta && typeof tpl.linkedResourceMeta === 'object' ? tpl.linkedResourceMeta : {};
          const nextMeta = {};
          nextIds.forEach((id) => {
            nextMeta[id] = oldMeta[id] ? String(oldMeta[id]) : '手动确认匹配';
          });
          tpl.linkedResourceMeta = nextMeta;
          this.closeProjectSkillRunConfirm();
          this.runSingleTemplateAnalysis(tpl, '分析任务已提交');
        },
        templateMatchedDocumentsListText(tpl) {
          const t = tpl || {};
          const ids = new Set();
          if (Array.isArray(t.manualMaterialIds)) t.manualMaterialIds.forEach((id) => ids.add(String(id)));
          (Array.isArray(t.extractionRules) ? t.extractionRules : []).forEach((rule) => {
            (Array.isArray(rule.materialIds) ? rule.materialIds : []).forEach((id) => ids.add(String(id)));
          });
          const rows = this.currentProjectMaterials || [];
          const byId = new Map(rows.map((m) => [String(m.id), m]));
          const names = [...ids].map((id) => {
            const row = byId.get(id);
            return row && row.name ? String(row.name) : '';
          }).filter(Boolean);
          return names.length ? names.join('、') : '—';
        },
        buildOverviewMaterialMeta(record) {
          const r = record || {};
          return [
            { label: '名称', value: this.toOverviewMetaValue(r.name) },
            { label: '标签', value: this.overviewMetaTagText(r.tags) },
            { label: '大小', value: this.formatOverviewMaterialSize(r) },
            { label: '格式', value: this.toOverviewMetaValue(r.format) },
            { label: '状态', value: this.materialStatusLabel(r.status) },
            { label: '上传人', value: this.toOverviewMetaValue(r.uploader || r.uploadedBy) },
            { label: '上传时间', value: this.toOverviewMetaValue(r.uploadedAt) },
          ];
        },
        buildOverviewTemplateMeta(tpl) {
          const t = tpl || {};
          return [
            { label: '名称', value: this.toOverviewMetaValue(t.name) },
            { label: '标签', value: this.overviewMetaTagText(t.tags) },
            { label: '关联资料', value: this.templateMatchedDocumentsListText(tpl) },
          ];
        },
        buildOverviewResultMeta(record) {
          const r = record || {};
          return [
            { label: '名称', value: this.toOverviewMetaValue(r.name) },
            { label: '标签', value: this.overviewMetaTagText(r.tags) },
            { label: '来源技能', value: this.toOverviewMetaValue(r.sourceSkillName) },
            { label: '状态', value: this.analysisResultStatusLabel(r.status) },
            { label: '生成时间', value: this.toOverviewMetaValue(r.createdAt) },
          ];
        },
        onOverviewAnalysisResultCardClick(r) {
          if (!r) return;
          if (r.status !== 'done') {
            message.warning('仅分析完成的条目支持预览');
            return;
          }
          this.viewAnalysisResult(r);
        },
        viewAnalysisResult(record) {
          if (!record) return;
          if (record.status !== 'done') {
            message.warning('仅分析完成的条目支持预览');
            return;
          }
          this.clearAnalysisCitationFloats();
          this.analysisResultPreviewEditing = false;
          this.analysisResultPreviewDraft = '';
          this.analysisResultPreviewRecord = { ...record };
          this.analysisResultPreviewActiveTab = 'body';
          this.analysisResultPreviewVisible = true;
        },
        closeAnalysisResultPreview() {
          this.analysisResultPreviewVisible = false;
          this.analysisResultPreviewRecord = null;
          this.analysisResultPreviewActiveTab = 'basic';
          this.analysisResultPreviewEditing = false;
          this.analysisResultPreviewDraft = '';
          this.analysisResultVersionDetailVisible = false;
          this.analysisResultVersionDetailMarkdown = '';
          this.clearAnalysisCitationFloats();
        },
        onAnalysisResultPreviewTabUpdate(key) {
          const next = String(key || 'basic');
          if (next === String(this.analysisResultPreviewActiveTab)) return;
          if (String(this.analysisResultPreviewActiveTab) === 'body' && this.analysisResultPreviewEditing && next !== 'body') {
            Modal.confirm({
              centered: true,
              title: '有未保存的编辑',
              content: '切换页签将放弃对正文的未保存修改，是否继续？',
              okText: '放弃并切换',
              cancelText: '留在本页',
              onOk: () => {
                this.cancelAnalysisResultPreviewEdit();
                this.analysisResultPreviewActiveTab = next;
              },
            });
            return;
          }
          this.analysisResultPreviewActiveTab = next;
        },
        downloadMaterialPreview() {
          const rec = this.materialPreviewRecord;
          if (!rec) return;
          const pages = this.materialPreviewPages || [];
          const body = pages.join('\n\n---\n\n');
          const base = String(rec.name || '资料').replace(/\.[^.]+$/, '');
          const safe = base.replace(/[/\\?%*:|"<>]/g, '_');
          const blob = new Blob([body], { type: 'text/plain;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${safe}-预览.txt`;
          a.click();
          URL.revokeObjectURL(url);
          message.success('已开始下载');
        },
        startAnalysisResultPreviewEdit() {
          if (!this.analysisResultPreviewRecord) return;
          this.analysisResultPreviewActiveTab = 'body';
          this.analysisResultPreviewDraft = this.analysisResultPreviewMarkdown || '';
          this.analysisResultPreviewEditing = true;
        },
        analysisResultMaterialNameById(materialId) {
          const pid = this.currentProjectId;
          if (!pid || materialId == null || materialId === '') return '';
          const rows = this.projectMaterialsById[pid] || [];
          const id = String(materialId);
          const r = rows.find((x) => x && String(x.id) === id);
          return r && r.name ? String(r.name).trim() : id;
        },
        openAnalysisResultVersionDetail(record) {
          if (!record) return;
          this.analysisResultVersionDetailMarkdown = String(record.markdown || '');
          this.analysisResultVersionDetailVisible = true;
        },
        closeAnalysisResultVersionDetail() {
          this.analysisResultVersionDetailVisible = false;
          this.analysisResultVersionDetailMarkdown = '';
        },
        /**
         * @param {string} resultId
         * @param {object|string} payloadOrLabel - 新版本传入 `{ markdown, savedAt?, generationDesc?, label? }`；兼容旧签名为版本标签字符串
         * @param {string} [markdownLegacy]
         */
        pushAnalysisResultVersionEntry(resultId, payloadOrLabel, markdownLegacy) {
          if (!resultId) return;
          let markdown;
          let savedAt;
          let generationDesc;
          let label;
          if (payloadOrLabel && typeof payloadOrLabel === 'object' && !Array.isArray(payloadOrLabel) && ('markdown' in payloadOrLabel)) {
            markdown = payloadOrLabel.markdown;
            savedAt = payloadOrLabel.savedAt;
            generationDesc = payloadOrLabel.generationDesc;
            label = payloadOrLabel.label;
          } else {
            markdown = markdownLegacy;
            label = payloadOrLabel;
          }
          if (markdown == null) return;
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const at = savedAt != null && String(savedAt).trim() ? String(savedAt).trim() : now;
          const key = `v-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
          const prev = (this.analysisResultVersionHistoryById || {})[resultId] || [];
          const gd = String(generationDesc || '').trim();
          const lb = String(label || '').trim();
          const entry = {
            key,
            markdown: String(markdown),
            savedAt: at,
            ...(lb ? { label: lb } : {}),
            ...(gd ? { generationDesc: gd } : {}),
          };
          const next = [entry, ...prev].slice(0, 30);
          this.analysisResultVersionHistoryById = { ...(this.analysisResultVersionHistoryById || {}), [resultId]: next };
        },
        /** 切换「版本管理」Tab 时的占位钩子（当前版本由列表上方单独展示，不再自动注入基线快照） */
        ensureAnalysisResultVersionHistoryForRecord() {},
        applyAnalysisResultMarkdownRollbackById(resultId, md) {
          const pid = this.currentProjectId;
          const id = String(resultId || '');
          if (!id || !pid) return;
          const text = String(md ?? '');
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          const patch = {
            analysisMarkdown: text,
            analysisMarkdownEditedBy: '我',
            analysisMarkdownEditedAt: now,
          };
          const list = this.projectAnalysisResultsById[pid];
          if (Array.isArray(list)) {
            const idx = list.findIndex((r) => r && String(r.id) === id);
            if (idx >= 0) list.splice(idx, 1, { ...list[idx], ...patch });
          }
          if (this.analysisResultPreviewRecord && String(this.analysisResultPreviewRecord.id) === id) {
            this.analysisResultPreviewRecord = { ...this.analysisResultPreviewRecord, ...patch };
          }
          this.analysisResultPreviewEditing = false;
          this.analysisResultPreviewDraft = '';
          message.success('已回退到所选版本');
        },
        cancelAnalysisResultPreviewEdit() {
          this.analysisResultPreviewEditing = false;
          this.analysisResultPreviewDraft = '';
        },
        saveAnalysisResultPreviewEdit() {
          const rec = this.analysisResultPreviewRecord;
          const pid = this.currentProjectId;
          if (!rec || !rec.id || !pid) return;
          const oldMd = String(this.analysisResultPreviewMarkdown || '');
          const md = String(this.analysisResultPreviewDraft ?? '');
          const now = new Date().toISOString().slice(0, 19).replace('T', ' ');
          if (oldMd !== md) {
            const baseDesc =
              typeof buildAnalysisResultGenerationDesc === 'function'
                ? buildAnalysisResultGenerationDesc(rec, (id) => this.analysisResultMaterialNameById(id))
                : '';
            this.pushAnalysisResultVersionEntry(rec.id, {
              markdown: oldMd,
              savedAt: now,
              generationDesc: baseDesc ? `编辑保存前的快照 · ${baseDesc}` : '编辑保存前的快照',
              label: `${now} · 保存前`,
            });
          }
          const patch = {
            analysisMarkdown: md,
            analysisMarkdownEditedBy: '我',
            analysisMarkdownEditedAt: now,
          };
          const list = this.projectAnalysisResultsById[pid];
          if (Array.isArray(list)) {
            const idx = list.findIndex((r) => r && r.id === rec.id);
            if (idx >= 0) {
              list.splice(idx, 1, { ...list[idx], ...patch });
            }
          }
          this.analysisResultPreviewRecord = { ...rec, ...patch };
          this.analysisResultPreviewEditing = false;
          this.analysisResultPreviewDraft = '';
          message.success('内容已保存');
        },
        copyAnalysisResultPreview() {
          if (!this.analysisResultPreviewRecord) return;
          const text = this.analysisResultPreviewEditing
            ? String(this.analysisResultPreviewDraft ?? '')
            : this.analysisResultPreviewMarkdown || '';
          const ok = () => message.success('已复制到剪贴板');
          const fail = () => message.warning('复制失败');
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(ok).catch(fail);
          } else {
            try {
              const ta = document.createElement('textarea');
              ta.value = text;
              ta.style.cssText = 'position:fixed;left:-9999px;top:0';
              document.body.appendChild(ta);
              ta.select();
              document.execCommand('copy');
              document.body.removeChild(ta);
              ok();
            } catch (_) {
              fail();
            }
          }
        },
        downloadAnalysisResultPreview() {
          if (!this.analysisResultPreviewRecord) return;
          const text = this.analysisResultPreviewEditing
            ? String(this.analysisResultPreviewDraft ?? '')
            : this.analysisResultPreviewMarkdown || '';
          const name = String((this.analysisResultPreviewRecord && this.analysisResultPreviewRecord.name) || '结果');
          const safe = name.replace(/[/\\?%*:|"<>]/g, '_');
          const blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${safe}.md`;
          a.click();
          URL.revokeObjectURL(url);
          message.success('已开始下载');
        },
        onAnalysisPreviewCitationHover(event) {
          const el = event && event.target ? event.target.closest('.analysis-inline-citation') : null;
          if (!el) return;
          const key = String(el.getAttribute('data-cite') || '').trim();
          if (!key) return;
          this.showAnalysisCitationPopoverByKey(key, el.getBoundingClientRect());
        },
        showAnalysisCitationPopoverByKey(key, rect) {
          const map = this.analysisResultCitationMap || {};
          const data = map[key];
          if (!data) return;
          if (this.analysisCitationPopoverTimer) {
            window.clearTimeout(this.analysisCitationPopoverTimer);
            this.analysisCitationPopoverTimer = null;
          }
          let x = rect.left;
          let y = rect.bottom + 4;
          const maxW = 320;
          const maxH = 220;
          if (x + maxW > window.innerWidth) x = window.innerWidth - maxW - 8;
          if (x < 8) x = 8;
          if (y + maxH > window.innerHeight) y = rect.top - maxH - 4;
          if (y < 8) y = 8;
          const title = `${key} · ${data.sourceLabel || '溯源信息'}`;
          const excerpt = String(data.sourceExcerpt || data.sourceFullText || '').trim() || '暂无溯源内容';
          this.analysisCitationPopover = { show: true, title, excerpt, x, y };
        },
        onAnalysisPreviewCitationLeave() {
          this.analysisCitationPopoverTimer = window.setTimeout(() => {
            this.analysisCitationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
            this.analysisCitationPopoverTimer = null;
          }, 120);
        },
        onAnalysisCitationPopoverEnter() {
          if (this.analysisCitationPopoverTimer) {
            window.clearTimeout(this.analysisCitationPopoverTimer);
            this.analysisCitationPopoverTimer = null;
          }
        },
        onAnalysisCitationPopoverLeave() {
          this.onAnalysisPreviewCitationLeave();
        },
        clearAnalysisCitationFloats() {
          this.analysisCitationPopover = { show: false, title: '', excerpt: '', x: 0, y: 0 };
          if (this.analysisCitationPopoverTimer) {
            window.clearTimeout(this.analysisCitationPopoverTimer);
            this.analysisCitationPopoverTimer = null;
          }
        },
        deleteAnalysisResult(record) {
          if (!this.currentProjectId || !record || !record.id) return;
          Modal.confirm({
            centered: true,
            title: '确定删除该结果？',
            content: '删除后不可恢复。',
            okText: '删除',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              const rows = this.projectAnalysisResultsById[this.currentProjectId] || [];
              this.projectAnalysisResultsById[this.currentProjectId] = rows.filter((x) => x.id !== record.id);
              this.selectedAnalysisResultIds = (this.selectedAnalysisResultIds || []).filter((id) => id !== record.id);
              message.success('已删除');
            },
          });
        },
        batchDeleteAnalysisResults() {
          if (!this.currentProjectId) return;
          const ids = this.selectedAnalysisResultIds || [];
          if (!ids.length) {
            message.info('选中任何数据即可');
            return;
          }
          Modal.confirm({
            centered: true,
            title: `确定删除已选 ${ids.length} 项结果？`,
            content: '删除后不可恢复。',
            okText: '删除',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              const rows = this.projectAnalysisResultsById[this.currentProjectId] || [];
              this.projectAnalysisResultsById[this.currentProjectId] = rows.filter((x) => !ids.includes(x.id));
              this.selectedAnalysisResultIds = [];
              message.success('已批量删除');
            },
          });
        },
        clearAllAnalysisResults() {
          if (!this.currentProjectId) return;
          const total = (this.projectAnalysisResultsById[this.currentProjectId] || []).length;
          if (!total) return;
          Modal.confirm({
            centered: true,
            title: '确定清空全部结果？',
            content: `将清空共 ${total} 条结果。`,
            okText: '清空',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              this.projectAnalysisResultsById[this.currentProjectId] = [];
              this.selectedAnalysisResultIds = [];
              message.success('已清空');
            },
          });
        },
        playAnalysisFlowWave() {
          if (this._analysisFlowWaveTimer) window.clearTimeout(this._analysisFlowWaveTimer);
          this.analysisFlowWaveActive = false;
          this.$nextTick(() => {
            requestAnimationFrame(() => {
              this.analysisFlowWaveActive = true;
              this._analysisFlowWaveTimer = window.setTimeout(() => {
                this.analysisFlowWaveActive = false;
                this._analysisFlowWaveTimer = null;
              }, 1100);
            });
          });
        },
        /**
         * @param {boolean} [useAllProjectTemplates=false] 为 true 时基于当前工作台下全部技能提交；否则仅提交已勾选的技能
         * @param {boolean} [navigateToResults=false] 为 true 时切换至「结果」页签；默认仅提示、不跳转
         * @param {string} [successMessage] 自定义成功提示；不传则使用默认「已提交 n 条分析任务」
         */
        runProjectAnalysis(useAllProjectTemplates = false, navigateToResults = false, successMessage) {
          if (!this.currentProjectId) return;
          const list = this.currentProjectAnalysisTemplates || [];
          const selectedIds = new Set(this.selectedAnalysisTemplateIds || []);
          const templates = useAllProjectTemplates ? list.slice() : list.filter((tpl) => selectedIds.has(tpl.id));
          if (!templates.length) {
            message.warning(useAllProjectTemplates ? '请先在工作台中添加技能' : '请先选择至少一个技能');
            return;
          }
          this.playAnalysisFlowWave();
          if (!Array.isArray(this._analysisJobTimers)) this._analysisJobTimers = [];
          if (typeof demoSubmitProjectTemplateAnalysisJobs === 'function') {
            demoSubmitProjectTemplateAnalysisJobs(this.currentProjectId, templates, {
              message,
              successMessage,
              registerTimer: (id) => this._analysisJobTimers.push(id),
            });
          }
          if (navigateToResults) this.projectDetailTab = 'results';
        },
        closeUploadMaterialModal() {
          this.uploadMaterialVisible = false;
        },
        simulateProjectUploadSelect() {
          this.appendMockUploadBatch();
        },
        appendMockUploadBatch() {
          const pool = [
            { name: '合同补充协议', format: 'PDF' },
            { name: '银行流水-补传', format: 'PDF' },
            { name: '会议纪要-项目例会', format: 'DOCX' },
            { name: '资金拨付台账', format: 'XLSX' },
            { name: '验收报告-阶段一', format: 'DOCX' },
          ];
          const now = Date.now();
          const pick = [pool[now % pool.length], pool[(now + 1) % pool.length], pool[(now + 2) % pool.length]];
          const next = pick.map((item, idx) => ({
            id: 'up-' + (now + idx),
            name: `${item.name}-${String((now + idx) % 1000).padStart(3, '0')}.${item.format.toLowerCase()}`,
            size: Number((1 + ((now + idx) % 120) / 10).toFixed(1)),
            format: item.format,
          }));
          this.uploadMaterialBatch = [...this.uploadMaterialBatch, ...next];
        },
        clearUploadMaterialBatch() {
          this.uploadMaterialBatch = [];
        },
        removeUploadBatchFile(id) {
          this.uploadMaterialBatch = (this.uploadMaterialBatch || []).filter((x) => x.id !== id);
        },
        uploadBatchFormatIcon(format) {
          const key = String(format || '').toUpperCase();
          if (key === 'PDF') return 'fa-file-pdf';
          if (key === 'DOCX' || key === 'DOC') return 'fa-file-word';
          if (key === 'XLSX' || key === 'XLS' || key === 'CSV') return 'fa-file-excel';
          if (key === 'PNG' || key === 'JPG' || key === 'JPEG' || key === 'WEBP') return 'fa-file-image';
          return 'fa-file-lines';
        },
        formatUploadBatchSize(size) {
          const n = Number(size || 0);
          if (!Number.isFinite(n) || n <= 0) return '—';
          return `${n.toFixed(1)} MB`;
        },
        submitUploadMaterial() {
          if (!this.currentProjectId) return;
          const queue = this.uploadMaterialBatch || [];
          if (!queue.length) {
            message.warning('请先添加待上传文件');
            return;
          }
          const now = new Date();
          const key = this.currentProjectId;
          if (!Array.isArray(this.projectMaterialsById[key])) this.projectMaterialsById[key] = [];
          const inserted = queue.map((f, idx) => {
            const stamp = new Date(now.getTime() + idx * 60000).toISOString().slice(0, 19).replace('T', ' ');
            return {
              id: 'm-' + Date.now() + '-' + idx,
              name: f.name,
              tags: [],
              uploader: '当前用户',
              size: Number(f.size || 1),
              format: f.format || 'PDF',
              status: 'queued',
              progress: 0,
              uploadedAt: stamp,
            };
          });
          this.projectMaterialsById[key] = [...inserted, ...this.projectMaterialsById[key]];
          this.projectMaterialPage = 1;
          this.uploadMaterialVisible = false;
          this.uploadMaterialBatch = [];
          message.success(`已加入上传队列 ${inserted.length} 项（演示）`);
        },
        closeMaterialPreviewModal() {
          this.materialPreviewVisible = false;
          this.materialPreviewRecord = null;
          this.materialPreviewActiveTab = 'basic';
        },
        toggleProjectMaterialTag(tag) {
          const keys = this.projectMaterialTagKeys || [];
          const idx = keys.indexOf(tag);
          if (idx >= 0) this.projectMaterialTagKeys = keys.filter((t) => t !== tag);
          else this.projectMaterialTagKeys = [...keys, tag];
        },
        setProjectMaterialStatus(v) {
          this.projectMaterialStatusKey = String(v || 'all');
          this.projectMaterialStatusPopoverOpen = false;
        },
        clearProjectMaterialStatus() {
          this.projectMaterialStatusKey = 'all';
          this.projectMaterialStatusPopoverOpen = false;
        },
        clearProjectMaterialTags() {
          this.projectMaterialTagKeys = [];
        },
        onProjectMaterialSortMenuClick(info) {
          const next = info && info.key ? String(info.key) : '';
          if (!next) return;
          this.projectMaterialSortBy = next;
          this.projectMaterialSortDropdownOpen = false;
        },
        toggleProjectAnalysisResultTag(tag) {
          const keys = this.projectAnalysisResultTagKeys || [];
          const idx = keys.indexOf(tag);
          if (idx >= 0) this.projectAnalysisResultTagKeys = keys.filter((t) => t !== tag);
          else this.projectAnalysisResultTagKeys = [...keys, tag];
        },
        setProjectAnalysisResultStatus(v) {
          this.projectAnalysisResultStatusKey = String(v || 'all');
          this.projectAnalysisResultStatusPopoverOpen = false;
        },
        clearProjectAnalysisResultStatus() {
          this.projectAnalysisResultStatusKey = 'all';
          this.projectAnalysisResultStatusPopoverOpen = false;
        },
        clearProjectAnalysisResultTags() {
          this.projectAnalysisResultTagKeys = [];
        },
        onProjectAnalysisResultSortMenuClick(info) {
          const next = info && info.key ? String(info.key) : '';
          if (!next) return;
          this.projectAnalysisResultSortBy = next;
          this.projectAnalysisResultSortDropdownOpen = false;
        },
        clearProjectAnalysisResultListFilters() {
          this.projectAnalysisResultSearchKeyword = '';
          this.projectAnalysisResultStatusKey = 'all';
          this.projectAnalysisResultTagKeys = [];
          this.projectAnalysisResultTagSearchQuery = '';
          this.projectAnalysisResultTagPopoverOpen = false;
        },
        toggleProjectDetailTemplateTag(tag) {
          const keys = this.projectDetailTemplateTagKeys || [];
          const idx = keys.indexOf(tag);
          if (idx >= 0) this.projectDetailTemplateTagKeys = keys.filter((t) => t !== tag);
          else this.projectDetailTemplateTagKeys = [...keys, tag];
        },
        clearProjectDetailTemplateTags() {
          this.projectDetailTemplateTagKeys = [];
        },
        onProjectDetailTemplateSortMenuClick(info) {
          const next = info && info.key ? String(info.key) : '';
          if (!next) return;
          this.projectDetailTemplateSortBy = next;
          this.projectDetailTemplateSortDropdownOpen = false;
        },
        clearProjectDetailTemplateListFilters() {
          this.projectDetailTemplateSearchKeyword = '';
          this.projectDetailTemplateTagKeys = [];
          this.projectDetailTemplateTagSearchQuery = '';
          this.projectDetailTemplateTagPopoverOpen = false;
        },
        isMaterialSelected(id) {
          return (this.selectedMaterialIds || []).includes(id);
        },
        projectMaterialTableRowClassName(record) {
          return this.isMaterialSelected(record && record.id) ? 'project-material-table-row-selected' : '';
        },
        analysisResultTableRowClassName(record) {
          const id = record && record.id;
          return id && (this.selectedAnalysisResultIds || []).includes(id) ? 'project-material-table-row-selected' : '';
        },
        toggleMaterialSelect(record) {
          if (!record || !record.id) return;
          const ids = this.selectedMaterialIds || [];
          const idx = ids.indexOf(record.id);
          if (idx >= 0) this.selectedMaterialIds = ids.filter((x) => x !== record.id);
          else this.selectedMaterialIds = [...ids, record.id];
        },
        openBatchTagModal(target = 'material') {
          if (target === 'analysisResult') {
            if (!this.selectedAnalysisResultCount) {
              message.info('选中任何数据即可');
              return;
            }
          } else if (!this.selectedMaterialCount) {
            message.info('选中任何数据即可');
            return;
          }
          this.batchTagTarget = target === 'analysisResult' ? 'analysisResult' : 'material';
          this.batchTagForm = { tags: [] };
          this.batchTagModalVisible = true;
        },
        closeBatchTagModal() {
          this.batchTagModalVisible = false;
          this.batchTagTarget = 'material';
        },
        confirmBatchTag() {
          if (!this.currentProjectId) return;
          const tags = (this.batchTagForm && Array.isArray(this.batchTagForm.tags) ? this.batchTagForm.tags : [])
            .map((t) => String(t || '').trim())
            .filter(Boolean);
          if (!tags.length) {
            message.warning('请至少填写一个标签');
            return;
          }
          const kind = this.batchTagTarget === 'analysisResult' ? 'analysisResult' : 'material';
          if (kind === 'analysisResult') {
            const ids = this.selectedAnalysisResultIds || [];
            if (!ids.length) {
              message.warning('请先选择结果');
              return;
            }
            const rows = this.projectAnalysisResultsById[this.currentProjectId] || [];
            let hit = 0;
            const nextRows = rows.map((row) => {
              if (!ids.includes(row.id)) return row;
              hit += 1;
              const merged = Array.from(new Set([...(Array.isArray(row.tags) ? row.tags : []), ...tags]));
              return { ...row, tags: merged };
            });
            this.projectAnalysisResultsById[this.currentProjectId] = nextRows;
            this.batchTagModalVisible = false;
            this.batchTagTarget = 'material';
            message.success(`已为 ${hit} 项结果打标签`);
            return;
          }
          const ids = this.selectedMaterialIds || [];
          if (!ids.length) {
            message.warning('请先选择资料');
            return;
          }
          const rows = this.projectMaterialsById[this.currentProjectId] || [];
          let hit = 0;
          const nextRows = rows.map((row) => {
            if (!ids.includes(row.id)) return row;
            hit += 1;
            const merged = Array.from(new Set([...(Array.isArray(row.tags) ? row.tags : []), ...tags]));
            return { ...row, tags: merged };
          });
          this.projectMaterialsById[this.currentProjectId] = nextRows;
          this.batchTagModalVisible = false;
          this.batchTagTarget = 'material';
          message.success(`已为 ${hit} 项资料打标签`);
        },
        openProjectMaterialMetaEdit(record) {
          if (!this.isRawProjectMaterial(record)) return;
          this.projectItemMetaEditKind = 'material';
          this.projectItemMetaEditTargetId = record.id;
          this.projectItemMetaEditForm = {
            name: String(record.name || '').trim(),
            tags: Array.isArray(record.tags) ? [...record.tags] : [],
          };
          this.projectItemMetaEditVisible = true;
        },
        openAnalysisResultMetaEdit(record) {
          if (!record || !record.id) return;
          this.projectItemMetaEditKind = 'analysisResult';
          this.projectItemMetaEditTargetId = record.id;
          this.projectItemMetaEditForm = {
            name: String(record.name || '').trim(),
            tags: Array.isArray(record.tags) ? [...record.tags] : [],
          };
          this.projectItemMetaEditVisible = true;
        },
        closeProjectItemMetaEdit() {
          this.projectItemMetaEditVisible = false;
          this.projectItemMetaEditTargetId = '';
        },
        confirmProjectItemMetaEdit() {
          const kind = this.projectItemMetaEditKind;
          const id = this.projectItemMetaEditTargetId;
          const name = String((this.projectItemMetaEditForm && this.projectItemMetaEditForm.name) || '').trim();
          const tagSrc = this.projectItemMetaEditForm && Array.isArray(this.projectItemMetaEditForm.tags) ? this.projectItemMetaEditForm.tags : [];
          const tags = Array.from(new Set(tagSrc.map((t) => String(t || '').trim()).filter(Boolean)));
          if (!this.currentProjectId || !id) return;
          if (!name) {
            message.warning(kind === 'analysisResult' ? '请填写结果名称' : '请填写资料名称');
            return;
          }
          if (kind === 'material') {
            const rows = this.projectMaterialsById[this.currentProjectId] || [];
            const idx = rows.findIndex((x) => x.id === id);
            if (idx < 0) return;
            rows.splice(idx, 1, { ...rows[idx], name, tags });
            if (this.materialPreviewRecord && this.materialPreviewRecord.id === id) {
              this.materialPreviewRecord = { ...this.materialPreviewRecord, name, tags };
            }
          } else {
            const rows = this.projectAnalysisResultsById[this.currentProjectId] || [];
            const idx = rows.findIndex((x) => x.id === id);
            if (idx < 0) return;
            rows.splice(idx, 1, { ...rows[idx], name, tags });
            if (this.analysisResultPreviewRecord && this.analysisResultPreviewRecord.id === id) {
              this.analysisResultPreviewRecord = { ...this.analysisResultPreviewRecord, name, tags };
            }
          }
          this.closeProjectItemMetaEdit();
          message.success('已保存');
        },
        batchRerunSelectedMaterials() {
          if (!this.currentProjectId) return;
          const ids = this.selectedMaterialIds || [];
          if (!ids.length) {
            message.info('选中任何数据即可');
            return;
          }
          const rows = this.projectMaterialsById[this.currentProjectId] || [];
          let hit = 0;
          const nextRows = rows.map((row) => {
            if (!ids.includes(row.id)) return row;
            hit += 1;
            return { ...row, status: 'parsing', progress: 12 };
          });
          this.projectMaterialsById[this.currentProjectId] = nextRows;
          message.success(`已将 ${hit} 项加入重跑队列`);
        },
        batchDeleteSelectedMaterials() {
          if (!this.currentProjectId) return;
          const ids = this.selectedMaterialIds || [];
          if (!ids.length) {
            message.info('选中任何数据即可');
            return;
          }
          Modal.confirm({
            centered: true,
            title: `确定删除已选 ${ids.length} 项资料？`,
            content: '删除后这些资料及解析记录将一并移除。',
            okText: '删除',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              const rows = this.projectMaterialsById[this.currentProjectId] || [];
              this.projectMaterialsById[this.currentProjectId] = rows.filter((x) => !ids.includes(x.id));
              this.selectedMaterialIds = [];
              message.success('已批量删除');
            },
          });
        },
        materialTagText(record) {
          const tags = record && Array.isArray(record.tags) ? record.tags.filter(Boolean) : [];
          return tags.length ? tags.join('、') : '—';
        },
        materialTypeIcon(record) {
          const fmt = String((record && record.format) || '').toUpperCase();
          if (fmt === 'PDF') return 'fas fa-file-pdf';
          if (fmt === 'XLSX' || fmt === 'CSV') return 'fas fa-file-excel';
          if (fmt === 'DOCX') return 'fas fa-file-word';
          if (fmt === 'JSON') return 'fas fa-file-code';
          return 'fas fa-file-lines';
        },
        materialTypeIconClass(record) {
          if (!record || record.status !== 'done') return '';
          const fmt = String((record && record.format) || '').toUpperCase();
          if (fmt === 'PDF') return 'is-pdf';
          if (fmt === 'XLSX' || fmt === 'CSV') return 'is-sheet';
          if (fmt === 'DOCX') return 'is-doc';
          if (fmt === 'JSON') return 'is-data';
          return '';
        },
        materialFormatIconClass(record) {
          const fmt = String((record && record.format) || '').toUpperCase();
          if (fmt === 'PDF') return 'is-pdf';
          if (fmt === 'XLSX' || fmt === 'CSV') return 'is-sheet';
          if (fmt === 'DOCX') return 'is-doc';
          if (fmt === 'JSON') return 'is-data';
          return '';
        },
        materialStatusLabel(status) {
          const map = {
            queued: '排队中',
            parsing: '解析中',
            done: '完成',
            failed: '失败',
          };
          return map[status] || '排队中';
        },
        /** R7：数据 status → .ds-status-pill 修饰类 */
        materialStatusPillModifier(status) {
          const s = status || 'queued';
          const map = { queued: 'is-neutral', parsing: 'is-primary', done: 'is-success', failed: 'is-error' };
          return map[s] || map.queued;
        },
        materialStatusTagColor(status) {
          const map = {
            queued: 'default',
            parsing: 'processing',
            done: 'success',
            failed: 'error',
          };
          return map[status] || 'default';
        },
        materialProgressPercent(record) {
          const p = Number(record && record.progress);
          if (Number.isNaN(p)) return 0;
          return Math.max(0, Math.min(100, p));
        },
        isRawProjectMaterial(record) {
          return !!record && (!record.type || record.type === 'raw');
        },
        materialProgressStatus(record) {
          if (!record) return 'normal';
          if (record.status === 'failed') return 'exception';
          if (record.status === 'done') return 'success';
          return 'active';
        },
        viewMaterial(record) {
          if (!record) return;
          this.materialPreviewRecord = { ...record };
          this.materialPreviewActiveTab = 'preview';
          this.materialPreviewVisible = true;
        },
        rerunMaterial(record) {
          if (!this.currentProjectId || !record || !this.isRawProjectMaterial(record)) return;
          const rows = this.projectMaterialsById[this.currentProjectId] || [];
          const idx = rows.findIndex((x) => x.id === record.id);
          if (idx < 0) return;
          const next = { ...rows[idx], status: 'parsing', progress: 12 };
          rows.splice(idx, 1, next);
          message.success('已加入重跑队列');
        },
        deleteMaterial(record) {
          if (!this.currentProjectId || !record || !this.isRawProjectMaterial(record)) return;
          Modal.confirm({
            centered: true,
            title: '确定删除该资料？',
            content: '删除后该资料的解析记录将一并移除。',
            okText: '删除',
            okType: 'danger',
            cancelText: '取消',
            onOk: () => {
              const rows = this.projectMaterialsById[this.currentProjectId] || [];
              this.projectMaterialsById[this.currentProjectId] = rows.filter((x) => x.id !== record.id);
              message.success('已删除');
            },
          });
        },
        refreshProjectMaterials() {
          message.success('已刷新资料列表');
        },
        goToProjectDetail(id) { window.location.hash = 'project/' + encodeURIComponent(id); this.projectIdFromHash = getProjectIdFromHash(); },
        goToWorkbenchFromList(projectId) { window.location.hash = 'freeaudit?projectId=' + encodeURIComponent(projectId); window.dispatchEvent(new HashChangeEvent('hashchange')); },
        goToWorkbenchFromListAnimated(projectId) {
          if (!projectId || this.projectDetailModeExit) return;
          this.projectDetailModeExit = true;
          window.setTimeout(() => {
            try { sessionStorage.setItem('demoAuxiliaryEnterAnim', '1'); } catch (_) { /* ignore */ }
            this.projectDetailModeExit = false;
            this.goToWorkbenchFromList(projectId);
          }, 340);
        },
        applyPendingNewProject() {
          const raw = sessionStorage.getItem('pendingNewProject');
          if (!raw || !this.projectIdFromHash) return;
          try {
            const parsed = JSON.parse(raw);
            if (parsed.id !== this.projectIdFromHash) return;
            if (this.projectList.some((p) => p.id === parsed.id)) { sessionStorage.removeItem('pendingNewProject'); return; }
            const createdAt = parsed.createdAt || new Date().toISOString().slice(0, 19).replace('T', ' ');
            let vis = 'private';
            if (parsed.visibility === 'shared') vis = 'shared';
            else if (parsed.visibility === 'public') vis = 'private';
            const sharedIds = vis === 'shared' && Array.isArray(parsed.sharedUserIds) ? parsed.sharedUserIds.filter(Boolean) : [];
            const sharedDeptIds = vis === 'shared' && Array.isArray(parsed.sharedDeptIds) ? parsed.sharedDeptIds.filter(Boolean) : [];
            this.projectList.push({
              id: parsed.id,
              name: parsed.name,
              description: parsed.description,
              templateName: parsed.templateName || '-',
              tags: Array.isArray(parsed.tags) ? parsed.tags.slice() : [],
              lifecycleStatus: parsed.lifecycleStatus === 'ended' ? 'ended' : 'active',
              docCount: parsed.fileCount || 0,
              materialCount: parsed.fileCount || 0,
              analysisCount: 0,
              reportCount: 0,
              createdAt,
              updatedAt: createdAt,
              visibility: vis,
              sharedUserIds: vis === 'shared' ? sharedIds : [],
              sharedDeptIds: vis === 'shared' ? sharedDeptIds : [],
            });
            this.projectMeta = { name: parsed.name, description: parsed.description || '', templateName: parsed.templateName || '-', docCount: parsed.fileCount || 0, createdAt: parsed.createdAt || '', updatedAt: '', owner: '张审计' };
            if (!this.projectMaterialsById[parsed.id]) this.projectMaterialsById[parsed.id] = [];
            if (!this.projectAnalysisResultsById[parsed.id]) this.projectAnalysisResultsById[parsed.id] = [];
            sessionStorage.removeItem('pendingNewProject');
          } catch (_) {}
        },
      },

    });

})();
