(function () {
  const PROJECT_MODE_COACH = Object.freeze({
    title: '切换工作模式',
    body: '点击「自动模式」可切换为「辅助模式」，通过 AI 对话开展审计工作。',
    target: 'mode',
  });

  window.__DEMO_PROJECT_UTILS = Object.freeze({
    PROJECT_MODE_COACH,
  });
})();
