(function () {
  function getFreeAuditQuery() {
    const raw = (window.location.hash || '').replace(/^#/, '');
    const base = raw.split('?')[0];
    if (base !== 'freeaudit') return {};
    const q = raw.includes('?') ? raw.split('?')[1] : '';
    const params = new URLSearchParams(q || '');
    return {
      projectId: params.get('projectId') || null,
      materialId: params.get('materialId') || null,
      analysisResultId: params.get('analysisResultId') || null,
      reportId: params.get('reportId') || null,
      openTemplate: params.get('openTemplate') === '1',
    };
  }

  const presetSuggestions = [
    '总结当前工作台中的主要疑点',
    '从资料中找出合规风险点',
    '基于所选资料生成报告初稿'
  ];

  const WORKBENCH_PROJECT_NAME_BY_ID = Object.freeze({
    'PRJ-2026-001': 'A市城建集团年度经济责任审计',
    'PRJ-2026-002': 'B区采购专项资金异常排查',
    'PRJ-2026-003': 'C县专项债流向跟踪审计',
    'PRJ-2026-004': 'D市道路改扩建工程审计',
    'PRJ-2026-005': 'E区财政收支审计',
    'PRJ-2026-006': 'F县乡村振兴资金审计',
    'PRJ-001': 'A市城建项目',
    'PRJ-002': 'B区采购专项',
    'PRJ-003': 'C县专项审计',
  });

  const SUMMARY_RESPONSE_DEMO = `基于所选资料，关于「总结当前工作台中的主要疑点」的总结：

1. 主要疑点：合同金额 100 万与已开发票 58 万不一致 [1][2]，剩余 42 万未开票，需核实是否已履约或分批开票；审批单金额 8 万与合同尾款 50 万（50%）不符 [1][3]，疑为分批审批或审批范围差异。

2. 合规风险：支出科目「应付账款」32 万与银行实际支付 58 万存在差异 [2][4]，需核对明细与分类；审批流程与合同约定付款节点未一一对应，待人工确认。

3. 建议：对上述疑点进行人工确认后纳入报告；建议补充合同履约证明及剩余发票。

引用：[1][2][3]`;

  const DEMO_RUN_SUMMARY_TEXT = '本次模型已完成：资料阅读与多轮关键词检索、技能「疑点归纳与交叉核对」结构化输出，并已更新《审计备忘录-疑点摘录.md》差异草案。你可继续追问、保存到结果或将结论沉淀为技能。';

  function demoToolDiffLineClass(line) {
    const s = String(line);
    if (s.startsWith('-')) return 'nlm-tool-diff-line--del';
    if (s.startsWith('+')) return 'nlm-tool-diff-line--add';
    return 'nlm-tool-diff-line--ctx';
  }

  function demoLinesUnifiedDiff(oldText, newText, options) {
    const maxOut = (options && options.maxOut) || 500;
    const cap = 600;
    const a0 = String(oldText || '').split(/\r?\n/);
    const b0 = String(newText || '').split(/\r?\n/);
    const truncatedInput = a0.length > cap || b0.length > cap;
    const a = a0.slice(0, cap);
    const b = b0.slice(0, cap);
    const n = a.length;
    const m = b.length;
    const dp = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
    for (let i = 1; i <= n; i++) {
      for (let j = 1; j <= m; j++) {
        if (a[i - 1] === b[j - 1]) dp[i][j] = dp[i - 1][j - 1] + 1;
        else dp[i][j] = dp[i - 1][j] > dp[i][j - 1] ? dp[i - 1][j] : dp[i][j - 1];
      }
    }
    const out = [];
    let i = n;
    let j = m;
    let truncated = truncatedInput;
    while ((i > 0 || j > 0) && out.length < maxOut) {
      if (i > 0 && j > 0 && a[i - 1] === b[j - 1]) {
        out.push(` ${a[i - 1]}`);
        i--;
        j--;
      } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
        out.push(`+${b[j - 1]}`);
        j--;
      } else if (i > 0) {
        out.push(`-${a[i - 1]}`);
        i--;
      } else {
        break;
      }
    }
    if (i > 0 || j > 0) truncated = true;
    out.reverse();
    return { lines: out, truncated };
  }

  function toAnalysisTemplateShared(seed, library) {
    const row = {
      id: seed.id,
      name: seed.name,
      description: seed.description || '',
      tags: Array.isArray(seed.tags) ? seed.tags.slice() : [],
      skillFiles: Array.isArray(seed.skillFiles) ? JSON.parse(JSON.stringify(seed.skillFiles)) : [],
      extractionRules: [],
      analysisRule: seed.analysisRule || '',
      applicableScenario: seed.applicableScenario != null ? String(seed.applicableScenario) : '',
      linkedResourceIds: Array.isArray(seed.linkedResourceIds) ? seed.linkedResourceIds.map((id) => String(id)) : [],
      linkedResourceMeta: seed.linkedResourceMeta && typeof seed.linkedResourceMeta === 'object' ? { ...seed.linkedResourceMeta } : {},
      createdAt: seed.createdAt,
      updatedAt: seed.updatedAt,
      library,
    };
    if (typeof DemoSkillFileTree !== 'undefined' && DemoSkillFileTree.syncExtractionRulesFromSkillFiles) {
      DemoSkillFileTree.syncExtractionRulesFromSkillFiles(row);
    }
    return row;
  }

  window.__DEMO_FREEAUDIT_UTILS = Object.freeze({
    getFreeAuditQuery,
    presetSuggestions,
    WORKBENCH_PROJECT_NAME_BY_ID,
    SUMMARY_RESPONSE_DEMO,
    DEMO_RUN_SUMMARY_TEXT,
    demoToolDiffLineClass,
    demoLinesUnifiedDiff,
    toAnalysisTemplateShared,
  });
})();
