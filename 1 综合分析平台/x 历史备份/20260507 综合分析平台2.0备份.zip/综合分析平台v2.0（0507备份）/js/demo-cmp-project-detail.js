(function () {
  const app = window.__DEMO_APP;

  /* === DEMO:project-detail-header · 工作台详情顶栏 === */
  app.component('ProjectCenterDetailHeader', {
    props: {
      projectTitle: { type: String, default: '工作台详情' },
      currentProjectId: { type: String, default: '' },
      hasProject: { type: Boolean, default: false },
      /** 工作台总览四步引导：当前高亮锚点（如 mode），与 ProjectCenterView 内引导同步 */
      overviewTourHighlightKey: { type: String, default: '' },
    },
    emits: ['back', 'workbench', 'edit'],
    methods: {
      onModePillActivate() {
        if (!this.currentProjectId) return;
        this.$emit('workbench');
      },
      onProjectHeaderMenu(info) {
        if (info && info.key === 'edit') this.$emit('edit');
      },
    },
    template: `
      <div class="project-detail-header-with-coach">
        <header class="workbench-top-header workbench-top-header--unified workbench-top-header--project-detail">
          <div class="workbench-top-header__left">
            <a-button type="text" class="ds-icon-btn workbench-back-text-btn" title="返回工作台" aria-label="返回工作台" @click="$emit('back')">
              <i class="fas fa-arrow-left workbench-back-icon" aria-hidden="true"></i>
            </a-button>
          </div>
          <div class="workbench-top-header__center-title-wrap">
            <div class="workbench-top-header__title-with-mode">
              <div class="workbench-top-header__title-cluster">
                <span class="workbench-top-header__title-kicker" aria-label="工作台" title="工作台">
                  <span class="ds-page-hero__title-icon ds-page-hero__title-icon--audit-space" aria-hidden="true"><i class="fas fa-cube"></i></span>
                </span>
                <span class="workbench-top-header__title-name" :title="'工作台 · ' + projectTitle">{{ projectTitle }}</span>
              </div>
              <div
                class="ds-mode-switch-slider is-auto"
                role="tablist"
                aria-label="模式切换"
                :class="{ 'is-overview-tour-highlight': overviewTourHighlightKey === 'mode' }"
              >
                <span class="ds-mode-switch-slider__thumb" aria-hidden="true"></span>
                <button
                  type="button"
                  class="ds-mode-switch-slider__item is-current"
                  role="tab"
                  aria-selected="true"
                  tabindex="-1"
                  data-overview-tour="mode"
                  title="当前为自动模式"
                  aria-label="当前为自动模式"
                >
                  <i class="fas fa-robot" aria-hidden="true"></i>
                  <span>自动</span>
                </button>
                <button
                  type="button"
                  class="ds-mode-switch-slider__item"
                  role="tab"
                  :aria-selected="currentProjectId ? 'false' : 'true'"
                  :tabindex="currentProjectId ? 0 : -1"
                  :disabled="!currentProjectId"
                  :title="currentProjectId ? '切换到辅助模式（与工作台卡片「辅助模式」一致）' : '请先进入工作台'"
                  :aria-label="currentProjectId ? '切换到辅助模式' : '请先进入工作台'"
                  @click="onModePillActivate"
                >
                  <i class="fas fa-comments" aria-hidden="true"></i>
                  <span>辅助</span>
                </button>
              </div>
            </div>
          </div>
          <div class="workbench-top-header__actions">
            <a-dropdown :trigger="['click']" placement="bottomRight" :disabled="!hasProject">
              <a-button
                type="text"
                size="small"
                class="ds-icon-btn workbench-project-gear-btn"
                title="工作台操作"
                aria-label="工作台操作菜单"
                :disabled="!hasProject"
              >
                <i class="fas fa-ellipsis" aria-hidden="true"></i>
              </a-button>
              <template #overlay>
                <a-menu @click="onProjectHeaderMenu">
                  <a-menu-item key="edit">编辑</a-menu-item>
                </a-menu>
              </template>
            </a-dropdown>
          </div>
        </header>
      </div>
    `,
  });
})();
