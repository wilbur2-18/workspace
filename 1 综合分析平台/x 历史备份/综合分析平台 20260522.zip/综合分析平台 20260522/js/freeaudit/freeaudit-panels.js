(function () {
  const NS = window.DemoFreeAudit = window.DemoFreeAudit || {};
  const panels = NS.panels = NS.panels || {};
  const app = window.__DEMO_APP;
  const toolbarBtnClass = 'ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn';

  function toolbarSearchButton(openExpr, toggleHandler) {
    return `
      <a-tooltip :title="${openExpr} ? '收起搜索' : '展开搜索'">
        <a-button type="text" class="${toolbarBtnClass}" :title="${openExpr} ? '收起搜索' : '展开搜索'" :aria-label="${openExpr} ? '收起搜索' : '展开搜索'" @click="${toggleHandler}">
          <ds-icon name="search" />
        </a-button>
      </a-tooltip>
    `;
  }

  function toolbarRefreshButton(resource, label) {
    return `
      <a-tooltip title="重新加载${label}列表（不刷新对话）">
        <a-button type="text" class="${toolbarBtnClass} nlm-toolbar-pool-refresh-btn" :disabled="!workbenchProjectId" title="重新加载${label}列表。不会刷新中间助手对话。" aria-label="重新加载${label}列表，不刷新对话" @click="refreshWorkbenchDemoResources('${resource}')">
          <ds-icon name="refresh" aria-hidden="true" />
        </a-button>
      </a-tooltip>
    `;
  }

  function toolbarBulkButton(area, scope, label) {
    const bulkScope = scope || area;
    return `
      <a-tooltip :title="workbenchBulkScopeActive('${area}', '${bulkScope}') ? '取消${label}多选' : '${label}多选'">
        <a-button
          type="text"
          :class="['${toolbarBtnClass}', { 'is-active': workbenchBulkScopeActive('${area}', '${bulkScope}') }]"
          :disabled="!workbenchBulkScopeActive('${area}', '${bulkScope}') && !workbenchBulkSelectableKeys('${area}', '${bulkScope}').length"
          :title="workbenchBulkScopeActive('${area}', '${bulkScope}') ? '取消${label}多选' : '${label}多选'"
          :aria-label="workbenchBulkScopeActive('${area}', '${bulkScope}') ? '取消${label}多选' : '${label}多选'"
          :aria-pressed="workbenchBulkScopeActive('${area}', '${bulkScope}') ? 'true' : 'false'"
          @click.stop="workbenchBulkScopeActive('${area}', '${bulkScope}') ? resetWorkbenchBulkSelection('${area}') : startWorkbenchBulkMode('${area}', '${bulkScope}')"
        >
          <svg class="iconpark-icon" aria-hidden="true"><use href="#check-correct"></use></svg>
        </a-button>
      </a-tooltip>
    `;
  }

  panels.bulkBar = function bulkBar(area, scope) {
    const bulkScope = scope || area;
    return `
      <div v-if="workbenchBulkScopeActive('${area}', '${bulkScope}')" class="workbench-bulk-bar workbench-bulk-bar--${area}" role="toolbar" aria-label="批量操作">
        <span class="workbench-bulk-bar__summary">
          <a-checkbox
            class="workbench-bulk-bar__check"
            :checked="workbenchBulkAllSelected('${area}', '${bulkScope}')"
            :indeterminate="workbenchBulkSomeSelected('${area}', '${bulkScope}')"
            @change="(e) => toggleWorkbenchBulkSelectAll('${area}', '${bulkScope}', e)"
          />
          <span class="workbench-bulk-bar__count">已选 {{ workbenchBulkSelectedCount('${area}') }} 项</span>
          <button type="button" class="workbench-bulk-bar__cancel-link" @click.stop="resetWorkbenchBulkSelection('${area}')">取消</button>
        </span>
        <div class="workbench-bulk-bar__actions">
          <a-button
            v-for="action in workbenchBulkActionKeys('${area}', 'primary')"
            :key="'bulk-primary-' + action"
            type="text"
            class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn workbench-bulk-bar__btn"
            :title="workbenchBulkActionLabel(action, '${area}')"
            :aria-label="workbenchBulkActionLabel(action, '${area}')"
            @click.stop="onWorkbenchBulkAction('${area}', action)"
          ><ds-icon :name="workbenchBulkActionIcon(action)" aria-hidden="true" /></a-button>
          <a-dropdown v-if="workbenchBulkActionKeys('${area}', 'more').length" :trigger="['click']" @click.stop>
            <a-button type="text" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn workbench-bulk-bar__more" title="更多批量操作" aria-label="更多批量操作" @click.stop>
              <ds-icon name="more" aria-hidden="true" />
            </a-button>
            <template #overlay>
              <a-menu @click="({ key }) => onWorkbenchBulkAction('${area}', key)">
                <a-menu-item
                  v-for="action in workbenchBulkActionKeys('${area}', 'more')"
                  :key="action"
                  :danger="action === 'delete'"
                >{{ workbenchBulkActionLabel(action, '${area}') }}</a-menu-item>
              </a-menu>
            </template>
          </a-dropdown>
        </div>
      </div>
    `;
  };

  panels.drawerSectionOpen = function drawerSectionOpen(kind, options) {
    const hasActions = !options || options.hasActions !== false;
    const headClass = hasActions ? 'nlm-resource-drawer__head nlm-resource-drawer__head--split' : 'nlm-resource-drawer__head';
    const head = `
      <section class="nlm-resource-drawer" :class="{ 'is-open': resourceDrawerOpen.${kind} }" :style="resourceDrawerSectionStyle('${kind}')">
        ${hasActions ? '<div class="nlm-resource-drawer__head-row">' : ''}
          <button type="button" class="${headClass}" @click="toggleResourceDrawer('${kind}')">
            <span class="nlm-resource-drawer__title">
              <ds-icon name="chevron-right" class="nlm-resource-drawer__chevron" aria-hidden="true" />
              <span class="nlm-stat-count-label-row">
                <span class="nlm-resource-drawer__title-label">{{ workbenchResourceDrawerHeadLabel('${kind}') }}</span>
                <span class="nlm-resource-drawer__title-count nlm-stat-count-tag">{{ workbenchResourceDrawerHeadCount('${kind}') }}</span>
              </span>
            </span>
          </button>
    `;
    return hasActions ? `${head}<div class="nlm-material-action-row__right">` : head;
  };

  panels.drawerBodyOpen = function drawerBodyOpen(kind, options) {
    const hasActions = !options || options.hasActions !== false;
    return `
        ${hasActions ? '</div></div>' : ''}
        <div v-show="resourceDrawerOpen.${kind}" :ref="(el) => setResourceDrawerBodyRef('${kind}', el)" class="nlm-resource-drawer__body">
    `;
  };

  panels.drawerSectionClose = function drawerSectionClose() {
    return `
      </section>
    `;
  };

  panels.drawerActions = function drawerActions(kind) {
    if (kind === 'file') {
      return `
        <template v-if="resourceDrawerOpen.file">
          <a-tooltip :title="workbenchMaterialSearchOpen ? '收起搜索' : '展开搜索'">
            <a-button type="text" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn" :title="workbenchMaterialSearchOpen ? '收起搜索' : '展开搜索'" :aria-label="workbenchMaterialSearchOpen ? '收起搜索' : '展开搜索'" @click="toggleWorkbenchMaterialSearchPanel">
              <ds-icon name="search" />
            </a-button>
          </a-tooltip>
          ${toolbarBulkButton('resource', 'material', '资料')}
          <a-tooltip title="重新加载资料列表（不刷新对话）">
            <a-button type="text" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-toolbar-pool-refresh-btn" :disabled="!workbenchProjectId" title="重新加载资料列表。不会刷新中间助手对话。" aria-label="重新加载资料列表，不刷新对话" @click="refreshWorkbenchDemoResources('material')">
              <ds-icon name="refresh" aria-hidden="true" />
            </a-button>
          </a-tooltip>
        </template>
        <a-dropdown :trigger="['click']" @click.stop>
          <a-tooltip title="添加">
            <a-button type="text" size="small" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-upload-primary-btn" :disabled="!workbenchProjectId" title="添加" aria-label="添加" @click.stop>
              <ds-icon name="plus" aria-hidden="true" />
            </a-button>
          </a-tooltip>
          <template #overlay>
            <a-menu @click="({ key }) => onWorkbenchMaterialAddMenu(key, '')">
              <a-menu-item key="upload-file"><span class="wb-menu-action-item"><ds-icon class="wb-menu-action-item__icon" :name="workbenchMenuItemIcon('upload-file')" aria-hidden="true" /><span>上传文件</span></span></a-menu-item>
              <a-menu-item key="new-folder"><span class="wb-menu-action-item"><ds-icon class="wb-menu-action-item__icon" :name="workbenchMenuItemIcon('new-folder')" aria-hidden="true" /><span>新建文件夹</span></span></a-menu-item>
            </a-menu>
          </template>
        </a-dropdown>
      `;
    }
    if (kind === 'database' || kind === 'graph') {
      const searchOpen = kind === 'database' ? 'workbenchDbSearchOpen' : 'workbenchGraphSearchOpen';
      const searchToggle = kind === 'database' ? 'toggleWorkbenchDbSearchPanel' : 'toggleWorkbenchGraphSearchPanel';
      const addTitle = kind === 'database' ? '添加库表' : '添加图谱';
      const addAction = kind === 'database' ? 'openWorkbenchDbAddModal' : 'openWorkbenchGraphAddModal';
      return `
        <template v-if="resourceDrawerOpen.${kind}">
          <a-tooltip :title="${searchOpen} ? '收起搜索' : '展开搜索'">
            <a-button type="text" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn" :title="${searchOpen} ? '收起搜索' : '展开搜索'" :aria-label="${searchOpen} ? '收起搜索' : '展开搜索'" @click="${searchToggle}">
              <ds-icon name="search" />
            </a-button>
          </a-tooltip>
          ${kind === 'database' ? toolbarBulkButton('resource', 'database', '库表') : ''}
        </template>
        <a-tooltip title="${addTitle}">
          <a-button type="text" size="small" class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn nlm-sort-icon-btn nlm-upload-primary-btn" title="${addTitle}" aria-label="${addTitle}" @click="${addAction}">
            <ds-icon name="plus" aria-hidden="true" />
          </a-button>
        </a-tooltip>
      `;
    }
    return '';
  };

  panels.rightSplitPanelOpen = function rightSplitPanelOpen() {
    return `
      <div ref="rightSplitPanel" class="nlm-side-panel-body nlm-right-split-panel" :class="{ 'is-wb-batch-children-active': wbTaskListView === 'batch-children' }" style="display:flex;flex-direction:column;min-height:0;">
    `;
  };

  panels.rightSplitPanelClose = function rightSplitPanelClose() {
    return `
      </div>
    `;
  };

  panels.rightTaskSectionOpen = function rightTaskSectionOpen() {
    return `
      <section
        class="nlm-right-split-section nlm-right-split-section--task"
        :class="{ 'is-wb-batch-children-active': wbTaskListView === 'batch-children' }"
        :style="rightSplitTaskSectionStyle"
      >
        <div class="nlm-panel-header">
          <div class="nlm-panel-title-row nlm-panel-title-row--task-with-refresh">
            <a-button v-if="wbTaskListView === 'batch-children'" type="text" class="${toolbarBtnClass} wb-task-list-panel-back-btn" title="返回任务列表" aria-label="返回任务列表" @click.stop="exitBatchChildListView"><svg class="iconpark-icon"><use href="#arrow-left"></use></svg></a-button>
            <span class="nlm-panel-title">{{ wbTaskListPanelTitle }}</span>
            <div v-if="wbTaskListView !== 'batch-children'" class="nlm-material-toolbar__actions">
              ${toolbarBulkButton('task', 'task', '任务')}
              ${toolbarRefreshButton('task', '任务')}
              <a-button v-if="poolTabAnalysisTaskCount > 0" type="text" size="small" class="${toolbarBtnClass} nlm-task-add-icon-btn" title="新建任务" aria-label="新建任务" @click="handleWorkbenchTaskCreate"><ds-icon name="plus" aria-hidden="true" /></a-button>
            </div>
            <div v-else-if="wbActiveBatchParentTask" class="nlm-material-toolbar__actions">
              ${toolbarBulkButton('task', 'batch-child', '子任务')}
              ${toolbarRefreshButton('task', '任务')}
              <a-dropdown :trigger="['click']" @click.stop>
                <a-button type="text" class="${toolbarBtnClass}" title="更多" aria-label="更多操作" @click.stop><ds-icon name="more" aria-hidden="true" /></a-button>
                <template #overlay>
                  <a-menu @click="({ key }) => handleBatchParentHeaderMenu(key)">
                    <a-menu-item v-if="batchParentShowAbortQuick(wbActiveBatchParentTask)" key="abort-task">一键中止</a-menu-item>
                    <a-menu-item v-if="batchParentCanRerunMenu(wbActiveBatchParentTask)" key="rerun-all">一键重跑</a-menu-item>
                    <a-menu-item
                      v-if="batchParentCanRerunMenu(wbActiveBatchParentTask)"
                      key="rerun-failed-only"
                      :disabled="!batchParentFailedChildCount(wbActiveBatchParentTask)"
                    >一键重跑（仅失败）</a-menu-item>
                    <a-menu-item
                      v-if="batchParentCanRerunMenu(wbActiveBatchParentTask)"
                      key="clear-failed-only"
                      :disabled="!batchParentFailedChildCount(wbActiveBatchParentTask)"
                    >一键清空（仅失败）</a-menu-item>
                    <a-menu-divider v-if="batchParentShowAbortQuick(wbActiveBatchParentTask) || batchParentCanRerunMenu(wbActiveBatchParentTask)" />
                    <a-menu-item key="delete" danger>删除</a-menu-item>
                  </a-menu>
                </template>
              </a-dropdown>
            </div>
          </div>
        </div>
        <div class="nlm-fill-scroll nlm-right-split-scroll nlm-task-list-scroll" style="flex:1;min-height:0;display:flex;flex-direction:column;" @mouseleave="hoveredMaterialId = null" @click="onMaterialListAreaClick($event)">
    `;
  };

  panels.rightTaskSectionClose = function rightTaskSectionClose() {
    return `
        </div>
      </section>
      <div class="nlm-right-split-resizer" style="flex:0 0 8px;height:8px;min-height:8px;cursor:row-resize;background:var(--freeaudit-workspace-bg);" role="separator" aria-orientation="horizontal" title="调整任务和结果分区高度" @mousedown.stop.prevent="beginResize('rightSplit', $event)"></div>
    `;
  };

  panels.rightResultSectionOpen = function rightResultSectionOpen() {
    return `
      <section class="nlm-right-split-section nlm-right-split-section--result" :style="rightSplitResultSectionStyle">
        <div class="nlm-panel-header">
          <div class="nlm-panel-title-row nlm-panel-title-row--result-with-refresh">
            <span class="nlm-stat-count-label-row">
              <span class="nlm-panel-title">结果</span>
              <span class="nlm-stat-count-tag">{{ workbenchAnalysisResultPanelCount }}</span>
            </span>
            <div class="nlm-material-toolbar__actions">
              ${toolbarSearchButton('workbenchAnalysisSearchOpen', 'toggleWorkbenchAnalysisSearchPanel')}
              <a-dropdown :trigger="['click']" @click.stop>
                <a-button
                  type="text"
                  class="${toolbarBtnClass}"
                  :title="'结果排序：' + workbenchAnalysisResultSortLabel"
                  :aria-label="'结果排序：' + workbenchAnalysisResultSortLabel"
                  @click.stop
                >
                  <ds-icon name="arrow-down-short-wide" aria-hidden="true" />
                </a-button>
                <template #overlay>
                  <a-menu :selected-keys="[workbenchAnalysisResultSortMode || 'name']" @click="({ key }) => setWorkbenchAnalysisResultSortMode(key)">
                    <a-menu-item v-for="item in workbenchAnalysisResultSortOptions" :key="item.key">
                      <span class="nlm-sort-menu-item-label">
                        <ds-icon v-if="(workbenchAnalysisResultSortMode || 'name') === item.key" name="check" aria-hidden="true" />
                        <span>{{ item.label }}</span>
                      </span>
                    </a-menu-item>
                  </a-menu>
                </template>
              </a-dropdown>
              ${toolbarBulkButton('result', 'result', '结果')}
              ${toolbarRefreshButton('result', '结果')}
              <a-tooltip title="在结果根目录创建文件夹">
                <a-button type="text" class="${toolbarBtnClass}" title="创建文件夹" aria-label="创建文件夹" :disabled="!workbenchProjectId" @click="openWorkbenchAnalysisResultCreateFolderModal({ type: 'root' })">
                  <ds-icon name="folder-plus" aria-hidden="true" />
                </a-button>
              </a-tooltip>
            </div>
          </div>
        </div>
        <div class="nlm-material-toolbar">
          <div v-if="workbenchAnalysisSearchOpen" class="nlm-material-query-row">
            <a-input
              v-model:value="workbenchAnalysisSearchQuery"
              allow-clear
              placeholder="搜索名称、技能或结果文件夹"
              class="ds-input-inline-search ds-input-inline-search--compact"
            >
              <template #prefix>
                <ds-icon name="search" class="ds-input-inline-search__icon" aria-hidden="true" />
              </template>
            </a-input>
          </div>
          ${panels.bulkBar('result', 'result')}
        </div>
        <div class="nlm-fill-scroll nlm-right-split-scroll wb-material-file-drawer" style="flex:1;min-height:0;" @mouseleave="hoveredMaterialId = null" @click="onMaterialListAreaClick($event)">
    `;
  };

  panels.rightResultSectionClose = function rightResultSectionClose() {
    return `
        </div>
      </section>
    `;
  };

  if (app && !app.component('FreeAuditAnalysisOutputToolbar')) {
    app.component('FreeAuditAnalysisOutputToolbar', {
      props: {
        copyDisabled: { type: Boolean, default: false },
        exportDisabled: { type: Boolean, default: false },
        saveDisabled: { type: Boolean, default: false },
        dirty: { type: Boolean, default: false },
      },
      emits: ['copy', 'export-menu', 'save'],
      template: `
        <div class="analysis-result-preview-modal__toolbar-icons" role="toolbar" aria-label="复制、下载与保存">
          <a-button
            type="default"
            class="analysis-result-preview-toolbar-outline-btn"
            :disabled="copyDisabled"
            title="复制当前内容"
            aria-label="复制当前内容"
            @click="$emit('copy')"
          >复制</a-button>
          <a-dropdown :trigger="['click']" :disabled="exportDisabled">
            <a-button
              type="default"
              class="analysis-result-preview-toolbar-outline-btn"
              :disabled="exportDisabled"
              title="选择导出格式"
              aria-label="下载，选择格式"
              aria-haspopup="true"
            >
              下载 <ds-icon name="chevron-down" style="margin-left:4px;font-size:10px;opacity:0.75" aria-hidden="true" />
            </a-button>
            <template #overlay>
              <a-menu @click="(info) => $emit('export-menu', info)">
                <a-menu-item key="export-md">下载为 Markdown</a-menu-item>
                <a-menu-item key="export-pdf">下载为 PDF</a-menu-item>
                <a-menu-item key="export-docx">下载为 Word</a-menu-item>
              </a-menu>
            </template>
          </a-dropdown>
          <a-button
            class="analysis-result-preview-toolbar-outline-btn"
            :type="dirty ? 'primary' : 'default'"
            :disabled="saveDisabled"
            title="保存编辑内容"
            aria-label="保存编辑内容"
            @click="$emit('save')"
          >保存</a-button>
        </div>
      `,
    });
  }

  if (app && !app.component('FreeAuditStatusFilterBar')) {
    app.component('FreeAuditStatusFilterBar', {
      props: {
        items: { type: Array, default: () => [] },
        activeKey: { type: String, default: '' },
        ariaLabel: { type: String, default: '' },
      },
      emits: ['select'],
      template: `
        <div class="wb-material-status-footer__stats" :aria-label="ariaLabel || null">
          <button
            v-for="item in items"
            :key="item.key"
            type="button"
            :class="['ds-trigger-btn nlm-chat-result-toolbar-btn', { 'is-active': activeKey === item.key }]"
            @click.stop="$emit('select', item.key)"
          >
            <span class="ds-trigger-btn__text wb-status-chip" :class="item.tone ? ('wb-status-chip--' + item.tone) : ''">
              {{ item.label }}<span v-if="item.count !== undefined" class="wb-status-chip__count">{{ item.count }}</span>
            </span>
          </button>
        </div>
      `,
    });
  }

  if (app && !app.component('FreeAuditTaskCreateResourceRow')) {
    app.component('FreeAuditTaskCreateResourceRow', {
      props: {
        item: { type: Object, required: true },
        selected: { type: Boolean, default: false },
        selectedMode: { type: Boolean, default: false },
      },
      emits: ['remove', 'toggle'],
      template: `
        <div
          class="wb-task-create-transfer__list-item nlm-tree-leaf nlm-tree-leaf--analysis"
          :class="{ 'wb-task-create-transfer__list-item--selected': selectedMode }"
          @click="!selectedMode && $emit('toggle', item)"
        >
          <span v-if="!selectedMode" class="wb-task-create-transfer__check">
            <a-checkbox
              :checked="selected"
              @click.stop
              @change="$emit('toggle', item)"
            />
          </span>
          <span class="nlm-tree-leaf-icon">
            <svg v-if="item.iconClass === 'map-draw'" class="iconpark-icon" :class="item.iconToneClass || ''" aria-hidden="true"><use href="#map-draw"></use></svg>
            <ds-icon v-else :name="item.iconClass" :class="item.iconToneClass || ''" aria-hidden="true" />
          </span>
          <div class="nlm-tree-leaf-title-wrap">
            <div class="nlm-tree-leaf-col">
              <div class="nlm-tree-leaf-title">{{ item.name }}</div>
            </div>
          </div>
          <span v-if="selectedMode && item.typeLabel" class="nlm-tree-leaf-tag nlm-tree-leaf-tag--temp">{{ item.typeLabel }}</span>
          <a-button
            v-if="selectedMode"
            type="text"
            size="small"
            class="ds-icon-btn ds-icon-btn--compact ds-icon-btn--nlm nlm-input-bar-btn"
            title="移除"
            aria-label="移除资源"
            @click="$emit('remove', item.key)"
          >
            <svg class="iconpark-icon" aria-hidden="true"><use href="#close-small"></use></svg>
          </a-button>
        </div>
      `,
    });
  }

  if (app && !app.component('FreeAuditTaskConfigResourceRow')) {
    app.component('FreeAuditTaskConfigResourceRow', {
      props: {
        row: { type: Object, required: true },
        iconMeta: { type: Object, default: () => ({}) },
        label: { type: String, default: '' },
        ariaLabel: { type: String, default: '' },
      },
      emits: ['open'],
      template: `
        <FreeAuditTaskDetailSimpleRow :aria-label="ariaLabel" @open="$emit('open', row)">
          <template #icon>
            <svg v-if="iconMeta.iconClass === 'map-draw'" class="iconpark-icon" :class="iconMeta.iconToneClass || ''" aria-hidden="true"><use href="#map-draw"></use></svg>
            <ds-icon v-else :name="iconMeta.iconClass" :class="iconMeta.iconToneClass || ''" />
          </template>
          {{ label }}
        </FreeAuditTaskDetailSimpleRow>
      `,
    });
  }

  if (app && !app.component('FreeAuditTaskDetailSimpleRow')) {
    app.component('FreeAuditTaskDetailSimpleRow', {
      props: {
        ariaLabel: { type: String, default: '' },
        iconClass: { type: [String, Array, Object], default: '' },
      },
      emits: ['open'],
      template: `
        <li
          class="wb-task-detail-simple-row"
          role="button"
          tabindex="0"
          :aria-label="ariaLabel || null"
          @click="$emit('open')"
          @keydown.enter.prevent="$emit('open')"
        >
          <span class="nlm-tree-leaf-icon wb-task-detail-simple-row__icon" :class="iconClass" aria-hidden="true">
            <slot name="icon" />
          </span>
          <span class="wb-task-detail-simple-row__text"><slot /></span>
        </li>
      `,
    });
  }

  if (app && !app.component('FreeAuditBatchChildRow')) {
    app.component('FreeAuditBatchChildRow', {
      props: {
        child: { type: Object, required: true },
        selected: { type: Boolean, default: false },
        status: { type: String, default: '' },
        showMore: { type: Boolean, default: false },
        canAbort: { type: Boolean, default: false },
        canRerun: { type: Boolean, default: false },
        canDelete: { type: Boolean, default: false },
        queuePosition: { type: Number, default: 0 },
        bulkDescriptor: { type: Object, default: null },
        bulkSelected: { type: Boolean, default: false },
        bulkMode: { type: Boolean, default: false },
      },
      emits: ['open', 'menu', 'abort', 'rerun', 'bulk-toggle'],
      template: `
        <a-dropdown :trigger="['contextmenu']" @click.stop>
          <div :class="['nlm-tree-leaf', 'nlm-tree-leaf--analysis', { checked: selected, 'is-bulk-mode': bulkMode, 'is-bulk-selected': bulkSelected }]" @click="$emit('open', $event, child)">
            <span v-if="bulkMode && bulkDescriptor" class="workbench-bulk-tree-check" @click.stop>
              <a-checkbox :checked="bulkSelected" @change="(e) => $emit('bulk-toggle', bulkDescriptor, e)" />
            </span>
            <span class="nlm-tree-leaf-icon">
              <ds-icon name="edit-one" class="is-task-single" title="子任务" />
            </span>
            <div class="nlm-tree-leaf-title-wrap"><div class="nlm-tree-leaf-col"><div class="nlm-tree-leaf-title" :class="{ 'is-muted': ['queued','parsing','failed'].includes(status) }">{{ child.title || child.rowLabel }}</div></div></div>
            <span class="nlm-tree-leaf-right">
              <span v-if="status === 'parsing'" class="nlm-tree-leaf-task-status" title="执行中"><svg class="iconpark-icon is-spin is-status-pending nlm-tree-leaf-progress-ring" aria-hidden="true" focusable="false"><use href="#loading-four"></use></svg></span>
              <span v-else-if="status === 'failed'" class="nlm-tree-leaf-task-status" title="失败"><svg class="iconpark-icon is-status-failed" aria-hidden="true"><use href="#close-one"></use></svg></span>
              <span v-else-if="status === 'done'" class="nlm-tree-leaf-task-status" title="成功"><ds-icon name="check-circle" class="is-status-success" aria-hidden="true" /></span>
              <span
                v-if="status === 'queued' && queuePosition > 0"
                class="nlm-stat-count-tag nlm-tree-leaf-queue-pos"
                :title="'当前排队第 ' + queuePosition + ' 位'"
              >第<span class="nlm-tree-leaf-queue-pos__num">{{ queuePosition }}</span>位</span>
              <div v-if="!bulkMode" class="nlm-tree-leaf-actions">
              <a-dropdown v-if="showMore" :trigger="['click']" @click.stop>
                <a-button type="text" class="ds-icon-btn ds-icon-btn--xs ds-icon-btn--nlm nlm-tree-leaf-action-icon" title="更多" aria-label="更多操作" @click.stop><ds-icon name="more" /></a-button>
                <template #overlay><a-menu @click="({ key }) => $emit('menu', key, child)"><a-menu-item v-if="canAbort" key="abort-task">中止</a-menu-item><a-menu-item v-if="canRerun" key="rerun-task">重跑</a-menu-item><a-menu-divider v-if="canDelete && (canAbort || canRerun)" /><a-menu-item v-if="canDelete" key="delete" danger>删除</a-menu-item></a-menu></template>
              </a-dropdown>
            </div></span>
          </div>
          <template #overlay><a-menu @click="({ key }) => $emit('menu', key, child)"><a-menu-item v-if="canAbort" key="abort-task">中止</a-menu-item><a-menu-item v-if="canRerun" key="rerun-task">重跑</a-menu-item><a-menu-divider v-if="canDelete && (canAbort || canRerun)" /><a-menu-item v-if="canDelete" key="delete" danger>删除</a-menu-item></a-menu></template>
        </a-dropdown>
      `,
    });
  }

  if (app && !app.component('FreeAuditMetaRows')) {
    app.component('FreeAuditMetaRows', {
      props: {
        rows: { type: Array, default: () => [] },
        keyPrefix: { type: String, default: 'meta' },
        statusRowLabel: { type: String, default: '' },
        statusClass: { type: [String, Array, Object], default: '' },
        statusText: { type: String, default: '' },
      },
      template: `
        <template v-for="(row, idx) in rows" :key="keyPrefix + '-' + idx">
          <div class="material-preview-meta-dl-row">
            <span class="material-preview-meta-dl-label">{{ row.label }}</span>
            <span
              v-if="statusRowLabel && row.label === statusRowLabel"
              class="material-preview-meta-dl-value material-preview-meta-dl-value--status-pill"
            >
              <span class="ds-status-pill" :class="statusClass">
                <span class="ds-status-pill__dot"></span>
                <span class="ds-status-pill__label">{{ statusText }}</span>
              </span>
            </span>
            <span v-else class="material-preview-meta-dl-value">{{ row.value }}</span>
          </div>
        </template>
      `,
    });
  }

  if (app && !app.component('FreeAuditBasicInfoPane')) {
    app.component('FreeAuditBasicInfoPane', {
      props: {
        title: { type: String, default: '基本信息' },
        ariaLabel: { type: String, default: '基本信息' },
        paneClass: { type: String, default: '' },
        bodyClass: { type: String, default: 'material-preview-basic-tab' },
        nestedBodyClass: { type: String, default: '' },
        rows: { type: Array, default: () => [] },
        keyPrefix: { type: String, default: 'meta' },
        statusRowLabel: { type: String, default: '' },
        statusClass: { type: String, default: '' },
        statusText: { type: String, default: '' },
      },
      template: `
        <div v-if="paneClass" :class="paneClass">
          <div class="ds-unified-tab-pane-stack">
            <div class="ds-unified-tab-pane-chrome" role="toolbar" :aria-label="ariaLabel">
              <h3 class="ds-unified-tab-pane-chrome__title">{{ title }}</h3>
              <div class="ds-unified-tab-pane-chrome__actions"></div>
            </div>
            <div :class="bodyClass">
              <div v-if="nestedBodyClass" :class="nestedBodyClass">
                <FreeAuditMetaRows
                  :rows="rows"
                  :key-prefix="keyPrefix"
                  :status-row-label="statusRowLabel"
                  :status-class="statusClass"
                  :status-text="statusText"
                />
              </div>
              <FreeAuditMetaRows
                v-else
                :rows="rows"
                :key-prefix="keyPrefix"
                :status-row-label="statusRowLabel"
                :status-class="statusClass"
                :status-text="statusText"
              />
            </div>
          </div>
        </div>
        <div v-else class="ds-unified-tab-pane-stack">
          <div class="ds-unified-tab-pane-chrome" role="toolbar" :aria-label="ariaLabel">
            <h3 class="ds-unified-tab-pane-chrome__title">{{ title }}</h3>
            <div class="ds-unified-tab-pane-chrome__actions"></div>
          </div>
          <div :class="bodyClass">
            <div v-if="nestedBodyClass" :class="nestedBodyClass">
              <FreeAuditMetaRows
                :rows="rows"
                :key-prefix="keyPrefix"
                :status-row-label="statusRowLabel"
                :status-class="statusClass"
                :status-text="statusText"
              />
            </div>
            <FreeAuditMetaRows
              v-else
              :rows="rows"
              :key-prefix="keyPrefix"
              :status-row-label="statusRowLabel"
              :status-class="statusClass"
              :status-text="statusText"
            />
          </div>
        </div>
      `,
    });
  }

  if (app && !app.component('FreeAuditAnalysisHistoryTable')) {
    app.component('FreeAuditAnalysisHistoryTable', {
      props: {
        rows: { type: Array, default: () => [] },
        columns: { type: Array, default: () => [] },
        emptyDescription: { type: String, default: '暂无历史快照。' },
      },
      emits: ['detail', 'rollback'],
      template: `
        <template v-if="(rows || []).length">
          <div
            class="skill-version-mgmt-history-section"
            role="region"
            aria-label="历史版本列表"
          >
            <h4 class="skill-version-mgmt-history__heading">历史版本 ({{ rows.length }})</h4>
            <div class="skill-version-mgmt-history">
              <div class="ds-l2-table-panel">
                <a-table
                  :columns="columns"
                  :data-source="rows"
                  row-key="key"
                  size="small"
                  :pagination="false"
                  class="skill-library-version-mgmt-table wb-analysis-version-mgmt-table"
                >
                  <template #bodyCell="{ column, record }">
                    <template v-if="column.key === 'generationDesc'">
                      <span class="skill-version-table__cell-desc" :title="record.generationDesc">{{ record.generationDesc }}</span>
                    </template>
                    <template v-else-if="column.key === 'action'">
                      <span class="skill-version-mgmt-history__row-actions">
                        <a-button type="link" size="small" class="skill-version-table__version-link" @click="$emit('detail', record)">详情</a-button>
                        <a-button
                          type="link"
                          size="small"
                          class="skill-version-table__version-link"
                          @click="$emit('rollback', record)"
                        >回退</a-button>
                      </span>
                    </template>
                    <template v-else>{{ record[column.dataIndex] }}</template>
                  </template>
                </a-table>
              </div>
            </div>
          </div>
        </template>
        <a-empty v-else :description="emptyDescription" />
      `,
    });
  }

  if (app && !app.component('FreeAuditAnalysisHistoryPane')) {
    app.component('FreeAuditAnalysisHistoryPane', {
      props: {
        active: { type: Boolean, default: false },
        rows: { type: Array, default: () => [] },
        columns: { type: Array, default: () => [] },
        tableEmptyDescription: { type: String, default: '暂无历史快照。' },
        inactiveDescription: { type: String, default: '暂无历史版本。' },
      },
      emits: ['detail', 'rollback'],
      template: `
        <div class="skill-unified-tab-version-root">
          <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--version-row" role="toolbar" aria-label="历史版本">
            <h3 class="ds-unified-tab-pane-chrome__title">历史版本</h3>
            <div class="ds-unified-tab-pane-chrome__actions skill-modal-tab-chrome-actions"></div>
          </div>
          <div class="skill-unified-tab-version-root__main skill-wizard-panel">
            <template v-if="active">
              <FreeAuditAnalysisHistoryTable
                :rows="rows"
                :columns="columns"
                :empty-description="tableEmptyDescription"
                @detail="(record) => $emit('detail', record)"
                @rollback="(record) => $emit('rollback', record)"
              />
            </template>
            <a-empty v-else :description="inactiveDescription" />
          </div>
        </div>
      `,
    });
  }

  if (app && !app.component('FreeAuditAnalysisOutputPane')) {
    app.component('FreeAuditAnalysisOutputPane', {
      props: {
        draftValue: { type: String, default: '' },
        editorDisabled: { type: Boolean, default: false },
        copyDisabled: { type: Boolean, default: false },
        exportDisabled: { type: Boolean, default: false },
        saveDisabled: { type: Boolean, default: false },
        dirty: { type: Boolean, default: false },
      },
      emits: ['update:draftValue', 'copy', 'export-menu', 'save'],
      template: `
        <div class="ds-unified-tab-pane-stack">
          <div class="ds-unified-tab-pane-chrome ds-unified-tab-pane-chrome--result-body" role="toolbar" aria-label="输出结果操作">
            <h3 class="ds-unified-tab-pane-chrome__title">输出结果</h3>
            <div class="ds-unified-tab-pane-chrome__actions" aria-label="正文与编辑器操作">
              <FreeAuditAnalysisOutputToolbar
                :copy-disabled="copyDisabled"
                :export-disabled="exportDisabled"
                :dirty="dirty"
                :save-disabled="saveDisabled"
                @copy="$emit('copy')"
                @export-menu="(info) => $emit('export-menu', info)"
                @save="$emit('save')"
              />
            </div>
          </div>
          <div class="analysis-result-preview-modal__layout workbench-analysis-embed-wrap">
            <div class="preview-modal-content-frame">
              <div class="analysis-result-preview-modal__panel analysis-result-preview-modal__panel--editor analysis-result-preview-modal__panel--tab-chrome-only">
                <div class="analysis-result-preview-modal__panel-body">
                  <a-textarea
                    :value="draftValue"
                    class="analysis-result-preview-modal__editor-textarea"
                    :rows="22"
                    :disabled="editorDisabled"
                    placeholder="支持编辑 Markdown 正文，保存后写入当前结果"
                    @update:value="$emit('update:draftValue', $event)"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      `,
    });
  }
})();
