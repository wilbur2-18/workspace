(function () {
  const NS = window.DemoFreeAudit = window.DemoFreeAudit || {};
  const message = antd.message;

  function uniq(arr) {
    return Array.from(new Set((arr || []).map(String).filter(Boolean)));
  }

  function statusActions(status, doneActions) {
    const st = String(status || 'done');
    if (st === 'queued') return ['abort', 'delete'];
    if (st === 'parsing') return ['abort', 'rerun', 'delete'];
    if (st === 'failed') return ['rerun', 'delete'];
    return doneActions || ['delete'];
  }

  function materialStatusActions(status, doneActions) {
    const st = String(status || 'done');
    if (st === 'queued' || st === 'parsing') return ['abort'];
    if (st === 'failed') return ['rerun', 'delete'];
    return doneActions || ['ref', 'download', 'delete'];
  }

  function batchChildStatusActions(status) {
    const st = String(status || 'done');
    if (st === 'queued' || st === 'parsing') return ['abort'];
    if (st === 'failed' || st === 'done') return ['rerun', 'delete'];
    return ['delete'];
  }

  function taskStatusActions(status) {
    const st = String(status || 'done');
    if (st === 'queued' || st === 'parsing') return ['abort', 'rerun', 'delete'];
    if (st === 'failed' || st === 'done') return ['rerun', 'delete'];
    return ['delete'];
  }

  function intersectActions(items) {
    if (!items.length) return [];
    const first = items[0].availableActions || [];
    return first.filter((action) => items.every((item) => (item.availableActions || []).includes(action)));
  }

  function materialTreeKeyFromNode(node) {
    const key = node && (node.eventKey || node.key || (node.dataRef && node.dataRef.key));
    return String(key || '');
  }

  function parseTreeKey(key) {
    const s = String(key || '');
    const idx = s.indexOf(':');
    if (idx < 0) return { kind: '', id: '' };
    return { kind: s.slice(0, idx), id: s.slice(idx + 1) };
  }

  NS.actionGroups = NS.actionGroups || {};
  NS.actionGroups.bulkActions = {
        workbenchBulkAreaActive(area) {
          return String((this.workbenchBulkSelection && this.workbenchBulkSelection.area) || '') === String(area || '');
        },
        workbenchBulkScopeActive(area, scope) {
          if (!this.workbenchBulkAreaActive(area)) return false;
          const current = String((this.workbenchBulkSelection && this.workbenchBulkSelection.scope) || area || '');
          return current === String(scope || area || '');
        },
        workbenchBulkKeys(area) {
          if (!this.workbenchBulkAreaActive(area)) return [];
          return uniq((this.workbenchBulkSelection && this.workbenchBulkSelection.keys) || []);
        },
        workbenchBulkSelectedCount(area) {
          return this.workbenchBulkKeys(area).length;
        },
        workbenchBulkIsSelected(desc) {
          return !!(desc && this.workbenchBulkScopeActive(desc.area, desc.scope) && this.workbenchBulkKeys(desc.area).includes(String(desc.key)));
        },
        workbenchBulkRowClass(desc) {
          if (!desc || !desc.key) return {};
          return {
            'is-bulk-mode': this.workbenchBulkScopeActive(desc.area, desc.scope),
            'is-bulk-selected': this.workbenchBulkIsSelected(desc),
          };
        },
        resetWorkbenchBulkSelection(area) {
          if (area && !this.workbenchBulkAreaActive(area)) return;
          this.workbenchBulkSelection = { area: null, scope: null, keys: [] };
        },
        workbenchBulkSelectableKeys(area, scope) {
          const out = [];
          const pushKey = (key) => {
            const s = String(key || '');
            if (s) out.push(s);
          };
          const walkTree = (nodes) => {
            (nodes || []).forEach((node) => {
              pushKey(this.workbenchBulkTreeNodeKey(area, node));
              walkTree(node && node.children);
            });
          };
          if (area === 'resource' && scope === 'material') {
            const view = String(this.workbenchMaterialStatusView || 'all');
            if (view === 'queued' || view === 'parsing' || view === 'failed') {
              (this.workbenchRawMaterialsForTree || []).forEach((m) => {
                if (m && this.workbenchMaterialStatusOf(m) === view) pushKey(`resource:material:${m.id}`);
              });
            } else {
              walkTree(this.workbenchMaterialFileTreeData || []);
            }
          } else if (area === 'resource' && scope === 'database') {
            (this.filteredDatabaseResources || []).forEach((tbl) => {
              const desc = this.workbenchBulkDbTableDescriptor(tbl);
              if (desc) pushKey(desc.key);
            });
          } else if (area === 'result') {
            walkTree(this.workbenchAnalysisResultAntTreeData || []);
          } else if (area === 'task' && scope === 'batch-child') {
            (this.filteredBatchChildren || []).forEach((child) => {
              const desc = this.workbenchBulkBatchChildDescriptor(child);
              if (desc) pushKey(desc.key);
            });
          } else if (area === 'task') {
            (this.workbenchTaskTreeSections || []).forEach((section) => {
              (section.children || []).forEach((node) => {
                const desc = this.workbenchBulkTaskDescriptor(node);
                if (desc) pushKey(desc.key);
              });
            });
          }
          return uniq(out);
        },
        workbenchBulkAllSelected(area, scope) {
          const keys = this.workbenchBulkSelectableKeys(area, scope);
          const selected = new Set(this.workbenchBulkKeys(area));
          return !!keys.length && keys.every((key) => selected.has(key));
        },
        workbenchBulkSomeSelected(area, scope) {
          const keys = this.workbenchBulkSelectableKeys(area, scope);
          const selected = new Set(this.workbenchBulkKeys(area));
          const count = keys.filter((key) => selected.has(key)).length;
          return count > 0 && count < keys.length;
        },
        toggleWorkbenchBulkSelectAll(area, scope, evOrChecked) {
          const keys = this.workbenchBulkSelectableKeys(area, scope);
          if (!keys.length) return;
          let checked = true;
          if (typeof evOrChecked === 'boolean') checked = evOrChecked;
          else if (evOrChecked && evOrChecked.target && typeof evOrChecked.target.checked === 'boolean') checked = evOrChecked.target.checked;
          if (checked) {
            this.workbenchBulkSelection = { area: String(area), scope: String(scope || area), keys };
            return;
          }
          const removing = new Set(keys);
          const next = this.workbenchBulkKeys(area).filter((key) => !removing.has(key));
          this.workbenchBulkSelection = { area: String(area), scope: String(scope || area), keys: next };
        },
        startWorkbenchBulkMode(area, scope) {
          this.workbenchBulkSelection = { area: String(area), scope: String(scope || area), keys: [] };
        },
        toggleWorkbenchBulkSelection(desc, evOrChecked, force) {
          if (!desc || !desc.area || !desc.key) return;
          const area = String(desc.area);
          const scope = String(desc.scope || area);
          const key = String(desc.key);
          let keys = this.workbenchBulkScopeActive(area, scope) ? this.workbenchBulkKeys(area) : [];
          let checked = force;
          if (checked === undefined) {
            if (evOrChecked && evOrChecked.target && typeof evOrChecked.target.checked === 'boolean') checked = evOrChecked.target.checked;
            else checked = !keys.includes(key);
          }
          const cascadeKeys = this.workbenchBulkCascadeKeys(desc);
          if (checked) {
            keys = uniq([...keys, ...cascadeKeys]);
          } else {
            const removing = new Set([...cascadeKeys, ...this.workbenchBulkAncestorFolderKeys(desc)]);
            keys = keys.filter((item) => !removing.has(item));
          }
          this.workbenchBulkSelection = { area, scope, keys };
        },
        startWorkbenchBulkSelection(desc) {
          this.toggleWorkbenchBulkSelection(desc, null, true);
        },
        handleWorkbenchBulkRowClick(ev, desc) {
          if (!desc || !desc.key) return false;
          if (this.workbenchBulkScopeActive(desc.area, desc.scope)) {
            this.toggleWorkbenchBulkSelection(desc);
            return true;
          }
          return false;
        },
        onWorkbenchBulkMaterialFolderRowClick(ev, d) {
          const desc = this.workbenchBulkMaterialFolderDescriptor(d);
          if (this.workbenchBulkScopeActive('resource', 'material')) {
            this.onWorkbenchMaterialFolderRowClick(d);
            return;
          }
          if (this.handleWorkbenchBulkRowClick(ev, desc)) return;
          this.onWorkbenchMaterialFolderRowClick(d);
        },
        onWorkbenchBulkMaterialFileRowClick(ev, d) {
          const desc = this.workbenchBulkMaterialFileDescriptor(d);
          if (this.handleWorkbenchBulkRowClick(ev, desc)) return;
          this.onWorkbenchMaterialFileTreeRawClick(d);
        },
        onWorkbenchBulkStatusNodeRowClick(ev, node, sectionKey) {
          const desc = this.workbenchBulkStatusNodeDescriptor(node, sectionKey);
          if (this.handleWorkbenchBulkRowClick(ev, desc)) return;
          this.selectTreeNode(node, sectionKey);
        },
        onWorkbenchBulkDbTableRowClick(ev, tbl) {
          const desc = this.workbenchBulkDbTableDescriptor(tbl);
          if (this.handleWorkbenchBulkRowClick(ev, desc)) return;
          this.previewDbTableResource(tbl);
        },
        onWorkbenchBulkResultFolderRowClick(ev, d) {
          const desc = this.workbenchBulkResultFolderDescriptor(d);
          if (this.workbenchBulkScopeActive('result', 'result')) {
            this.onWorkbenchAnalysisResultFolderRowClick(d);
            return;
          }
          if (this.handleWorkbenchBulkRowClick(ev, desc)) return;
          this.onWorkbenchAnalysisResultFolderRowClick(d);
        },
        onWorkbenchBulkResultFileRowClick(ev, d) {
          const desc = this.workbenchBulkResultFileDescriptor(d);
          if (this.handleWorkbenchBulkRowClick(ev, desc)) return;
          this.onWorkbenchAnalysisResultTreeLeafClick(d);
        },
        onWorkbenchBulkTaskNodeRowClick(ev, node, sectionKey) {
          const desc = this.workbenchBulkTaskDescriptor(node);
          if (this.handleWorkbenchBulkRowClick(ev, desc)) return;
          this.selectTreeNode(node, sectionKey);
        },
        onWorkbenchBulkBatchChildRowOpen(ev, child) {
          const desc = this.workbenchBulkBatchChildDescriptor(child);
          if (this.handleWorkbenchBulkRowClick(ev, desc)) return;
          this.openMaterialDetail(child);
        },
        workbenchBulkMaterialFolderDescriptor(d) {
          const id = String((d && d.folderId) || '').trim();
          if (!id) return null;
          return { area: 'resource', scope: 'material', key: `resource:folder:${id}`, kind: 'resource-folder', raw: d, availableActions: ['ref', 'download', 'delete'] };
        },
        workbenchBulkMaterialFileDescriptor(d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return null;
          const st = this.workbenchMaterialStatusOf(m);
          return { area: 'resource', scope: 'material', key: `resource:material:${m.id}`, kind: 'resource-material', status: st, raw: m, node: d, availableActions: materialStatusActions(st, ['ref', 'download', 'delete']) };
        },
        workbenchBulkStatusNodeDescriptor(node, sectionKey) {
          if (!node || sectionKey !== 'material') return null;
          const m = node.raw;
          if (!m) return null;
          const st = this.workbenchMaterialStatusOf(m);
          return { area: 'resource', scope: 'material', key: `resource:material:${m.id}`, kind: 'resource-material', status: st, raw: m, node, availableActions: materialStatusActions(st, ['ref', 'download', 'delete']) };
        },
        workbenchBulkDbTableDescriptor(tbl) {
          const id = String((tbl && tbl.id) || '').trim();
          if (!id) return null;
          return { area: 'resource', scope: 'database', key: `resource:db:${id}`, kind: 'database-table', raw: tbl, availableActions: ['delete'] };
        },
        workbenchBulkResultFolderDescriptor(d) {
          const id = String((d && d.userFolderId) || '').trim();
          if (!id) return null;
          return { area: 'result', scope: 'result', key: `result:folder:${id}`, kind: 'result-folder', raw: d, availableActions: ['download', 'delete'] };
        },
        workbenchBulkResultFileDescriptor(d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return null;
          return { area: 'result', scope: 'result', key: `result:material:${m.id}`, kind: 'result-material', raw: m, node: d, availableActions: ['ref', 'download', 'delete'] };
        },
        workbenchBulkTaskDescriptor(node) {
          const m = node && node.raw;
          if (!m || this.isWorkbenchBatchParentTask(m)) return null;
          const st = this.workbenchAnalysisStatusOf(m);
          return { area: 'task', scope: 'task', key: `task:item:${m.id}`, kind: 'task', status: st, raw: m, node, availableActions: taskStatusActions(st) };
        },
        workbenchBulkBatchChildDescriptor(child) {
          if (!child) return null;
          const st = this.workbenchAnalysisStatusOf(child);
          return { area: 'task', scope: 'batch-child', key: `task:item:${child.id}`, kind: 'batch-child', status: st, raw: child, availableActions: batchChildStatusActions(st) };
        },
        workbenchBulkTreeNodeKey(area, node) {
          if (!node) return '';
          if (area === 'resource') {
            if (node.isFolder && node.folderId) return `resource:folder:${node.folderId}`;
            if (!node.isFolder && node.materialId) return `resource:material:${node.materialId}`;
          }
          if (area === 'result') {
            if (node.isFolder && node.userFolderId) return `result:folder:${node.userFolderId}`;
            if (!node.isFolder && node.materialId) return `result:material:${node.materialId}`;
          }
          return '';
        },
        findWorkbenchBulkTreeNode(area, key) {
          const nodes = area === 'resource' ? this.workbenchMaterialFileTreeData : this.workbenchAnalysisResultAntTreeData;
          let hit = null;
          const walk = (list) => {
            (list || []).forEach((node) => {
              if (hit || !node) return;
              if (this.workbenchBulkTreeNodeKey(area, node) === key) {
                hit = node;
                return;
              }
              walk(node.children || []);
            });
          };
          walk(nodes || []);
          return hit;
        },
        workbenchBulkTreeDescendantKeys(area, node) {
          const out = [];
          const walk = (list) => {
            (list || []).forEach((child) => {
              const key = this.workbenchBulkTreeNodeKey(area, child);
              if (key) out.push(key);
              walk(child && child.children);
            });
          };
          walk(node && node.children);
          return out;
        },
        workbenchBulkCascadeKeys(desc) {
          if (!desc || !desc.key) return [];
          const keys = [String(desc.key)];
          if (desc.kind !== 'resource-folder' && desc.kind !== 'result-folder') return keys;
          const node = this.findWorkbenchBulkTreeNode(desc.area, String(desc.key));
          return uniq([...keys, ...this.workbenchBulkTreeDescendantKeys(desc.area, node)]);
        },
        workbenchBulkAncestorFolderKeys(desc) {
          if (!desc || !desc.area || !desc.raw) return [];
          const out = [];
          if (desc.area === 'resource') {
            const folders = this.workbenchMaterialFoldersList || [];
            const byId = new Map(folders.map((f) => [String(f.id), f]));
            let pid = '';
            if (desc.kind === 'resource-material') {
              const ps = desc.raw.projectSource || {};
              pid = ps.parentId != null && ps.parentId !== '' ? String(ps.parentId) : '';
            } else if (desc.kind === 'resource-folder') {
              const f = byId.get(String(desc.raw.folderId || ''));
              pid = f && f.parentId != null && f.parentId !== '' ? String(f.parentId) : '';
            }
            const guard = new Set();
            while (pid && byId.has(pid) && !guard.has(pid)) {
              guard.add(pid);
              out.push(`resource:folder:${pid}`);
              const f = byId.get(pid);
              pid = f && f.parentId != null && f.parentId !== '' ? String(f.parentId) : '';
            }
          }
          if (desc.area === 'result') {
            const folders = this.workbenchAnalysisResultFoldersList || [];
            const byId = new Map(folders.map((f) => [String(f.id), f]));
            let pid = '';
            if (desc.kind === 'result-material') {
              const ps = desc.raw.projectSource || {};
              pid = ps.resultFolderId != null && ps.resultFolderId !== '' ? String(ps.resultFolderId) : '';
            } else if (desc.kind === 'result-folder') {
              const f = byId.get(String(desc.raw.userFolderId || ''));
              pid = f && f.parentId != null && f.parentId !== '' ? String(f.parentId) : '';
            }
            const guard = new Set();
            while (pid && byId.has(pid) && !guard.has(pid)) {
              guard.add(pid);
              out.push(`result:folder:${pid}`);
              const f = byId.get(pid);
              pid = f && f.parentId != null && f.parentId !== '' ? String(f.parentId) : '';
            }
          }
          return out;
        },
        findWorkbenchBulkResultFolderNode(id) {
          const target = String(id || '');
          let hit = null;
          const walk = (nodes) => {
            (nodes || []).forEach((node) => {
              if (hit || !node) return;
              if (node.isFolder && String(node.userFolderId || '') === target) {
                hit = node;
                return;
              }
              walk(node.children || []);
            });
          };
          walk(this.workbenchAnalysisResultAntTreeData || []);
          return hit;
        },
        resolveWorkbenchBulkDescriptor(key) {
          const parts = String(key || '').split(':');
          if (parts.length < 3) return null;
          const area = parts[0];
          const kind = parts[1];
          const id = parts.slice(2).join(':');
          if (area === 'resource' && kind === 'material') {
            const m = this.wbMaterialVmById(id);
            if (!m) return null;
            const st = this.workbenchMaterialStatusOf(m);
            return { area, key, kind: 'resource-material', status: st, raw: m, availableActions: materialStatusActions(st, ['ref', 'download', 'delete']) };
          }
          if (area === 'resource' && kind === 'folder') {
            const f = (this.workbenchMaterialFoldersList || []).find((row) => String(row.id) === id);
            const raw = { folderId: id, title: (f && f.name) || '文件夹' };
            return { area, key, kind: 'resource-folder', raw, availableActions: ['ref', 'download', 'delete'] };
          }
          if (area === 'resource' && kind === 'db') {
            const row = (this.dbResourceList || []).find((tbl) => String(tbl.id) === id);
            if (!row) return null;
            return { area, key, kind: 'database-table', raw: row, availableActions: ['delete'] };
          }
          if (area === 'result' && kind === 'material') {
            const m = this.wbMaterialVmById(id);
            if (!m) return null;
            return { area, key, kind: 'result-material', raw: m, availableActions: ['ref', 'download', 'delete'] };
          }
          if (area === 'result' && kind === 'folder') {
            const raw = this.findWorkbenchBulkResultFolderNode(id) || { userFolderId: id, title: '结果文件夹' };
            return { area, key, kind: 'result-folder', raw, availableActions: ['download', 'delete'] };
          }
          if (area === 'task' && kind === 'item') {
            const m = this.findWorkbenchTaskById(id) || this.findWorkbenchTaskChildById(id);
            if (!m || this.isWorkbenchBatchParentTask(m)) return null;
            const st = this.workbenchAnalysisStatusOf(m);
            const isChild = this.isWorkbenchBatchChildTask(m);
            return { area, key, kind: isChild ? 'batch-child' : 'task', status: st, raw: m, availableActions: isChild ? batchChildStatusActions(st) : taskStatusActions(st) };
          }
          return null;
        },
        workbenchBulkSelectedDescriptors(area) {
          return this.workbenchBulkKeys(area).map((key) => this.resolveWorkbenchBulkDescriptor(key)).filter(Boolean);
        },
        workbenchBulkActionKeys(area, group) {
          const items = this.workbenchBulkSelectedDescriptors(area);
          const isTaskScope = area === 'task';
          const actions = isTaskScope
            ? uniq(items.flatMap((item) => item.availableActions || []))
            : intersectActions(items);
          const primary = ['ref', 'download', 'abort', 'rerun'];
          const sensitive = ['delete'];
          const order = [...primary, ...sensitive];
          if (actions.length <= 3) {
            return group === 'more' ? [] : order.filter((action) => actions.includes(action));
          }
          const visible = group === 'more' ? sensitive : primary;
          return visible.filter((action) => actions.includes(action));
        },
        workbenchBulkActionLabel(action, area) {
          const items = this.workbenchBulkSelectedDescriptors(area);
          if (action === 'ref') return '添加到对话';
          if (action === 'download') return items.some((item) => item.kind.indexOf('folder') >= 0) ? '打包下载' : '下载';
          if (action === 'abort') return '中止';
          if (action === 'rerun') return '重跑';
          if (action === 'delete') return '删除';
          return action;
        },
        workbenchBulkActionIcon(action) {
          return {
            ref: 'chat-ref',
            download: 'download',
            abort: 'pause',
            rerun: 'redo',
            delete: 'trash',
          }[action] || 'more';
        },
        workbenchBulkAreaLabel(area) {
          return ({ resource: '资源', result: '结果', task: '任务' })[area] || '项目';
        },
        onWorkbenchBulkAction(area, action) {
          const items = this.workbenchBulkSelectedDescriptors(area).filter((item) => (item.availableActions || []).includes(action));
          if (!items.length) return;
          if (action === 'ref') return this.applyWorkbenchBulkRef(area, items);
          if (action === 'download') return this.applyWorkbenchBulkDownload(area, items);
          if (action === 'abort') return this.confirmWorkbenchBulkAbort(area, items);
          if (action === 'rerun') return this.confirmWorkbenchBulkRerun(area, items);
          if (action === 'delete') return this.confirmWorkbenchBulkDelete(area, items);
        },
        applyWorkbenchBulkRef(area, items) {
          items.forEach((item) => {
            if (item.kind === 'resource-folder') this.toggleWorkbenchMaterialFolderInChat(item.raw);
            if (item.kind === 'resource-material') this.handleTreeContextMenu('ref', { id: item.raw.id, raw: item.raw }, 'material');
            if (item.kind === 'result-material') this.handleTreeContextMenu('ref', { id: item.raw.id, raw: item.raw }, 'analysis', 'result');
          });
          this._setWorkbenchBatchToast(`已添加 ${items.length} 项到对话`, 1500);
        },
        applyWorkbenchBulkDownload(area, items) {
          if (area === 'result') {
            this.openWorkbenchPackageDownloadModalFromBulk(items);
            return;
          }
          items.forEach((item) => {
            if (item.kind === 'result-folder') this.downloadWorkbenchAnalysisResultFolderZip(item.raw, 'keep');
          });
          this._setWorkbenchBatchToast(`已开始下载 ${items.length} 项`, 1500);
        },
        confirmWorkbenchBulkAbort(area, items) {
          const n = items.length;
          window.dsConfirm.action({
            title: `中止已选 ${n} 项？`,
            content: '中止后将标记为失败。',
            okText: '中止',
            onOk: () => this.applyWorkbenchBulkAbort(area, items),
          });
        },
        applyWorkbenchBulkAbort(area, items) {
          items.forEach((item) => {
            if (item.kind === 'resource-material') this._applyAbortWorkbenchMaterial(item.raw);
            if (item.kind === 'task' || item.kind === 'batch-child') {
              const t = this.resolveCreatedWorkbenchTaskRef(item.raw) || this.resolveDemoWorkbenchTaskRef(item.raw) || item.raw;
              this.clearBatchChildRerunTimers(t);
              this.setWorkbenchTaskStatus(t, 'failed');
              const parent = this.findWorkbenchBatchParentOfChild(t);
              if (parent) this.syncBatchParentStatus(parent);
            }
          });
          this.resetWorkbenchBulkSelection(area);
          this._setWorkbenchBatchToast(`已中止 ${items.length} 项`, 1500);
        },
        confirmWorkbenchBulkRerun(area, items) {
          const n = items.length;
          window.dsConfirm.action({
            title: `重跑已选 ${n} 项？`,
            content: '将重新进入执行队列。',
            okText: '重跑',
            onOk: () => this.applyWorkbenchBulkRerun(area, items),
          });
        },
        applyWorkbenchBulkRerun(area, items) {
          items.forEach((item) => {
            if (item.kind === 'resource-material') {
              const arr = demoProjectMaterialsById[this.workbenchProjectId] || [];
              const row = arr.find((r) => r && String(r.id) === String(item.raw.id));
              if (row) {
                row.status = 'parsing';
                row.progress = 12;
              }
              if (item.raw.projectSource) {
                item.raw.projectSource.status = 'parsing';
                item.raw.projectSource.progress = 12;
              }
            }
            if (item.kind === 'task' || item.kind === 'batch-child') {
              const t = this.resolveCreatedWorkbenchTaskRef(item.raw) || this.resolveDemoWorkbenchTaskRef(item.raw) || item.raw;
              this.setWorkbenchTaskStatus(t, 'parsing');
              const parent = this.findWorkbenchBatchParentOfChild(t);
              if (parent) this.syncBatchParentStatus(parent);
            }
          });
          this.resetWorkbenchBulkSelection(area);
          this._setWorkbenchBatchToast(`已重跑 ${items.length} 项`, 1500);
        },
        confirmWorkbenchBulkDelete(area, items) {
          const n = items.length;
          window.dsConfirm.delete({
            batchTitle: `删除已选 ${n} 项？`,
            kind: area === 'task' ? 'task' : 'default',
            onOk: () => this.applyWorkbenchBulkDelete(area, items),
          });
        },
        applyWorkbenchBulkDelete(area, items) {
          const pid = this.workbenchProjectId;
          items.forEach((item) => {
            if (item.kind === 'resource-material' || item.kind === 'result-material') this._applyDeleteMaterial(item.raw);
            if (item.kind === 'resource-folder') {
              this.wbDeleteFolderTarget = { folderId: String(item.raw.folderId), name: item.raw.title || '文件夹' };
              this.confirmDeleteWorkbenchMaterialFolder();
            }
            if (item.kind === 'database-table') {
              this.dbResourceList = (this.dbResourceList || []).filter((tbl) => String(tbl.id) !== String(item.raw.id));
            }
            if (item.kind === 'result-folder') this.applyWorkbenchBulkDeleteResultFolder(item.raw.userFolderId);
            if (item.kind === 'task' || item.kind === 'batch-child') this.applyWorkbenchBulkDeleteTask(item.raw);
          });
          this.resetWorkbenchBulkSelection(area);
          this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          if (pid) this.refreshWorkbenchDemoResources(area === 'resource' ? 'material' : area);
          this._setWorkbenchBatchToast(`已删除 ${items.length} 项`, 1500);
        },
        applyWorkbenchBulkDeleteResultFolder(folderId) {
          const pid = this.workbenchProjectId;
          if (!pid || !folderId || typeof demoProjectAnalysisResultFoldersById === 'undefined') return;
          const folds = demoProjectAnalysisResultFoldersById[pid] || [];
          const delIds = this.collectWorkbenchAnalysisResultFolderSubtreeIds(folderId, folds);
          (this.materials || []).forEach((m) => {
            if (!m || m.type !== 'analysis') return;
            const ps = m.projectSource || {};
            const rid = String(ps.resultFolderId || '');
            if (rid && delIds.has(rid)) m.projectSource = { ...ps, resultFolderId: null };
          });
          if (typeof demoProjectAnalysisResultsById !== 'undefined') {
            (demoProjectAnalysisResultsById[pid] || []).forEach((r) => {
              if (r && delIds.has(String(r.resultFolderId || ''))) r.resultFolderId = null;
            });
          }
          demoProjectAnalysisResultFoldersById[pid] = folds.filter((f) => !delIds.has(String(f.id)));
        },
        applyWorkbenchBulkDeleteTask(task) {
          if (!task || !task.id) return;
          const id = String(task.id);
          const removeFrom = (rows) => {
            if (!Array.isArray(rows)) return;
            for (let i = rows.length - 1; i >= 0; i -= 1) {
              const row = rows[i];
              if (!row) continue;
              if (String(row.id) === id) {
                rows.splice(i, 1);
                continue;
              }
              if (Array.isArray(row.children)) row.children = row.children.filter((child) => child && String(child.id) !== id);
            }
          };
          removeFrom(this.workbenchCreatedTasks);
          if (typeof demoWorkbenchTaskRows !== 'undefined') removeFrom(demoWorkbenchTaskRows);
          if (this.selectedMaterialId === id) this.selectedMaterialId = null;
        },
        applyWorkbenchBulkTreeDrop(area, info) {
          if (!this.workbenchBulkAreaActive(area) || !(this.workbenchBulkSelectedCount(area) > 0)) return false;
          if (info && info.dropToGap === true) {
            message.info('批量移动请拖入目标文件夹');
            return true;
          }
          const drop = parseTreeKey(materialTreeKeyFromNode(info && info.node));
          if (area === 'resource') {
            if (drop.kind !== 'folder' || !drop.id) {
              message.warning('请选择目标文件夹');
              return true;
            }
            const items = this.workbenchBulkSelectedDescriptors('resource');
            if (items.some((item) => item.kind !== 'resource-material' && item.kind !== 'resource-folder')) {
              message.warning('当前选择包含不可移动对象');
              return true;
            }
            const pid = this.workbenchProjectId;
            const mats = demoProjectMaterialsById[pid] || [];
            const folds = demoProjectMaterialFoldersById[pid] || [];
            const invalidFolderMove = items.some((item) => {
              if (item.kind !== 'resource-folder') return false;
              const ids = this.collectWorkbenchMaterialFolderSubtreeIds(item.raw.folderId);
              return ids && ids.has(String(drop.id));
            });
            if (invalidFolderMove) {
              message.warning('不能将文件夹移入自身或其子文件夹');
              return true;
            }
            items.forEach((item) => {
              if (item.kind === 'resource-material') {
                const idx = mats.findIndex((row) => row && String(row.id) === String(item.raw.id));
                if (idx >= 0) mats[idx] = { ...mats[idx], parentId: drop.id };
              } else {
                const idx = folds.findIndex((row) => row && String(row.id) === String(item.raw.folderId));
                if (idx >= 0) folds[idx] = { ...folds[idx], parentId: drop.id };
              }
            });
          } else if (area === 'result') {
            if (drop.kind !== 'folder' || !drop.id) {
              message.warning('请选择目标结果文件夹');
              return true;
            }
            const items = this.workbenchBulkSelectedDescriptors('result');
            if (items.some((item) => item.kind !== 'result-material' && item.kind !== 'result-folder')) {
              message.warning('当前选择包含不可移动对象');
              return true;
            }
            const pid = this.workbenchProjectId;
            const rows = demoProjectAnalysisResultsById[pid] || [];
            const folds = demoProjectAnalysisResultFoldersById[pid] || [];
            const invalidFolderMove = items.some((item) => {
              if (item.kind !== 'result-folder') return false;
              const ids = this.collectWorkbenchAnalysisResultFolderSubtreeIds(item.raw.userFolderId, folds);
              return ids && ids.has(String(drop.id));
            });
            if (invalidFolderMove) {
              message.warning('不能将文件夹移入自身或其子文件夹');
              return true;
            }
            items.forEach((item) => {
              if (item.kind === 'result-material') {
                const idx = rows.findIndex((row) => row && String(row.id) === String(item.raw.id));
                if (idx >= 0) rows[idx] = { ...rows[idx], resultFolderId: drop.id };
                if (item.raw.projectSource) item.raw.projectSource = { ...item.raw.projectSource, resultFolderId: drop.id };
              } else {
                const idx = folds.findIndex((row) => row && String(row.id) === String(item.raw.userFolderId));
                if (idx >= 0) folds[idx] = { ...folds[idx], parentId: drop.id };
              }
            });
          } else {
            return false;
          }
          this.resetWorkbenchBulkSelection(area);
          this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          message.success('已批量移动');
          return true;
        }
  };
})();
