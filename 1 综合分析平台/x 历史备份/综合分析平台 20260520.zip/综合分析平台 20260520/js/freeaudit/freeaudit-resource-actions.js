(function () {
  const NS = window.DemoFreeAudit = window.DemoFreeAudit || {};

  const Modal = antd.Modal;
  const message = antd.message;
  const freeauditUtils = window.__DEMO_FREEAUDIT_UTILS || {};
  const getFreeAuditQuery = freeauditUtils.getFreeAuditQuery || function () { return {}; };
  const presetSuggestions = freeauditUtils.presetSuggestions || [];
  const WORKBENCH_PROJECT_NAME_BY_ID = freeauditUtils.WORKBENCH_PROJECT_NAME_BY_ID || {};
  const SUMMARY_RESPONSE_DEMO = freeauditUtils.SUMMARY_RESPONSE_DEMO || '';
  const DEMO_RUN_SUMMARY_TEXT = freeauditUtils.DEMO_RUN_SUMMARY_TEXT || '';
  const demoToolDiffLineClass = freeauditUtils.demoToolDiffLineClass || function () { return 'nlm-tool-diff-line--ctx'; };
  const demoLinesUnifiedDiff = freeauditUtils.demoLinesUnifiedDiff || function () { return { lines: [], truncated: false }; };
  const toAnalysisTemplateShared = freeauditUtils.toAnalysisTemplateShared || function (seed) { return seed; };
  const buildWorkbenchMaterialAntTreeData = freeauditUtils.buildWorkbenchMaterialAntTreeData || function () { return { treeData: [], autoExpandKeys: [] }; };
  const buildWorkbenchAnalysisResultAntTreeData = freeauditUtils.buildWorkbenchAnalysisResultAntTreeData || function () { return { treeData: [], autoExpandKeys: [], initialExpandKeys: [] }; };
  const buildWorkbenchAnalysisResultFolderPickerTree = freeauditUtils.buildWorkbenchAnalysisResultFolderPickerTree || function () { return []; };
  const WB_TASK_CREATE_RESULT_OUTPUT_ROOT = freeauditUtils.WB_TASK_CREATE_RESULT_OUTPUT_ROOT || '__root__';
  const resolveWbTaskCreateResultOutputFolder = freeauditUtils.resolveWbTaskCreateResultOutputFolder || function () { return { folderId: null, folderLabel: '根目录' }; };
  const applyWorkbenchMaterialTreeDrop = freeauditUtils.applyWorkbenchMaterialTreeDrop || function () { return { ok: false, message: '未实现' }; };
  const applyWorkbenchAnalysisResultTreeDrop = freeauditUtils.applyWorkbenchAnalysisResultTreeDrop || function () { return { ok: false, message: '未实现' }; };
  const wbMatMaterialPathPrefixForRow = freeauditUtils.wbMatMaterialPathPrefixForRow || function () { return ''; };
  const wbMatAntTreeKey = freeauditUtils.wbMatAntTreeKey || function (k, id) { return `${k}:${id}`; };

  NS.actionGroups = NS.actionGroups || {};
  NS.actionGroups.resourceActions = {
        workbenchResourceDrawerHeadLabel(key) {
          const names = {
            file: '文件',
            database: '数据库表',
            graph: '数据图谱',
            knowledge: '知识库',
          };
          return names[String(key || '')] || '';
        },
        workbenchResourceDrawerHeadCount(key) {
          const counts = this.workbenchResourceDrawerCounts || {};
          return Number(counts[key]) || 0;
        },
        toggleResourceDrawer(key) {
          if (!key || !this.resourceDrawerOpen || !(key in this.resourceDrawerOpen)) return;
          this.resourceDrawerOpen[key] = !this.resourceDrawerOpen[key];
          this.$nextTick(() => this.updateResourceDrawerHeights());
        },
        ensureResourceDrawerOpen(key) {
          if (!key || !this.resourceDrawerOpen || !(key in this.resourceDrawerOpen)) return;
          this.sourcesCollapsed = false;
          if (!this.resourceDrawerOpen[key]) this.resourceDrawerOpen[key] = true;
          this.$nextTick(() => this.updateResourceDrawerHeights());
        },
        toggleWorkbenchMaterialSearchPanel() {
          this.workbenchMaterialSearchOpen = !this.workbenchMaterialSearchOpen;
          if (!this.workbenchMaterialSearchOpen) this.materialSearchQuery = '';
        },
        findWorkbenchTaskChildById(id) {
          const tid = String(id || '');
          if (!tid) return null;
          const sources = [...(this.workbenchCreatedTasks || []), ...(this.workbenchTaskDemoRows || [])];
          for (let i = 0; i < sources.length; i += 1) {
            const t = sources[i];
            if (!t || !Array.isArray(t.children)) continue;
            const c = t.children.find((x) => x && x.id === tid);
            if (c) return c;
          }
          return null;
        },
        mockWbTaskCreateDataSourceUpload() {
          if (this.wbTaskCreateForm.dataSourceFile) return;
          this.applyWbTaskCreateDataSourceFile('企业清单-跑批样本.xlsx');
        },
        beforeWbTaskCreateDataSourceUpload(file) {
          const name = String((file && file.name) || '').trim();
          if (!name) return false;
          this.applyWbTaskCreateDataSourceFile(name);
          return false;
        },
        onWbTaskCreateResourceTabChange(tab) {
          const next = String(tab || 'file');
          this.wbTaskCreateForm.resourceTab = next;
          this.wbTaskCreateForm.resourceQuery = '';
          this.syncWbTaskCreateTreeExpandedKeys(next);
        },
        syncWbTaskCreateTreeExpandedKeys(tab) {
          const f = this.wbTaskCreateForm || {};
          const t = String(tab || f.resourceTab || 'file');
          if (t === 'file') {
            f.fileExpandedKeys = (this.wbTaskCreateFileTreeFolderKeys || []).slice();
          } else if (t === 'result') {
            f.resultExpandedKeys = (this.wbTaskCreateResultTreeFolderKeys || []).slice();
          }
        },
        wbTaskCreateTreeNodeCoveredKeys(node, tab) {
          const t = String(tab || (this.wbTaskCreateForm && this.wbTaskCreateForm.resourceTab) || 'file');
          const keys = [];
          const walk = (n) => {
            if (!n) return;
            if (n.isFolder) {
              (n.children || []).forEach(walk);
              return;
            }
            const mapped = this.wbTaskCreateTreeNodeToResource(n, t);
            if (mapped && mapped.key) keys.push(mapped.key);
          };
          walk(node);
          return Array.from(new Set(keys));
        },
        wbTaskCreateTreeNodeToResource(node, tab) {
          if (!node) return null;
          const t = String(tab || (this.wbTaskCreateForm && this.wbTaskCreateForm.resourceTab) || 'file');
          if (t === 'file') {
            if (node.isFolder) {
              const id = String(node.folderId || '').trim();
              if (!id) return null;
              return {
                key: `file-folder:${id}`,
                type: 'file-folder',
                typeLabel: '文件夹',
                id,
                name: String(node.title || '未命名文件夹'),
                iconClass: 'folder',
                iconToneClass: '',
                coveredResourceKeys: this.wbTaskCreateTreeNodeCoveredKeys(node, t),
              };
            }
            const id = String(node.materialId || '').trim();
            const vm = id ? this.wbMaterialVmById(id) : null;
            if (!id) return null;
            return {
              key: `file:${id}`,
              type: 'file',
              typeLabel: '文件',
              id,
              name: String((vm && vm.title) || node.title || '未命名文件'),
              iconClass: this.getMaterialIcon(vm || { title: node.title, type: 'raw' }),
              iconToneClass: this.getMaterialIconColorClass(vm || { type: 'raw' }),
            };
          }
          if (t === 'result') {
            if (node.isFolder) {
              const id = String(node.userFolderId || node.key || '').trim();
              if (!id) return null;
              return {
                key: `result-folder:${id}`,
                type: 'result-folder',
                typeLabel: '结果文件夹',
                id,
                name: String(node.title || node.folderName || '未命名结果文件夹'),
                iconClass: 'folder',
                iconToneClass: 'is-result',
                coveredResourceKeys: this.wbTaskCreateTreeNodeCoveredKeys(node, t),
              };
            }
            const id = String(node.materialId || '').trim();
            const vm = id ? this.wbMaterialVmById(id) : null;
            if (!id) return null;
            return {
              key: `result:${id}`,
              type: 'result',
              typeLabel: '结果',
              id,
              name: String((vm && vm.title) || node.title || '未命名结果'),
              iconClass: 'file-text',
              iconToneClass: 'is-result',
            };
          }
          return null;
        },
        wbTaskCreateTreeNodeMatchesQuery(node) {
          const q = String((this.wbTaskCreateForm && this.wbTaskCreateForm.resourceQuery) || '').trim().toLowerCase();
          if (!q) return true;
          return String((node && node.title) || '').toLowerCase().includes(q);
        },
        collectWbTaskCreateCurrentTreeResources() {
          const tab = String((this.wbTaskCreateForm && this.wbTaskCreateForm.resourceTab) || 'file');
          const q = String((this.wbTaskCreateForm && this.wbTaskCreateForm.resourceQuery) || '').trim().toLowerCase();
          const roots = tab === 'result' ? (this.wbTaskCreateResultTreeData || []) : (this.wbTaskCreateFileTreeData || []);
          const out = [];
          const visit = (node) => {
            if (!node) return;
            const titleMatches = !q || String(node.title || '').toLowerCase().includes(q);
            if (node.isFolder) {
              if (!q || titleMatches) {
                this.wbTaskCreateTreeNodeLeafResources(node, tab).forEach((item) => out.push(item));
                return;
              }
              (node.children || []).forEach(visit);
              return;
            }
            if (!q || titleMatches) {
              const mapped = this.wbTaskCreateTreeNodeToResource(node, tab);
              if (mapped) out.push(mapped);
            }
          };
          roots.forEach(visit);
          const byKey = new Map();
          out.forEach((item) => {
            if (item && item.key && !byKey.has(item.key)) byKey.set(item.key, item);
          });
          return Array.from(byKey.values());
        },
        toggleWbTaskCreateTreeNodeExpanded(node, tab) {
          if (!node || !node.isFolder || node.key == null) return;
          const t = String(tab || (this.wbTaskCreateForm && this.wbTaskCreateForm.resourceTab) || 'file');
          const field = t === 'result' ? 'resultExpandedKeys' : 'fileExpandedKeys';
          const f = this.wbTaskCreateForm || {};
          const key = String(node.key);
          const expanded = new Set((f[field] || []).map(String));
          if (expanded.has(key)) expanded.delete(key);
          else expanded.add(key);
          f[field] = Array.from(expanded);
        },
        wbTaskCreateTreeNodeAllResourceKeys(node, tab) {
          const t = String(tab || (this.wbTaskCreateForm && this.wbTaskCreateForm.resourceTab) || 'file');
          const keys = [];
          const walk = (n) => {
            if (!n) return;
            const mapped = this.wbTaskCreateTreeNodeToResource(n, t);
            if (mapped && mapped.key) keys.push(mapped.key);
            (n.children || []).forEach(walk);
          };
          walk(node);
          return Array.from(new Set(keys));
        },
        wbTaskCreateTreeNodeLeafResources(node, tab) {
          const t = String(tab || (this.wbTaskCreateForm && this.wbTaskCreateForm.resourceTab) || 'file');
          const out = [];
          const walk = (n) => {
            if (!n) return;
            if (n.isFolder) {
              (n.children || []).forEach(walk);
              return;
            }
            const mapped = this.wbTaskCreateTreeNodeToResource(n, t);
            if (mapped && mapped.key) out.push(mapped);
          };
          walk(node);
          const byKey = new Map();
          out.forEach((item) => {
            if (item && item.key && !byKey.has(item.key)) byKey.set(item.key, item);
          });
          return Array.from(byKey.values());
        },
        wbTaskCreateSelectedCoveredKeySet() {
          const keys = new Set();
          (this.wbTaskCreateForm.selectedResources || []).forEach((item) => {
            if (!item || !item.key) return;
            keys.add(item.key);
            (item.coveredResourceKeys || []).forEach((key) => {
              if (key) keys.add(key);
            });
          });
          return keys;
        },
        isWbTaskCreateTreeNodeChecked(node, tab) {
          const mapped = this.wbTaskCreateTreeNodeToResource(node, tab);
          if (!mapped || !mapped.key) return false;
          const covered = this.wbTaskCreateSelectedCoveredKeySet();
          if (!node.isFolder) return covered.has(mapped.key);
          const leafKeys = mapped.coveredResourceKeys || [];
          return covered.has(mapped.key) || (!!leafKeys.length && leafKeys.every((key) => covered.has(key)));
        },
        isWbTaskCreateTreeNodeIndeterminate(node, tab) {
          if (!node || !node.isFolder || this.isWbTaskCreateTreeNodeChecked(node, tab)) return false;
          const mapped = this.wbTaskCreateTreeNodeToResource(node, tab);
          const leafKeys = (mapped && mapped.coveredResourceKeys) || [];
          if (!leafKeys.length) return false;
          const covered = this.wbTaskCreateSelectedCoveredKeySet();
          return leafKeys.some((key) => covered.has(key));
        },
        toggleWbTaskCreateTreeNodeSelection(node, tab) {
          const mapped = this.wbTaskCreateTreeNodeToResource(node, tab);
          if (!mapped || !mapped.key) return;
          const checked = this.isWbTaskCreateTreeNodeChecked(node, tab);
          if (node.isFolder) {
            const leafResources = this.wbTaskCreateTreeNodeLeafResources(node, tab);
            const nodeKeys = new Set(this.wbTaskCreateTreeNodeAllResourceKeys(node, tab));
            const leafKeys = new Set(leafResources.map((item) => item.key).filter(Boolean));
            this.wbTaskCreateForm.selectedResources = (this.wbTaskCreateForm.selectedResources || []).filter((item) => {
              if (!item || !item.key) return false;
              if (nodeKeys.has(item.key)) return false;
              return !(item.coveredResourceKeys || []).some((key) => leafKeys.has(key));
            });
            if (!checked) leafResources.forEach((item) => this.addWbTaskCreateResource(item));
            return;
          }
          if (checked) {
            this.removeWbTaskCreateResource(mapped.key);
            return;
          }
          this.addWbTaskCreateResource(mapped);
        },
        wbTaskCreateDbGroupTableKeys(grp) {
          return Array.from(new Set(((grp && grp.tables) || []).map((item) => item && item.key).filter(Boolean)));
        },
        isWbTaskCreateDbGroupChecked(grp) {
          const keys = this.wbTaskCreateDbGroupTableKeys(grp);
          if (!keys.length) return false;
          return keys.every((key) => this.isWbTaskCreateResourceSelected(key));
        },
        isWbTaskCreateDbGroupIndeterminate(grp) {
          const keys = this.wbTaskCreateDbGroupTableKeys(grp);
          if (!keys.length || this.isWbTaskCreateDbGroupChecked(grp)) return false;
          return keys.some((key) => this.isWbTaskCreateResourceSelected(key));
        },
        toggleWbTaskCreateDbGroupSelection(grp) {
          const tables = (grp && grp.tables) || [];
          if (!tables.length) return;
          const checked = this.isWbTaskCreateDbGroupChecked(grp);
          if (checked) {
            const keys = new Set(tables.map((item) => item && item.key).filter(Boolean));
            this.wbTaskCreateForm.selectedResources = (this.wbTaskCreateForm.selectedResources || []).filter((item) => !keys.has(item && item.key));
            return;
          }
          tables.forEach((item) => this.addWbTaskCreateResource(item));
        },
        selectAllWbTaskCreateCurrentResources() {
          const rows = this.wbTaskCreateCurrentSelectableResources || [];
          rows.forEach((item) => this.addWbTaskCreateResource(item));
        },
        cancelAllWbTaskCreateCurrentResources() {
          const f = this.wbTaskCreateForm || {};
          const tab = String(f.resourceTab || 'file');
          const q = String(f.resourceQuery || '').trim();
          if (!q && (tab === 'file' || tab === 'result' || tab === 'database' || tab === 'graph')) {
            const typeSet =
              tab === 'file' ? new Set(['file', 'file-folder']) :
              tab === 'result' ? new Set(['result', 'result-folder']) :
              new Set([tab]);
            f.selectedResources = (f.selectedResources || []).filter((item) => !typeSet.has(String((item && item.type) || '')));
            return;
          }
          const keys = new Set((this.wbTaskCreateCurrentSelectableResources || []).map((item) => item && item.key).filter(Boolean));
          f.selectedResources = (f.selectedResources || []).filter((item) => !keys.has(item && item.key));
        },
        addWbTaskCreateResource(item) {
          if (!item || !item.key) return;
          const exists = (this.wbTaskCreateForm.selectedResources || []).some((row) => row.key === item.key);
          if (exists) return;
          this.wbTaskCreateForm.selectedResources = [...(this.wbTaskCreateForm.selectedResources || []), { ...item }];
        },
        isWbTaskCreateResourceSelected(key) {
          return (this.wbTaskCreateForm.selectedResources || []).some((item) => item.key === key);
        },
        toggleWbTaskCreateResource(item) {
          if (!item || !item.key) return;
          if (this.isWbTaskCreateResourceSelected(item.key)) {
            this.removeWbTaskCreateResource(item.key);
            return;
          }
          this.addWbTaskCreateResource(item);
        },
        removeWbTaskCreateResource(key) {
          this.wbTaskCreateForm.selectedResources = (this.wbTaskCreateForm.selectedResources || []).filter((item) => item.key !== key);
        },
        clearWbTaskCreateResources() {
          this.wbTaskCreateForm.selectedResources = [];
        },
        setWorkbenchMaterialStatusView(status) {
          if (status !== 'queued' && status !== 'parsing' && status !== 'failed') return;
          this.workbenchMaterialStatusView = status;
          this.selectedTreeNode = null;
        },
        resetWorkbenchMaterialStatusView() {
          this.workbenchMaterialStatusView = 'all';
          this.selectedTreeNode = null;
        },
        toggleWorkbenchDbSearchPanel() {
          this.workbenchDbSearchOpen = !this.workbenchDbSearchOpen;
          if (!this.workbenchDbSearchOpen) this.dbResourceSearchQuery = '';
        },
        toggleWorkbenchGraphSearchPanel() {
          this.workbenchGraphSearchOpen = !this.workbenchGraphSearchOpen;
          if (!this.workbenchGraphSearchOpen) this.graphResourceSearchQuery = '';
        },
        setResourceDrawerBodyRef(key, el) {
          if (!key || !this.resourceDrawerBodyEls || !(key in this.resourceDrawerBodyEls)) return;
          const nextEl = el || null;
          if (this.resourceDrawerBodyEls[key] === nextEl) return;
          this.resourceDrawerBodyEls[key] = nextEl;
          this.updateResourceDrawerHeights();
        },
        updateResourceDrawerHeights() {
          const keys = ['file', 'database', 'graph', 'knowledge'];
          const prev = this.resourceDrawerContentHeights || {};
          const next = { ...prev };
          let changed = false;
          keys.forEach((k) => {
            if (!this.resourceDrawerOpen[k]) return;
            const el = this.resourceDrawerBodyEls[k];
            const h = el ? Math.max(1, Math.ceil(el.scrollHeight || el.clientHeight || 1)) : 1;
            if (next[k] !== h) {
              next[k] = h;
              changed = true;
            }
          });
          if (changed) this.resourceDrawerContentHeights = next;
        },
        resourceDrawerSectionStyle(key) {
          const isOpen = !!(this.resourceDrawerOpen && this.resourceDrawerOpen[key]);
          if (!isOpen) return { flex: '0 0 auto', minHeight: '34px' };
          const keys = ['file', 'database', 'graph', 'knowledge'].filter((k) => this.resourceDrawerOpen[k]);
          const openCount = keys.length || 1;
          const minPct = 10;
          const totalMin = minPct * openCount;
          const freePct = Math.max(0, 100 - totalMin);
          const weightSum = keys.reduce((sum, k) => sum + Math.max(1, Number(this.resourceDrawerContentHeights[k] || 1)), 0);
          const w = Math.max(1, Number(this.resourceDrawerContentHeights[key] || 1));
          const growPct = weightSum > 0 ? (w / weightSum) * freePct : freePct / openCount;
          const basis = minPct + growPct;
          return {
            flex: '1 1 0',
            minHeight: '10%',
            height: `${basis}%`,
          };
        },
        closeResourcePreview() {
          this.selectedResourcePreview = null;
          this.resourcePreviewTab = 'basic';
          this.sourcesLeftView = 'list';
        },
        previewResource(type, row) {
          if (!row) return;
          this.selectedResourcePreview = { ...row, type };
          this.resourcePreviewTab = 'basic';
          this.sourcesLeftView = 'detail';
          this.sourcesDetailWidth = 450;
        },
        removeResource(type, row) {
          if (!row) return;
          const title = row.name || '未命名资源';
          if (type === 'knowledge') {
            message.info('知识库能力暂未开放');
            return;
          }
          if (type === 'database') {
            this.confirmRemoveDbTableResource(row);
            return;
          }
          window.dsConfirm.delete({
            subject: '该资源',
            onOk: () => {
              if (type === 'graph') {
                this.graphResourceList = (this.graphResourceList || []).filter((item) => item.id !== row.id);
              }
              message.success(`已删除：${title}`);
            },
          });
        },
        confirmRemoveDbTableResource(row) {
          if (!row) return;
          const label =
            row.databaseName && row.tableName ? `${row.databaseName} / ${row.tableName}` : String(row.tableName || row.name || '该表');
          window.dsConfirm.delete({
            title: '删除库表引用？',
            kind: 'folder',
            syncScope: `库表「${label}」`,
            onOk: () => {
              this.dbResourceList = (this.dbResourceList || []).filter((item) => item.id !== row.id);
              message.success(`已删除：${label}`);
            },
          });
        },
        formatWorkbenchDbTableRowCount(n) {
          if (n == null || n === '') return '—';
          const num = Number(n);
          if (!Number.isFinite(num) || num < 0) return String(n);
          if (num >= 100000000) return `${(Math.round((num / 100000000) * 10) / 10).toString().replace(/\.0$/, '')} 亿行`;
          if (num >= 10000) return `${(Math.round((num / 10000) * 10) / 10).toString().replace(/\.0$/, '')} 万行`;
          if (num >= 1000) return `${(Math.round((num / 1000) * 10) / 10).toString().replace(/\.0$/, '')} 千行`;
          return `${num} 行`;
        },
        workbenchDbTableRowExists(databaseId, tableName) {
          const id = String(databaseId || '') + '::' + String(tableName || '');
          return (this.dbResourceList || []).some((r) => r.id === id);
        },
        buildDbTablePreviewPayload(row) {
          if (!row) return {};
          const tc = row.comment != null && String(row.comment).trim() !== '' ? String(row.comment) : '—';
          return {
            id: row.id,
            name: `${row.databaseName} / ${row.tableName}`,
            source: row.source || '',
            owner: row.owner,
            updatedAt: row.updatedAt,
            tableComment: tc,
            rowCountLabel: this.formatWorkbenchDbTableRowCount(row.rowCount),
            tables: [{ name: row.tableName, ddl: row.ddl }],
          };
        },
        previewDbTableResource(row) {
          if (!row) return;
          this.previewResource('database', this.buildDbTablePreviewPayload(row));
        },
        onWorkbenchDbTableContextMenu(key, tbl) {
          if (key === 'chat') this.addResourceToChat('database', tbl);
          else if (key === 'delete') this.confirmRemoveDbTableResource(tbl);
        },
        onWorkbenchDbCatalogMoreMenu(key, grp) {
          if (key === 'remove-catalog') this.removeWorkbenchDatabaseCatalog(grp);
        },
        onWorkbenchDbCatalogContextMenu(key, grp) {
          if (key === 'chat') {
            this.addResourceToChat('database', {
              databaseId: grp && grp.databaseId,
              databaseName: grp && grp.databaseName,
            });
            return;
          }
          if (key === 'remove-catalog') this.removeWorkbenchDatabaseCatalog(grp);
        },
        removeWorkbenchDatabaseCatalog(grp) {
          if (!grp || grp.databaseId == null) return;
          const id = String(grp.databaseId);
          const name = String(grp.databaseName || '').trim() || '该数据源';
          window.dsConfirm.delete({
            title: '移除此数据源？',
            kind: 'folder',
            syncScope: `「${name}」下的全部库表引用`,
            okText: '移除',
            onOk: () => {
              this.dbResourceList = (this.dbResourceList || []).filter((r) => String(r.databaseId) !== id);
              message.success('已移除数据源及其表引用');
            },
          });
        },
        onWorkbenchGraphContextMenu(key, graph) {
          if (key === 'delete') this.removeResource('graph', graph);
        },
        onWorkbenchGraphRowContextMenu(key, graph) {
          if (key === 'chat') this.addResourceToChat('graph', graph);
          else if (key === 'delete') this.removeResource('graph', graph);
        },
        onResourcePreviewContextMenu(key, row) {
          if (key !== 'delete' || !row) return;
          if (row.type === 'database') {
            this.confirmRemoveDbTableResource(row);
            return;
          }
          if (row.type === 'graph') {
            this.removeResource('graph', row);
          }
        },
        onWbDbAddTableRowSelectionChange(keys) {
          this.wbDbAddSelectedTableNames = Array.isArray(keys) ? keys : [];
        },
        wbDbAddTableGetCheckboxProps(record) {
          return record && record.disabled ? { disabled: true } : { disabled: false };
        },
        isWorkbenchDbTableGroupExpanded(databaseId) {
          const key = String(databaseId);
          const v = this.workbenchDbTableGroupExpanded[key];
          if (v === undefined) return true;
          return !!v;
        },
        toggleWorkbenchDbTableGroup(databaseId) {
          const key = String(databaseId);
          const open = this.isWorkbenchDbTableGroupExpanded(databaseId);
          this.workbenchDbTableGroupExpanded = { ...this.workbenchDbTableGroupExpanded, [key]: !open };
        },
        openWorkbenchDbAddModal() {
          this.wbDbAddCatalogId = undefined;
          this.wbDbAddSelectedTableNames = [];
          this.wbDbAddTableSearchQuery = '';
          this.wbDbAddModalOpen = true;
        },
        closeWorkbenchDbAddModal() {
          this.wbDbAddModalOpen = false;
          this.wbDbAddCatalogId = undefined;
          this.wbDbAddSelectedTableNames = [];
          this.wbDbAddTableSearchQuery = '';
        },
        onWorkbenchDbAddCatalogChange() {
          this.wbDbAddSelectedTableNames = [];
          this.wbDbAddTableSearchQuery = '';
        },
        openWorkbenchGraphAddModal() {
          this.wbGraphAddSelectedIds = [];
          this.wbGraphAddModalOpen = true;
        },
        closeWorkbenchGraphAddModal() {
          this.wbGraphAddModalOpen = false;
          this.wbGraphAddSelectedIds = [];
        },
        openWorkbenchGraphDetailModal(item) {
          if (!item) return;
          this.wbGraphDetailRecord = { ...item };
          this.wbGraphDetailActiveTab = 'basic';
          this.wbGraphDetailModalOpen = true;
        },
        closeWorkbenchGraphDetailModal() {
          this.wbGraphDetailModalOpen = false;
          this.wbGraphDetailRecord = null;
          this.wbGraphDetailActiveTab = 'basic';
        },
        toggleWorkbenchGraphCard(item) {
          if (!item || item.disabled) return;
          const id = String(item.id);
          const set = new Set(this.wbGraphAddSelectedIds || []);
          if (set.has(id)) set.delete(id);
          else set.add(id);
          this.wbGraphAddSelectedIds = Array.from(set);
        },
        onWbGraphAddCheckboxChange(item, e) {
          if (!item || item.disabled) return;
          const id = String(item.id);
          const checked = !!(e && e.target && e.target.checked);
          const set = new Set(this.wbGraphAddSelectedIds || []);
          if (checked) set.add(id);
          else set.delete(id);
          this.wbGraphAddSelectedIds = Array.from(set);
        },
        submitWorkbenchGraphAdd() {
          const selected = new Set((this.wbGraphAddSelectedIds || []).map((x) => String(x)));
          if (!selected.size) {
            message.warning('请至少勾选一个数据图谱');
            return;
          }
          const exists = new Set((this.graphResourceList || []).map((g) => String(g.id)));
          const toAdd = (this.graphCatalogs || []).filter((g) => selected.has(String(g.id)) && !exists.has(String(g.id)));
          if (!toAdd.length) {
            message.info('所选图谱均已存在于工作台，未新增');
            this.closeWorkbenchGraphAddModal();
            return;
          }
          this.graphResourceList = [...toAdd.map((g) => ({ ...g })), ...(this.graphResourceList || [])];
          message.success(`已添加 ${toAdd.length} 个数据图谱`);
          this.closeWorkbenchGraphAddModal();
          this.ensureResourceDrawerOpen('graph');
        },
        filterWbDbAddCatalogOption(input, option) {
          const q = String(input || '').trim().toLowerCase();
          if (!q) return true;
          const lab = option && option.label != null ? String(option.label).toLowerCase() : '';
          return lab.includes(q);
        },
        submitWorkbenchDbAddTables() {
          const catalog = (this.dbCatalogs || []).find((x) => x.id === this.wbDbAddCatalogId);
          if (!catalog) {
            message.warning('请先选择数据库');
            return;
          }
          const names = Array.isArray(this.wbDbAddSelectedTableNames) ? this.wbDbAddSelectedTableNames : [];
          if (!names.length) {
            message.warning('请至少勾选一张数据表');
            return;
          }
          const stamp = new Date().toISOString().slice(0, 19).replace('T', ' ');
          let added = 0;
          names.forEach((tableName) => {
            const t = (catalog.tables || []).find((x) => x.name === tableName);
            if (!t) return;
            if (this.workbenchDbTableRowExists(catalog.id, tableName)) return;
            this.dbResourceList = this.dbResourceList || [];
            this.dbResourceList.push({
              id: `${catalog.id}::${tableName}`,
              databaseId: catalog.id,
              databaseName: catalog.name,
              tableName,
              name: tableName,
              ddl: t.ddl,
              comment: t.comment != null ? String(t.comment) : '',
              rowCount: t.rowCount,
              source: catalog.source,
              owner: catalog.owner,
              updatedAt: stamp,
            });
            added += 1;
          });
          if (!added) {
            message.info('所选表均已存在于工作台，未新增');
          } else {
            message.success(`已添加 ${added} 张表`);
            this.closeWorkbenchDbAddModal();
            this.ensureResourceDrawerOpen('database');
          }
        },
        addGraphResource() {
          const now = Date.now();
          this.graphResourceList = [
            {
              id: 'graph-added-' + now,
              name: '新建图谱配置',
              source: '内置图谱中心',
              entityCount: 0,
              edgeCount: 0,
              updatedAt: new Date().toISOString().slice(0, 19).replace('T', ' '),
            },
            ...(this.graphResourceList || []),
          ];
          message.success('已添加数据图谱配置');
          this.ensureResourceDrawerOpen('graph');
        },
        initFromUrl() {
          const rawRoute = (window.location.hash || '').replace(/^#/, '');
          /* hash 已切到 project/ 等其它路由时仍会触发本组件的 hashchange，勿按「无 projectId」误跳工作台 */
          if (!rawRoute.startsWith('freeaudit')) return;
          const q = getFreeAuditQuery();
          if (!q.projectId) {
            message.warning('请先选择或创建工作台后再打开审计助手');
            window.location.hash = 'project';
            return;
          }
          let auxiliaryEnterStaged = false;
          try {
            if (sessionStorage.getItem('demoAuxiliaryEnterAnim') === '1') {
              sessionStorage.removeItem('demoAuxiliaryEnterAnim');
              auxiliaryEnterStaged = true;
            }
          } catch (_) { /* ignore */ }
          if (auxiliaryEnterStaged) {
            this.sourcesCollapsed = true;
            this.studioCollapsed = true;
          }
          this.workbenchProjectId = q.projectId;
          this.workbenchMaterialId = q.materialId || null;
          this.workbenchAnalysisResultId = q.analysisResultId || null;
          this.workbenchReportId = q.reportId || null;
          const pid = this.workbenchProjectId;
          const pRows = demoProjectMaterialsById[pid] || [];
          const aRows = demoProjectAnalysisResultsById[pid] || [];
          const mappedRaw = pRows.map((r) => mapProjectRowToWorkbenchMaterial(r, pid));
          const mappedAnalysis = aRows.map((r) => mapAnalysisResultRowToWorkbench(r, pid));
          this.materials = [...mappedRaw, ...mappedAnalysis];
          this.$nextTick(() => {
            this.ensureWorkbenchAnalysisResultTaskFolders();
            const keys = this.workbenchAnalysisResultAntTreeInitialExpandKeys || [];
            if (keys.length) this.workbenchAnalysisResultTreeExpandedKeys = keys.slice();
          });
          this.workbenchMaterialFilterPopoverOpen = false;
          this.wbSkillSidebarSearchKeyword = '';
          this.workbenchAnalysisSearchQuery = '';
          if (this.workbenchMaterialId && this.materials.some((x) => x.id === this.workbenchMaterialId)) this.selectedMaterialId = this.workbenchMaterialId;
          else if (this.workbenchAnalysisResultId && this.materials.some((x) => x.id === this.workbenchAnalysisResultId)) this.selectedMaterialId = this.workbenchAnalysisResultId;
          else if (this.workbenchReportId) this.selectedMaterialId = this.materials.find((x) => x.type === 'analysis')?.id || this.materials[0]?.id;
          else if (this.materials.length) this.selectedMaterialId = this.materials[0].id;
          else this.selectedMaterialId = null;
          const sel = this.selectedMaterialId ? this.materials.find((m) => m.id === this.selectedMaterialId) : null;
          this.sourcesRightView = 'list';
          if (sel) sel.checked = true;
          if (q.openTemplate) {
            this.$nextTick(() => this.openTemplateLibrary());
            const raw2 = (window.location.hash || '').replace(/^#/, '');
            if (raw2.startsWith('freeaudit?')) {
              const [base2, query2 = ''] = raw2.split('?');
              const params2 = new URLSearchParams(query2);
              params2.delete('openTemplate');
              const next2 = params2.toString() ? `${base2}?${params2.toString()}` : base2;
              window.history.replaceState(null, '', '#' + next2);
            }
          }
          if (auxiliaryEnterStaged) {
            this.$nextTick(() => {
              window.setTimeout(() => {
                this.sourcesCollapsed = false;
                this.studioCollapsed = false;
              }, 70);
            });
          }
          this.$nextTick(() => this.ensureDefaultDemoConversation());
        },
        refreshWorkbenchDemoResources(listScope) {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先进入工作台');
            return;
          }
          const pRows = demoProjectMaterialsById[pid] || [];
          const aRows = demoProjectAnalysisResultsById[pid] || [];
          const mappedRaw = pRows.map((r) => mapProjectRowToWorkbenchMaterial(r, pid));
          const mappedAnalysis = aRows.map((r) => mapAnalysisResultRowToWorkbench(r, pid));
          this.materials = [...mappedRaw, ...mappedAnalysis];
          this.ensureWorkbenchAnalysisResultTaskFolders();
          this.syncTaskOutputsIntoLinkedResultFolders();
          this.$nextTick(() => {
            const keys = this.workbenchAnalysisResultAntTreeInitialExpandKeys || [];
            if (keys.length) this.workbenchAnalysisResultTreeExpandedKeys = keys.slice();
          });
          const prevSel = this.selectedMaterialId;
          if (prevSel && this.materials.some((x) => x.id === prevSel)) {
            this.selectedMaterialId = prevSel;
          } else if (this.workbenchMaterialId && this.materials.some((x) => x.id === this.workbenchMaterialId)) {
            this.selectedMaterialId = this.workbenchMaterialId;
          } else if (this.workbenchAnalysisResultId && this.materials.some((x) => x.id === this.workbenchAnalysisResultId)) {
            this.selectedMaterialId = this.workbenchAnalysisResultId;
          } else if (this.workbenchReportId) {
            this.selectedMaterialId = this.materials.find((x) => x.type === 'analysis')?.id || this.materials[0]?.id || null;
          } else if (this.materials.length) {
            this.selectedMaterialId = this.materials[0].id;
          } else {
            this.selectedMaterialId = null;
          }
          const sel = this.selectedMaterialId ? this.materials.find((m) => m.id === this.selectedMaterialId) : null;
          if (sel) sel.checked = true;
          this.workbenchMaterialStatusPopoverOpenQueued = false;
          this.workbenchMaterialStatusPopoverOpenParsing = false;
          this.workbenchMaterialStatusPopoverOpenFailed = false;
          this.workbenchAnalysisStatusPopoverOpenQueued = false;
          this.workbenchAnalysisStatusPopoverOpenParsing = false;
          this.workbenchAnalysisStatusPopoverOpenFailed = false;
          this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          const scope = listScope === 'skill' ? 'skill' : listScope === 'result' ? 'result' : listScope === 'task' ? 'task' : 'material';
          const hint =
            scope === 'result'
              ? '结果列表已同步；助手对话未刷新。'
              : scope === 'skill'
                ? '技能列表已同步；助手对话未刷新。'
                : scope === 'task'
                  ? '任务列表已同步；助手对话未刷新。'
                  : '资料列表已同步；助手对话未刷新。';
          message.success(hint);
        },
        openProjectCenterUpload() {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先进入工作台并打开审计助手后再上传资料');
            return;
          }
          const bridge = window.__demoQuoteSkillBridge;
          if (bridge && typeof bridge.openUploadForWorkbenchProject === 'function') {
            bridge.openUploadForWorkbenchProject(pid, null);
            return;
          }
          message.warning('上传入口暂不可用，请稍后重试');
        },
        openProjectCenterUploadForFolder(folderId) {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先进入工作台并打开审计助手后再上传资料');
            return;
          }
          const fid = folderId != null ? String(folderId).trim() : '';
          if (!fid) {
            this.openProjectCenterUpload();
            return;
          }
          const bridge = window.__demoQuoteSkillBridge;
          if (bridge && typeof bridge.openUploadForWorkbenchProject === 'function') {
            bridge.openUploadForWorkbenchProject(pid, { parentFolderId: fid });
            return;
          }
          message.warning('上传入口暂不可用，请稍后重试');
        },
        onWorkbenchMaterialAddMenu(key, folderId) {
          const pid = this.workbenchProjectId;
          if (!pid) {
            message.warning('请先进入工作台并打开审计助手后再上传资料');
            return;
          }
          const targetFolderId = folderId != null ? String(folderId).trim() : '';
          if (key === 'upload-file') {
            if (targetFolderId) this.openProjectCenterUploadForFolder(targetFolderId);
            else this.openProjectCenterUpload();
            return;
          }
          if (key === 'new-folder') {
            this.openWorkbenchMaterialCreateFolderModal(targetFolderId);
          }
        },
        openWorkbenchMaterialCreateFolderModal(parentFolderId) {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialFoldersById === 'undefined') {
            message.warning('请先进入工作台并打开审计助手后再新建文件夹');
            return;
          }
          this.wbCreateFolderForm = {
            name: '',
            parentFolderId: parentFolderId != null ? String(parentFolderId).trim() : '',
          };
          this.wbCreateFolderModalOpen = true;
        },
        closeWorkbenchMaterialCreateFolderModal() {
          this.wbCreateFolderModalOpen = false;
          this.wbCreateFolderForm = { name: '', parentFolderId: '' };
        },
        wbTaskConfigResolveResourceKind(item) {
          if (!item || typeof item !== 'object') return 'unknown';
          const t = String(item.type || '').trim().toLowerCase();
          if (t === 'file' || t === 'file-folder' || t === 'result' || t === 'result-folder' || t === 'database' || t === 'graph' || t === 'knowledge' || t === 'intent') return t;
          const k = String(item.key || '');
          if (k.startsWith('file:')) return 'file';
          if (k.startsWith('file-folder:')) return 'file-folder';
          if (k.startsWith('result:')) return 'result';
          if (k.startsWith('result-folder:')) return 'result-folder';
          if (k.startsWith('database:')) return 'database';
          if (k.startsWith('graph:')) return 'graph';
          if (k.startsWith('knowledge:')) return 'knowledge';
          if (k === 'dialog-intent' || k === 'intent') return 'intent';
          return 'unknown';
        },
        wbTaskConfigResourceTypeLabelZh(kind) {
          const map = {
            file: '文件',
            'file-folder': '文件夹',
            result: '结果',
            'result-folder': '结果文件夹',
            database: '数据库表',
            graph: '知识图谱',
            knowledge: '知识库',
            intent: '意图',
            unknown: '资料',
          };
          return map[kind] || map.unknown;
        },
        wbTaskConfigResourceDisplayTitle(item) {
          if (!item || typeof item !== 'object') return '—';
          const v = item.name || item.title || item.fileName || item.label;
          return String(v != null ? v : '').trim() || '未命名';
        },
        wbTaskConfigResourceRowSingleLine(item) {
          if (!item || typeof item !== 'object') return '—';
          const title = this.wbTaskConfigResourceDisplayTitle(item);
          const cleaned = this.wbTaskDetailStripDemoLabel(title);
          return cleaned || '未命名';
        },
        wbTaskConfigResourceRowAriaLabel(item) {
          if (!item || typeof item !== 'object') return '引用资源';
          const k = this.wbTaskConfigResolveResourceKind(item);
          const t = this.wbTaskConfigResourceRowSingleLine(item);
          const typeZh = this.wbTaskConfigResourceTypeLabelZh(k);
          return `${t}，${typeZh}`;
        },
        wbTaskConfigResourceIconMeta(item) {
          if (!item || typeof item !== 'object') return { iconClass: 'folder', iconToneClass: '' };
          if (item.iconClass) {
            const ic = String(item.iconClass).trim();
            const { faSuffixToLogical } = window.DEMO_ICON_MAP || {};
            let logical = ic;
            if (ic.startsWith('fa-')) {
              const suffix = ic.slice(3);
              logical = typeof faSuffixToLogical === 'function' ? faSuffixToLogical(suffix) : suffix;
            } else if (typeof faSuffixToLogical === 'function') {
              logical = faSuffixToLogical(ic) || ic;
            }
            return { iconClass: logical, iconToneClass: item.iconToneClass || '' };
          }
          const kind = this.wbTaskConfigResolveResourceKind(item);
          if (kind === 'file') {
            const api = window.DemoFileIcons;
            if (api && typeof api.iconFor === 'function') {
              const meta = api.iconFor(item.format || item.mimeType || item.mime, item.name || item.fileName || item.title);
              return { iconClass: meta.iconName, iconToneClass: meta.toneClass };
            }
            return { iconClass: 'file-lines', iconToneClass: '' };
          }
          if (kind === 'file-folder') return { iconClass: 'folder', iconToneClass: '' };
          if (kind === 'result') return { iconClass: 'file-text', iconToneClass: 'is-result' };
          if (kind === 'result-folder') return { iconClass: 'folder', iconToneClass: 'is-result' };
          if (kind === 'database') return { iconClass: 'table', iconToneClass: 'is-data' };
          if (kind === 'graph') return { iconClass: 'map-draw', iconToneClass: 'is-data' };
          if (kind === 'knowledge') return { iconClass: 'book', iconToneClass: '' };
          if (kind === 'intent') return { iconClass: 'bullseye', iconToneClass: 'is-primary' };
          return { iconClass: 'file', iconToneClass: '' };
        },
        wbTaskConfigResourceDetailRowsForItem(item) {
          const rows = [];
          if (!item || typeof item !== 'object') return rows;
          const kind = this.wbTaskConfigResolveResourceKind(item);
          rows.push({ label: '资源类型', value: this.wbTaskConfigResourceTypeLabelZh(kind) });
          if (item.key != null && String(item.key).trim()) rows.push({ label: '标识', value: String(item.key).trim() });
          if (item.id != null && String(item.id).trim()) rows.push({ label: 'ID', value: String(item.id).trim() });
          const title = this.wbTaskConfigResourceDisplayTitle(item);
          if (title && title !== '—') rows.push({ label: '名称', value: title });
          if (kind === 'database') {
            if (item.connectionLabel) rows.push({ label: '数据源', value: String(item.connectionLabel).trim() });
            if (item.logicalTableName) rows.push({ label: '逻辑表名', value: String(item.logicalTableName).trim() });
            if (item.tableSchema) rows.push({ label: 'Schema', value: String(item.tableSchema).trim() });
            if (item.physicalTable) rows.push({ label: '物理表', value: String(item.physicalTable).trim() });
            if (item.rowEstimate != null && String(item.rowEstimate).trim() !== '') {
              const n = Number(item.rowEstimate);
              rows.push({
                label: '行数（估算）',
                value: Number.isFinite(n) ? n.toLocaleString('zh-CN') : String(item.rowEstimate).trim(),
              });
            }
          }
          if (kind === 'unknown') rows.push({ label: '说明', value: '未标注类型时可从「创建任务」侧资源选择器获得完整类型信息。' });
          return rows;
        },
        materialBasicMetaRowsFromProjectSourceRow(r) {
          if (!r) return [];
          const statusMap = { queued: '排队中', parsing: '解析中', done: '完成', failed: '失败' };
          const st = statusMap[r.status] || '排队中';
          const size = r.size == null || r.size === '' ? '—' : `${Number(r.size).toFixed(1)} MB`;
          return [
            { label: '名称', value: String(r.name || '').trim() || '—' },
            { label: '大小', value: size },
            { label: '格式', value: String(r.format || '').trim() || '—' },
            { label: '状态', value: st },
            { label: '上传人', value: String(r.uploader || r.uploadedBy || '').trim() || '—' },
            { label: '上传时间', value: String(r.uploadedAt || '').trim() || '—' },
          ];
        },
        wbResolveTaskResourceMaterialVm(item) {
          if (!item || typeof item !== 'object') return null;
          const key = String(item.key != null ? item.key : '').trim();
          const mats = this.materials || [];
          const tryMatch = (k) => {
            if (!k) return null;
            for (let i = 0; i < mats.length; i++) {
              const m = mats[i];
              if (!m) continue;
              const t = m.type;
              if (t !== 'raw' && t !== undefined) continue;
              const id = String(m.id || '').trim();
              const psId = m.projectSource && String(m.projectSource.id || '').trim();
              if (id === k || psId === k) return m;
            }
            return null;
          };
          let hit = tryMatch(key);
          if (hit) return hit;
          if (key.startsWith('file:')) hit = tryMatch(key.replace(/^file:/, '').trim());
          return hit;
        },
        wbTaskResourceBuildDdlFromFieldDefinitions(item) {
          if (!item || typeof item !== 'object') return '';
          const defs = Array.isArray(item.fieldDefinitions) ? item.fieldDefinitions.filter(Boolean) : [];
          if (!defs.length) return '';
          const schema = String(item.tableSchema || '').trim();
          const table = String(item.physicalTable || item.tableName || 'DEMO_TABLE').trim();
          const qual = schema ? `"${schema}"."${table}"` : `"${table}"`;
          const cols = defs.map((f) => {
            const cn = String(f.columnName || f.name || 'COL').trim();
            const dt = String(f.dataType || f.type || 'VARCHAR(64)').trim();
            const nullableZh = String(f.nullable != null ? f.nullable : '是').trim();
            const nn = nullableZh === '否' ? ' NOT NULL' : '';
            return `  "${cn}" ${dt}${nn}`;
          }).join(',\n');
          return `CREATE TABLE ${qual} (\n${cols}\n);`;
        },
        wbTaskResourceResolveDatabasePreviewTables(item) {
          if (!item || typeof item !== 'object') return [];
          const tablesIn = Array.isArray(item.tables) ? item.tables : [];
          const normalized = tablesIn.map((t) => ({
            name: String(t.name || t.tableName || '—').trim() || '—',
            ddl: String(t.ddl || '').trim(),
          })).filter((t) => t.ddl);
          if (normalized.length) return normalized;
          const ddlDirect = String(item.ddl || '').trim();
          if (ddlDirect) {
            const nm = String(item.physicalTable || item.tableName || item.logicalTableName || item.name || '表').trim();
            const clean = nm.replace(/（演示）/g, '').replace(/\(演示\)/g, '').trim() || '表';
            return [{ name: clean, ddl: ddlDirect }];
          }
          const key = String(item.key != null ? item.key : '').trim();
          const idFromKey = key.startsWith('database:') ? key.slice('database:'.length).trim() : '';
          const list = this.dbResourceList || [];
          const row = list.find((r) => {
            const id = String(r.id || '').trim();
            return id && (id === key || id === idFromKey);
          });
          if (row && String(row.ddl || '').trim()) {
            return [{ name: String(row.tableName || row.name || '—').trim(), ddl: String(row.ddl).trim() }];
          }
          const built = this.wbTaskResourceBuildDdlFromFieldDefinitions(item);
          if (built) {
            const nm = String(item.physicalTable || item.logicalTableName || '表')
              .replace(/（演示）/g, '')
              .replace(/\(演示\)/g, '')
              .trim() || '表';
            return [{ name: nm, ddl: built }];
          }
          return [];
        },
        openWbTaskResourcePreview(item) {
          const resolved = this.wbResolveTaskResourceMaterialVm(item);
          this.wbTaskResourcePreviewItem = item;
          this.wbTaskResourcePreviewResolvedMaterial = resolved;
          this.wbTaskResourcePreviewActiveTab = 'basic';
          this.wbTaskResourcePreviewOcrLines = false;
          this.wbTaskResourcePreviewOpen = true;
        },
        wbTaskDetailStripDemoLabel(s) {
          let t = String(s == null ? '' : s).trim();
          if (!t) return t;
          t = t
            .replace(/（演示）/g, '')
            .replace(/\(演示\)/g, '')
            .replace(/\s{2,}/g, ' ')
            .trim();
          return t;
        },
        closeWbTaskResourcePreview() {
          this.wbTaskResourcePreviewOpen = false;
          this.wbTaskResourcePreviewItem = null;
          this.wbTaskResourcePreviewResolvedMaterial = null;
          this.wbTaskResourcePreviewActiveTab = 'basic';
          this.wbTaskResourcePreviewOcrLines = false;
        },
        downloadWbTaskResourcePreview() {
          const vm = this.wbTaskResourcePreviewResolvedMaterial;
          if (!vm || !vm.projectSource) return;
          const pages = this.wbTaskResourcePreviewDocumentPages || [];
          const body = pages.join('\n\n---\n\n');
          const base = String(vm.projectSource.name || '资料').replace(/\.[^.]+$/, '');
          const safe = base.replace(/[/\\?%*:|"<>]/g, '_');
          const blob = new Blob([body], { type: 'text/plain;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${safe}-预览.txt`;
          a.click();
          URL.revokeObjectURL(url);
          message.success('已开始下载');
        },
        confirmWorkbenchMaterialCreateFolder() {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialFoldersById === 'undefined') {
            this.closeWorkbenchMaterialCreateFolderModal();
            return;
          }
          const folds = demoProjectMaterialFoldersById[pid] || [];
          const name = String((this.wbCreateFolderForm && this.wbCreateFolderForm.name) || '').trim();
          if (!name) {
            message.warning('名称不能为空');
            return;
          }
          const parentFolderId = this.wbCreateFolderForm && this.wbCreateFolderForm.parentFolderId != null
            ? String(this.wbCreateFolderForm.parentFolderId).trim()
            : '';
          const siblings = folds.filter((f) => String(f.parentId || '') === parentFolderId);
          const nextSort = siblings.reduce((acc, f) => Math.max(acc, Number(f.sort) || 0), -1) + 1;
          const newFolderId = this.wbMatNewFolderId();
          folds.push({
            id: newFolderId,
            name,
            parentId: parentFolderId,
            sort: nextSort,
          });
          if (parentFolderId) {
            const expanded = new Set(this.workbenchFileTreeExpandedKeys || []);
            expanded.add(wbMatAntTreeKey('folder', parentFolderId));
            this.workbenchFileTreeExpandedKeys = Array.from(expanded);
          }
          this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          this.closeWorkbenchMaterialCreateFolderModal();
          message.success('已新建文件夹');
        },
        wbMaterialVmById(materialId) {
          const id = materialId != null ? String(materialId) : '';
          if (!id) return null;
          return (this.materials || []).find((m) => m && String(m.id) === id) || null;
        },
        wbMaterialFileTreeSlotNodeData(node) {
          if (!node) return null;
          const direct = node.dataRef || node;
          if (direct && direct.materialId) return direct;
          const rawKey = direct && (direct.key != null ? direct.key : direct.eventKey != null ? direct.eventKey : '');
          const key = String(rawKey || '');
          if (!key.startsWith('raw:')) return direct;
          const materialId = key.slice('raw:'.length);
          const row = (this.workbenchDoneProjectRowsForFileTree || []).find((r) => String(r.id) === materialId) || null;
          return {
            materialId,
            rawProjectRow: row,
          };
        },
        wbWorkbenchMaterialVmForTreeFile(d) {
          if (!d) return null;
          const vm = this.wbMaterialVmById(d.materialId);
          if (vm) return vm;
          const r = d.rawProjectRow;
          if (!r) return { type: 'raw', id: d.materialId, projectSource: {} };
          const fmt = String(r.format || '').toUpperCase();
          const rawSubtype = fmt === 'XLSX' || fmt === 'XLS' || fmt === 'CSV' ? 'table' : 'document';
          return {
            type: 'raw',
            id: String(r.id),
            title: r.name,
            rawSubtype,
            format: r.format,
            projectSource: r,
          };
        },
        wbMatNewFolderId() {
          return typeof newSkillId === 'function' ? newSkillId('mf') : `mf-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
        },
        collectWorkbenchMaterialFolderSubtreeIds(rootFolderId) {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialFoldersById === 'undefined') return new Set();
          const folds = demoProjectMaterialFoldersById[pid] || [];
          const root = String(rootFolderId || '');
          if (!root) return new Set();
          const out = new Set([root]);
          let added = true;
          while (added) {
            added = false;
            folds.forEach((f) => {
              const id = String(f.id || '');
              const p = f.parentId != null && f.parentId !== '' ? String(f.parentId) : '';
              if (!id || out.has(id)) return;
              if (p && out.has(p)) {
                out.add(id);
                added = true;
              }
            });
          }
          return out;
        },
        collectDoneRawProjectRowsInMaterialFolder(folderId) {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialsById === 'undefined' || !folderId) return [];
          const folderIds = this.collectWorkbenchMaterialFolderSubtreeIds(folderId);
          const mats = demoProjectMaterialsById[pid] || [];
          return mats.filter((r) => {
            if (String(r.status || '') !== 'done') return false;
            const p = r.parentId != null && r.parentId !== '' ? String(r.parentId) : '';
            return folderIds.has(p);
          });
        },
        onWorkbenchMaterialFileTreeDrop(info) {
          const pid = this.workbenchProjectId;
          if (!pid) return;
          const res = applyWorkbenchMaterialTreeDrop(pid, info);
          if (!res.ok) {
            if (res.message) message.warning(res.message);
            return;
          }
          this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
          message.success('已更新目录顺序');
        },
        onWorkbenchMaterialFolderRowClick(d) {
          if (!d || !d.folderId) return;
          const key = d.key != null ? String(d.key) : wbMatAntTreeKey('folder', d.folderId);
          const expanded = new Set(this.workbenchFileTreeExpandedKeys || []);
          if (expanded.has(key)) expanded.delete(key);
          else expanded.add(key);
          this.workbenchFileTreeExpandedKeys = Array.from(expanded);
        },
        onWorkbenchMaterialFolderMenu(key, d) {
          const pid = this.workbenchProjectId;
          if (!pid || typeof demoProjectMaterialFoldersById === 'undefined' || !d || !d.folderId) return;
          const folds = demoProjectMaterialFoldersById[pid];
          if (key === 'upload-file' || key === 'new-folder') {
            this.onWorkbenchMaterialAddMenu(key, d.folderId);
            return;
          }
          if (key === 'ref') {
            this.toggleWorkbenchMaterialFolderInChat(d);
            return;
          }
          if (key === 'rename') {
            const row = folds.find((f) => String(f.id) === String(d.folderId));
            if (!row) return;
            const name = window.prompt('重命名文件夹', row.name || '');
            if (name == null) return;
            const trimmed = String(name).trim();
            if (!trimmed) {
              message.warning('名称不能为空');
              return;
            }
            const idx = folds.findIndex((f) => String(f.id) === String(d.folderId));
            if (idx >= 0) folds.splice(idx, 1, { ...folds[idx], name: trimmed });
            this.workbenchDemoRefreshTick = (this.workbenchDemoRefreshTick || 0) + 1;
            message.success('已重命名');
            return;
          }
          if (key === 'delete') {
            const row = folds.find((f) => String(f.id) === String(d.folderId));
            this.wbDeleteFolderTarget = { folderId: String(d.folderId), name: (row && row.name) || d.title || '文件夹' };
            this.wbDeleteFolderModalOpen = true;
          }
        },
        openWorkbenchFileTreeRawDetail(d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return;
          this.openDetailFromTreeTitle({ id: m.id, raw: m }, 'material');
        },
        onWorkbenchFileTreeRawToggleRef(d) {
          const m = this.wbMaterialVmById(d && d.materialId);
          if (!m) return;
          this.handleTreeContextMenu('ref', { id: m.id, raw: m }, 'material');
        }
  };
})();
