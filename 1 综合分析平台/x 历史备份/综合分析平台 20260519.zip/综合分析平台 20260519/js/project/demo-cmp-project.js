(function () {
  const app = window.__DEMO_APP;
  const message = antd.message;

  const DEFAULT_PROJECT_LIST = [
    { id: 'PRJ-2026-001', name: 'A市城建集团年度经济责任审计', description: '围绕城建集团年度经济责任履行情况的综合审计。', visibility: 'private' },
    { id: 'PRJ-2026-002', name: 'B区采购专项资金异常排查', description: '对采购专项资金使用与审批流程的专项排查。', visibility: 'shared', sharedUserIds: ['u-1'], sharedDeptIds: ['d-inv'] },
    { id: 'PRJ-2026-003', name: 'C县专项债流向跟踪审计', description: '专项债资金流向与合规性跟踪审计。', visibility: 'private' },
  ];

  app.component('ProjectCenterView', {
    props: { openNewProjectModal: { type: Function } },
    template: `<a-layout class="shell-main">
      <div class="app-main">
        <project-center-list-panel
          :project-list-search="projectListSearch"
          :project-list-scope="projectListScope"
          :filtered-project-list="filteredProjectList"
          :empty-description="projectListEmptyDescription"
          :project-total-count="(projectList || []).length"
          :project-sort-by="projectListSortBy"
          :project-sort-options="projectListSortOptions"
          :card-material-count="projectCardMaterialCount"
          :card-analysis-result-count="projectCardAnalysisResultCount"
          :card-template-count="projectCardTemplateCount"
          :card-task-count="projectCardTaskCount"
          @update:project-list-search="projectListSearch = $event"
          @update:project-list-scope="projectListScope = $event"
          @update:project-sort-by="projectListSortBy = $event"
          @clear-search="projectListSearch = ''"
          @create-space="openNewProjectModal && openNewProjectModal()"
          @open-detail="goToProjectDetail"
          @open-workbench="goToWorkbenchFromList"
          @card-menu="(info, p) => onProjectCardMoreMenu(info, p)"
        />

        <a-modal v-model:open="analysisTemplateModalVisible" title="引用技能" width="960" wrapClassName="modal-w-960">
          <ProjectTemplatePickerPanel
            v-model:search-keyword="analysisTemplateSearchKeyword"
            :templates="filteredTemplatePool"
            @quote="quoteTemplateToProject"
          />
          <template #footer>
            <div class="ds-modal-footer-end"><a-button @click="analysisTemplateModalVisible = false">关闭</a-button></div>
          </template>
        </a-modal>

        <a-modal v-model:open="uploadMaterialVisible" title="上传资料" width="760" wrapClassName="modal-w-760" @cancel="uploadMaterialParentFolderId = null">
          <a-upload-dragger :multiple="true" :before-upload="beforeUploadMaterial" :file-list="uploadMaterialBatch" @remove="removeUploadMaterial">
            <p class="ant-upload-drag-icon"><ds-icon name="file-arrow-up" /></p>
            <p class="ant-upload-text">拖拽文件到此处，或点击上传</p>
            <p class="ant-upload-hint">支持 pdf/word/excel/png，单文件不超过 50MB</p>
          </a-upload-dragger>
          <template #footer>
            <div class="ds-modal-footer-end">
              <a-space>
                <a-button @click="uploadMaterialVisible = false; uploadMaterialParentFolderId = null">取消</a-button>
                <a-button type="primary" @click="submitUploadMaterials">确认上传</a-button>
              </a-space>
            </div>
          </template>
        </a-modal>

        <a-modal v-model:open="projectEditVisible" title="编辑工作台" width="640" wrapClassName="modal-w-640" @cancel="cancelProjectEdit">
          <a-form layout="vertical">
            <a-form-item label="工作台名称"><a-input v-model:value="projectEditForm.name" allow-clear /></a-form-item>
            <a-form-item label="工作台简介"><a-textarea v-model:value="projectEditForm.description" :rows="3" /></a-form-item>
          </a-form>
          <template #footer>
            <div class="ds-modal-footer-end">
              <a-button
                :type="projectEditDirty ? 'primary' : 'default'"
                :disabled="!projectEditDirty"
                @click="saveProjectEdit"
              >保存</a-button>
            </div>
          </template>
        </a-modal>
      </div>
    </a-layout>`,
    data() {
      return {
        projectList: DEFAULT_PROJECT_LIST.slice(),
        projectListSearch: '',
        projectListScope: 'mine',
        projectListSortBy: 'created_desc',
        projectIdFromHash: null,
        projectEditVisible: false,
        projectEditForm: { id: '', name: '', description: '' },
        _projectEditSnap: null,
        analysisTemplateModalVisible: false,
        analysisTemplateSearchKeyword: '',
        quoteSkillTargetProjectId: '',
        uploadMaterialVisible: false,
        uploadMaterialBatch: [],
        /** 从审计助手文件夹入口上传时，由 bridge 传入，提交后写入资料 parentId */
        uploadMaterialParentFolderId: null,
      };
    },
    computed: {
      projectListSortOptions() {
        return [
          { value: 'name_asc', label: '按名称（A→Z / 拼音）' },
          { value: 'name_desc', label: '按名称（Z→A / 拼音）' },
          { value: 'created_desc', label: '按创建时间（新→旧）' },
          { value: 'created_asc', label: '按创建时间（旧→新）' },
        ];
      },
      filteredProjectList() {
        const list = this.projectList || [];
        const scopeList = list.filter((p) => (this.projectListScope === 'shared' ? p.visibility === 'shared' : p.visibility !== 'shared'));
        const kw = String(this.projectListSearch || '').trim().toLowerCase();
        const filtered = scopeList.filter((p) => {
          if (!kw) return true;
          return String(p.name || '').toLowerCase().includes(kw) || String(p.description || '').toLowerCase().includes(kw);
        });
        const byName = (a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'zh-CN');
        if (this.projectListSortBy === 'name_asc') return [...filtered].sort(byName);
        if (this.projectListSortBy === 'name_desc') return [...filtered].sort((a, b) => byName(b, a));
        return filtered;
      },
      projectListEmptyDescription() {
        if ((this.projectList || []).length === 0) return '暂无工作台，请先创建。';
        if (String(this.projectListSearch || '').trim()) return '没有符合搜索条件的工作台，请调整关键词。';
        return this.projectListScope === 'shared' ? '暂无共享工作台。' : '暂无我的工作台。';
      },
        filteredTemplatePool() {
          const pool = Array.isArray(demoSharedPrivateAnalysisTemplatePool) ? demoSharedPrivateAnalysisTemplatePool : [];
          const kw = String(this.analysisTemplateSearchKeyword || '').trim().toLowerCase();
          if (!kw) return pool;
          return pool.filter((tpl) => String(tpl.name || '').toLowerCase().includes(kw) || String(tpl.description || '').toLowerCase().includes(kw));
        },
        projectEditDirty() {
          const snap = this._projectEditSnap;
          const f = this.projectEditForm;
          if (!snap || !f || !f.id) return false;
          return (
            String(f.name || '') !== String(snap.name || '')
            || String(f.description || '') !== String(snap.description || '')
          );
        },
    },
    mounted() {
      const onHashChange = () => {
        this.projectIdFromHash = getProjectIdFromHash();
        if (this.projectIdFromHash) {
          this.goToWorkbenchFromList(this.projectIdFromHash);
          return;
        }
        this.applyPendingNewProject();
      };
      window.addEventListener('hashchange', onHashChange);
      this._projectHashCleanup = () => window.removeEventListener('hashchange', onHashChange);

      this.projectIdFromHash = getProjectIdFromHash();
      if (this.projectIdFromHash) this.goToWorkbenchFromList(this.projectIdFromHash);
      this.applyPendingNewProject();

      window.__demoQuoteSkillBridge = {
        _owner: this,
        /** FreeAuditView 挂载时赋值：资料上传弹窗提交成功后回调 */
        onMaterialsUploaded: null,
        openForWorkbenchProject: (projectId) => {
          if (!projectId) return;
          this.quoteSkillTargetProjectId = String(projectId);
          this.analysisTemplateModalVisible = true;
        },
        openUploadForWorkbenchProject: (projectId, opts) => {
          if (!projectId) return;
          this.projectIdFromHash = String(projectId);
          const pf = opts && opts.parentFolderId != null && String(opts.parentFolderId).trim() !== '' ? String(opts.parentFolderId).trim() : null;
          this.uploadMaterialParentFolderId = pf;
          this.uploadMaterialBatch = [];
          this.uploadMaterialVisible = true;
        },
        openEditForWorkbenchProject: (projectId) => {
          if (!projectId) return;
          const pid = String(projectId);
          const target = (this.projectList || []).find((p) => String(p.id) === pid);
          if (!target) return;
          this.projectEditForm = { id: pid, name: target.name || '', description: target.description || '' };
          this._projectEditSnap = { ...this.projectEditForm };
          this.projectEditVisible = true;
        },
      };
    },
    beforeUnmount() {
      if (this._projectHashCleanup) this._projectHashCleanup();
      if (window.__demoQuoteSkillBridge && window.__demoQuoteSkillBridge._owner === this) window.__demoQuoteSkillBridge = null;
    },
    methods: {
      goToProjectDetail(id) { this.goToWorkbenchFromList(id); },
      goToWorkbenchFromList(projectId) {
        window.location.hash = 'freeaudit?projectId=' + encodeURIComponent(projectId);
        window.dispatchEvent(new HashChangeEvent('hashchange'));
      },
      onProjectCardMoreMenu(info, p) {
        const key = info && info.key;
        if (key === 'edit') {
          this.projectEditForm = { id: p.id, name: p.name || '', description: p.description || '' };
          this._projectEditSnap = { ...this.projectEditForm };
          this.projectEditVisible = true;
          return;
        }
        if (key === 'delete') {
          const dc = window.dsConfirm;
          const run = () => {
            this.projectList = (this.projectList || []).filter((x) => x.id !== p.id);
            message.success('已删除');
          };
          if (!dc || !dc.delete) {
            run();
            return;
          }
          dc.delete({
            subject: '该工作台',
            onOk: run,
          });
        }
      },
      saveProjectEdit() {
        const id = this.projectEditForm.id;
        const name = String(this.projectEditForm.name || '').trim();
        if (!id || !name) {
          message.warning('请填写工作台名称');
          return;
        }
        const i = (this.projectList || []).findIndex((x) => String(x.id) === String(id));
        if (i >= 0) {
          const desc = String(this.projectEditForm.description || '');
          this.projectList.splice(i, 1, { ...this.projectList[i], name, description: desc });
          this._projectEditSnap = { id, name, description: desc };
          message.success('保存成功');
        }
        this.projectEditVisible = false;
      },
      cancelProjectEdit() {
        const snap = this._projectEditSnap;
        if (snap) {
          this.projectEditForm = { id: snap.id, name: snap.name, description: snap.description };
        }
        this.projectEditVisible = false;
      },
      beforeUploadMaterial(file) {
        const uid = file && file.uid ? String(file.uid) : ('upload-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8));
        this.uploadMaterialBatch.push({ uid, name: file.name, size: file.size, type: file.type });
        return false;
      },
      removeUploadMaterial(file) {
        const uid = String(file && file.uid ? file.uid : '');
        this.uploadMaterialBatch = this.uploadMaterialBatch.filter((x) => String(x.uid) !== uid);
      },
      submitUploadMaterials() {
        const pid = String(this.projectIdFromHash || this.quoteSkillTargetProjectId || '');
        if (!pid) {
          message.warning('未定位到工作台');
          return;
        }
        if (!Array.isArray(this.uploadMaterialBatch) || this.uploadMaterialBatch.length === 0) {
          message.warning('请先选择资料');
          return;
        }
        const rows = Array.isArray(demoProjectMaterialsById[pid]) ? demoProjectMaterialsById[pid] : [];
        const parentFolder = this.uploadMaterialParentFolderId ? String(this.uploadMaterialParentFolderId) : null;
        const siblingSortMax = rows.reduce((acc, r) => {
          const same = (r && String(r.parentId || '') === String(parentFolder || ''));
          if (!same) return acc;
          const s = Number(r.sort);
          return Number.isFinite(s) ? Math.max(acc, s) : acc;
        }, 0);
        this.uploadMaterialBatch.forEach((f, idx) => {
          rows.unshift({
            id: 'mat-' + Date.now() + '-' + idx,
            name: f.name || '未命名资料',
            status: 'queued',
            uploadedAt: dayjs().format('YYYY-MM-DD HH:mm'),
            tags: [],
            format: String((f.name || '').split('.').pop() || '').toUpperCase() || 'FILE',
            size: Number(f.size || 0),
            parentId: parentFolder,
            sort: siblingSortMax + idx + 1,
          });
        });
        demoProjectMaterialsById[pid] = rows;
        this.uploadMaterialVisible = false;
        this.uploadMaterialBatch = [];
        this.uploadMaterialParentFolderId = null;
        message.success('已加入上传队列');
        const bridge = typeof window !== 'undefined' ? window.__demoQuoteSkillBridge : null;
        if (bridge && typeof bridge.onMaterialsUploaded === 'function') {
          try {
            bridge.onMaterialsUploaded(pid);
          } catch (_) { /* noop */ }
        }
      },
      quoteTemplateToProject(tpl) {
        const pid = String(this.quoteSkillTargetProjectId || '');
        if (!pid || !tpl) return;
        const rows = Array.isArray(demoProjectAnalysisTemplatesById[pid]) ? demoProjectAnalysisTemplatesById[pid] : [];
        const exists = rows.some((x) => String(x.id) === String(tpl.id));
        if (!exists) rows.unshift({ ...tpl });
        demoProjectAnalysisTemplatesById[pid] = rows;
        this.analysisTemplateModalVisible = false;
        message.success('已引用到当前工作台');
      },
      applyPendingNewProject() {
        const raw = sessionStorage.getItem('pendingNewProject');
        if (!raw) return;
        try {
          const parsed = JSON.parse(raw);
          if (!parsed || !parsed.id) return;
          const exists = (this.projectList || []).some((p) => String(p.id) === String(parsed.id));
          if (!exists) {
            this.projectList.push({
              id: parsed.id,
              name: parsed.name || '未命名工作台',
              description: parsed.description || '',
              visibility: parsed.visibility === 'shared' ? 'shared' : 'private',
              sharedUserIds: Array.isArray(parsed.sharedUserIds) ? parsed.sharedUserIds.slice() : [],
              sharedDeptIds: Array.isArray(parsed.sharedDeptIds) ? parsed.sharedDeptIds.slice() : [],
            });
          }
          if (!Array.isArray(demoProjectMaterialsById[parsed.id])) demoProjectMaterialsById[parsed.id] = [];
          if (typeof demoProjectMaterialFoldersById !== 'undefined' && !Array.isArray(demoProjectMaterialFoldersById[parsed.id])) {
            demoProjectMaterialFoldersById[parsed.id] = [];
          }
          if (!Array.isArray(demoProjectAnalysisTemplatesById[parsed.id])) demoProjectAnalysisTemplatesById[parsed.id] = [];
          if (!Array.isArray(demoProjectAnalysisResultsById[parsed.id])) demoProjectAnalysisResultsById[parsed.id] = [];
          if (typeof demoProjectAnalysisResultFoldersById !== 'undefined' && !Array.isArray(demoProjectAnalysisResultFoldersById[parsed.id])) {
            demoProjectAnalysisResultFoldersById[parsed.id] = [];
          }
          sessionStorage.removeItem('pendingNewProject');
        } catch (_) { /* ignore */ }
      },
      projectCardMaterialCount(projectId) {
        const rows = demoProjectMaterialsById[String(projectId)] || [];
        const total = rows.length;
        const done = rows.filter((r) => String(r.status || '') === 'done').length;
        return done + '/' + total;
      },
      projectCardAnalysisResultCount(projectId) {
        const rows = demoProjectAnalysisResultsById[String(projectId)] || [];
        const done = rows.filter((r) => String(r.status || '') === 'done').length;
        return done;
      },
      projectCardTemplateCount(projectId) {
        const rows = demoProjectAnalysisTemplatesById[String(projectId)] || [];
        return rows.length;
      },
      projectCardTaskCount(projectId) {
        const rows = String(projectId) === 'PRJ-2026-001' ? demoWorkbenchTaskRows : [];
        const visibleRows = rows.filter((r) => r && String(r.taskType || '') !== 'batch-child');
        const completed = visibleRows.filter((r) => ['done', 'failed'].includes(String(r.status || ''))).length;
        return completed + '/' + visibleRows.length;
      },
    },
  });
})();
