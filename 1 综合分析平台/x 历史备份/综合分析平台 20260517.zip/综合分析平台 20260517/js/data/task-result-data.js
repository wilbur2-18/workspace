(function registerDemoTaskResultData(global) {
  global.DemoTaskResultData = {
    workbenchTaskRows: typeof demoWorkbenchTaskRows !== 'undefined' ? demoWorkbenchTaskRows : [],
    analysisResultsByProject: typeof demoProjectAnalysisResultsById !== 'undefined' ? demoProjectAnalysisResultsById : {},
    analysisResultFoldersByProject: typeof demoProjectAnalysisResultFoldersById !== 'undefined' ? demoProjectAnalysisResultFoldersById : {},
  };
})(window);
