(function registerDemoMaterialData(global) {
  global.DemoMaterialData = {
    materialFoldersByProject: typeof demoProjectMaterialFoldersById !== 'undefined' ? demoProjectMaterialFoldersById : {},
    materialsByProject: typeof demoProjectMaterialsById !== 'undefined' ? demoProjectMaterialsById : {},
  };
})(window);
