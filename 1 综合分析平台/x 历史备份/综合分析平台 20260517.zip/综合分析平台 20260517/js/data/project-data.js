(function registerDemoProjectData(global) {
  global.DemoProjectData = {
    projects: typeof demoProjectSpaces !== 'undefined' ? demoProjectSpaces : [],
    materialFoldersByProject: typeof demoProjectMaterialFoldersById !== 'undefined' ? demoProjectMaterialFoldersById : {},
    projectAnalysisTemplatesByProject: typeof demoProjectAnalysisTemplatesById !== 'undefined' ? demoProjectAnalysisTemplatesById : {},
  };
})(window);
