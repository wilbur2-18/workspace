(function registerDemoSkillData(global) {
  global.DemoSkillData = {
    skillLibrary: typeof SKILL_LIBRARY !== 'undefined' ? SKILL_LIBRARY : {},
    publicSkillSeeds: typeof SKILL_SEED_PUBLIC !== 'undefined' ? SKILL_SEED_PUBLIC : [],
    privateSkillSeeds: typeof SKILL_SEED_PRIVATE !== 'undefined' ? SKILL_SEED_PRIVATE : [],
    sharedPrivateAnalysisTemplates: typeof demoSharedPrivateAnalysisTemplatePool !== 'undefined' ? demoSharedPrivateAnalysisTemplatePool : [],
  };
})(window);
