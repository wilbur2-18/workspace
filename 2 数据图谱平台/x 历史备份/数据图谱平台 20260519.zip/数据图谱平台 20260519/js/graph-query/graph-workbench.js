(function () {
  const app = window.__DGP_COMPONENT_APP;
  const layoutMixin = window.DGP_WORKBENCH_LAYOUT || {};

  app.component('GraphWorkbenchView', {
    mixins: [layoutMixin],
    props: {
      graph: { type: Object, required: true },
      history: { type: Array, required: true },
      result: { type: Object, required: true },
      querySummary: { type: String, required: true },
      activeHistoryId: { type: String, default: '' },
    },
    emits: ['open-quick-query-modal', 'open-template-query', 'go-home', 'select-history'],
    data() {
      return {
        viewMode: 'canvas',
        rightPanel: 'detail',
        selectedType: 'node',
        selectedId: 'n1',
        hiddenNodeIds: [],
        historyFilter: '',
        layoutKind: 'center',
        assistantInput: '',
        assistantMessages: [{ role: 'assistant', text: '可以直接问：张明与王伟之间是否存在最短路径？' }],
        rightPanelOptions: [
          { label: '详情', value: 'detail' },
          { label: '显示', value: 'display' },
          { label: '分析', value: 'analysis' },
          { label: '助手', value: 'assistant' },
        ],
      };
    },
    computed: {
      graphHistory() {
        const q = this.historyFilter.trim().toLowerCase();
        const list = this.history
          .filter((h) => h.baseId === this.graph.id)
          .filter((h) => {
            if (!q) return true;
            return [h.name, h.mode, h.updated].some((v) => String(v || '').toLowerCase().includes(q));
          });
        list.sort((a, b) => {
          const ta = Date.parse(String(a.updated).replace(/-/g, '/')) || 0;
          const tb = Date.parse(String(b.updated).replace(/-/g, '/')) || 0;
          return tb - ta;
        });
        return list;
      },
      workbenchTitle() {
        return (this.graph.name || '') + ' / ' + (this.result.name || '');
      },
      selectedNode() {
        return this.result.nodes.find((n) => n.id === this.selectedId) || this.result.nodes[0];
      },
      selectedEdge() {
        return this.result.edges.find((e) => e.id === this.selectedId) || this.result.edges[0];
      },
      selectedObject() {
        return this.selectedType === 'edge' ? this.selectedEdge : this.selectedNode;
      },
      visibleNodes() {
        return this.result.nodes.filter((n) => !this.hiddenNodeIds.includes(n.id));
      },
      visibleNodeIds() {
        return new Set(this.visibleNodes.map((n) => n.id));
      },
      visibleEdges() {
        return this.result.edges.filter((e) => this.visibleNodeIds.has(e.from) && this.visibleNodeIds.has(e.to));
      },
      nodeRows() {
        return this.visibleNodes.map((n) => ({ key: n.id, id: n.id, label: n.label, type: n.type, props: n.props }));
      },
      edgeRows() {
        return this.visibleEdges.map((e) => ({
          key: e.id,
          id: e.id,
          type: e.type,
          from: this.nodeLabel(e.from),
          to: this.nodeLabel(e.to),
          amount: e.amount,
        }));
      },
      nodeColumns() {
        return [
          { title: '名称', dataIndex: 'label' },
          { title: '类型', dataIndex: 'type' },
          { title: 'ID', dataIndex: 'id' },
        ];
      },
      edgeColumns() {
        return [
          { title: '关系', dataIndex: 'type' },
          { title: '起点', dataIndex: 'from' },
          { title: '终点', dataIndex: 'to' },
        ];
      },
    },
    watch: {
      result: {
        immediate: true,
        handler(next) {
          if (!next || !next.nodes || !next.nodes.length) return;
          if (!next.nodes.some((n) => n.id === this.selectedId)) {
            this.selectedId = next.nodes[0].id;
            this.selectedType = 'node';
          }
        },
      },
    },
    methods: {
      toast(text) {
        antd.message.info(text);
      },
      nodeById(id) {
        return this.result.nodes.find((n) => n.id === id) || {};
      },
      nodeLabel(id) {
        return this.nodeById(id).label || id;
      },
      selectNode(n) {
        this.selectedType = 'node';
        this.selectedId = n.id;
        this.rightPanel = 'detail';
      },
      selectEdge(e) {
        this.selectedType = 'edge';
        this.selectedId = e.id;
        this.rightPanel = 'detail';
      },
      hideSelected() {
        if (this.selectedType === 'node' && !this.hiddenNodeIds.includes(this.selectedId)) {
          this.hiddenNodeIds.push(this.selectedId);
        }
      },
      expandSelected() {
        this.toast('已基于当前节点拓展 1 跳关系');
      },
      sendAssistant() {
        if (!this.assistantInput.trim()) return;
        this.assistantMessages.push({ role: 'user', text: this.assistantInput });
        this.assistantMessages.push({ role: 'assistant', text: '已识别为图谱查询意图，可生成查询条件并落到当前小图。' });
        this.assistantInput = '';
      },
      nodeRow(record) {
        return { onClick: () => this.selectNode(this.result.nodes.find((n) => n.id === record.id)) };
      },
      edgeRow(record) {
        return { onClick: () => this.selectEdge(this.result.edges.find((e) => e.id === record.id)) };
      },
      formatHistoryUpdated(value) {
        const raw = String(value || '').trim();
        if (!raw) return '—';
        return raw.split(/\s+/)[0] || raw;
      },
      onHistoryClick(h) {
        this.$emit('select-history', h);
      },
      onNewQueryMenuClick({ key }) {
        if (key === 'quick') {
          this.$emit('open-quick-query-modal', { graph: this.graph });
          return;
        }
        if (key === 'template') {
          this.$emit('open-template-query');
        }
      },
    },
    template: `
      <section class="graph-canvas-view shell-main-flex-col">
        <header class="workbench-top-header workbench-top-header--unified workbench-top-header--project-detail">
          <div class="workbench-top-header__left workbench-top-header__left--with-pane-toggle">
            <a-button type="text" class="ds-icon-btn workbench-back-text-btn" title="返回图谱查询" aria-label="返回图谱查询" @click="$emit('go-home')">
              <svg class="iconpark-icon workbench-back-icon"><use href="#arrow-left"></use></svg>
            </a-button>
            <a-button
              type="text"
              class="ds-icon-btn workbench-left-pane-toggle-btn"
              :title="sourcesCollapsed ? '展开左栏（历史查询）' : '收起左栏（历史查询）'"
              :aria-label="sourcesCollapsed ? '展开左栏' : '收起左栏'"
              :aria-expanded="sourcesCollapsed ? 'false' : 'true'"
              @click="toggleSourcesCollapsed"
            >
              <svg class="iconpark-icon workbench-left-pane-toggle-icon" aria-hidden="true"><use href="#left-bar"></use></svg>
            </a-button>
          </div>
          <div class="workbench-top-header__center-title-wrap">
            <div class="workbench-top-header__title-with-mode">
              <div class="workbench-top-header__title-cluster">
                <span class="workbench-top-header__title-kicker" aria-label="图谱查询" title="图谱查询">
                  <span class="ds-page-hero__title-icon ds-page-hero__title-icon--audit-space" aria-hidden="true">
                    <svg class="iconpark-icon"><use href="#map-draw"></use></svg>
                  </span>
                </span>
                <span class="workbench-top-header__title-name" :title="'图谱画布 · ' + workbenchTitle">{{ workbenchTitle }}</span>
              </div>
            </div>
          </div>
          <div class="workbench-top-header__actions graph-wb-header-actions">
            <span class="graph-wb-header-stat">
              <svg class="iconpark-icon" aria-hidden="true"><use href="#avatar"></use></svg>
              {{ visibleNodes.length }} 个节点
            </span>
            <span class="graph-wb-header-stat">
              <svg class="iconpark-icon" aria-hidden="true"><use href="#connection-point-two"></use></svg>
              {{ visibleEdges.length }} 条关系
            </span>
          </div>
        </header>

        <div ref="mainBody" class="workbench-body">
          <aside class="workbench-rail workbench-rail--sources" :style="leftWorkbenchRailStyle">
            <div v-show="!sourcesCollapsed" class="nlm-side-panel graph-wb-side-panel graph-wb-history-panel">
              <div class="nlm-panel-header graph-wb-history-panel__header">
                <div class="graph-wb-panel-title-row">
                  <div class="graph-wb-history-panel__title-block">
                    <strong class="graph-wb-history-panel__title">历史查询</strong>
                    <span class="graph-wb-history-panel__hint">切换小图或新建查询</span>
                  </div>
                  <a-dropdown :trigger="['click']">
                    <a-button size="small" type="primary">新建查询</a-button>
                    <template #overlay>
                      <a-menu @click="onNewQueryMenuClick">
                        <a-menu-item key="quick">快捷查询</a-menu-item>
                        <a-menu-item key="template">模板查询</a-menu-item>
                      </a-menu>
                    </template>
                  </a-dropdown>
                </div>
              </div>
              <div class="nlm-side-panel-body graph-wb-side-panel-body graph-wb-history-panel__body">
                <a-input
                  v-model:value="historyFilter"
                  size="small"
                  allow-clear
                  placeholder="搜索历史"
                  aria-label="搜索历史查询"
                  class="ds-input-inline-search ds-input-inline-search--compact"
                >
                  <template #prefix><ds-icon name="search" class="ds-input-inline-search__icon" aria-hidden="true" /></template>
                </a-input>
                <div v-if="graphHistory.length" class="graph-query-history-list graph-wb-history-panel__list">
                  <button
                    v-for="h in graphHistory"
                    :key="h.id"
                    type="button"
                    class="graph-query-history-row"
                    :class="{ 'is-active': activeHistoryId === h.id }"
                    :aria-label="'切换历史小图：' + h.name + (h.updated ? '，更新于 ' + formatHistoryUpdated(h.updated) : '')"
                    @click="onHistoryClick(h)"
                  >
                    <span class="graph-query-history-row__content">
                      <svg class="iconpark-icon graph-query-history-row__graph-icon" aria-hidden="true"><use href="#map-draw"></use></svg>
                      <span class="graph-query-history-row__text">
                        <span class="graph-query-history-row__name">{{ h.name }}</span>
                        <span class="graph-query-history-row__mode">{{ h.mode }}</span>
                      </span>
                    </span>
                    <span class="graph-query-history-row__aside">
                      <span v-if="activeHistoryId === h.id" class="graph-query-history-row__badge">当前</span>
                      <time
                        v-else-if="h.updated"
                        class="graph-query-history-row__date"
                        :datetime="String(h.updated).replace(' ', 'T')"
                      >{{ formatHistoryUpdated(h.updated) }}</time>
                    </span>
                  </button>
                </div>
                <div v-else class="graph-wb-history-panel__empty">
                  <a-empty :description="historyFilter ? '未找到匹配历史' : '暂无历史查询，可新建查询'" />
                </div>
              </div>
            </div>
          </aside>

          <div
            v-show="!sourcesCollapsed"
            class="nlm-resizer"
            role="separator"
            aria-orientation="vertical"
            title="调整左栏宽度"
            @mousedown.stop.prevent="beginResize('sources', $event)"
          ></div>

          <main class="graph-wb-center-panel nlm-assistant-column">
            <div class="graph-canvas-wrap">
              <div class="graph-canvas-stage">
                <div class="graph-canvas-floating-toolbar" aria-label="画布工具栏">
                  <div class="graph-canvas-toolbar-group">
                    <a-button size="small" type="text" class="graph-canvas-tool-btn" title="选择">
                      <ds-icon name="check" aria-hidden="true" />
                    </a-button>
                    <a-button size="small" type="text" class="graph-canvas-tool-btn" title="拖拽画布">
                      <ds-icon name="table-columns" aria-hidden="true" />
                    </a-button>
                    <a-button size="small" type="text" class="graph-canvas-tool-btn" title="撤销" @click="toast('已撤销上一步操作')">
                      <ds-icon name="arrow-rotate-left" aria-hidden="true" />
                    </a-button>
                    <a-button size="small" type="text" class="graph-canvas-tool-btn" title="重做" @click="toast('已重做操作')">
                      <ds-icon name="refresh" aria-hidden="true" />
                    </a-button>
                  </div>
                  <div class="graph-canvas-toolbar-group">
                    <a-segmented
                      v-model:value="viewMode"
                      size="small"
                      class="ds-ant-segmented ds-ant-segmented--compact"
                      :options="[{ label: '画布', value: 'canvas' }, { label: '列表', value: 'list' }]"
                    />
                    <a-button size="small" @click="layoutKind = layoutKind === 'center' ? 'community' : 'center'">
                      {{ layoutKind === 'center' ? '中心布局' : '社区布局' }}
                    </a-button>
                    <a-button size="small" @click="toast('已自动布局')">自动布局</a-button>
                  </div>
                  <div class="graph-canvas-toolbar-group">
                    <a-button size="small" type="text" class="graph-canvas-tool-btn" title="居中显示" @click="toast('已居中显示')">
                      <ds-icon name="bullseye" aria-hidden="true" />
                    </a-button>
                    <a-button size="small" type="text" class="graph-canvas-tool-btn" title="放大" @click="toast('已放大画布')">
                      <ds-icon name="plus" aria-hidden="true" />
                    </a-button>
                    <a-button size="small" type="text" class="graph-canvas-tool-btn" title="缩小" @click="toast('已缩小画布')">
                      <span class="graph-canvas-tool-text" aria-hidden="true">-</span>
                    </a-button>
                    <a-button size="small" @click="toast('已保存为历史小图')">保存</a-button>
                    <a-button size="small" @click="toast('已准备下载 PNG / Excel / JSON')">导出</a-button>
                  </div>
                </div>

                <div class="graph-canvas-floating-query">
                  <a-button type="primary" size="small" @click="$emit('open-quick-query-modal', { graph })">
                    <ds-icon name="search" aria-hidden="true" />
                    探查工具
                  </a-button>
                  <a-button size="small" @click="$emit('open-template-query')">模板查询</a-button>
                </div>

                <div v-if="viewMode === 'canvas'" class="graph-canvas-stage-inner">
                  <svg class="graph-svg" viewBox="0 0 640 430">
                    <g v-for="e in visibleEdges" :key="e.id" class="graph-edge" :class="{ 'is-selected': selectedType === 'edge' && selectedId === e.id }" @click.stop="selectEdge(e)">
                      <line :x1="nodeById(e.from).cx" :y1="nodeById(e.from).cy" :x2="nodeById(e.to).cx" :y2="nodeById(e.to).cy" stroke="var(--ds-c-danger)" stroke-width="2" />
                      <text :x="(nodeById(e.from).cx + nodeById(e.to).cx) / 2" :y="(nodeById(e.from).cy + nodeById(e.to).cy) / 2 - 5" font-size="11" fill="var(--ds-text-2)" text-anchor="middle">{{ e.type }}</text>
                    </g>
                    <g v-for="n in visibleNodes" :key="n.id" class="graph-node" :class="{ 'is-selected': selectedType === 'node' && selectedId === n.id }" @click.stop="selectNode(n)">
                      <circle :cx="n.cx" :cy="n.cy" :r="n.size" fill="color-mix(in srgb, var(--ds-c-primary) 62%, var(--ds-c-success))" stroke="var(--ds-bg-container)" stroke-width="2" />
                      <text :x="n.cx" :y="n.cy + n.size + 15" font-size="12" fill="var(--ds-text-1)" text-anchor="middle">{{ n.label }}</text>
                    </g>
                  </svg>
                </div>
                <div v-else class="graph-list-mode">
                  <a-tabs>
                    <a-tab-pane key="nodes" tab="节点列表">
                      <a-table size="small" :columns="nodeColumns" :data-source="nodeRows" :pagination="false" @row="nodeRow" />
                    </a-tab-pane>
                    <a-tab-pane key="edges" tab="关系列表">
                      <a-table size="small" :columns="edgeColumns" :data-source="edgeRows" :pagination="false" @row="edgeRow" />
                    </a-tab-pane>
                  </a-tabs>
                </div>

                <section class="graph-canvas-floating-inspector" aria-label="画布检查器">
                  <a-segmented
                    v-model:value="rightPanel"
                    class="ds-ant-segmented ds-ant-segmented--compact nlm-pool-tab-bar"
                    size="small"
                    :options="rightPanelOptions"
                    aria-label="右侧面板"
                  />
                  <div class="graph-canvas-inspector-body">
                    <template v-if="rightPanel === 'detail'">
                      <div class="graph-object-panel-title">{{ selectedType === 'edge' ? '关系详情' : '节点详情' }}：{{ selectedObject.label || selectedObject.type }}</div>
                      <table class="graph-prop-table">
                        <tbody>
                          <tr><th>ID</th><td>{{ selectedObject.id }}</td></tr>
                          <tr v-for="(v, k) in selectedObject.props" :key="k"><th>{{ k }}</th><td>{{ v }}</td></tr>
                        </tbody>
                      </table>
                    </template>
                    <template v-else-if="rightPanel === 'display'">
                      <div class="graph-control-section">
                        <div class="graph-control-title">实体类型</div>
                        <a-checkbox checked>人员</a-checkbox>
                        <a-button size="small" block style="margin-top: var(--ds-space-xs);" @click="hiddenNodeIds = []">恢复默认显示</a-button>
                      </div>
                      <div class="graph-control-section">
                        <div class="graph-control-title">关系类型</div>
                        <a-checkbox checked>同事关系</a-checkbox>
                        <a-checkbox checked>上下级关系</a-checkbox>
                      </div>
                      <div class="graph-control-section">
                        <div class="graph-control-title">显示字段</div>
                        <a-radio-group value="type"><a-radio value="type">关系类型</a-radio><a-radio value="amount">金额</a-radio></a-radio-group>
                      </div>
                    </template>
                    <template v-else-if="rightPanel === 'analysis'">
                      <div class="graph-control-section">
                        <div class="graph-control-title">图上分析</div>
                        <a-space direction="vertical" style="width: 100%;">
                          <a-button block @click="toast('已标注直接邻居')">直接邻居标注</a-button>
                          <a-button block @click="toast('请选择第二个节点以计算最短路径')">最短路径</a-button>
                          <a-button block @click="toast('已执行环检测')">环检测</a-button>
                          <a-button block @click="toast('已清除分析样式')">清除样式</a-button>
                        </a-space>
                      </div>
                    </template>
                    <template v-else>
                      <div class="graph-assistant">
                        <div v-for="(m, idx) in assistantMessages" :key="idx" style="margin-bottom: var(--ds-space-xs);">{{ m.text }}</div>
                        <a-input-search v-model:value="assistantInput" placeholder="输入自然语言查询" enter-button="发送" @search="sendAssistant" />
                      </div>
                    </template>
                  </div>
                </section>

                <div class="graph-canvas-context-bar" aria-label="当前对象操作">
                  <span class="graph-canvas-context-bar__label">{{ selectedType === 'edge' ? '已选关系' : '已选节点' }}：{{ selectedObject.label || selectedObject.type }}</span>
                  <a-button size="small" @click="rightPanel = 'detail'">查看详情</a-button>
                  <a-button v-if="selectedType === 'node'" size="small" @click="expandSelected">直接拓展</a-button>
                  <a-button v-if="selectedType === 'node'" size="small" @click="toast('打开条件拓展配置')">条件拓展</a-button>
                  <a-button size="small" @click="hideSelected">隐藏</a-button>
                  <a-button v-if="selectedType === 'node'" size="small" @click="toast('已设为中心节点')">设为中心</a-button>
                  <a-button size="small" @click="rightPanel = 'analysis'">图上分析</a-button>
                  <a-button size="small" danger @click="toast('仅从本次查询结果删除，不删除原始数据')">删除</a-button>
                </div>
              </div>
            </div>
          </main>
        </div>
      </section>
    `,
  });
})();
