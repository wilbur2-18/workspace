(function () {
  const app = window.__DGP_COMPONENT_APP;
  const { compactNumber } = window.DGP_RUNTIME;
  const { buildInitialValues } = window.DGP_TEMPLATE_VARS || {
    buildInitialValues: () => ({}),
  };

  app.component('TemplateQueryModal', {
    props: {
      open: { type: Boolean, required: true },
      graphs: { type: Array, required: true },
      dataTemplates: { type: Array, required: true },
      initialGraph: { type: Object, default: null },
      initialTemplateId: { type: String, default: '' },
    },
    emits: ['update:open', 'finish'],
    data() {
      return {
        step: 0,
        selectedGraphId: '',
        dataTemplateId: '',
        paramValues: {},
      };
    },
    watch: {
      open: {
        immediate: true,
        handler(v) {
          if (!v) return;
          this.selectedGraphId = this.initialGraph?.id || this.graphs[0]?.id || '';
          this.dataTemplateId = this.initialTemplateId || '';
          this.step = 0;
          if (this.initialTemplateId && !this.dataTemplates.some((t) => t.id === this.initialTemplateId)) {
            this.dataTemplateId = this.dataTemplates[0]?.id || '';
          }
          this.resetParamValues();
        },
      },
      dataTemplateId() {
        this.resetParamValues();
      },
    },
    computed: {
      wizardSteps() {
        const steps = [];
        if (!this.initialGraph) steps.push({ key: 'graph', title: '选择图谱' });
        if (!this.initialTemplateId) steps.push({ key: 'template', title: '选择模板' });
        steps.push({ key: 'params', title: '填写参数' });
        return steps;
      },
      currentStepKey() {
        return this.wizardSteps[this.step]?.key || 'params';
      },
      selectedGraph() {
        return this.graphs.find((g) => g.id === this.selectedGraphId) || this.graphs[0];
      },
      selectedTemplate() {
        return (
          this.dataTemplates.find((t) => t.id === this.dataTemplateId) ||
          this.dataTemplates[0] ||
          null
        );
      },
      title() {
        if (this.selectedTemplate?.name) return `模板查询 · ${this.selectedTemplate.name}`;
        return '模板查询';
      },
      templateVariables() {
        return this.selectedTemplate?.variables || [];
      },
      isDraftTemplate() {
        return this.selectedTemplate?.status === '草稿';
      },
      canSubmitParams() {
        return this.selectedTemplate && !this.isDraftTemplate;
      },
    },
    template: `
      <a-modal :open="open" :title="title" width="860px" :footer="null" destroy-on-close @cancel="close">
        <a-steps :current="step" size="small" style="margin-bottom: var(--ds-space-m);">
          <a-step v-for="s in wizardSteps" :key="s.key" :title="s.title" />
        </a-steps>

        <div v-show="currentStepKey === 'graph'">
          <div class="graph-wizard-grid">
            <div
              v-for="g in graphs"
              :key="g.id"
              class="graph-choice-card"
              :class="{ 'is-selected': selectedGraphId === g.id }"
              @click="selectedGraphId = g.id"
            >
              <div class="dgp-row-between">
                <strong>{{ g.name }}</strong>
                <a-tag :color="g.permission === 'query' ? 'green' : 'default'">{{ g.permission === 'query' ? '可查询' : '仅查看' }}</a-tag>
              </div>
              <p class="dgp-section-desc">{{ g.desc }}</p>
              <div class="graph-domain-meta"><span>{{ g.region }}</span><span>实体 {{ compactNumber(g.entities) }}</span></div>
            </div>
          </div>
          <div class="dgp-row-between" style="margin-top: var(--ds-space-m);">
            <a-button @click="close">取消</a-button>
            <a-button type="primary" :disabled="!selectedGraphId" @click="nextStep">下一步</a-button>
          </div>
        </div>

        <div v-show="currentStepKey === 'template'">
          <div class="graph-wizard-grid">
            <div
              v-for="t in dataTemplates"
              :key="t.id"
              class="graph-choice-card"
              :class="{ 'is-selected': dataTemplateId === t.id, 'is-disabled': t.status === '草稿' }"
              @click="selectTemplate(t)"
            >
              <div class="dgp-row-between">
                <strong>{{ t.name }}</strong>
                <a-tag :color="t.status === '已发布' ? 'green' : 'default'">{{ t.status }}</a-tag>
              </div>
              <p class="dgp-section-desc">{{ t.desc }}</p>
              <a-tag>{{ t.type }}</a-tag>
            </div>
          </div>
          <div class="dgp-row-between" style="margin-top: var(--ds-space-m);">
            <a-button @click="prevStep">上一步</a-button>
            <a-button type="primary" :disabled="!dataTemplateId" @click="nextStep">下一步</a-button>
          </div>
        </div>

        <div v-show="currentStepKey === 'params'">
          <a-alert
            v-if="selectedTemplate"
            type="info"
            show-icon
            :message="selectedTemplate.name"
            :description="selectedTemplate.desc"
            style="margin-bottom: var(--ds-space-s);"
          />
          <a-alert
            v-if="isDraftTemplate"
            type="warning"
            show-icon
            message="该模板为草稿，暂不可发起查询"
            style="margin-bottom: var(--ds-space-s);"
          />
          <template-variable-form
            ref="variableForm"
            :variables="templateVariables"
            :values="paramValues"
            :disabled="isDraftTemplate"
            @update:values="paramValues = $event"
          />
          <div class="dgp-row-between" style="margin-top: var(--ds-space-m);">
            <a-button v-if="step > 0" @click="prevStep">上一步</a-button>
            <span v-else></span>
            <a-button type="primary" :disabled="!canSubmitParams" @click="submit">提交查询</a-button>
          </div>
        </div>
      </a-modal>
    `,
    methods: {
      compactNumber,
      close() {
        this.$emit('update:open', false);
      },
      resetParamValues() {
        const tpl = this.dataTemplates.find((t) => t.id === this.dataTemplateId);
        this.paramValues = buildInitialValues(tpl?.variables || []);
      },
      selectTemplate(t) {
        if (t.status === '草稿') {
          antd.message.warning('草稿模板暂不可查询');
          return;
        }
        this.dataTemplateId = t.id;
      },
      nextStep() {
        if (this.step < this.wizardSteps.length - 1) this.step += 1;
      },
      prevStep() {
        if (this.step > 0) this.step -= 1;
      },
      submit() {
        const form = this.$refs.variableForm;
        if (form && typeof form.validate === 'function') {
          const { ok, missing } = form.validate();
          if (!ok) {
            const labels = missing.map((v) => v.label).join('、');
            antd.message.warning(`请填写：${labels}`);
            return;
          }
        }
        if (!this.selectedGraph || !this.selectedTemplate) return;
        this.$emit('finish', {
          source: 'template',
          graph: this.selectedGraph,
          template: this.selectedTemplate,
          params: { ...this.paramValues },
        });
        this.close();
      },
    },
  });
})();
