(function () {
  antd.message.config({ top: '24px' });
  window.__DGP_APP.use(antd).mount('#app');
})();
