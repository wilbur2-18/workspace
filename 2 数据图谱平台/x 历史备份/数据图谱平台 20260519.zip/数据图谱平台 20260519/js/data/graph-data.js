(function () {
  const graphs = [
    { id: 'g-audit', tabLabel: '浙江审计', name: '浙江审计关系图谱', desc: '审计项目、人员、单位与资金流的综合关系网络', region: '浙江', permission: 'query', entities: 1280000, relations: 4200000 },
    { id: 'g-finance', tabLabel: '财务审计', name: '财务审计总图', desc: '凭证、科目、供应商、客户与账户关系', region: '财务', permission: 'query', entities: 890000, relations: 2100000 },
    { id: 'g-procurement', tabLabel: '采购审计', name: '政府采购审计图谱', desc: '采购项目、供应商、合同与资金支付链路', region: '浙江', permission: 'query', entities: 640000, relations: 1800000 },
    { id: 'g-company', tabLabel: '工商关联', name: '企业工商关联图谱', desc: '企业、股东、高管、对外投资与控制链', region: '华东', permission: 'view', entities: 5600000, relations: 9800000 },
    { id: 'g-social', tabLabel: '社保任职', name: '社保缴纳与任职图谱', desc: '人员、单位、任职、社保缴纳记录', region: '华东', permission: 'query', entities: 3200000, relations: 5100000 },
  ];

  const basicTemplates = [
    { id: 'entity', name: '实体信息查询', desc: '按实体类型、ID、名称和步数生成初始查询结果。' },
    { id: 'path', name: '路径分析', desc: '指定起点、终点和最大跳数，分析两实体间关联路径。' },
    { id: 'cypher', name: '查询语句', desc: '使用已有查询语句模板发起图谱探查。' },
  ];

  const dataTemplates = [
    {
      id: 'dt-chain',
      name: '主体链路穿透',
      type: '图数据模板',
      status: '已发布',
      desc: '按主体名称拉取多跳关联。',
      variables: [
        { key: 'subjectName', label: '主体名称', type: 'text', required: true, placeholder: '输入企业或人员名称' },
        { key: 'depth', label: '查询层级', type: 'number', required: true, default: 2, min: 1, max: 6 },
        {
          key: 'relationTypes',
          label: '关系类型',
          type: 'multiSelect',
          required: false,
          options: ['投资关系', '任职关系', '交易关系', '资金往来'],
        },
      ],
    },
    {
      id: 'dt-risk',
      name: '风险名单碰撞',
      type: 'API数据模板',
      status: '已发布',
      desc: '与风险名单做交集扩展。',
      variables: [
        { key: 'listName', label: '风险名单', type: 'select', required: true, options: ['名单A', '名单B', '监管黑名单'] },
        { key: 'minScore', label: '最低匹配分', type: 'number', required: true, default: 60, min: 0, max: 100 },
      ],
    },
    {
      id: 'dt-fund',
      name: '资金流向聚类',
      type: '图数据模板',
      status: '草稿',
      desc: '账户级资金流聚类与热点标注。',
      variables: [
        { key: 'accountKeyword', label: '账户关键词', type: 'text', required: true },
        { key: 'windowDays', label: '时间窗口（天）', type: 'number', default: 30, min: 1, max: 365 },
      ],
    },
    {
      id: 'dt-control',
      name: '隐性控制识别',
      type: '图数据模板',
      status: '已发布',
      desc: '通过股权、任职和交易关系识别疑似控制链。',
      variables: [
        { key: 'subjectName', label: '目标主体', type: 'text', required: true },
        { key: 'depth', label: '穿透层级', type: 'number', default: 3, min: 1, max: 8 },
        { key: 'includeTrade', label: '纳入交易关系', type: 'select', options: ['是', '否'], default: '是' },
      ],
    },
    {
      id: 'dt-supplier',
      name: '供应商围标排查',
      type: '图数据模板',
      status: '已发布',
      desc: '按项目和供应商展开投标、合同与人员关联。',
      variables: [
        { key: 'projectName', label: '项目名称', type: 'text', required: true },
        { key: 'supplierName', label: '供应商名称', type: 'text' },
      ],
    },
    {
      id: 'dt-account',
      name: '账户异常往来',
      type: 'API数据模板',
      status: '已发布',
      desc: '按账户和时间窗口识别高频、拆分和回流关系。',
      variables: [
        { key: 'accountId', label: '账户 ID', type: 'text', required: true },
        { key: 'dateRange', label: '时间范围说明', type: 'text', placeholder: '如 2025-01-01 至 2025-06-30' },
      ],
    },
    {
      id: 'dt-project',
      name: '项目资金穿透',
      type: '图数据模板',
      status: '已发布',
      desc: '围绕项目资金拨付、支付、收款路径做多跳穿透。',
      variables: [
        { key: 'projectName', label: '项目名称', type: 'text', required: true },
        { key: 'depth', label: '穿透跳数', type: 'number', default: 4, min: 1, max: 8 },
        { key: 'minAmount', label: '最小金额（万）', type: 'number', default: 10, min: 0 },
        {
          key: 'flowTypes',
          label: '资金流类型',
          type: 'multiSelect',
          options: ['拨付', '支付', '收款', '回流'],
          default: ['拨付', '支付'],
        },
        { key: 'remark', label: '备注条件', type: 'textarea', rows: 2 },
      ],
    },
  ].map((t) => ({
    ...t,
    vars: (t.variables || []).length,
  }));

  const reasoningTemplates = [
    { id: 'rt-control', name: '隐性控制关系推理', model: 'MindJunc-Lite', status: '已保存', desc: '基于股权、任职和交易线索推理隐性控制关系。' },
    { id: 'rt-risk', name: '风险传导推理', model: 'MindJunc-Lite', status: '测试中', desc: '根据路径关系和交易频次识别风险传导链。' },
  ];

  const batchTasks = [
    { id: 'bt-01', name: '主体链路穿透-批次07', type: '数据模板批量执行', status: '已完成', progress: 100, result: '可预览 28 个查询图' },
    { id: 'bt-02', name: '风险传导推理-名单A', type: '推理模板批量执行', status: '运行中', progress: 64, result: '已生成 64 条 JSON 结果' },
  ];

  const history = [
    { id: 'h-a', baseId: 'g-audit', name: '查询图-张明关联关系', mode: '实体信息查询', updated: '2026-05-18 10:22' },
    { id: 'h-b', baseId: 'g-audit', name: '最短路径-张明到王伟', mode: '路径分析', updated: '2026-05-17 18:04' },
    { id: 'h-a-03', baseId: 'g-audit', name: '主体链路-某城投公司', mode: '主体链路穿透', updated: '2026-05-18 09:46' },
    { id: 'h-a-04', baseId: 'g-audit', name: '资金穿透-水利项目A', mode: '项目资金穿透', updated: '2026-05-18 08:55' },
    { id: 'h-a-05', baseId: 'g-audit', name: '人员任职-李华交叉关系', mode: '人员任职交叉', updated: '2026-05-17 16:20' },
    { id: 'h-a-06', baseId: 'g-audit', name: '风险名单-供应商批次02', mode: '风险名单碰撞', updated: '2026-05-17 14:12' },
    { id: 'h-a-07', baseId: 'g-audit', name: '路径分析-经办人到收款账户', mode: '路径分析', updated: '2026-05-17 11:36' },
    { id: 'h-a-08', baseId: 'g-audit', name: '同联系方式-项目联系人聚合', mode: '同联系方式聚合', updated: '2026-05-16 19:28' },
    { id: 'h-a-09', baseId: 'g-audit', name: '隐性控制-供应商A', mode: '隐性控制识别', updated: '2026-05-16 15:42' },
    { id: 'h-a-10', baseId: 'g-audit', name: '补贴对象-名单抽查', mode: '补贴对象关联', updated: '2026-05-16 10:15' },
    { id: 'h-a-11', baseId: 'g-audit', name: '发票关系-工程款样本', mode: '发票交易关系', updated: '2026-05-15 17:31' },
    { id: 'h-a-12', baseId: 'g-audit', name: '资产处置-拍卖链路', mode: '资产处置链路', updated: '2026-05-15 13:09' },
    { id: 'h-a-13', baseId: 'g-audit', name: '黑名单扩散-企业控制人', mode: '黑名单关系扩散', updated: '2026-05-14 18:44' },
    { id: 'h-a-14', baseId: 'g-audit', name: '账户异常-资金回流样本', mode: '账户异常往来', updated: '2026-05-14 10:02' },
    { id: 'h-c', baseId: 'g-finance', name: '模板跑批预览-批次07', mode: '数据模板', updated: '2026-05-16 09:40' },
    { id: 'h-f-02', baseId: 'g-finance', name: '凭证供应商-异常往来', mode: '账户异常往来', updated: '2026-05-15 15:18' },
    { id: 'h-f-03', baseId: 'g-finance', name: '发票关系-供应商A', mode: '发票交易关系', updated: '2026-05-14 12:36' },
    { id: 'h-d', baseId: 'g-social', name: '邻居扩展-人员任职', mode: '实体信息查询', updated: '2026-05-15 11:18' },
    { id: 'h-s-02', baseId: 'g-social', name: '同联系方式-社保单位', mode: '同联系方式聚合', updated: '2026-05-13 17:52' },
    { id: 'h-e', baseId: 'g-procurement', name: '供应商关联-项目A', mode: '路径分析', updated: '2026-05-14 16:30' },
    { id: 'h-p-02', baseId: 'g-procurement', name: '围标排查-采购批次04', mode: '供应商围标排查', updated: '2026-05-13 09:25' },
  ];

  const graphResult = {
    name: '查询图-张明关联关系',
    nodes: [
      { id: 'n1', label: '张明', type: '人员', cx: 260, cy: 170, size: 36, props: { ID: '1', 年龄: '32', 姓名: '张明', 性别: 'M' } },
      { id: 'n2', label: '罗成', type: '人员', cx: 150, cy: 95, size: 18, props: { ID: '2', 姓名: '罗成', 性别: 'M' } },
      { id: 'n3', label: '朱军', type: '人员', cx: 250, cy: 50, size: 18, props: { ID: '3', 姓名: '朱军', 性别: 'M' } },
      { id: 'n4', label: '李华', type: '人员', cx: 105, cy: 205, size: 18, props: { ID: '4', 姓名: '李华', 性别: 'F' } },
      { id: 'n5', label: '王伟', type: '人员', cx: 430, cy: 52, size: 18, props: { ID: '5', 姓名: '王伟', 性别: 'M' } },
      { id: 'n6', label: '赵敏', type: '人员', cx: 378, cy: 110, size: 18, props: { ID: '6', 姓名: '赵敏', 性别: 'F' } },
      { id: 'n7', label: '许静', type: '人员', cx: 515, cy: 50, size: 18, props: { ID: '7', 姓名: '许静', 性别: 'F' } },
      { id: 'n8', label: '高翔', type: '人员', cx: 105, cy: 305, size: 18, props: { ID: '8', 姓名: '高翔' } },
      { id: 'n9', label: '吴刚', type: '人员', cx: 230, cy: 305, size: 18, props: { ID: '9', 姓名: '吴刚' } },
      { id: 'n10', label: '刘强', type: '人员', cx: 355, cy: 305, size: 18, props: { ID: '10', 姓名: '刘强' } },
    ],
    edges: [
      { id: 'e1', from: 'n1', to: 'n2', type: '同事关系', amount: '-', props: { 类型: '同事关系', 来源: '人员关系表' } },
      { id: 'e2', from: 'n3', to: 'n1', type: '同事关系', amount: '-', props: { 类型: '同事关系', 来源: '人员关系表' } },
      { id: 'e3', from: 'n1', to: 'n4', type: '同事关系', amount: '-', props: { 类型: '同事关系', 来源: '人员关系表' } },
      { id: 'e4', from: 'n5', to: 'n6', type: '上下级关系', amount: '-', props: { 类型: '上下级关系', 来源: '组织关系表' } },
    ],
  };

  const graphResultsByHistory = {
    'h-a': graphResult,
    'h-b': {
      name: '最短路径-张明到王伟',
      nodes: [
        { id: 'n1', label: '张明', type: '人员', cx: 120, cy: 215, size: 32, props: { ID: '1', 姓名: '张明' } },
        { id: 'n2', label: '罗成', type: '人员', cx: 240, cy: 150, size: 20, props: { ID: '2', 姓名: '罗成' } },
        { id: 'n5', label: '王伟', type: '人员', cx: 480, cy: 215, size: 32, props: { ID: '5', 姓名: '王伟' } },
      ],
      edges: [
        { id: 'e1', from: 'n1', to: 'n2', type: '同事关系', amount: '-', props: { 类型: '同事关系' } },
        { id: 'ep', from: 'n2', to: 'n5', type: '间接关联', amount: '-', props: { 类型: '路径推断' } },
      ],
    },
    'h-c': {
      name: '模板跑批预览-批次07',
      nodes: [
        { id: 'f1', label: '供应商A', type: '企业', cx: 200, cy: 180, size: 28, props: { 名称: '供应商A' } },
        { id: 'f2', label: '凭证#8821', type: '凭证', cx: 380, cy: 120, size: 22, props: { 金额: '128万' } },
        { id: 'f3', label: '科目-应付', type: '科目', cx: 380, cy: 260, size: 22, props: { 编码: '2202' } },
      ],
      edges: [
        { id: 'fe1', from: 'f1', to: 'f2', type: '开票', amount: '128万', props: {} },
        { id: 'fe2', from: 'f2', to: 'f3', type: '入账', amount: '128万', props: {} },
      ],
    },
    'h-d': {
      name: '邻居扩展-人员任职',
      nodes: [
        { id: 's1', label: '李华', type: '人员', cx: 180, cy: 200, size: 30, props: { 姓名: '李华' } },
        { id: 's2', label: '某科技公司', type: '单位', cx: 400, cy: 140, size: 26, props: { 统一社会信用代码: '9133…' } },
        { id: 's3', label: '社保缴纳', type: '记录', cx: 400, cy: 280, size: 20, props: { 月份: '2026-04' } },
      ],
      edges: [
        { id: 'se1', from: 's1', to: 's2', type: '任职', amount: '-', props: {} },
        { id: 'se2', from: 's1', to: 's3', type: '缴纳', amount: '-', props: {} },
      ],
    },
  };

  function getResultForHistory(historyId) {
    return graphResultsByHistory[historyId] || graphResult;
  }

  window.DGP_DATA = {
    graphs,
    basicTemplates,
    dataTemplates,
    reasoningTemplates,
    batchTasks,
    history,
    graphResult,
    graphResultsByHistory,
    getResultForHistory,
  };
})();
